# Common stuff for compiling a score and parts
# Include this file from the Makefile.
# The Makefile must define:
#	WORK	a file base for score and part files
#	NOTES	a list of .ly files that contain the notes
#	INSTR	a list of instrument names for the part files (WORK is prepended)

.SUFFIXES:
.SUFFIXES:	.ly .pdf .midi .zip .flac

LILYROOT	:= /usr/share/lilypond/lilypond-2.17
LILYPOND	:= $(LILYROOT)/bin/lilypond
LILYFLAGS	:=


.PHONY:	score parts all zip deploy clean

all:	score parts

SCORE	:= $(WORK)-score.ly

PARTS	:= $(INSTR:%=$(WORK)-%.ly)

SCORE_PDF	:= $(SCORE:%.ly=%.pdf)
PARTS_PDF	:= $(PARTS:%.ly=%.pdf)

score:	$(SCORE_PDF)

parts:	$(PARTS_PDF)

%.pdf:	%.ly
	$(LILYPOND) $(LILYFLAGS) $*.ly

.PHONY: convert
convert:
	$(LILYROOT)/bin/convert-ly -e $(wildcard *.ly)

ZIP_PDF	:= $(WORK)-pdf.zip
ZIP_SRC	:= $(WORK)-src.zip

$(WORK)-pdf.zip:	$(SCORE_PDF) $(PARTS_PDF)
	zip $@ $(SCORE_PDF) $(PARTS_PDF)

SRC	+= $(SCORE)
SRC	+= $(PARTS)
SRC	+= $(NOTES)
SRC	+= Makefile
SRC	+= ../../../lilypond.mk

$(WORK)-src.zip:	$(SCORE) $(PARTS) $(NOTES) Makefile
	zip $@ $(SRC)

zip:	$(ZIP_SRC) $(ZIP_PDF)

DEPLOY_HOST	:= flits.cs.vu.nl
DEPLOY_DIR	:= www/sheet-music/$(WORK)

.PHONY: deploy
deploy:
	-rm $(PARTS_PDF) $(SCORE_PDF)
	$(MAKE) $(MFLAGS) LILYFLAGS=-dno-point-and-click parts score
	$(MAKE) $(MFLAGS) $(ZIP_SRC) $(ZIP_PDF)
	chmod a+rX $(PARTS_PDF) $(SCORE_PDF)
	scp $(PARTS_PDF) $(SCORE_PDF) $(DEPLOY_HOST):$(DEPLOY_DIR)
	scp $(ZIP_SRC) $(ZIP_PDF) $(DEPLOY_HOST):$(DEPLOY_DIR)

.PHONY: flac
flac:
	for f in *.midi; do timidity -OF "$$f"; done

clean:
	rm -f $(SCORE_PDF) $(PARTS_PDF) *~

$(SCORE_PDF):	$(NOTES)
$(PARTS_PDF):	$(NOTES)
