\include "bach-49-1.ly"

\paper {
    system-separator-markup = \markup {
	\center-align
	\vcenter \combine
	\beam #4.0 #0.5 #0.96
	\raise #1.4 \beam #4.0 #0.5 #0.96
    }
    % system-separator-markup = \slashSeparator
    two-sided = ##t
    indent = 16
    short-indent = 8
    ragged-last-bottom = ##f
    % system-system-spacing = #'((basic-distance . 4) (minimum-distance . 4) (padding . 1) (stretchability . 60))
    % % system-system-spacing #'basic-distance = #25
    % system-system-spacing #'minimum-distance = #15
    % page-count = 9
}

\include "paged-title.ly"
% \include "title.ly"

\markup\null
\pageBreak


#(set-global-staff-size 11)

mvtIbreaks = {
    s4.*7^"Breaks left in"
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*8
    \break
    s4.*8
    \break
    s4.*8
    \pageBreak

    s4.*7
    \break
    s4.*7
    \break
    s4.*8
    \pageBreak

    s4.*7
    \break
    s4.*7
    \break
    s4.*7
    \pageBreak

    \bar "||"
}

mvtImanuscrBreaks = {
    s4.*12^"Manuscript breaks left in"
    \break
    s4.*12
    \break
    s4.*12
    \break
    s4.*12
    \pageBreak

    s4.*12
    \break
    s4.*12
    \break
    s4.*12
    \break
    s4.*11
    \pageBreak

    s4.*10
    \break
    s4.*11
    \break
    s4.*11
    \break
    s4.*9
    \pageBreak

    s4.*11
    \break
    s4.*12
    \break
    s4.*10
    \break
    s4.*10
    \pageBreak

    s4.*11
    \break
    s4.*11
    \break
    s4.*11
    \break
    s4.*10
    \pageBreak

    s4.*11
    \break
    s4.*10
    \break
    s4.*10
    \break
    s4.*5
    \bar "||"
}


% %{

\score {
    \new StaffGroup <<
	\new Staff <<
	    \commonScore

	    \transpose a c'
		\mvtIobDam

	    \set Staff.instrumentName = "Oboe d'amore"
	    \set Staff.shortInstrumentName = "Ob d'a."

	    % \mvtImanuscrBreaks
	    % \mvtIbreaks
	>>
	\new GrandStaff <<
	    \new Staff <<
		\mvtIvlnI

		\set Staff.instrumentName = "I"
		\set Staff.shortInstrumentName = "I"
	    >>
	    \new Staff <<
		\mvtIvlnII

		\set Staff.instrumentName = "II"
		\set Staff.shortInstrumentName = "II"
	    >>

	    \set GrandStaff.instrumentName = "Violino"
	    \set GrandStaff.shortInstrumentName = "Vln"
	>>
	\new Staff <<
	    \mvtIvla

	    \set Staff.instrumentName = "Viola."
	    \set Staff.shortInstrumentName = "Vla."
	>>
	\new PianoStaff <<
	    \new Staff <<
		% \transpose e d
		    \mvtIorgR

		\set Staff.instrumentName = "Organo obligato"
		\set Staff.shortInstrumentName = "Org"
	    >>
	    \new Staff <<
		% \transpose e d
		    \mvtIorgL

		\set Staff.instrumentName = "Continuo"
		\set Staff.shortInstrumentName = "Cont"
	    >>
	    \set PianoStaff.instrumentName = "e"
	    \set PianoStaff.shortInstrumentName = "e"
	>>
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }
}

\score {
    <<
	\mvtIobDam
	\mvtIvlnI
	\mvtIvlnII
	\mvtIvla
	\mvtIorgR
	\mvtIorgL
    >>

    \midi{ }
}
