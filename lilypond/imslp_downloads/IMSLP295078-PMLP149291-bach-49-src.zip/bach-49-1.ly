\version "2.17.18"

\include "common.ly"

mvtImarks = {
    \commonMusic

    \time 3/8
    \key e \major

    s4.*258
    \once \override Score.RehearsalMark.break-visibility = #end-of-line-visible
    \once \override Score.RehearsalMark.self-alignment-X = #RIGHT
    \once \override Score.RehearsalMark #'direction = #DOWN
    \mark \markup{\bold{D.C.}}
    \bar "||"
}


mvtIobDam = <<
\relative c' {
    \slurDotted
    r8 e8 gis8 | % bar 1
    b8 e,16(  fis16 gis16  a16) | % bar 2
    b8 e8 gis8 | % bar 3
    b8 a16(  gis16 fis16  e16) | % bar 4
    dis16 b16 fis'8 fis8 | % bar 5
    fis8 gis16(  a16 b16  gis16) | % bar 6
    e16 cis16 e8 e8 | % bar 7
    e8 fis16(  gis16 a16  fis16) | % bar 8
    dis8 fis8 dis8 | % bar 9
    b8 dis16( cis b a) | % bar 10
    gis8 b'8 gis8 | % bar 11
    e8 gis16(  fis16 e16  dis16) | % bar 12
    cis8 a'16 gis16 fis16 a16 | % bar 13
    b,8 gis'16 fis16 e16 gis16 | % bar 14
    a,8 fis'16 e16 dis16 fis16 | % bar 15
    b,16( cis16) dis16(  e16 fis16  gis16) | % bar 16
    a16 fis16 gis16 e16 b'8 | % bar 17
    r16 e,16\noBeam fis8 dis8 | % bar 18
    e4 r8 | % bar 19
    R4.*3 | % bar 20
    r8 e,8 gis8 | % bar 23
    b8 e,16(  fis16 gis16  a16) | % bar 24
    b8 e8 gis8 | % bar 25
    b8 a16(  gis16 fis16  e16) | % bar 26
    dis16\p(  e16 fis16 gis16 a16  b16) | % bar 27
    dis,16(   cis16) dis16( e16 fis16 gis16) | % bar 28
    a4 r8 | % bar 29
    r8 \slurSolid b,16\f( a16 gis16 fis16) | % bar 30
    e4 r8 | % bar 31
    r8 cis'16( b16 ais16 gis16) | % bar 32
    fis4 r8 | % bar 33
    r8 dis'16(  cis16 b16  a16) | % bar 34
    gis4 r8 | % bar 35
    r8 e'16(  dis16 cis16  b16) | % bar 36
    ais4 r8 | % bar 37
    R4.*5 | % bar 38
    r8 b,8 dis | % bar 43
    fis8 \slurDotted b,16(  cis16 dis16  e16) | % bar 44
    fis8 b8 dis8 | % bar 45
    fis8 e16(  dis16 cis16  b16) | % bar 46
    ais16 fis16 cis'8 cis8 | % bar 47
    cis8 dis16(  e16 fis16  dis16) | % bar 48
    b16 gis16 b8 b8 | % bar 49
    b8 cis16(  dis16 e16  cis16) | % bar 50
    ais8 cis8 ais8 | % bar 51
    fis8 ais16(  gis16 fis16  e16) | % bar 52
    dis8 fis'8 dis8 | % bar 53
    b8 dis16(  cis16 b16  ais?16) | % bar 54
    gis8 e'16 dis16 cis16 e16 | % bar 55
    fis,8 dis'16 cis16 b16 dis16 | % bar 56
    e,8 cis'16 b16 ais16 cis16 | % bar 57
    fis,16( gis16) ais16( b16 cis16 dis16) | % bar 58
    e16 cis16 dis16 b16 fis'8 | % bar 59
    r16 b,16\noBeam cis8 ais8 | % bar 60
    b8 dis16(  e16 fis16  dis16) | % bar 61
    b16 a16 b16 cis16 dis16 b16 | % bar 62
    gis8 cis16(  dis16 e16  cis16) | % bar 63
    a16 gis16 a16 b16 cis16 a16 | % bar 64
    fis4 r8 | % bar 65
    r8 fis'8\p dis8 | % bar 66
    e4 r8 | % bar 67
    r8 b'8 gis8 ~  | % bar 68
    gis8 fis16 e16 fis8 ~  | % bar 69
    fis8 e16 dis16 e8 | % bar 70
    r8 \slurSolid a16(  gis16 fis16  e16) | % bar 71
    dis16(  cis16 b16 a16 gis16  fis16) | % bar 72
    e4 r8 | % bar 73
    R4.*5 | % bar 74
    r8 e8\f gis8 | % bar 79
    b8 \slurDotted e,16(  fis16 gis16  a16) | % bar 80
    b8 e8 gis8 | % bar 81
    b8 a16(  gis16 fis16  e16) | % bar 82
    dis8 r8 r8 | % bar 83
    R4. | % bar 84
    r8 b8\f dis8 | % bar 85
    fis8 gis16(  fis16 e16  dis16) | % bar 86
    e8 r8 r8 | % bar 87
    R4. | % bar 88
    r8 e8 gis8 | % bar 89
    b4.~ | % bar 90
    b16 gis16(  fis16 e16 dis16  cis16) | % bar 91
    a'4. ~  | % bar 92
    a16 fis16(  e16 dis16 cis16  b16) | % bar 93
    gis'4. ~  | % bar 94
    gis8 e8 cis8 | % bar 95
    fis4. ~  | % bar 96
    fis8 dis8 b8 | % bar 97
    e4. ~  | % bar 98
    e8 cis8 a8 | % bar 99
    fis8 dis'4\trill | % bar 100
    e4.~\p  | % bar 101
    e4.~  | % bar 102
    e4.~ | % bar 103
    e4. | % bar 104
    dis4. ~  | % bar 105
    dis4. | % bar 106
    r8 e,8\f gis8 | % bar 107
    b8 e,16( fis16 gis16 a16) | % bar 108
    b8 e8 gis8 | % bar 109
    b8 a16(  gis16 fis16  e16) | % bar 110
    dis16 b16 fis'8 fis8 | % bar 111
    fis8 gis16(  a16 b16  gis16) | % bar 112
    e16 cis16 e8 e8 | % bar 113
    e8 fis16(  gis16 a16  fis16) | % bar 114
    dis8 fis8 dis8 | % bar 115
    b8 dis16(  cis16 b16  a16) | % bar 116
    gis8 b'8 gis8 | % bar 117
    e8 gis16(  fis16 e16  d16) | % bar 118
    cis8 a'16 gis16 fis16 a16 | % bar 119
    b,8 gis'16 fis16 e16 gis16 | % bar 120
    a,8 fis'16 e16 dis16 fis16 | % bar 121
    b,16( cis16) dis16(  e16 fis16  gis16) | % bar 122
    a16 fis16 gis16 e16 b'8 | % bar 123
    r16 e,16(  gis16 fis16 e16  dis16) | % bar 124
    e8 b8 b8 | % bar 125
    b8 cis16(  dis16 e16  cis16) | % bar 126
    a16 fis16 a8\p a8 | % bar 127
    a8  b16( cis16 dis16  b16) | % bar 128
    gis8 b'8\f gis8 | % bar 129
    e8 gis16(  fis16 e16  d16) | % bar 130
    cis8 cis'8 a8 | % bar 131
    fis8 a16(  gis16 fis16  e16) | % bar 132
    dis16(   cis16) b16(  cis16 dis16  e16) | % bar 133
    fis16(   e16) dis16(  e16 fis16  gis16) | % bar 134
    a16 fis16 gis16 e16 b'8 | % bar 135
    r16 e,16\noBeam fis8 dis8 | % bar 136
    e4\fermata r8 | % bar 137
    R4.*2 | % bar 138
    r8 \slurSolid cis16\f(  b16 a16  gis16) | % bar 140
    fis8 r8 r8 | % bar 141
    R4.*2 | % bar 142
    r8 b16\f( a16 gis16 fis16) | % bar 144
    e8 r8 r8 | % bar 145
    r8 a16\p( gis16 fis16 e16) | % bar 146
    dis8 e8 fis8 | % bar 147
    gis8 r8 r8 | % bar 148
    R4.*7 | % bar 149
    r8 fis16-\parenthesize\f(  e16 d16  cis16) | % bar 156
    b8 r8 r8 | % bar 157
    R4.*2 | % bar 158
    r8 e16-\parenthesize\f(  d16 cis16  b16) | % bar 160
    a8 r8 r8 | % bar 161
    r8 d'16-\parenthesize\p(  cis16 b16  a16) | % bar 162
    gis8 a8 b8 | % bar 163
    cis8 r8 r8 | % bar 164
    R4.*10 | % bar 165
    r8 fis,8\f a | % bar 175
    cis8 \slurDotted fis,16(  gis16 a16  b16) | % bar 176
    cis8 fis8 a8 | % bar 177
    cis8 b16(  a16 gis16  fis16) | % bar 178
    eis8 eis8\p fis8 | % bar 179
    r8 gis8 a8 | % bar 180
    r8 eis8 fis8 | % bar 181
    r8 dis8 eis8 | % bar 182
    r8 fis8\f fis8 | % bar 183
    fis8 gis16(  a16 b16  gis16) | % bar 184
    e16 cis16 e8 e8 | % bar 185
    e8 fis16(  gis16 a16  fis16) | % bar 186
    dis8 dis8\p e8 | % bar 187
    r8 fis8 gis8 | % bar 188
    r8 dis8 e8 | % bar 189
    r8 cis8 dis8 | % bar 190
    r8 e,8\f gis8 | % bar 191
    b8 e,16(  fis16 gis16  a16) | % bar 192
    b8 e8 gis8 | % bar 193
    b8 a16(  gis16 fis16  e16) | % bar 194
    dis4 r8 | % bar 195
    R4.*2 | % bar 196
    r8 b'8\f gis8 | % bar 198
    e8 gis16(  fis16 e16 \once \set suggestAccidentals = ##t d16) | % bar 199
    cis8 r8 r8 | % bar 200
    R4.*2 | % bar 201
    r8 cis'8 a8 | % bar 203
    fis8 a16(  gis16 fis16  e16) | % bar 204
    dis8 fis8 dis8 | % bar 205
    b8 dis16(  cis16 b16  a16) | % bar 206
    gis8 \slurSolid b16(  a16 gis16  fis16) | % bar 207
    e8 r8 r8 | % bar 208
    r8 e'16(  d16 cis16  b16) | % bar 209
    a8 r8 r8 | % bar 210
    r8 fis'16(  e16 dis16  cis16) | % bar 211
    b8 r8 r8 | % bar 212
    R4.*8 | % bar 213
    r8 dis8-\parenthesize\f fisis8 | % bar 221
    ais8 \slurDotted b16(  ais16 gis16  fisis16) | % bar 222
    gis8 r8 r8 | % bar 223
    R4. | % bar 224
    r8 gis,8\f bis8 | % bar 225
    dis8 e16(  dis16 cis16  bis16) | % bar 226
    cis16 \slurSolid gis16(  fis16 e16 dis16 \slurDotted cis16) | % bar 227
    a'4. ~  | % bar 228
    a16 fis16(  e16 d16 cis16  b16) | % bar 229
    gis'4. ~  | % bar 230
    gis8 e8 a8 | % bar 231
    fis4. ~  | % bar 232
    fis8 \slurSolid a16(  gis16 fis16 \slurDotted e16) | % bar 233
    dis8 fis16(  e16 dis16  cis16) | % bar 234
    bis8 r8 r8 | % bar 235
    R4.*2 | % bar 236
    r8 \slurSolid gis'16\f( fis16 e16 dis16) | % bar 238
    cis8 r8 r8 | % bar 239
    R4.*2 | % bar 240
    r8 cis'16(  b16 a16  gis16) | % bar 242
    fis8 r8 r8 | % bar 243
    r8 a16\p( gis16 fis16 e16) | % bar 244
    dis8 e8 fis8 | % bar 245
    gis8 r8 r8 | % bar 246
    R4.*12 | % bar 247
}
\mvtImarks
>>

mvtIvlnI = <<
\relative c' {
    \slurDotted
    r8 e8 gis8 | % bar 1
    b8 e,16(  fis16 gis16  a16) | % bar 2
    b8 e8 gis8 | % bar 3
    b8 a16(  gis16 fis16  e16) | % bar 4
    dis16 b16 fis'8 fis8 | % bar 5
    fis8 gis16(  a16 b16  gis16) | % bar 6
    e16 cis16 e8 e8 | % bar 7
    e8 fis16(  gis16 a16  fis16) | % bar 8
    dis8 fis8 dis8 | % bar 9
    b8 dis16(  cis16 b16  a16) | % bar 10
    gis8 b'8 gis8 | % bar 11
    e8 gis16(  fis16 e16  dis16) | % bar 12
    cis8 a'16 gis16 fis16 a16 | % bar 13
    b,8 gis'16 fis16 e16 gis16 | % bar 14
    a,8 fis'16 e16 dis16 fis16 | % bar 15
    b,16( cis16) dis16(  e16 fis16  gis16) | % bar 16
    a16 fis16 gis16 e16 b'8 | % bar 17
    r16 e,16\noBeam fis8 dis8 | % bar 18
    e4 r8 | % bar 19
    R4.*3 | % bar 20
    r8 e,8 gis8 | % bar 23
    b8 e,16(  fis16 gis16  a16) | % bar 24
    b8 e8 gis8 | % bar 25
    b8 a16(  gis16 fis16  e16) | % bar 26
    dis16\p( e16 fis16 gis16 a16 b16) | % bar 27
    dis,16( cis16) dis16(  e16 fis16  gis16) | % bar 28
    a4 r8 | % bar 29
    r8 \slurSolid b,16\f(  a16 gis16  fis16) | % bar 30
    e4 r8 | % bar 31
    r8 cis'16(  b16 ais16  gis16) | % bar 32
    fis4 r8 | % bar 33
    r8 dis'16(  cis16 b16  a16) | % bar 34
    gis4 r8 | % bar 35
    r8 e'16(  dis16 cis16  b16) | % bar 36
    ais4 r8 | % bar 37
    R4.*5 | % bar 38
    r8 b,8 dis8 | % bar 43
    fis8 \slurDotted b,16(  cis16 dis16  e16) | % bar 44
    fis8 b8 dis8 | % bar 45
    fis8 e16(  dis16 cis16  b16) | % bar 46
    ais16 fis16 cis'8 cis8 | % bar 47
    cis8 dis16(  e16 fis16  dis16) | % bar 48
    b16 gis16 b8 b8 | % bar 49
    b8 cis16(  dis16 e16  cis16) | % bar 50
    ais8 cis8 ais8 | % bar 51
    fis8 ais16(  gis16 fis16  e16) | % bar 52
    dis8 fis'8 dis8 | % bar 53
    b8 dis16(  cis16 b16  ais?16) | % bar 54
    gis8 e'16 dis16 cis16 e16 | % bar 55
    fis,8 dis'16 cis16 b16 dis16 | % bar 56
    e,8 cis'16 b16 ais16 cis16 | % bar 57
    fis,16( gis16) ais16(  b16 cis16  dis16) | % bar 58
    e16 cis16 dis16 b16 fis'8 | % bar 59
    r16 b,16\noBeam cis8 ais8 | % bar 60
    b8 r8 r8 | % bar 61
    R4.*4 | % bar 62
    r8 fis'8\p dis8 | % bar 66
    e4 r8 | % bar 67
    r8 b'8 gis8 ~  | % bar 68
    gis8 fis16 e16 fis8 ~  | % bar 69
    fis8 e16 dis16 e8 | % bar 70
    r8 \slurSolid a16(  gis16 fis16  e16) | % bar 71
    dis16(  cis16 b16 a16 gis16  fis16) | % bar 72
    e4 r8 | % bar 73
    R4.*5 | % bar 74
    r8 e8\f gis8 | % bar 79
    b8  \slurDotted e,16( fis16 gis16  a16) | % bar 80
    b8 e8 gis8 | % bar 81
    b8 a16(  gis16 fis16  e16) | % bar 82
    dis8 b,8\p dis8 | % bar 83
    fis8 b,16(  cis16 dis16  e16) | % bar 84
    fis8 b8\f dis8 | % bar 85
    fis8 gis16(  fis16 e16  dis16) | % bar 86
    e8 e,8\p gis8 | % bar 87
    b8 e,16( fis16 gis16 a16) | % bar 88
    b8 e8 gis8 | % bar 89
    b4. ~  | % bar 90
    b16 gis16(  fis16 e16 dis16  cis16) | % bar 91
    a'4. ~  | % bar 92
    a16 fis16( e16 dis16 cis16 b16) | % bar 93
    gis'4. ~  | % bar 94
    gis8 e8 cis8 | % bar 95
    fis4. ~  | % bar 96
    fis8 dis8 b8 | % bar 97
    e4. ~  | % bar 98
    e8 cis8 a8 | % bar 99
    fis8 dis'4\trill | % bar 100
    e4.~\p  | % bar 101
    e4.~  | % bar 102
    e4.~ | % bar 103
    e4. | % bar 104
    dis4. ~  | % bar 105
    dis4. | % bar 106
    r8 e,\f gis | % bar 107
    b8 e,16(  fis16 gis16  a16) | % bar 108
    b8 e8 gis8 | % bar 109
    b8 a16( gis fis e) | % bar 110
    dis16 b16 fis'8 fis8 | % bar 111
    fis8 gis16(  a16 b16  gis16) | % bar 112
    e16 cis16 e8 e8 | % bar 113
    e8 fis16(  gis16 a16  fis16) | % bar 114
    dis8 fis8 dis8 | % bar 115
    b8 dis16( cis16 b16 a16) | % bar 116
    gis8 b'8 gis8 | % bar 117
    e8 gis16(  fis16 e16  d16) | % bar 118
    cis8 a'16 gis16 fis16 a16 | % bar 119
    b,8 gis'16 fis16 e16 gis16 | % bar 120
    a,8 fis'16 e16 dis16 fis16 | % bar 121
    b,16( cis16) dis16(  e16 fis16  gis16) | % bar 122
    a16 fis16 gis16 e16 b'8 | % bar 123
    r16 e,16(  gis16 fis16 e16  dis16) | % bar 124
    e8 b8 b8 | % bar 125
    b8 cis16(  dis16 e16  cis16) | % bar 126
    a16 fis16 a8\p a8 | % bar 127
    a8 b16(  cis16 dis16  b16) | % bar 128
    gis8 b'8\f gis8 | % bar 129
    e8 gis16(  fis16 e16  d16) | % bar 130
    cis8 cis'8 a8 | % bar 131
    fis8 a16(  gis16 fis16  e16) | % bar 132
    dis16( cis16) b16(  cis16 dis16  e16) | % bar 133
    fis16(  e16)  dis16(  e16 fis16  gis16) | % bar 134
    a16 fis16 gis16 e16 b'8 | % bar 135
    r16 e,16\noBeam fis8 dis8 | % bar 136
    e4\fermata r8 | % bar 137
    R4.*2 | % bar 138
    r8 \slurSolid cis16\f(  b16 a16  gis16) | % bar 140
    fis8 r8 r8 | % bar 141
    R4.*2 | % bar 142
    r8 b16\f( a16 gis16 fis16) | % bar 144
    e8 r r8 | % bar 145
    r8 a16\p(  gis16 fis16  e16) | % bar 146
    dis8 e8 fis8 | % bar 147
    gis8 r8 r8 | % bar 148
    R4.*7 | % bar 149
    r8 fis16-\parenthesize\f(  e16 d16  cis16) | % bar 156
    b8 r8 r8 | % bar 157
    R4.*2 | % bar 158
    r8 e16-\parenthesize\f(  d16 cis16  b16) | % bar 160
    a8 r8 r8 | % bar 161
    r8 d'16-\parenthesize\p( cis16 b16 a16) | % bar 162
    gis8 a8 b8 | % bar 163
    cis8 r8 r8 | % bar 164
    R4.*10 | % bar 165
    r8 fis,\f a | % bar 175
    cis8  \slurDotted fis,16( gis16 a16  b16) | % bar 176
    cis8 fis8 a8 | % bar 177
    cis8 b16(  a16 gis16  fis16) | % bar 178
    eis8 eis8\p fis8 | % bar 179
    r8 gis8 a8 | % bar 180
    r8 eis8 fis8 | % bar 181
    r8 dis8 eis8 | % bar 182
    r8 fis8\f fis8 | % bar 183
    fis8 gis16(  a16 b16  gis16) | % bar 184
    e16 cis16 e8 e8 | % bar 185
    e8 fis16(  gis16 a16 fis16) | % bar 186
    dis8 dis8\p e8 | % bar 187
    r8 fis8 gis8 | % bar 188
    r8 dis8 e8 | % bar 189
    r8 cis8 dis8 | % bar 190
    r8 e,8\f gis8 | % bar 191
    b8 e,16(  fis16 gis16  a16) | % bar 192
    b8 e8 gis8 | % bar 193
    b8 a16(  gis16 fis16  e16) | % bar 194
    dis4 r8 | % bar 195
    R4.*2 | % bar 196
    r8 b'8\f gis8 | % bar 198
    e8 gis16(  fis16 e16 \once \set suggestAccidentals = ##t d16) | % bar 199
    cis8 r8 r8 | % bar 200
    R4.*2 | % bar 201
    r8 cis'8 a8 | % bar 203
    fis8 a16(  gis16 fis16  e16) | % bar 204
    dis8 fis8 dis8 | % bar 205
    b8 dis16(  cis16 b16  a16) | % bar 206
    gis8 \slurSolid b16(  a16 gis16  fis16) | % bar 207
    e8 r8 r8 | % bar 208
    r8 e'16(  d16 cis16  b16) | % bar 209
    a8 r8 r8 | % bar 210
    r8 fis'16(  e16 dis16  cis16) | % bar 211
    b8 r8 r8 | % bar 212
    R4.*6 | % bar 213
    r8 dis,8\p fisis8 | % bar 219
    ais8 \slurDotted dis,16(  eis16 fisis16  gis16) | % bar 220
    ais8 dis8-\parenthesize\f fisis8 | % bar 221
    ais8 \slurDotted b16(  ais16 gis16  fisis16) | % bar 222
    gis8 gis,,8\p bis8 | % bar 223
    dis8 gis,16(  ais16 bis16  cis16) | % bar 224
    dis8 gis8\f bis8 | % bar 225
    dis8 e16(  dis16 cis16  bis16) | % bar 226
    cis16 \slurSolid gis16(  fis16 e16 dis16 \slurDotted cis16) | % bar 227
    a'4. ~  | % bar 228
    a16 fis16(  e16 d16 cis16  b16) | % bar 229
    gis'4. ~  | % bar 230
    gis8 e8 a8 | % bar 231
    fis4. ~  | % bar 232
    fis8 \slurSolid a16(  gis16 fis16 \slurDotted e16) | % bar 233
    dis8 fis16(  e16 dis16  cis16) | % bar 234
    bis8 r8 r8 | % bar 235
    R4.*2 | % bar 236
    r8 \slurSolid gis'16\f(  fis16 e16  dis16) | % bar 238
    cis8 r8 r8 | % bar 239
    R4.*2 | % bar 240
    r8 cis'16(  b16 a16  gis16) | % bar 242
    fis8 r8 r8 | % bar 243
    r8 a16\p( gis16 fis16 e16) | % bar 244
    dis8 e8 fis8 | % bar 245
    gis8 r8 r8 | % bar 246
    R4.*12 | % bar 247
}
\mvtImarks
>>

mvtIvlnII = <<
\relative c' {
    \slurDotted
    r8 b8 e8 | % bar 1
    gis8 b8 e,16( fis16 | % bar 2
    gis16 a16) b8 e16 fis16 | % bar 3
    gis8 e8 cis8 | % bar 4
    b8 dis16 e16 fis16 dis16 | % bar 5
    b8 dis8 b8 | % bar 6
    gis8 cis16 dis16 e16 cis16 | % bar 7
    a8 cis8 a8 | % bar 8
    fis8 dis'8 b8 | % bar 9
    fis8 b8 fis8 | % bar 10
    e16(   dis16) e16(  fis16 gis16  a16) | % bar 11
    b16( cis16) b16(  a16 gis16  fis16) | % bar 12
    e8 dis8 r8 | % bar 13
    e8 b'8 r8 | % bar 14
    a8 cis8 a8 | % bar 15
    fis8 b16(  cis16 dis16  e16) | % bar 16
    fis16 dis16 e16 cis16 dis8 | % bar 17
    r16 b16\noBeam cis8 b8 | % bar 18
    b4 r8 | % bar 19
    R4.*3 | % bar 20
    r8 b,8 e8 | % bar 23
    gis8 b8 e,16(  fis16 | % bar 24
    gis16 a16) b8 e16 fis16 | % bar 25
    gis8 e8 b8 | % bar 26
    b8\p a8 gis8 | % bar 27
    fis16(   gis16) fis16(  e16 dis16  cis16) | % bar 28
    b4 r8 | % bar 29
    r8 \slurSolid gis'16\f(  fis16 e16  dis16) | % bar 30
    cis4 r8 | % bar 31
    r8 ais'16( gis16 fis16 e16) | % bar 32
    dis4 r8 | % bar 33
    r8 b'16(  a16 gis16  fis16) | % bar 34
    e4 r8 | % bar 35
    r8 cis'16( b16 a16 gis16) | % bar 36
    fis4 r8 | % bar 37
    R4.*5 | % bar 38
    r8 dis8 b8 | % bar 43
    dis8 fis8 \slurDotted b,16(  cis16 | % bar 44
    dis16  e16) fis8 b16 cis16 | % bar 45
    dis8 b8 gis8 | % bar 46
    fis8 fis8 cis8 | % bar 47
    dis8 ais'8 ais8 | % bar 48
    gis8 gis8 gis8 | % bar 49
    gis8 gis8 gis8 | % bar 50
    ais8 ais8 ais8 | % bar 51
    cis8 cis8 cis8 | % bar 52
    b8 a?8 a8 | % bar 53
    a8 fis8 b8 | % bar 54
    b8 cis8 cis8 | % bar 55
    cis8 b8 b8 | % bar 56
    b8 gis8 gis8 | % bar 57
    fis8 fis8 fis8 | % bar 58
    cis'8 b8 cis8 | % bar 59
    fis,8 gis8 fis8 | % bar 60
    fis4 r8 | % bar 61
    R4.*4 | % bar 62
    r8 b8\p b8 | % bar 66
    b4 r8 | % bar 67
    r8 e8 e8 | % bar 68
    e8 dis8 r8 | % bar 69
    dis8 cis8 r8 | % bar 70
    r8 \slurSolid cis16( b16 a16 gis16) | % bar 71
    fis16( e16 dis16 cis16) b8 | % bar 72
    e4 r8 | % bar 73
    R4.*5 | % bar 74
    r8 b8\f e8 | % bar 79
    gis8 b8 \slurDotted e,16(  fis16 | % bar 80
    gis16 a16) b8 e16 fis16 | % bar 81
    gis8 e8 cis8 | % bar 82
    b8 dis,8\p b8 | % bar 83
    dis8 b'8 b,16( cis16 | % bar 84
    dis16 e16) fis8\f b16 cis16 | % bar 85
    dis8 b8 b8 | % bar 86
    b8 b,8\p e8 | % bar 87
    gis8 e'8 e,16( fis16 | % bar 88
    gis16 a16) b8 e16 fis16 | % bar 89
    gis4. ~  | % bar 90
    gis4. | % bar 91
    fis4. ~  | % bar 92
    fis4. | % bar 93
    e4. ~  | % bar 94
    e4. | % bar 95
    dis4. | % bar 96
    b4. ~  | % bar 97
    b4. | % bar 98
    a8 r8 r8 | % bar 99
    a8 r8 r8 | % bar 100
    gis4.~\p | % bar 101
    gis4. | % bar 102
    fis4. | % bar 103
    ais4. | % bar 104
    fis4. ~  | % bar 105
    fis4. | % bar 106
    r8 b,8\f e8 | % bar 107
    gis8 b8 e,16(  fis16 | % bar 108
    gis16  a16) b16 cis16 dis16 e16 | % bar 109
    fis8 b,8 ais8 | % bar 110
    b8 b8 dis8 | % bar 111
    dis8 dis8 gis,8 | % bar 112
    cis8 cis8 cis8 | % bar 113
    cis8 cis8 fis,8 | % bar 114
    b8 dis8 b8 | % bar 115
    fis8 b8 fis8 | % bar 116
    e16(   dis16) e16(  fis16 gis16  a16) | % bar 117
    b16(   cis16) b16(  a16 gis16  fis16) | % bar 118
    e8 dis8 r8 | % bar 119
    e8 b' r8 | % bar 120
    a8 a8 b8 | % bar 121
    fis8 fis8 fis8 | % bar 122
    fis8 cis'8 b8 | % bar 123
    b8 e,8 b'8 | % bar 124
    b8 gis16(  a16 b16  gis16) | % bar 125
    e8 gis8 r8 | % bar 126
    r8 fis16\p( gis16 a16 fis16) | % bar 127
    dis8 fis8 r8 | % bar 128
    r8 e16\f(  fis16 gis16  a16) | % bar 129
    b16( cis16) b16(  a16 gis16  fis16) | % bar 130
    e8 fis16(  gis16 a16  b16) | % bar 131
    cis16(   d16) cis16( b16  a16  gis16) | % bar 132
    fis16( e16) dis16(  e16 fis16  gis16)  | % bar 133
    a16(  gis16) fis16(  gis16 a16  b16) | % bar 134
    cis16 dis16 e16 cis16 dis8 | % bar 135
    r16 b16\noBeam cis8 b8 | % bar 136
    b4\fermata r8 | % bar 137
    R4.*2 | % bar 138
    r8 \slurSolid cis16\f(  b16 a16  gis16) | % bar 140
    fis8 r8 r8 | % bar 141
    R4.*2 | % bar 142
    r8 b16\f(  a16 gis16  fis16) | % bar 144
    e8 r8 r8 | % bar 145
    r8 fis16\p(  e16 dis16  cis16) | % bar 146
    bis8 cis8 cis8 | % bar 147
    d8 r8 r8 | % bar 148
    R4.*7 | % bar 149
    r8 fis16-\parenthesize\f(  e16 d16  cis16) | % bar 156
    b8 r8 r8 | % bar 157
    R4.*2 | % bar 158
    r8 e16-\parenthesize\f( d16 cis16 b16) | % bar 160
    a8 r8 r8 | % bar 161
    r8 b'16-\parenthesize\p(  a16 gis16  fis16) | % bar 162
    eis8 fis8 fis8 | % bar 163
    g8 r8 r8 | % bar 164
    R4.*10 | % bar 165
    r8 cis,8\f fis8 | % bar 175
    a8 cis8 \slurDotted fis,16 (  gis16 | % bar 176
    a16 b16) cis8 fis16 gis16 | % bar 177
    a8 fis8 d8 | % bar 178
    cis8 gis8\p a8 | % bar 179
    r8 eis'8 cis8 | % bar 180
    r8 gis'8 cis,8 | % bar 181
    r8 fis8 gis8 | % bar 182
    r8 cis,8\f cis8 | % bar 183
    b16( a16) b16(  cis16 dis16  b16) | % bar 184
    cis8 b8 b8 | % bar 185
    a16( gis16) a16(  b16 cis16  a16) | % bar 186
    b8 fis8\p gis8 | % bar 187
    r8 dis'8 b8 | % bar 188
    r8 fis'8 b,8 | % bar 189
    r8 e8 fis8 | % bar 190
    r8 b,,\f e | % bar 191
    gis8 b8 e,16(  fis16 | % bar 192
    gis16 a16) b8 e16 fis16 | % bar 193
    gis8 e8 cis8 | % bar 194
    b4 r8 | % bar 195
    R4.*2 | % bar 196
    r8 e,16(\f fis16 gis16 a16) | % bar 198
    b16( cis16) b16(  a16 gis16  fis16) | % bar 199
    e8 r8 r8 | % bar 200
    R4.*2 | % bar 201
    r8 fis16(  gis16 a16  b16)  | % bar 203
    cis16( d16) cis16( b16 a16  gis16) | % bar 204
    fis8 dis'8 b8 | % bar 205
    fis8 b8 fis8 | % bar 206
    gis8 \slurSolid gis16(  fis16 e16  dis16) | % bar 207
    e8 r8 r8 | % bar 208
    r8 cis'16(  b16 a16  gis16) | % bar 209
    fis8 r8 r8 | % bar 210
    r8 dis'16(  cis16 b16  a16) | % bar 211
    gis8 r8 r8 | % bar 212
    R4.*6 | % bar 213
    r8 ais,8\p dis8 | % bar 219
    fisis8 dis'8 \slurDotted dis,16(  eis16 | % bar 220
    fisis16 gis16) ais8-\parenthesize\f dis16 eis16 | % bar 221
    fisis8 dis8 dis8 | % bar 222
    dis8 bis,8\p gis8 | % bar 223
    bis8 gis'8 gis,16(  ais16 | % bar 224
    bis16  cis16) dis8\f gis16 ais16 | % bar 225
    bis8 cis8 dis8 | % bar 226
    cis4. ~  | % bar 227
    cis4. | % bar 228
    b4.~ | % bar 229
    b4. | % bar 230
    a4. ~  | % bar 231
    a4. | % bar 232
    gis8 \slurSolid fis16(  e16 dis16 \slurDotted cis16) | % bar 233
    bis8 dis16(  cis16 bis16  ais16) | % bar 234
    gis8 r8 r8 | % bar 235
    R4.*2 | % bar 236
    r8 \slurSolid gis'16\f(  fis16 e16  dis16) | % bar 238
    cis8 r8 r8 | % bar 239
    R4.*2 | % bar 240
    r8 cis'16(  b16 a16  gis16) | % bar 242
    fis8 r8 r8 | % bar 243
    r8 fis16\p(  e16 dis16  cis16) | % bar 244
    bis8 cis8 cis8 | % bar 245
    d8 r8 r8 | % bar 246
    R4.*12 | % bar 247
}
\mvtImarks
>>

mvtIvla = <<
\relative c' {
    \clef C
    \slurDotted
    r8 gis8 b8 | % bar 1
    e8 gis8 b8 | % bar 2
    e,16(  fis16 gis16  a16) b8 | % bar 3
    e,8 a8 cis8 | % bar 4
    fis,8 b,8 cis8 | % bar 5
    dis8 gis8 dis8 | % bar 6
    e8 a,8 b8 | % bar 7
    cis8 fis8 cis8 | % bar 8
    dis8 b16(  cis16 dis16  e16) | % bar 9
    fis16( gis16)  fis16( e16 dis16  cis16) | % bar 10
    b8 gis'8 e8 | % bar 11
    b8 e8 b8 | % bar 12
    cis8 b8 r8 | % bar 13
    b8 cis8 r8 | % bar 14
    cis8 cis8 fis8 | % bar 15
    b8 a16(  gis16 fis16  e16) | % bar 16
    dis8 b8 fis'8 | % bar 17
    r16 e16\noBeam a8 fis8 | % bar 18
    gis4 r8 | % bar 19
    R4.*3 | % bar 20
    r8 gis,8 b8 | % bar 23
    e8 gis8 b8 | % bar 24
    e,16(  fis16 gis16  a16) b8 | % bar 25
    e,8 b'8 gis8 | % bar 26
    fis8\p a8 gis8 | % bar 27
    fis16(   gis16) fis16(  e16 dis16  cis16) | % bar 28
    dis8 e8 fis8 | % bar 29
    b,4 r8 | % bar 30
    gis'8-\parenthesize\p gis8 gis8 | % bar 31
    cis,4 r8 | % bar 32
    ais'8 ais8 ais8 | % bar 33
    dis,4 r8 | % bar 34
    b'8 b8 b8 | % bar 35
    fis4 r8 | % bar 36
    cis'8 ais8 cis8 | % bar 37
    fis,4 r8 | % bar 38
    R4.*4 | % bar 39
    r8 fis,8-\parenthesize\f fis | % bar 43
    b8 dis8 fis8 | % bar 44
    b,16(  cis16 dis16  e16) fis8 | % bar 45
    b,8 e8 gis8 | % bar 46
    cis,8 cis8 cis8 | % bar 47
    fis8 fis8 fis8 | % bar 48
    dis8 dis8 dis8 | % bar 49
    e8 e8 e8 | % bar 50
    e8 cis8 fis8 | % bar 51
    fis8 fis8 fis8 | % bar 52
    fis8 fis8 fis8 | % bar 53
    fis8 fis8 fis8 | % bar 54
    gis8 gis8 gis8 | % bar 55
    fis8 fis8 fis8 | % bar 56
    e8 e16 dis16 cis b | % bar 57
    cis8 cis8 cis8 | % bar 58
    cis8 gis'8 fis8 | % bar 59
    fis8 cis8 e8 | % bar 60
    dis4 r8 | % bar 61
    R4.*4 | % bar 62
    r8 fis8\p fis8 | % bar 66
    gis4 r8 | % bar 67
    r8 b8 b8 | % bar 68
    cis8 cis8 r8 | % bar 69
    b8 b8 r8 | % bar 70
    a,8[ << { b8 cis] } \new Voice { \tiny \stemDown a b } >> | % bar 71
    dis8 e8 fis8 | % bar 72
    b,4 r8 | % bar 73
    R4.*5 | % bar 74
    r8 gis8\f b8 | % bar 79
    e8 gis8 b8 | % bar 80
    e,16(  fis16 gis16  a16) b8 | % bar 81
    e,8 a8 cis8 | % bar 82
    fis,8 fis,8\p fis8 | % bar 83
    b8 dis8 fis8 | % bar 84
    b,16(  cis16 dis16\f  e16) fis8 | % bar 85
    b,8 e8 fis8 | % bar 86
    gis8 gis,8\p b8 | % bar 87
    e8 gis8 b8 | % bar 88
    e,16(  fis16 gis16  a16) b8 | % bar 89
    e,4. ~  | % bar 90
    e4. ~  | % bar 91
    e4. | % bar 92
    dis4. ~  | % bar 93
    dis4. | % bar 94
    cis4. | % bar 95
    b4. ~  | % bar 96
    b4. | % bar 97
    d4. | % bar 98
    cis8 r8 r8 | % bar 99
    fis8 r8 r8 | % bar 100
    cis4.~\p | % bar 101
    cis4.~ | % bar 102
    cis4.~ | % bar 103
    cis4. | % bar 104
    b4. ~  | % bar 105
    b4. | % bar 106
    r8 gis8\f b8 | % bar 107
    e8 gis8 b8 | % bar 108
    e,8 b8 b'8 | % bar 109
    a8 b8 cis8 | % bar 110
    fis,8 fis8 b8 | % bar 111
    b8 b,8 e8 | % bar 112
    gis8 gis8 gis8 | % bar 113
    a8 a8 a8 | % bar 114
    fis8 b,16(  cis16 dis16  e16) | % bar 115
    fis16(   gis16) fis16(  e16 dis16  cis16) | % bar 116
    b8 gis'8 e8 | % bar 117
    b8 e8 b8 | % bar 118
    cis8 b8 r8 | % bar 119
    b8 cis8 r8 | % bar 120
    cis8 cis8 gis'8 | % bar 121
    b8 b8 b8 | % bar 122
    fis8 e8 fis8 | % bar 123
    b,8 cis8 b8 | % bar 124
    b8 e8 e8 | % bar 125
    gis8 e8 r8 | % bar 126
    r8 dis8\p fis8 | % bar 127
    fis8 dis8 r8 | % bar 128
    r8 gis8\f b8 | % bar 129
    b,8 e8 b8 | % bar 130
    cis8 a'8 cis8 | % bar 131
    cis,8 fis8 cis8 | % bar 132
    dis8 fis16(  e16 dis16  cis16) | % bar 133
    b8 a'16(  gis16 fis16  e16) | % bar 134
    dis8 b8 fis'8 | % bar 135
    r16 e16\noBeam a8 fis8 | % bar 136
    gis4\fermata r8 | % bar 137
    R4.*2 | % bar 138
    r8 \slurSolid cis16\f(  b16 a16  gis16) | % bar 140
    fis8 r8 r8 | % bar 141
    R4.*2 | % bar 142
    r8 b16\f( a16  gis16  fis16) | % bar 144
    e8 r8 r8 | % bar 145
    r8 bis16\p(  cis16 dis16  e16) | % bar 146
    fis8 a8 fis8 | % bar 147
    eis8 r8 r8 | % bar 148
    R4.*7 | % bar 149
    r8 fis16-\parenthesize\f(  e16 d16  cis16) | % bar 156
    b8 r8 r8 | % bar 157
    R4.*2 | % bar 158
    r8 e16-\parenthesize\f( d16 cis16 b16) | % bar 160
    a8 r8 r8 | % bar 161
    r8 eis16-\parenthesize\p(  fis16 gis16  a16) | % bar 162
    b8 d8 b8 | % bar 163
    ais8 r8 r8 | % bar 164
    R4.*10 | % bar 165
    r8 a8\f cis8 | % bar 175
    fis8 a8 cis8 | % bar 176
    \slurDotted fis,16(  gis16 a16  b16) cis8 | % bar 177
    fis,8 b8 d8 | % bar 178
    gis,8 cis,8\p r8 | % bar 179
    gis' cis, r8 | % bar 180
    eis8 gis8 r8 | % bar 181
    eis8 cis8 r8 | % bar 182
    r8 fis16\f( gis16 a16 fis16) | % bar 183
    b8 dis,8 b8 | % bar 184
    gis8 e'16(  fis16 gis16  e16) | % bar 185
    a8 cis,8 a8 | % bar 186
    fis8 b8\p r8 | % bar 187
    fis'8 b,8 r8 | % bar 188
    dis8 fis8 r8 | % bar 189
    dis8 b8 r8 | % bar 190
    r8 gis8\f b8 | % bar 191
    e8 gis8 b8 | % bar 192
    e,16(  fis16 gis16  a16) b8 | % bar 193
    e,8 a8 cis8 | % bar 194
    fis,4 r8 | % bar 195
    R4.*2 | % bar 196
    r8 gis8\f e8 | % bar 198
    b8 e8 b8 | % bar 199
    cis8 r8 r8 | % bar 200
    R4.*2 | % bar 201
    r8 a'8 fis8 | % bar 203
    cis8 fis8 cis8 | % bar 204
    dis16( cis16) b16(  cis16 dis16  e16) | % bar 205
    fis16(   gis16) fis16(  e16 dis16  cis16) | % bar 206
    b4 r8 | % bar 207
    b'8 b8 b8 | % bar 208
    e,4 r8 | % bar 209
    cis'8 cis8 cis8 | % bar 210
    fis,4 r8 | % bar 211
    dis'8 dis8 dis8 | % bar 212
    gis,8 r8 r8 | % bar 213
    R4.*5 | % bar 214
    r8 fisis,8\p ais8 | % bar 219
    dis8 fisis8 ais8 | % bar 220
    dis,16(  eis16 fisis16-\parenthesize\f  gis16) ais8 | % bar 221
    dis,8 gis8 ais8 | % bar 222
    gis8 dis,8\p dis8 | % bar 223
    gis8 bis8 dis8 | % bar 224
    gis,16(  ais16 bis16\f  cis16) dis8 | % bar 225
    gis4. ~  | % bar 226
    gis4. | % bar 227
    fis4. ~  | % bar 228
    fis4. | % bar 229
    e4. ~  | % bar 230
    e4 fis8 | % bar 231
    a,8 gis8 fis8 | % bar 232
    dis'8 cis8 r8 | % bar 233
    fis8 gis8 r8 | % bar 234
    gis8 r8 r8 | % bar 235
    R4.*2 | % bar 236
    r8 \slurSolid gis16\f(  fis16 e16  dis16) | % bar 238
    cis8 r8 r8 | % bar 239
    R4.*2 | % bar 240
    r8 cis'16(  b16 a16  gis16) | % bar 242
    fis8 r8 r8 | % bar 243
    r8 bis,16\p(  cis16 dis16  e16) | % bar 244
    fis8 a8 fis8 | % bar 245
    eis8 r8 r8 | % bar 246
    R4.*12 | % bar 247
}
\mvtImarks
>>

mvtIorgR = <<
\relative c'' {
    R4.*18 | % bar 1
    b16(  cis16 dis16 e16 fis16  gis16) | % bar 19
    a,16 gis16 a8 fis'8 ~  | % bar 20
    fis16 e16 dis16 cis16 b16 a16 | % bar 21
    gis16 fis16 e16 fis16 gis16 a16 | % bar 22
    b8 b8 b8 | % bar 23
    b8 b8 b8 | % bar 24
    b8 b8 b8 | % bar 25
    b8 b8 b8 | % bar 26
    \slurDotted b16(  cis16 dis16 e16 fis16 \slurSolid gis16) | % bar 27
    a,16 gis16 a8 fis'8 ~  | % bar 28
    fis16 e16 dis16 cis16 b16 a16 | % bar 29
    gis16 e16 gis16 b16 cis8 ~  | % bar 30
    cis16 dis16 e16 cis16 gis16 b16 | % bar 31
    ais16 fis16 ais16 cis16 dis8 ~  | % bar 32
    dis16 e16 fis16 dis16 ais16 cis16 | % bar 33
    b16 gis16 b16 dis16 e8 ~  | % bar 34
    e16 fis16 gis16 e16 b16 dis16 | % bar 35
    cis16 ais16 cis16 e16 fis8 ~  | % bar 36
    fis16 dis16 e16 gis16 fis16 e16 | % bar 37
    dis16 b16 cis16 e16 dis16 cis16 | % bar 38
    b16 gis16 ais16 cis16 b16 ais16 | % bar 39
    gis16 ais16 b16 cis16 dis16 e16 | % bar 40
    ais,16 fis16 ais16 cis16 fis8 | % bar 41
    r16 b,16 dis16 cis16 b16 ais16 | % bar 42
    b4 r8 | % bar 43
    R4.*3 | % bar 44
    r8 \slurDotted fis'16(  gis16 ais16  fis16) | % bar 47
    dis8 dis8 dis8 | % bar 48
    dis8 e16(  fis16 gis16  e16) | % bar 49
    cis8 cis8 cis8 | % bar 50
    cis16 b16 cis16 dis16 e16 cis16 | % bar 51
    ais16 gis16 ais16 b16 cis16 ais16 | % bar 52
    fis16 e16 fis16 gis16 a16 fis16 | % bar 53
    dis16 cis16 dis16 e16 fis16 dis16 | % bar 54
    b8 gis''8 b,8 | % bar 55
    ais8 fis'8 ais,8 | % bar 56
    gis8 e'8 gis,8 | % bar 57
    ais16 b16 cis16 dis16 e16 fis16 | % bar 58
    gis16 ais16 b16 gis16 a16 fis16 | % bar 59
    b8 fis16(  e16 dis16 cis16) | % bar 60
    b8 fis'8 fis8 | % bar 61
    fis8 gis16(  a16 b16  gis16) | % bar 62
    e16 cis16 e8 e8 | % bar 63
    e8 fis16(  gis16 a16  fis16) | % bar 64
    dis16 cis16 b16 cis16 dis16 e16 | % bar 65
    fis16 e16 dis16 cis16 b16 a16 | % bar 66
    gis16 b16 e16 fis16 gis16 a16 | % bar 67
    b16 a16 gis16 fis16 e16 dis16 | % bar 68
    cis16 e16 a16 gis16 fis16 a16 | % bar 69
    b,16 dis16 gis16 fis16 e16 gis16 | % bar 70
    a,4.~ | % bar 71
    a4.~  | % bar 72
    a16 cis16 b16 a16 gis16 d'16 | % bar 73
    cis16 b16 a16 e'16 dis16 cis16 | % bar 74
    b16 fis'16 e16 dis16 cis16 gis'16 | % bar 75
    fis16 e16 dis16 a'16 gis16 fis16 | % bar 76
    e16 b'16 a16 gis16 fis16 e16 | % bar 77
    dis16 cis16 b16 a16 gis16 fis16 | % bar 78
    gis8 e8 gis8 | % bar 79
    b8 e,16(  fis16 gis16  a16) | % bar 80
    b8 e8 gis8 | % bar 81
    b8 a16(  gis16 fis16  e16) | % bar 82
    dis16 b16 dis16 fis16 a16 gis16 | % bar 83
    a4. ~  | % bar 84
    a4. ~  | % bar 85
    a16 fis16(  e16 dis16 cis16  b16) | % bar 86
    gis'16 b16 gis16 e16 d16 cis16 | % bar 87
    d4. ~  | % bar 88
    d4. ~  | % bar 89
    d16 b16(  a16 gis16  fis16 e16) | % bar 90
    cis'4. ~  | % bar 91
    cis16  a16( gis16 fis16 e16  dis16) | % bar 92
    b'4. ~  | % bar 93
    b16 gis16(  fis16 e16 dis16  cis16) | % bar 94
    a'16 gis16 a16 cis16 b16 gis16 | % bar 95
    a16 cis16 b16 a16 gis16 fis16 | % bar 96
    gis16 fis16 gis16 b16 a16 fis16 | % bar 97
    gis16 b16 a16 gis16 fis16 e16 | % bar 98
    cis'16 b16 a16 gis16 fis16 e16 | % bar 99
    dis'16 cis16 b16 a16 gis16 fis16 | % bar 100
    e'8 r8 r8 | % bar 101
    cis8 r8 r8 | % bar 102
    fis,16 gis16 ais16 b16 cis16 dis16 | % bar 103
    e16 dis16 e16 gis16 fis16 e16 | % bar 104
    dis16 cis16 b16 cis16 dis16 e16 | % bar 105
    fis16 gis16 a16 cis16 b16 a16 | % bar 106
    gis16 e16 b'16 a16 gis16 fis16 | % bar 107
    gis16 b,16 gis'16 fis16 e16 dis16 | % bar 108
    e16 b16 a16 gis16 fis16 e16 | % bar 109
    dis'16 e16 e8.-\parenthesize\trill dis32 e32 | % bar 110
    fis8 b,8 r8 | % bar 111
    r8 b'8 b8 | % bar 112
    b16 a16 gis16 fis16 e16 dis16 | % bar 113
    cis16 e16 a8 a8 | % bar 114
    a16 gis16 fis16 e16 dis16 cis16 | % bar 115
    b16 cis16 dis16 cis16 b16 a16 | % bar 116
    gis16 fis16 e16 fis16 gis16 a16 | % bar 117
    b16 cis16 d16 fis16 e16 d16 | % bar 118
    cis16 e16 a8 r8 | % bar 119
    b,16 e16 gis8 r8 | % bar 120
    a,16 b16 a16 gis16 fis16 e16 | % bar 121
    dis16 e16 fis16 gis16 a16 b16 | % bar 122
    cis16 dis16 e16 cis16 dis16 b16 | % bar 123
    e8 b16 a16 gis16 fis16 | % bar 124
    e4 r8 | % bar 125
    R4.*11 | % bar 126
    r8\fermata gis8 ais8 | % bar 137
    b8 bis8 cis8 | % bar 138
    dis8 e8 eis8 | % bar 139
    fis8 a16 gis16 a8 | % bar 140
    r8 fis,8 gis8 | % bar 141
    a8 ais8 b8 | % bar 142
    dis8 d8 dis8 | % bar 143
    e8 gis16 fis16 gis8 | % bar 144
    r16 \slurSolid gis16(  fis16 e16 dis16  cis16) | % bar 145
    bis16 gis'16  dis16( e16 bis16  cis16) | % bar 146
    gis16 gis'16(  fis16 e16 dis16  cis16) | % bar 147
    b16 gis'16  eis16( fis16 d16  cis16) | % bar 148
    a'16 b16( d,16  cis16 b16  a'16) | % bar 149
    gis16 a16( cis,16  b16 a16  gis'16) | % bar 150
    fis16 gis16( b,16  a16 gis16  fis'16) | % bar 151
    eis16 gis16(  fis16 eis16 dis16  cis16) | % bar 152
    r8 cis,8 dis8 | % bar 153
    e8 eis8 fis8 | % bar 154
    gis8 a8 ais8 | % bar 155
    b8 d16 cis16 d8 | % bar 156
    r8 b8 cis8 | % bar 157
    d8 dis8 e8 | % bar 158
    fis8 g8 gis8 | % bar 159
    a8 cis16 b16 cis8 | % bar 160
    r16 cis,16(  b16 a16 gis16  fis16) | % bar 161
    eis16 cis'16(  gis16 a16 eis16  fis16) | % bar 162
    cis16 cis'16(  b16 a16 gis16  fis16) | % bar 163
    e16 cis'16( ais16 b16 g16 fis16) | % bar 164
    e'16 d16 \slurDotted ais16( b16 g'16  \slurSolid e16) | % bar 165
    d16 cis16(  gis16 a16 fis'16  d16) | % bar 166
    cis16 b16(  fis16 g16 e'16  cis16) | % bar 167
    b16 ais16 \slurDotted eis16(  fis16 ais16  e16) | % bar 168
    dis16 fis16 a16 c16 b16 dis16 | % bar 169
    e16 fis16 g16 e16 d16 cis16 | % bar 170
    ais'16 b16 cis16 g16 fis16 e16 | % bar 171
    d16 cis16 b16 a16 gis16 fis16 | % bar 172
    eis'8 r16 cis16 fis8 | % bar 173
    r16 gis16\noBeam gis8. fis16 | % bar 174
    fis4 r8 | % bar 175
    R4.*3 | % bar 176
    r16 \slurSolid cis16(  bis16 cis16 dis16  cis16) | % bar 179
    eis16 cis16(  bis16  cis16) fis16 cis16 | % bar 180
    gis'16 cis,16(  bis16  cis16) a'16 cis,16 | % bar 181
    b'8 a8 gis8 | % bar 182
    a4 r8 | % bar 183
    R4.*3 | % bar 184
    r16 b,16(  ais16 b16 cis16  b16) | % bar 187
    dis16 b16( ais16 b16) e16 b16 | % bar 188
    fis'16 b,16( ais16 b16) gis'16 b,16 | % bar 189
    a'8 gis8 fis8 | % bar 190
    gis4 r8 | % bar 191
    R4.*3 | % bar 192
    \slurDotted b,16(  cis16 dis16 e16 fis16  gis16) | % bar 195
    a,16 gis16 a8 fis'8 ~  | % bar 196
    fis16 e16 dis16 cis16 b16 a16 | % bar 197
    gis8 e8 r8 | % bar 198
    R4. | % bar 199
    cis'16(  dis16 eis16 fis16 gis16  a16) | % bar 200
    b,16 a16 b8 gis'8 ~  | % bar 201
    gis16 fis16 eis16 dis16 cis16 b16 | % bar 202
    a8 fis8 r8 | % bar 203
    R4. | % bar 204
    r8 fis'8 dis8 | % bar 205
    b8 dis16(  cis16 b16  a16) | % bar 206
    gis16 e16 gis16 b16 e8~ | % bar 207
    e16 fis16 gis16 e16 b16 d16 | % bar 208
    cis16 a16 cis16 eis16 fis8  ~  | % bar 209
    fis16 gis16 a16 fis16 cis16 e16 | % bar 210
    dis16 b16 dis16 fis16 gis8 ~  | % bar 211
    gis16 a16 b16 gis16 dis16 fis16 | % bar 212
    e16 a16 b16 cis16 gis16 a16 | % bar 213
    dis,16 gis16 ais16 b16 fisis16 gis16 | % bar 214
    cis,16 fisis16 gis16 ais16 e!16 dis16 | % bar 215
    cis16 ais'16 gis16 fisis16 eis16 dis16 | % bar 216
    b'16 ais16 gis16 fisis16 gis8 ~  | % bar 217
    gis16 b16 ais16 gis16 fisis16 gis16 | % bar 218
    fisis16 gis16 ais8 cis,8 | % bar 219
    cis4.~  | % bar 220
    cis4.~ | % bar 221
    cis16 ais16 gis16 fisis16 eis16 dis16 | % bar 222
    b'16 gis16 bis16 dis16 fis16 e!16 | % bar 223
    fis4. ~  | % bar 224
    fis4. ~  | % bar 225
    fis16 dis16( cis16 bis16 ais16 gis16) | % bar 226
    e'4. ~  | % bar 227
    e16 cis16(  b?16 a!16 gis16  fis16) | % bar 228
    d'4.~ | % bar 229
    d16 b16( a16 gis16 fis16 e16) | % bar 230
    cis'16 b16 cis16 e16 dis16 bis16 | % bar 231
    cis16 fis16 gis16 a16 dis,16 fis16 | % bar 232
    bis,16 dis16 e16 fis16 bis,16 dis16 | % bar 233
    gis,16 bis16 cis16 dis16 fis,16 a!16 | % bar 234
    dis,8 e8 eis8 | % bar 235
    fis8 fisis8 gis8 | % bar 236
    ais8 b8 bis8 | % bar 237
    cis8 e16 dis16 e8 | % bar 238
    r8 gis,8 ais8 | % bar 239
    b8 bis8 cis8 | % bar 240
    dis8 e8 eis8 | % bar 241
    fis8 a16 gis16 a8 | % bar 242
    r16 \slurSolid gis16(  fis16 e16 dis16  cis16) | % bar 243
    bis16 \slurDotted gis'16(  dis16 e16 bis16  cis16) | % bar 244
    gis16 gis'16(  fis16 e16 dis16  cis16) | % bar 245
    b16 \slurSolid gis'16(  eis16 fis16 d16  cis16) | % bar 246
    a'16 fis16 dis16 e16 cis16 b16 | % bar 247
    gis'16 e16 cis16 dis16 b16 ais16 | % bar 248
    fisis'16(  e?16 dis16 cis16 b16  ais16) | % bar 249
    e'16(  cis16 b16 ais16 gis16  fisis16) | % bar 250
    cis'16(  ais16 gis16 fisis16 eis16  dis16) | % bar 251
    ais'16 fisis16 eis16 dis16 e'!8 ~  | % bar 252
    e16 dis16(  cis16 b16 ais16  gis16) | % bar 253
    gis'16 eis16 dis16 cisis16 b'8 ~  | % bar 254
    b16 ais16 gis16 fisis16 gis16 ais16 | % bar 255
    cis,?8 r16 dis b8 | % bar 256
    r16 ais'16\noBeam fisis8. gis16 | % bar 257
    gis4. | % bar 258
}
\mvtImarks
>>

mvtIorgL = <<
\relative c {
    \clef F
    \slurDotted
    r8 e8 e8 | % bar 1
    e8 e8 e8 | % bar 2
    e8 e8 e8 | % bar 3
    e8 cis8 a8 | % bar 4
    b8 b'8 a8 | % bar 5
    gis8 b8 gis8 | % bar 6
    cis8 a8 gis8
    | % bar 7
    fis8 a8 fis8 | % bar 8
    b8 a16(  gis16 fis16  e16) | % bar 9
    dis8 b8 dis8 | % bar 10
    e8 d16(  cis16 b16  a16) | % bar 11
    gis8 e8 gis8 | % bar 12
    a8 fis'8 r8 | % bar 13
    gis,8 e'8 r8 | % bar 14
    fis,8 a'8 fis8 | % bar 15
    dis8 fis16( e16 dis16 cis16) | % bar 16
    b4 a8 | % bar 17
    gis8 a8 b8 | % bar 18
    e,4 r8 | % bar 19
    fis'16(   gis16) fis16(  e16 dis16  cis16) | % bar 20
    b8 b'8 b,8 | % bar 21
    e8 gis,8 b8 | % bar 22
    e,8 e'8 e8 | % bar 23
    e8 e,8 e'8 | % bar 24
    e8 e,8 e'8 | % bar 25
    e8 e,8 gis8 | % bar 26
    b8-\parenthesize\p(  b8  b8) | % bar 27
    b8(  b8  b8) | % bar 28
    b8 cis8 dis8 | % bar 29
    e8 e, r8 | % bar 30
    e'8-\parenthesize\p cis8 e8 | % bar 31
    fis8 fis,8 r8 | % bar 32
    fis'8 dis8 fis8 | % bar 33
    gis8 fis,8 r8 | % bar 34
    gis'8 e8 gis8 | % bar 35
    ais8 ais,8 r8 | % bar 36
    ais'8 fis8 ais8 | % bar 37
    b8 ais8 fis8 | % bar 38
    gis8 fis8 dis8 | % bar 39
    e8 dis8 cis8 | % bar 40
    e8. dis16 e16 cis16 | % bar 41
    dis8 e8 fis8 | % bar 42
    b,8 b8-\parenthesize\f b8 | % bar 43
    b8 b8 b8 | % bar 44
    b8 b8 b8 | % bar 45
    b8 gis8 e8 | % bar 46
    fis8 ais'8 gis8 | % bar 47
    fis8 e8 dis8 | % bar 48
    gis,8 gis'8 fis8 | % bar 49
    e8 dis8 cis8 | % bar 50
    fis,8 fis8 fis8 | % bar 51
    fis8 gis8 ais8 | % bar 52
    b8 b8 b8 | % bar 53
    b8 cis8 dis8 | % bar 54
    e8 e8 e8 | % bar 55
    e8 dis8 dis8 | % bar 56
    dis8 cis8 dis8 | % bar 57
    e8 e8 e8 | % bar 58
    e8 e8 e8 | % bar 59
    dis8 e8 fis8 | % bar 60
    b,8 b'8-\parenthesize\p a8 | % bar 61
    gis8 gis,8 gis'8 | % bar 62
    cis8 a8 gis8 | % bar 63
    fis8 fis,8 fis'8 | % bar 64
    b8 b,8 cis8 | % bar 65
    dis8 b8 b'8 | % bar 66
    e,8 e,8 fis8 | % bar 67
    gis8 dis8 e'8 | % bar 68
    a,8 fis'8 r8 | % bar 69
    gis,8 e'8 r8 | % bar 70
    fis,8 gis8 a8 | % bar 71
    b8 cis8 dis8 | % bar 72
    e8 gis8 e8 | % bar 73
    a8 fis8 b8 | % bar 74
    gis8 cis8 a8 | % bar 75
    dis8 b8 gis8 | % bar 76
    cis,8 cis'8 a8 | % bar 77
    b8 cis8 dis8 | % bar 78
    e8 e,8-\parenthesize\f e8 | % bar 79
    e8 e8 e8 | % bar 80
    e8 e8 e8 | % bar 81
    e8 cis'8 a8 | % bar 82
    b8 a16-\parenthesize\p(  gis16 fis16  e16) | % bar 83
    dis8 fis8 dis8 | % bar 84
    b4 r8 | % bar 85
    r8 b'8-\parenthesize\f b,8 | % bar 86
    e8 d16-\parenthesize\p(  cis16 b16  a16) | % bar 87
    gis8 b8 gis8 | % bar 88
    e8 r8 r8 | % bar 89
    r8 e'8 e, | % bar 90
    a8 b8 cis8 | % bar 91
    fis,8 fis'8 r8 | % bar 92
    gis,8 a8 b8 | % bar 93
    e,8 e'8 r8 | % bar 94
    fis8 gis8 a8 | % bar 95
    dis,8 cis8 b8 | % bar 96
    e4 r8 | % bar 97
    e,8 fis8 gis8 | % bar 98
    a8 r8 r8 | % bar 99
    b8 r8 r8 | % bar 100
    cis16-\parenthesize\p dis16 e16 fis16 gis16 ais16 | % bar 101
    b16 ais16 b16 dis16 cis16 b16 | % bar 102
    ais8 cis16(  b16 ais16  gis16) | % bar 103
    fis8 ais8 fis8 | % bar 104
    b8 a16(  gis16 fis16  e16) | % bar 105
    dis8 b8 dis8 | % bar 106
    \slurSolid e8( e8-\parenthesize\f \slurDotted e8) | % bar 107
    e8 e8 e8 | % bar 108
    e8 e8 e8 | % bar 109
    e8 gis8 cis8 | % bar 110
    b16 cis16 dis16 cis16 b16 a16 | % bar 111
    gis16 a16 gis16 fis16 e16 dis16 | % bar 112
    cis8 cis'16 dis16 cis16 b16 | % bar 113
    a16 gis16 fis16 e16 dis16 cis16 | % bar 114
    b16 b'16 a16 gis16 fis16 e16 | % bar 115
    dis8 b8 dis8 | % bar 116
    e8  d16( cis16 b16  a16) | % bar 117
    gis8 e8 gis8 | % bar 118
    a8 fis'8 r8 | % bar 119
    gis,8 e'8 r8 | % bar 120
    fis,8 fis'8 gis8 | % bar 121
    a8 a8 a8 | % bar 122
    a8 a8 a8 | % bar 123
    gis8 a8 b8 | % bar 124
    e,8 gis8 e8 | % bar 125
    cis8 cis'8 r8 | % bar 126
    r8 fis,8-\parenthesize\p dis8 | % bar 127
    b8 b'8 r8 | % bar 128
    r8 e,16-\parenthesize\f(  dis16 e16  fis16) | % bar 129
    gis8 e8 gis8 | % bar 130
    a16(   gis16) fis16(  eis16 fis16  gis16) | % bar 131
    a8 fis8 a8 | % bar 132
    b8 a16(  gis16 fis16  e16) | % bar 133
    dis16(   e16) fis16(  e16 dis16  cis16) | % bar 134
    b4 a8 | % bar 135
    gis8 a8 b8 | % bar 136
    e,4\fermata r8 | % bar 137
    r8 fis'8 e8 | % bar 138
    dis8 cis8 b8 | % bar 139
    a8 \slurSolid cis16-\parenthesize\f(  b16 a16  gis16) | % bar 140
    fis8 a8 cis8 | % bar 141
    fis8 e8 \once \set suggestAccidentals = ##t d8 | % bar 142
    cis8 b8 a8 | % bar 143
    gis8 b16-\parenthesize\f(  a16 gis16  fis16) | % bar 144
    e8 a8 fis8 | % bar 145
    gis8 gis'8 r8 | % bar 146
    R4. | % bar 147
    gis8 fis8 eis8 | % bar 148
    fis8 e8 d8 | % bar 149
    e8 d8 cis8 | % bar 150
    d8 cis8 b8 | % bar 151
    cis8 cis'8 b8 | % bar 152
    a16 cis16(  b16 a16 gis16  fis16) | % bar 153
    cis'8 b8 a8 | % bar 154
    gis8 fis8 e8 | % bar 155
    d8 fis16-\parenthesize\f(  e16 d16  cis16) | % bar 156
    b8 d8 fis8 | % bar 157
    b8 a8 \once \set suggestAccidentals = ##t g8 | % bar 158
    fis8 e8 d8 | % bar 159
    cis8 e16-\parenthesize\f(  d16 cis16  b16) | % bar 160
    a8 d8 b8 | % bar 161
    cis8 cis'8 r8 | % bar 162
    R4. | % bar 163
    cis,8 b8 ais8 | % bar 164
    b8 d8 e8 | % bar 165
    a,8 cis8 d8 | % bar 166
    g,8 b8 cis8 | % bar 167
    fis,8 ais8 fis8 | % bar 168
    b8 dis8 b8 | % bar 169
    g'8 fis8 e8 | % bar 170
    fis8 gis8 ais8 | % bar 171
    b8 cis8 d8 ~  | % bar 172
    d8 cis16(  b16 a16  gis16) | % bar 173
    fis b cis8 cis,8 | % bar 174
    fis,8 fis8-\parenthesize\f fis8 | % bar 175
    fis8 fis8 fis8 | % bar 176
    fis8 fis8 fis8 | % bar 177
    fis8 d'8 b8 | % bar 178
    cis8 cis'8-\parenthesize\p r8 | % bar 179
    cis,8 cis'8 r8 | % bar 180
    cis,8 cis'8 r8 | % bar 181
    cis,8 \slurDotted cis'16(  b16 a16  gis16) | % bar 182
    fis8 a16-\parenthesize\f(  gis16 fis16  e16) | % bar 183
    dis8 b8 gis8 | % bar 184
    cis8 gis'16(  fis16 e16  dis16) | % bar 185
    cis8 a8 fis8 | % bar 186
    b8 b'8-\parenthesize\p r8 | % bar 187
    b,8 b'8 r8 | % bar 188
    b,8 b'8 r8 | % bar 189
    b,8 b'16(  a16 gis16  fis16) | % bar 190
    \slurSolid e8(  e8-\parenthesize\f  e8) | % bar 191
    e8(  e8  e8) | % bar 192
    \slurDotted e8(  e8  e8) | % bar 193
    e8 cis8 a8 | % bar 194
    b8 b16(  cis16 dis16  e16) | % bar 195
    fis16 e16 fis16 gis16 a16 fis16 | % bar 196
    b8 b,8 dis8 | % bar 197
    e8 d16(-\parenthesize\f  cis16 b16  a16) | % bar 198
    gis8 e8 gis8 | % bar 199
    a16(  b16 cis16 dis16 eis16  fis16) | % bar 200
    gis16 fis16 gis16 a16 b16 gis16 | % bar 201
    cis8 cis,8 eis8 | % bar 202
    fis8 fis,16(  eis16 fis16  gis16) | % bar 203
    a8 fis8 a8 | % bar 204
    b8 b16( \once \set suggestAccidentals = ##t ais16 b16 cis16) | % bar 205
    dis8 b8 dis8 | % bar 206
    e e, r8 | % bar 207
    gis'8 e8 gis8 | % bar 208
    a a, r8 | % bar 209
    a'8 fis8 a8 | % bar 210
    b b, r8 | % bar 211
    b'8 gis8 b8 | % bar 212
    cis cis, r8 | % bar 213
    b' b, r8 | % bar 214
    ais'8 ais,8 gis'8 | % bar 215
    fisis8 dis8 fisis8 | % bar 216
    gis8 ais8 b8 | % bar 217
    cis8 dis8 e8 | % bar 218
    dis8 cis16(  b16-\parenthesize\p ais16  gis16) | % bar 219
    fisis8 ais8 fisis8 | % bar 220
    dis4 r8 | % bar 221
    r8 dis'8-\parenthesize\f dis,8 | % bar 222
    gis8 fis16\p(  e16 dis16  cis16) | % bar 223
    bis8 dis8 bis8 | % bar 224
    gis8 r8 r8 | % bar 225
    r8 gis'8-\parenthesize\f gis,8 | % bar 226
    cis8 dis8 e8 | % bar 227
    fis,8 fis'8 r8 | % bar 228
    b,8 cis8 d8 | % bar 229
    e,8 e'8 r8 | % bar 230
    a,8 gis8 fis8 | % bar 231
    dis'8 e8 fis8 | % bar 232
    gis,8 gis'8 r8 | % bar 233
    gis,8 gis'8 r8 | % bar 234
    gis,8 gis'8 b8 | % bar 235
    ais8 cis8 b8 | % bar 236
    ais8 gis8 fis8 | % bar 237
    e8 gis16-\parenthesize\f(  fis16 e16  dis16) | % bar 238
    cis16 bis16 cis16 dis16 e16 fis16 | % bar 239
    gis8 fis8 e8 | % bar 240
    dis8 cis8 b8 | % bar 241
    a8 cis'16(  b16 a16  gis16) | % bar 242
    fis8 gis8 a8 | % bar 243
    gis8 gis,8 r8 | % bar 244
    R4. | % bar 245
    gis'8 fis8 eis8 | % bar 246
    fis8 e8 dis8 | % bar 247
    e8 dis8 cis8 | % bar 248
    dis8 eis8 fisis8 ~  | % bar 249
    fisis8 gis8 ais8 ~  | % bar 250
    ais8 b8 cis8~ | % bar 251
    cis8 ais8 fisis8 | % bar 252
    dis8 dis'8 r8 | % bar 253
    b8 gis8 eis8 | % bar 254
    cisis8 cisis'8 r8 | % bar 255
    e?8 fisis,8 gis8 | % bar 256
    cis,8 dis8 dis,8 | % bar 257
    gis4. | % bar 258
}
\new FiguredBass {
    \figuremode {
	\set figuredBassAlterationDirection = #RIGHT
	\set figuredBassPlusDirection = #RIGHT

	s4.*40
	<4+ 2>4.
    }
}
\mvtImarks
>>
