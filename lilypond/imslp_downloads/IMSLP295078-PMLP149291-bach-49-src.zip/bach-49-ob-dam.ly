\include "bach-49-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    page-count = 3
    ragged-last-bottom = ##f
}

\header {
    instr = "Oboe d'Amore"
}


% %{

\score {
    \new Staff <<
	\transpose a c' \mvtIobDam
    >>

    \header {
	piece = \markup{\bold{1. (SINFONIA)}}
    }

    \layout {
    }
}
