\include "bach-49-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    % page-count = 3
    ragged-last-bottom = ##f
}

\header {
    instr = "Organo"
}


% %{

\score {
    \new PianoStaff <<
	\new Staff <<
	    \mvtIorgR
	>>
	\new Staff <<
	    \mvtIorgL
	>>
    >>

    \header {
	piece = \markup{\bold{1. (SINFONIA)}}
    }

    \layout {
    }
}
