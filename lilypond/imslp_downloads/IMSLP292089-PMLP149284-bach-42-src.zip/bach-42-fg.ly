\include "bach-42-sinf.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    page-breaking = #ly:page-turn-breaking
}

\header {
    instr = "Fagotto"
}


% %{

\addQuote "sinfVlnI" { \sinfVlnI }
\addQuote "sinfObI" { \sinfObI }

sinfCues = {
    \cueDuringWithClef #"sinfVlnI" #DOWN "G" { s1*2^"Vln.I" s4 } s2. |
    s1*5 |
    \cueDuringWithClef #"sinfObI" #DOWN "G" { s2^"Ob.I" } s2 |
}

\score {
    \new Staff <<
	\sinfFg
	\sinfCues
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }

    \layout {
    }
}
