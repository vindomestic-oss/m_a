\version "2.17.18"

\include "title.ly"

\paper {
    bookTitleMarkup = \markup {
	\center-column {
	    \vspace #10.0
	    \huge \larger \bold 
	    \fill-line {
		\larger \fromproperty #'header:composer
	    }
	    \vspace #2.0
	    \huge \larger \bold 
	    \fill-line {
		\larger \fromproperty #'header:poet
	    }
	    \vspace #2.0
	    \huge \larger \larger
	    \fill-line {
		\larger \larger \larger \bold \fromproperty #'header:title
	    }
	    \vspace #2.0
	    \huge \bold
	    \fill-line {
		\fromproperty #'header:subtitle
	    }
	    \vspace #2.0
	    \large \bold
	    \fill-line {
		\fromproperty #'header:subsubtitle
	    }
	    \vspace #15.0
	    \huge \larger \bold
	    \fill-line {
		\larger \fromproperty #'header:instr
	    }
	    %{
	    \vspace #6.0
	    \fill-line {
		\epsfile #Y #120 #"neubauer-12-2-title.eps"
	    }
	    %}
	}
    }
}

\pageBreak

