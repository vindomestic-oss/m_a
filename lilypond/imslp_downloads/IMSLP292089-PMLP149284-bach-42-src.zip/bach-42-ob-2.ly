\include "bach-42-sinf.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    page-breaking = #ly:page-turn-breaking
}

\header {
    instr = "Oboe II"
}


% %{

\addQuote "sinfVlnI" { \sinfVlnI }
\addQuote "sinfObI" { \sinfObI }

sinfCues = {
    \cueDuring #"sinfVlnI" #DOWN { s1*2^"Vln.I" s4 } s2. |
    s1*49 |
    s2
    \cueDuring #"sinfObI" #DOWN { s2^"Ob.I" s1*2 } |
}

\score {
    \new Staff <<
	\sinfObII
	\sinfCues
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }

    \layout {
    }
}
