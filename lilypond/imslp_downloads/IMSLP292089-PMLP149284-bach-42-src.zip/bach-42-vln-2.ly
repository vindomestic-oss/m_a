\include "bach-42-sinf.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    page-breaking = #ly:page-turn-breaking
    page-count = 3
}

\header {
    instr = "Violino II"
}


% %{

\score {
    \new Staff <<
	\sinfVlnII
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }

    \layout {
    }
}
