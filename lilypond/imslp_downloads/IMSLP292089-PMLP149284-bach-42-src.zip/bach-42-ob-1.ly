\include "bach-42-sinf.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    page-breaking = #ly:page-turn-breaking
}

\header {
    instr = "Oboe I"
}


% %{

\addQuote "sinfVlnI" { \sinfVlnI }

sinfCues = {
    \cueDuring #"sinfVlnI" #DOWN { s1*2^"Vln.I" s4 }
}

\score {
    \new Staff <<
	\sinfObI
	\sinfCues
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }

    \layout {
    }
}
