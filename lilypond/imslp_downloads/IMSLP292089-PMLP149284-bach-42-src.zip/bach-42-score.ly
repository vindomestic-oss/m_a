\include "bach-42-sinf.ly"

\paper {
    system-separator-markup = \markup {
	\center-align
	\vcenter \combine
	\beam #4.0 #0.5 #0.96
	\raise #1.4 \beam #4.0 #0.5 #0.96
    }
    % system-separator-markup = \slashSeparator
    two-sided = ##t
    indent = 12
    short-indent = 8
    ragged-last-bottom = ##f
    % system-system-spacing = #'((basic-distance . 4) (minimum-distance . 4) (padding . 1) (stretchability . 60))
    % % system-system-spacing #'basic-distance = #25
    % system-system-spacing #'minimum-distance = #15
    % page-count = 9
}

\include "paged-title.ly"
% \include "title.ly"

\markup\null
\pageBreak


#(set-global-staff-size 14)


% %{

\score {
    \new StaffGroup <<
	\new GrandStaff <<
	    \new Staff <<
		\commonScore

		\sinfObI

		% \sinfBreaks

		\set Staff.instrumentName = "I."
		\set Staff.shortInstrumentName = "I."
	    >>
	    \new Staff <<
		\sinfObII

		\set Staff.instrumentName = "II."
		\set Staff.shortInstrumentName = "II."
	    >>

	    \set GrandStaff.instrumentName = "Oboi"
	    \set GrandStaff.shortInstrumentName = "Ob."
	>>
	\new Staff <<
	    \sinfFg

	    \set Staff.instrumentName = "Fagotto."
	    \set Staff.shortInstrumentName = "Fg."
	>>
	\new GrandStaff <<
	    \new Staff <<
		\sinfVlnI

		\set Staff.instrumentName = "I"
		\set Staff.shortInstrumentName = "I"
	    >>
	    \new Staff <<
		\sinfVlnII

		\set Staff.instrumentName = "II"
		\set Staff.shortInstrumentName = "II"
	    >>

	    \set GrandStaff.instrumentName = "Violino"
	    \set GrandStaff.shortInstrumentName = "Vln"
	>>
	\new Staff <<
	    \sinfVla

	    \set Staff.instrumentName = "Viola."
	    \set Staff.shortInstrumentName = "Vla."
	>>
	\new Staff <<
	    \sinfBasso

	    \set Staff.instrumentName = \markup{\center-column{ "Organo e" "Continuo" }}
	    \set Staff.shortInstrumentName = "B.C."
	>>
    >>

    \header {
	piece = \markup{\larger\larger\bold{SINFONIA}}
    }
}

\score {
    <<
	\sinfObI
	\sinfObII
	\sinfFg
	\sinfVlnI
	\sinfVlnII
	\sinfVla
	\sinfBasso
    >>

    \midi{ }
}
