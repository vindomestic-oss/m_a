\version "2.18.0"
\language "nederlands"
scoreAViolinII = \relative c' {
  \scoreAGlobal

  d16\paren\f e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  d8 r8 a'8(\p g8) r4 d'8( cis8) | % 7
  r4 f8( e8) r4 d8( cis8) | % 8
  r4 f,8( e8) r4 d'8( cis8) | % 9
  r4 g8( e8) r4 d8( cis8) | % 10
  r4 f8( e8) f4 r4 | % 11
  R4*4*1 | % 12
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 13
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 14
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 15
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 16
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 17
  fis,8( g8) r4 e8( f8) r4 | % 18
  d'4 r4 f,4 r4 | % 19
  b,16 e16 fis16 gis16 a16 b16 c16 d16 e16 f16 g8-. g16 a16 bes8-. | % 20
  cis,8-. d8-. gis,8-. a8-. dis,8 r8 e8 r8 | % 21
  a,8 r8 e'8(\p d8) r4 a'8( gis8) | % 22
  r4 c8( b8) r4 a8( gis8) | % 23
  r4 e8( d8) r4 c8( b8) | % 24
  r4 a8( gis8) r4 d'8( b8) | % 25
  c4 r4 r2 | % 26
  R4*4*1 | % 27
  e8\p r8 e'8 r8 cis8 r8 a8 r8 | % 28
  d,16 e16 f8 e8 d8 a'8 d4 a8 | % 29
  d,8 r8 d'8 r8 b8 r8 g8 r8 | % 30
  c,16 d16 e8 d8 c8 g'8 c4 g8 | % 31
  c,8 r8 c'8 r8 a8 r8 f8 r8 | % 32
  bes,16 c16 d8 c8 bes8 f'8 bes4 f8 | % 33
  b,8 r8 b8 r8 c8 r8 e8 r8 | % 34
  fis8 r8 a,8 r8 bes8 r8 d8 r8 | % 35
  e8 r8 g,8 r8 a8 r8 c8 r8 | % 36
  d8 r8 e8 r8 e8 r8 d8 r8 | % 37
  d8 r8 c8 r8 f4 r8 c'8 | % 38
  f,16 c'16\f d16 e16 f16 g16 a16 bes16 c8 f,8 g,8 e'8 | % 39
  c1\p | % 40
  bes1 | % 41
  a4 r4 r8 fis8\f g8 a8 | % 42
  d,4 r4 r8 gis8 a8 b8 | % 43
  e,4 r4 r8 cis'8 d8 e8 | % 44
  a,8. bes16 a16 g16 f16 e16 d4 r4 | % 45
  r8 d'8~\p d8 b16 gis16 b,8 d'8~ d8 b16 gis16 | % 46
  \slurDashed e8( c8) a8( c8) e8( c8) a8( cis8) | % 47
  e8 g'8~ g8 e16 cis16 e,8 g'8~ g8 e16 cis16 | % 48
  a8( f8) d8( f8) a8( f8) d8( f8) \slurSolid | % 49
  b8 a'8~ a8 fis16 dis16 fis,8 a'8~ a8 fis16 dis16 | % 50
  e8 d8~ d8 b16 gis16 e8 d'8~ d8 b16 gis16 | % 51
  a8( e8) c8( e8) a8( e8) c8( e8) | % 52
  a8( f8) c8( f8) a8( e8) c8( e8) | % 53
  a8( g8) f8( e8) d8( c8) b8( d8) | % 54
  c8 r8 r4 r2 | % 55
  r2 c'16\f d16 e8 d8 c8~ | % 56
  c8 b4 a8~ a d8~ d b16 gis16 | % 57
  d8 f'8~ f8 d16 b16 d,8 gis'8~ gis8 f16 d16 | % 58
  d,8 b''8~ b8 gis16 e16 f16 d16 e16 c16 d16 b16 c16 a16 | % 59
  e'1~ | % 60
  e8 f8-. b,8-. c8-. dis,8 r8 e8 r8 | % 61
  a,8 r8 r4 r2 | % 62
  R1*6
  r8 e''8\f dis8 e8 fis8 r8 dis8 r8 | % 69
  b8 r8 r4 r2 | % 70
  R1*6 | % 76
  r4 r8 e8~\p e8 c16 a16 e8 e'8~ | % 77
  e8 b16 g16 e8 e'8~ e c16 a16 e8 e'8~ | % 78
  e8 r8 r4 r2 | % 79
  R4*4*11 | % 90
  g,1\p | % 91
  f1 | % 92
  e4 r r8 g8\f f8 e8 | % 93
  d8 r8 r4 r8 c'8 bes8 a8 | % 94
  g4 r4 r8 bes8\p d8 bes8 | % 95
  es,4 r4 r8 c'8 es8 c8 | % 96
  bes4 r4 r8 g8 d8 bes'8 | % 97
  c4 r4 r8 c8 g8 es8 | % 98
  a,8 d8 fis8 a8 d8 r8 r4 | % 99
  r8 bes8 g8 e8 cis8 r8 r4 | % 100
  r8 a'8 fis8 c8 a8 r8 r4 | % 101
  r8 fis''8 c8 a8 d,8 r8 r4 | % 102
  R4*4*1 | % 103
  g16\f a16 bes8 a8 g8 d'8 g4 d8 | % 104
  es8 c16 a16 d8 bes16 g16 c8 a16 fis16 d8 es'8~ | % 105
  es8 c16 a16 d,8 fis'8~ fis8 es16 c16 d,8 a''8~ | % 106
  a8 fis16 d16 es16 c16 d16 bes16 c16 a16 bes16 g16 a16 fis16 g16 e16 | % 107
  fis16 d16 e16 fis16 g16 a16 bes16 c16 d16 es16 f8-. f16 g16 as8-. | % 108
  b,8-. c8-. fis,8-. g8-. cis,8-\fermata r8 r4 | % 109
  R4*4*2 | % 111
  r2 r8 bes'8\f es8 d8 | % 112
  d16 c16 bes16 a16 g16 f16 es16 d16 c8 c'8 r4 | % 113
  c16 bes16 a16 g16 f16 es16 d16 c16 bes8 bes'8 r4 | % 114
  bes16 a16 g16 f16 e16 d16 cis16 b16 a8 a'8 r4 | % 115
  r8 f8\p a8 d8 r8 a8 e'8 g8 | % 116
  r8 f8 a8 d8 r8 a,8 e'8 g8 | % 117
  r8 a4 a16 f16 d8 bes'4 d,16 bes16 | % 118
  e,8 a'4 e16 c16 a8 a'4 e16 c16 | % 119
  f,8 a'4 a16 f16 d8 bes'4 bes16 g16 | % 120
  e8 cis4 e16 cis16 a8 a4 e16 cis16 | % 121
  d16 e16 f8 e8 d8 a'8 d4 fis,8 | % 122
  g8 r8 bes8 r8 g8 r8 d8 r8 | % 123
  c16 d16 es8 d8 c8 g'8 c4 e,8 | % 124
  f8 r8 a8 r8 f8 r8 c8 r8 | % 125
  bes16 c16 d8 c8 bes8 f'8 bes4 d,8 | % 126
  es8 r8 g8 r8 es8 r8 g8 r8 | % 127
  e8 r8 e8 r8 f8 r8 a8 r8 | % 128
  b8 r8 d,8 r8 es8 r8 g8 r8 | % 129
  a8 r8 c,8 r8 d8 r8 f8 r8 | % 130
  g8 r8 a8 r8 a8 r8 g8 r8 | % 131
  g8 r8 f8 r8 bes4 r8 f8 | % 132
  d16 f16\f g16 a16 bes16 c16 d16 es16 f8 bes,8 f8 a8 | % 133
  bes4 r8 d,8\p es8( d8) f8( es8) | % 134
  d16 es16 f8 es8 d8 bes'8 bes,8 d8 es8 | % 135
  f4 r4 r8 g8\f g8 g8 | % 136
  g4 r4 r2 | % 137
  r8 a8 a8 a8 a4 r4 | % 138
  r2 r8 d8 d8 d8 | % 139
  d8 bes8\p es4~ es8 c8 fis4~ | % 140
  fis8 d8 g4~ g8 e8 a4~ | % 141
  a8 g8( f8 e8) d8 b( c d) | % 142
  c8 d8( c8 bes8) a8 c8 f4~ | % 143
  f8 e( d c) bes c( bes a) | % 144
  \slurDashed g8 a8( g8 f8) \slurSolid e4 r8 e8 | % 145
  d8 d8 e8 f8 g8 bes8 a8 g8 | % 146
  f8 g8 a8 f8 bes8 g8 e8 a8 | % 147
  a4 r4 cis4 r4 | % 148
  d4 r4 cis4 r4 | % 149
  d4 r4 r8 d8 cis8 e8 | % 150
  d4 r4 r8 f,8 e8 e8 | % 151
  d4 r4 r2 | % 152
  f4 r4 r2 | % 153
  R4*4*18 | % 171
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 173
  bes8 g'4\p e16 cis16 e,8 g'4 e16 cis16 | % 174
  a8( f8) d8( f8) \slurDashed a8( f8) d8( fis8) \slurSolid | % 175
  es'8 c'4 a16 fis16 a,8 c'4 a16 fis16 | % 176
  d8( bes8) g8( bes8) d8( bes8) g8( bes8) | % 177
  f'8 d4 b16 gis16 gis,8 d''4 b16 gis16 | % 178
  a8 g4 e16 cis16 a8 g'4 e16 cis16 | % 179
  d'8( a8) f8( a8) d8( a8) f8( a8) | % 180
  d8( bes8) f8( bes8) d8( a8) f8( a8) | % 181
  d( c) bes( a) g( f) e( g) | % 182
  f8 r8 r4 r2 | % 183
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8 c16 d16 es8 | % 188
  fis,8-. g8-. cis,8-. d8-. gis,8 r8 a8 r8 | % 189
  d4\fermata r4 r2 | % 190
  \bar "|."

}
