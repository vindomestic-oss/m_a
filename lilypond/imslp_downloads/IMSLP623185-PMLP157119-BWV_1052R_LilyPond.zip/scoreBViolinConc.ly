\version "2.18.2"
\language "nederlands"
scoreBViolinConc = \relative c'' {
  \scoreBGlobal

  R4*3*12 | % 12
  d4 bes4 fis4 | % 13
  g8 fis8 g4 r4 | % 14
  g'4 es4 b4 | % 15
  c8 b8 c2~ | % 16
  c4 bes8 a8 g8 fis8 | % 17
  es'4 d8 c8 bes8 a8 | % 18
  g8 a16 fis16 g4 r4 | % 19
  es'16( d16 f16 es16) es4 r4 | % 20
  fis8 g32 fis32 e32 fis32 fis4.-\trill e16 fis16 | % 21
  g8 d8 es8 b8 c8 as8 | % 22
  \appoggiatura {g4} f2.~ | % 23
  f8 d8 es8 g16 f16 g8 b16 a16 | % 24
  b8 c8 es4 d16 c16 d8 | % 25
  c4 g4 es4 | % 26
  c8 b8 c4 r4 | % 27
  bes''!8~ bes32 a32 g32 f32 e16 g16 f16 e16 d16 cis16 b16 a16 | % 28
  f'16 bes a8 g16 f8 e16 d16 e16 cis8 | % 29
  d8( cis8) d4 r4 | % 30
  d'4 bes4 fis4 | % 31
  g16 fis16 a16 g16 g2 ~ | % 32
  g4 f8 e8 d8 cis8 | % 33
  bes'16 a g bes a g f( e32 g32) f16 e d( e32 cis) | % 34
  d8( cis) d4 r4 | % 35
  bes'16 a16 c16 bes16 bes4( bes16) a16 g32 fis32 g32 bes32 | % 36
  cis8 d32 cis32 b32 cis32 cis4.-\trill b16 cis16 | % 37
  d8( a8) bes8( fis8) g8( es8) | % 38
  \appoggiatura { d4 } c2.~ | % 39
  c8 a8 bes8 d16 c16 d8 f16 es16 | % 40
  f8 as16 g16 \appoggiatura { es8 } d4( c16-\trill) bes16 c8 | % 41
  bes16 f16 g16 d16 es16 c16 d16 bes16 as16 g16 as16 f'16 | % 42
  <<
    \new Voice {
      \voiceOne f2.~ |
      f16
    } \new Voice {
      \voiceTwo \stemDown g,2.~ | % 43
      g16 b16 d16 f16
    }
  >>
  \oneVoice
  as16 b16 d16 f16 as32[ g16 f32] es16[ f32 d32] | % 44
  es2.~ | % 45
  es16 c des b c g as16 e16 f16 des'16 c16 b16 | % 46
  <<
    {
      f'2.~ | % 47
      f16( e f) as
    } \\ {
      b,2.~ | % 47
      b16
    }
  >>
  \oneVoice f'16( e16 f16) as f( e f) des'16 | % 48
  b16( c \appoggiatura d8 c16 b32 c32) d2~ | % 49
  d16 c16 b16 d16 c16 bes16 as16 bes32 g32 as4~ | % 50
  as8 c,8 des16( c16 des16) as'16 g16 f16 e16 f16 | % 51
  <<f4 \\ g,4 \\ b4>> r8 g8 as8 g8 | % 52
  es'8 c16 as16 g16 f16 e16 f16 f16 des16 a16 bes16 | % 53
  bes2.~ | % 54
  bes8 g8 as c f4~ | % 55
  f16 as16 fis16 g16 es'8. d16 c16-\prall b16 c8 | % 56
  c8( c32) g32 a32 b32 c32( d32 es32 d32 c32 bes32 a32 bes32 c32[ fis,32 g32 a32 g32 fis32 e32 d32)] | % 57
  fis'4~ fis16 g fis g16 g8.(-\trill fis32 g32) | % 58
  a16 es16 c16 a16 c16 es16 fis16 g16 a bes a c32 bes | % 59
  c8.( d32 es32) d8. c16 bes16. a32 g16. fis32 | % 60
  g8. as32 fis32 g2~ | % 61
  g16 g16 a16 c32( b32) c16 b c16 es32 d32 es16. d32 c32 b c16 | % 62
  c2.~ | % 63
  c16( b c) es c( b c) es as,( g as) c | % 64
  fis,16 e fis a d,8~ d32 e d e fis e fis g fis16.\trill e64 fis | % 65
  g4~ g16 as16 g16 f16 es d16 f es | % 66
  es4~ es16 f16 es16 d16 c b d c | % 67
  c4~ c16 g'16 fis16 g32 a32 es16 c16 bes16\trill a16 | % 68
  g16( fis16 g16) bes16 es,16( d16 es16) g16 c,16( b16 c16) es16 | % 69
  as,16( g16 as16) d16 f16( es16 f16) as16 d,16( c16 d16) f16 | % 70
  b,16( d16 f16 as16) g16( f16 es16 d16) c16( es16 g16 b16) | % 71
  c16( es16) des16( b16) c16( es16) as16( fis16) g16( es16) cis16( d16) | % 72
  bes'16( as16 fis16 g16) c4~ c16. bes32 a32 g32 a16 | % 73
  g8~ g32 bes32 a32 g32 fis32 es32 d32 c32 bes32 c32 c32.-\trill bes128 c128 d32[ bes g fis] g64[ d64 bes64 c64 c64\prall bes128 c128 d64 bes64] | % 74
  g4 r4 r4 | % 75
  R4*3*11 | % 86
  R4*3\fermataMarkup | % 87
  \bar "|."

}
