\version "2.18.2"
\language "nederlands"
scoreCViolinConc = \relative c'' {
  \scoreCGlobal

  d8\paren\f c16 bes16 a8 g8 f8 e8 | % 1
  f8 d8 d'8 d8 d8 d8 | % 2
  d16 c16 d16 e16 f8 f8 f8 f8 | % 3
  f16 e16 f16 g16 a8 a8 a8 a8 | % 4
  a8 g16 f16 g8 e16 f16 g8 g8 | % 5
  g8 f16 e16 f8 d16 e16 f8 g16 a16 | % 6
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 7
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 8
  g8( fis8 g8) bes16 a16 bes8 g8 | % 9
  es8( d8 es8) g16 f16 g8 es8 | % 10
  cis8 bes'16( a16 bes8) g16( fis16 g8) cis,8 | % 11
  d8 f,8 g8 d'8 a8 cis8 | % 12
  d8 d'16^"(Solo)" cis16 d8 a16 g16 a8 f16 e16 | % 13
  f8 d16 cis16 d8 r8 r4 | % 14
  r8 a'16 gis16 a8 e16 d16 e8 c16 b16 | % 15
  c8 a16 gis16 a8 r8 r4 | % 16
  R4*3*1 | % 17
  r8 d16 cis16 d8 a16 g16 a8 f16 e16 | % 18
  f8 d16 cis16 d8 f16 e16 f8 bes16 a16 | % 19
  bes8 c,16 bes16 c8 e16 d16 e8 a16 g16 | % 20
  a8 bes,16 a16 bes8 d16 cis16 d8 g16 f16 | % 21
  g8 a,8 a8 g'8 g16 a16 bes16 g16 | % 22
  cis8 a,8 a8 cis'8 cis16 d16 e16 cis16 | % 23
  a'8 es16 d16 es8 c16 b16 c8 g'16 fis16 | % 24
  g8 d16 c16 d8 b16 a16 b8 bes'16 a16 | % 25
  bes8 g16 f16 g8 e16 d16 e8 cis16 b16 | % 26
  cis8 a16 g16 a8 \tieDashed g'8~ g16 \tieNeutral f16 g16 e16 | % 27
  f16 g f g16 g4.-\trill f16 g16 | % 28
  a4 r4 r4 | % 29
  r8 c,16 d16 e8 d16 e16 f8 e16 f16 | % 30
  b,8 r8 g'8 f16 g16 a8 g16 a16 | % 31
  d,8 r8 b'8 a16 b16 c8 b16 c16 | % 32
  fis,8 gis16 a16 b16 a16 gis16 a16 b16 a16 gis16 fis16 | % 33
  e4~ e16 d16 c16 d16 e4~ | % 34
  e16 g16 f16 e16 d16 c16 b16 c16 d4~ | % 35
  d16 f16 e16 d16 c16 a16 c16 e16 a4~ | % 36
  a16 d,16 f16 a16 d8 d8 d8 \tieDashed d8~ | % 37
  d8 d8 d8 d8 d8 d8~ | % 38
  \tieSolid d8 d16 c16 d8 b16 a16 b8 e16 d | % 39
  e8 c8 a8. b16 b8.-\trill a16 | % 40
  a8 a,,16 gis16 a8 c16 b16 c8 e16 d16 | % 41
  e8 a16 gis16 a4 r4 | % 42
  r8 e16 d16 e8 g16 f16 g8 bes16 a16 | % 43
  bes8 cis16 b16 cis4 r4 | % 44
  r8 d16 e16 f8 d16^"(Tutti)" e16 f8 g16 a16 | % 45
  bes8 g,16^"(Solo)" a16 bes16 c16 d16 a16 bes16 g16 d'16 bes16 | % 46
  e8 c16 d16 e8 c16^"(Tutti)" d16 e8 f16 g16 | % 47
  a8 f,16^"(Solo)" g16 a16 bes16 c16 g16 a16 f16 c'16 a16 | % 48
  d8 bes16 c16 d8 bes16^"(Tutti)" c16 d8 e16 f16 | % 49
  g8^"(Solo)" c,,16 d16 e16 f16 g16 d16 e16 c16 g'16 e16 | % 50
  bes'16 a16 g16 f16 g16 a16 bes16 f16 g16 e16 bes'16 g16 | % 51
  e'16 d16 c16 d16 e16 f16 g16 d16 e16 c16 g'16 e16 | % 52
  bes'16 a16 g16 a16 bes16 c16 d16 a16 bes16 g16 c16 g16 | % 53
  a16 e16 f16 c16 d16 f16 bes16 g16 a16 f16 c16 e16 | % 54
  f8^"(Tutti)" e16 d16 c8 bes8 a8 g8 | % 55
  a8 f8 f'8 f8 f8 f8 | % 56
  f16^"(Solo)" a16 g16 f16 e4 r4 | % 57
  r8 e16 f16 g8 fis16 g16 a8 g16 a16 | % 58
  d,4 r4 r4 | % 59
  r8 g8 f16 a16 g16 f16 e16 g16 f16 e16 | % 60
  d8 d,8 f8 a8 d8 cis8 | % 61
  d8 d,16^"(Tutti)" e16 f8 e16 f16 g8 f16 g16 | % 62
  \allowPageTurn a8 f16 g16 a8 g16 a16 b8 a16 b16 | % 63
  c8 a16 b16 c8 b16 c16 d8 c16 d16 | % 64
  e8 e,8 e'8 d8 cis8 a8 | % 65
  d8 d,8 d'8 d16 e16 f8 g16 a16 | % 66
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 67
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 68
  g8( fis8 g8) bes16 a16 bes8 g8 | % 69
  es8( d8 es8) g16 f16 g8 es8 | % 70
  cis8 bes'16^"(Solo)" a16 bes8 g16 f16 g8 cis,8^"(Tutti)" | % 71
  d8 f,8 g8 d'8 a8 cis8 | % 72
  d,2.\paren\p~ | % 73
  \allowPageTurn d2.~ | % 74
  d2.~ | % 75
  d2.~ | % 76
  d4. d'16\paren\f e16 f8 g16 a16 | % 77
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 78
  a8 f16 e16 d8 r8 r4 | % 79
  es4^"(Solo)" r4 r4 | % 80
  g4 r4 r4 | % 81
  r8 bes16(^"(Tutti)" a16 bes8) g16( fis16 g8) cis,8 | % 82
  d8 f,8 g8 d'8 a8 cis8 | % 83
  d,16^"(Solo)" e16 f16 g16 a16 b16 cis16 d16 a16 d16 f,16 a16 | % 84
  d,16 d'16 a16 d16 f,16 a16 d,16 d'16 a16 d16 f,16 a16 | % 85
  <<
    {
      s16 d,16 a'16 d,16 s16 d16 a'16 d,16 s16 d16 a'16 d,16 | % 86
      s16 d16 a'16 d,16 s16 d16 a'16 d,16 s16 d16 a'16 d,16 | % 87
      s16 d16 a'16 d,16 s16 d16 a'16 d,16 s16 d16 a'16 d,16 | % 88
      s16 d16 a'16 d,16 s16 d16 a'16 d,16 s16 d16 a'16 d,16 | % 89
      s16 <d a'>16[ s16 <d a'>16] s16 <d a'>16[ s16 <d a'>16] s16 <d a'>16[ s16 <d a'>16] | % 90
      s16 <d a'>16[ s16 <d a'>16] s16 <d a'>16[ s16 <d a'>16] s16 <d a'>16[ s16 <d a'>16] | % 91
      <d a'>16 s8.
    }
    \\
    {
      d16 s8. e16 s8. f16 s8. | % 86
      g16 s8. f16 s8. e16 s8. | % 87
      d16 s8. e16 s8. f16 s8. | % 88
      g16 s8. f16 s8. e16 s8. | % 89
      f16[ s16 f16] s16 e16[ s16 f16] s16 g16[ s16 e16] s16 | % 90
      f16[ s16 f16] s16 e16[ s16 f16] s16 g16[ s16 e16] s16 | % 91
      f16 d f a
    }
  >>
  d16 a16 d16 f16 a16 g16 f16 e16 | % 92
  d16 c16 b16 a16 gis16 fis16 e16 d16 c16 b16 a16 gis16 | % 93
  a16 b16 c16 d16 e16 fis16 gis16 a16 e16 a16 c,16 e16 | % 94
  a,16 a''16 e16 a16 c,16 e16 a,16 a'16 e16 a16 c,16 e16 | % 95
  <<
    {
      s16 a,16 e'16 a,16 s16 a16 e'16 a,16 s16 a16 e'16 a,16 | % 96
      s16 a16 e'16 a,16 s16 a16 e'16 a,16 s16 a16 e'16 a,16 | % 97
      s16 a16 e'16 a,16 s16 a16 e'16 a,16 s16 a16 e'16 a,16 | % 98
      s16 a16 e'16 a,16 s16 a16 e'16 a,16 s16 a16 e'16 a,16 | % 99
      s16 <a e'>16[ s16 <a e'>16] s16 <a e'>16[ s16 <a e'>16] s16 <a e'>16[ s16 <a e'>16] | % 100
      s16 <a e'>16[ s16 <a e'>16] s16 <a e'>16[ s16 <a e'>16] s16 <a e'>16[ s16 <a e'>16] | % 101
    }
    \\
    {
      a16 s8. b16 s8. c16 s8. | % 96
      d16 s8. c16 s8. b16 s8. | % 97
      a16 s8. b16 s8. c16 s8. | % 98
      d16 s8. c16 s8. b16 s8. | % 99
      c16[ s c] s b[ s c] s d[ s b] s | %100
      c16[ s c] s b[ s c] s d[ s b] s | %101
    }
  >>
  \oneVoice
  c16 a16 c16 e16 a16 e16 a16 c16 e16 d16 c16 b16 | % 102
  a16 g16 fis16 e16 dis16 cis16 b16 a16 g16 fis16 e16 dis16 | % 103
  e16 fis16 g16 a16 b16 cis16 dis16 e16 b16 e16 g,16 b16 | % 104
  e,16 e'16 b16 e16 g,16 b16 e,16 e'16 b16 e16 g,16 b16 | % 105
  e,16 g16 b16 e16 g16 b,16 e16 g16 bes16 a16 g16 f16 | % 106
  e16 f16 g16 f16 e16 d16 cis16 b16 a16 g16 f16 e16 | % 107
  d16 e16 f16 g16 a16 b16 cis16 d16 a16 d16 f,16 a16 | % 108
  d,16 d''16 a16 d16 f,16 a16 d,16 f16 a,16 d16 f,16 a16 | % 109
  bes,16 c16 d16 es16 f16 g16 a16 bes16 f16 bes16 d,16 f16 | % 110
  g,16 a16 bes16 c16 d16 e16 f16 g16 a16 bes16 c16 d16 | % 111
  e16 f16 g16 a16 bes16 a16 g16 f16 e16 d16 c16 bes16 | % 112
  a16 g16 f16 e16 d16 c16 bes16 a16 g16 f'16 g,16 e'16 | % 113
  f8^"(Tutti)" e16 d16 c8 bes8 a8 g8 | % 114
  a8 c8 f8 f8 f8 f8 | % 115
  e8 c16^"(Solo)" d16 e16 f16 g16 d16 e16 c16 g'16 d16 | % 116
  e8 g8^"(Tutti)" c8 c8 c8 c8 | % 117
  bes8 g,16^"(Solo)" a16 bes16 c16 d16 a16 bes16 g16 d'16 a16 | % 118
  bes8 d8^"(Tutti)" g8 g8 g8 g8 | % 119
  \allowPageTurn g16 f16 g16 a16 bes8 bes8 bes8 bes8 | % 120
  bes16 a16 bes16 c16 d8 d8 d8 d8 | % 121
  d8 c16 bes16 c8 a16 bes16 c8 c8 | % 122
  c8 bes16 a16 bes8 g16 a16 bes8 c16 d16 | % 123
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 124
  d8 bes16 a16 g8 g'16 fis16 g8 es8 | % 125
  c8( b8 c8) es16 d16 es8 c8 | % 126
  as8( g8 as8) c16 bes16 c8 as8 | % 127
  fis8 es'16( d16 es8) c16( bes16 c8) fis,8 | % 128
  g8 bes,8 c8 g'8 d8 fis8 | % 129
  g,16^"(Solo)" \slurDashed g'16( fis16 g16) bes16 g16( fis16 g16) d16 g16( fis16 g16) | % 130
  g,16 g'16( fis16 g16) bes16 g16( fis16 g16) d16 g16( fis16 g16) | % 131
  a,16 g'16( fis16 g16) c16 g16( fis16 g16) d16 g16( fis16 g16) | % 132
  a,16 g'16( fis16 g16) c16 g16( fis16 g16) d16 g16( fis16 g16) | % 133
  bes,16 g'16( fis16 g16) d'16 g,16( fis16 g16) d16 g16( fis16 g16) | % 134
  bes,16 g'16( fis16 g16) d'16 g,16( fis16 g16) d16 g16( fis16 g16) | % 135
  c,16 g'16( fis16 g16) es'16 g,16( fis16 g16) es'16 g,16( fis16 g16) | % 136
  c,16 g'16( fis16 g16) es'16 g,16( fis16 g16) es'16 g,16( fis16 g16) \slurSolid | % 137
  %   <fis' a, c,>2. | % 138
  %   <g bes, cis,>2. | % 139
  %   <c fis, a, d,>2. | % 140
  %   <b d, g,>4 <b cis, g>2 | % 141
  %   <a c, f,>2. | % 142
  %   <bes d, g,>2. | % 143
  %   <a g d,>2. | % 144
  %   <a f d,>2. | % 145
  %   <g f g, b,>2. | % 146
  %   <g es g, c,> | % 147
  %   <f es f, a,> | % 148
  %   <f d f, bes,> | % 149
  <<
    {
      fis'2. | g | a | bes | a | bes |
      g2. | f | f | es | es | d |
    }
    \\
    {
      d,2. | d | d | d | d | g |
      d2. | d | b | c | a | bes |
    }
    \\
    {
      a'2. | bes | c | cis | d | d |
      a2. | a | g | g | f | f |
    }
  >>
  g16 f'16 as,16 f'16 g,16 es'16 c16 es16 bes16 es16 c16 es16 | % 150
  f,16 es'16 g,16 es'16 f,16 d'16 bes16 d16 as16 d16 bes16 d16 | % 151
  es,16 d'16 f,16 d'16 es,16 c'16 a16 c16 g16 c16 a16 c16 | % 152
  d,16 c'16 es,16 c'16 d,16 bes'16 g16 bes16 f16 bes16 g16 bes16 | % 153
  es,16 bes'16 f16 bes16 g16 bes16 f16 bes16 es,16 bes'16 d,16 bes'16 | % 154
  es,16 a16 g16 a16 f16 a16 es16 a16 d,16 a'16 es16 a16 | % 155
  d,16 bes'16 es,16 c'16 f,16 d'16 g,16 es'16 a,16 f'16 bes,16 g'16 | % 156
  c,16 a'16 d,16 a'16 es16 a16 d,16 a'16 es16 a16 c,16 a'16 | % 157
  d,16 bes'16 bes,16 bes'16 c,16 bes'16 d,16 bes'16 es,16 a16 c,16 a'16 | % 158
  bes8^"(Tutti)" a16 g16 f8 es8 d8 c8 | % 159
  d8 bes8 bes'8 bes8 bes8 bes8 | % 160
  bes16^"(Solo)" d16 c16 bes16 a16 bes16 a16 bes16 bes8.\trill a32 bes32 | % 161
  c8 a16 bes16 c8 b16 c16 d8 c16 d16 | % 162
  g,8 c,8 c'8 c8 c c | % 163
  c8 c8 bes16 d16 c16 bes16 a16 c16 bes16 a16 | % 164
  g8 \ottava #-1 \set Staff.ottavation = #"Ossia 8vb" g,, bes d g fis | % 165
  g8 \ottava #0 g16^"(Tutti)" a16 bes8 a16 bes16 c8 bes16 c16 | % 166
  \allowPageTurn d8 bes16 c16 d8 c16 d16 e8 d16 e16 | % 167
  f8 d16 e16 f8 e16 f16 g8 f16 g16 | % 168
  a8 a,8 a'8 g8 fis8 d8 | % 169
  g8 g,16 fis16 g8 g16 a16 bes8 c16 d16 | % 170
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 171
  d8 bes16 a16 g8 g'16 fis16 g8 es8 | % 172
  c8( b8 c8) es16 d16 es8 c8 | % 173
  as8( g8 as8) c16 b16 c8 as8 | % 174
  fis8 es16 d16 es8 c16 bes16 c8 fis8 | % 175
  g8 bes,8 c8 g'8 d8 fis8 | % 176
  g,2.\paren\p~ | % 177
  g2.~ | % 178
  g2.~ | % 179
  g4. g'16\paren\f a16 bes8 c16 d16 | % 180
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 181
  d8 bes16 a16 g8 r8 r4 | % 182
  as4^"(Solo)" r4 r4 | % 183
  c4 r4 r4 | % 184
  r8 es16(^"(Tutti)" d16 es8) c16( b16 c8) fis8 | % 185
  g8.^"(Solo)" a16 a4.-\trill g8 | % 186
  g8 bes16 a16 bes16 c16 bes16 a16 g16 a16 bes16 g16 | % 187
  e16 d16 c16 bes16 c16 d16 c16 bes16 a16 bes16 c16 a16 | % 188
  f8 a'16 g16 a16 bes16 a16 g16 f16 g16 a16 f16 | % 189
  d16 c16 bes16 a16 bes16 c16 bes16 a16 g16 a16 bes16 g16 | % 190
  e8 g'16 f16 g16 a16 g16 f16 e16 f16 g16 e16 | % 191
  cis16 b16 a16 gis16 a16 bes16 a16 g16 f16 g16 a16 f16 | % 192
  d16 e f g a16 b16 cis16 d16 cis16 d16 cis16 d16 | % 193
  e,8 f16 g a b16 cis16 d16 cis16 d16 cis16 d16 | % 194
  f,16 e f g a16 b16 cis16 d16 cis16 d16 cis16 d16 | % 195
  g,16 fis g a bes16 d16 cis16 d16 cis16 d16 cis16 d16 | % 196
  a8 bes16 c d16 e16 fis16 g16 fis16 g16 fis16 g16 | % 197
  bes,16 a bes c d16 e16 fis16 g16 fis16 g16 fis16 g16 | % 198
  b,16 a b c d16 e16 f16 a16 gis16 a16 gis16 a16 | % 199
  c,16 b c d e16 f16 gis16 a16 gis a gis a | % 200
  cis,16 d16 e16 g16 e16 f16 g16 bes16 g16 a16 bes16 cis16 | % 201
  fis,16 g16 a16 d16 d,16 e16 fis16 a16 c,16 d16 es16 fis16 | % 202
  b,16 c16 d16 f16 d16 e16 f16 as16 f16 g16 as16 b16 | % 203
  e,16 f16 g16 c16 c,16 d16 e16 g16 bes,16 c16 des16 e16 | % 204
  a,16 bes16 c16 es16 c16 d16 es16 ges16 es16 f16 ges16 a16 | % 205
  d,16 es16 f16 bes16 bes,16 c16 d16 f16 f,16 g16 as16 d16 | % 206
  g,16 as16 bes16 es16 es,16 f16 g16 bes16 es16 f16 g16 bes16 | % 207
  c,16 des16 es16 ges16 a,16 bes16 c16 es16 es,16 f16 ges16 c16 | % 208
  a,8 f'16 g16 a16 bes16 c16 g16 a16 f16 c'16 a16 | % 209
  es'16 d16 c16 bes16 c16 d16 es16 bes16 c16 a16 es'16 c16 | % 210
  ges'16 f16 es16 d16 es16 f16 ges16 es16 a16 f16 c'16 es,16 | % 211
  d8 bes8^"(Tutti)" es,8 bes'8 f8 a8 | % 212
  bes,8^"(Solo)" bes''16 a16 bes8 f16 es16 f8 d16 c16 | % 213
  d8 bes16 a16 bes8 r8 r4 | % 214
  r8 f16 e16 f8 a16 g16 a8 c16 bes16 | % 215
  c8 es16 d16 es8 r8 r4 | % 216
  r8 g16 fis16 g8 d16 c16 d8 bes16 a16 | % 217
  bes8 g16 fis16 g8 bes16 a16 bes8 e16 d16 | % 218
  e8 cis16 b16 cis8 a16 g16 a8 f16 e16 | % 219
  f8 d16 cis16 d8 f16 e16 f8 b16 a16 | % 220
  b8 gis16 fis16 gis8 e16 d16 e8 cis16 b16 | % 221
  cis8 a16 gis16 a8 cis16 b16 cis8 e16 d16 | % 222
  e8 g16 f16 g8 bes16 a16 bes8 d16 cis16 | % 223
  d8^"(Tutti)" c16 bes16 a8 g8 f8 e8 | % 224
  \allowPageTurn f8 d8 d'8 d8 d8 d8 | % 225
  d16 c16 d16 e16 f8 f8 f8 f8 | % 226
  f16 e16 f16 g16 a8 a8 a8 a8 | % 227
  a8 g16 f16 g8 e16 f16 g8 g8 | % 228
  g8 d'16^"(Solo)" cis16 d8 a16 g16 a8 f16 e16 | % 229
  f8 d16 cis16 d8 f16 e16 f8 bes16 a16 | % 230
  bes8 c,16 b16 c8 e16 d16 e8 a16 g16 | % 231
  a8 bes,16 a16 bes8 d16 cis16 d8 g16 fis16 | % 232
  g8 a,8 a8 g'8 g16 a16 bes16 g16 | % 233
  cis8 a,8 a8 cis'8 cis16 d16 e16 cis16 | % 234
  g16 cis16( d16 e16) g,16 cis16( d16 e16) g,16 cis16( d16 e16) | % 235
  fis,16 c'16( d16 es16) fis,16 c'16( d16 es16) fis,16 c'16( d16 es16) | % 236
  f,16 b16( c16 d16) f,16 b16( c16 d16) f,16 b16( c16 d16) | % 237
  e,16 bes'16( c16 des16) e,16 bes'16( c16 des16) e,16 bes'16( c16 des16) | % 238
  es,16 a16( bes16 c16) es,16 a16( bes16 c16) es,16 a16( bes16 c16) | % 239
  d,16 bes'16( fis16 g16) es16 bes'16( fis16 g16) d16 bes'16( fis16 g16) | % 240
  cis,8 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 g16 | % 241
  e16 d16 cis16 d16 e16 f16 g16 a16 bes16 a16 bes16 g16 | % 242
  cis16 b16 a16 b16 cis16 d16 e16 f16 g16 f16 g16 e16 | % 243
  a16 f16 d16 a16 a'16 f16 d16 a16 a16 d16 f16 a16 | % 244
  g16 e16 cis16 a16 g'16 e16 cis16 a16 a16 cis16 e16 g16 | % 245
  f16 d16 bes16 a16 f'16 d16 bes16 a16 a16 bes16 d16 f16 | % 246
  e16 cis16 bes16 a16 e'16 cis16 bes16 a16 a16 bes16 cis16 e16 | % 247
  f16 d16 bes16 a16 f'16 d16 bes16 a16 a16 bes16 d16 f16 | % 248
  gis16 f16 d16 a16 gis'16 f16 d16 a16 a16 d16 f16 gis16 | % 249
  a16 e16 f16 a16 a16 d,16 e16 a16 a16 cis,16 d16 a'16 | % 250
  a16 b,16 cis16 e16 a16 e16 cis16 a16 g16 a16 bes16 cis16 | % 251
  d16 a16 bes16 d16 d16 g,16 a16 d16 d16 f,16 g16 d'16 | % 252
  d16 e,16 f16 a16 d16 a16 f16 d16 c16 d16 es16 fis'16 | % 253
  g16 d16 es16 g16 g16 c,16 d16 g16 g16 bes,16 c16 g'16 | % 254
  g16 a,16 bes16 d16 g16 d16 bes16 g16 f16 g16 as16 b16 | % 255
  c16 g16 a16 c16 c16 f,16 g16 c16 c16 e,16 f16 c'16 | % 256
  c16 d,16 e16 g16 c16 g16 e16 c16 bes16 c16 des16 e'16 | % 257
  f16 c16 d16 f16 f16 bes,16 c16 f16 f16 a,16 bes16 f'16 | % 258
  f16 g,16 a16 c16 f16 c16 a16 f16 es16 f16 ges16 a16 | % 259
  bes16 f16 g16 bes16 bes16 es,16 f16 bes16 bes16 d,16 es16 bes'16 | % 260
  bes16 c,16 d16 f16 bes16 f16 d16 bes16 as16 bes16 ces16 d16 | % 261
  es16 bes16 c16 es16 es16 as,16 bes16 es16 es16 g,16 as16 es'16 | % 262
  es16 f, g bes es bes g es g bes es bes |
  g'16 es bes' g es g bes, es g, bes es, g |
  <<
    {g'2.^\markup {\column {"ad libitum" arpeggio}} f e a g g g f f e bes' a b e, bes' e,}
    \\
    {cis, b a a a a d d g, g g g gis a a a}
    \\
    {a' d cis d d cis a c bes bes d cis d d d cis}
    \\
    {e,2. gis g f e e s s d g f e f e g g}
  >>
  <<{d'8[ c16^"(Tutti)" bes16]}\\{a,8 s8}\\{f'8 s8}>> a8 g8 f8 e8 | % 281
  \allowPageTurn f8 d8 d'8 d8 d8 d8 | % 282
  d16 c16 d16 e16 f8 f8 f8 f8 | % 276
  f16 e16 f16 g16 a8 a8 a8 a8 | % 277
  a8 g16 f16 g8 e16 f16 g8 g8 | % 278
  g8 f16 e16 f8 d16 e16 f8 g16 a16 | % 279
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 280
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 281
  g8( fis8 g8) bes16 a16 bes8 g8 | % 282
  es8( d8 es8) g16 fis16 g8 es8 | % 283
  cis8 bes'16( a16 bes8) g16( fis16 g8) cis,8 | % 284
  d8 f,8 g8 d'8 a8 cis8 | % 285
  d4\fermata r4 r4 | % 286
  \bar "|."

}
