\version "2.20.0"

\header {
  title = "Concerto for Violin, Strings and Continuo in D Minor BWV 1052R"
  subtitle = "Reconstructed from BWV 146/1, 146/2, 188/1, 1052a, and 1052"
  composer = "Johann Sebastian Bach (1685 - 1750)"
  arranger = "Reconstructed by Jun Tamura (b. 1959)"
  copyright = "Reconstruction ©2019-20 Jun Tamura (CC BY 4.0), continuo realization partly by Robert Reitz (1917)"
  instrument = \instrument
}

pieceA = \markup { \fontsize #2 \bold "1." }
pieceB = \markup { \fontsize #2 \bold "2." }
pieceC = \markup { \fontsize #2 \bold "3." }

edition = \markup {\fontsize #-2 "Violin Concerto BWV 1052R reconstructed by Jun Tamura edition 1 May 2020"}