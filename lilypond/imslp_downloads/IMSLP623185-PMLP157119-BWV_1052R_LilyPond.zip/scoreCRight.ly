\version "2.18.2"
\language "nederlands"
scoreCRight = \relative c' {
  \scoreCGlobal

  R2. | % 1
  r8 <f d>8 <a f d>4 <bes e, d> | % 2
  << a4 \\{<e d>8[ <f c>]}>> <c' f, c>4 <d g, f> | % 3
  << c4 \\{<g f>8[ <a e>]}>> <e' a, e>4 <f b, a> | % 4
  << <e b>4. \\{a,8( g4)}>> <e' b g>8 <e a, g> <cis a g> | % 5
  << <d a>4. \\{g,8( f4)}>> <a f>8 <d a f>4 | % 6
  <d bes g>4 <e bes g>2 | % 7
  <e c a>4 << <d bes>2 \\{f,4 g}>> | % 8
  <<{cis8[ d e d]}\\{<bes g>4 <bes g>}>> <cis bes g>8 <d a> | % 9
  <es bes g>4. <c g es>8 <<{d8( bes)}\\<g d>4 >> | % 10
  <a e cis>4 r4 r8 <a e cis>8 | % 11
  <a d,>8 <d a f> <<{<d g,>8[ <bes f>] a[ g]}\\{d4 <e cis>}>> | % 12
  <a f d>4 r4 r | % 13
  r8 <a f>8 <c a f>4 <d bes e,> | % 14
  <<{d8[ c]}\\<a e>4>> r4 r | % 15
  r8 <c a>8 <e c a>4 <f b, a> | % 16
  << <e b>4. \\{a,8( g4)}>> <e' b g>8\noBeam <e a, g> <cis a g> | % 17
  <<{<d a>8 r8}\\{g,8[( f])}>> r4 r | % 18
  r4 r8 <a f>8 <d g, d> <bes f d> | % 19
  <bes e,>4 r8 <a e>8 <c f, c> <a e c> | % 20
  <a d,>4 r8 <g d>8 <bes e, bes> <g e d> | % 21
  <a e cis>4 r4 r | % 22
  <cis a e>4 r4 r | % 23
  <c a es>4 r4 r | % 24
  <b g d>4 r4 r | % 25
  <cis g e>4 r4 r | % 26
  <cis a e>4 r8 <cis g>8 <<{e8 cis}\\ <a g>4 >> | % 27
  <d a f>8 <a f e> <g d>4 <d' g, d> | % 28
  <c a e>4 r4 r | % 29
  r8 <e, c>8 <a e c>4 <a f c> | % 30
  <<{<a b,>8[ <g c,>]}\\ e4 >> <c' g c,>4 <c a e> | % 31
  <<{<c d,>8[ <b e,>]}\\ g4 >> <e' b e,>4 <c g e> | % 32
  << <b fis>4. \\{e,8( d4)}>> <b' f d>8 <b e, d> <gis e d> | % 33
  << <a e>4. \\{d,8( c4)}>> <e c>8 <a e c>4 | % 34
  <a f d>4 <b f d>2 | % 35
  <b g e>4 << <a f>2 \\{c,4 d}>> | % 36
  <b' f d>4. <a f d>8\noBeam <gis d> <a e> | % 37
  <bes f d>2 << <a f>4 \\{d,8 c}>> | % 38
  <gis' e b>4 r4 r8 <b gis e> | % 39
  <a e>8[ <c a e>] <d a d,>[ <b a f>] <b gis e>4 | % 40
  <c a e>4 r4 r | % 41
  r8 <c a>8 <e c a>4 <f b, a> | % 42
  << <e b>4 \\{a,8[ g]}>> r4 r | % 43
  r8 <b g>8 <e b g>4 <<{e8 cis}\\ <a g>4 >> | % 44
  << <d a>4 \\{g,8[ f]}>> <a f>4 <d a f> | % 45
  <d bes g>8 r8 r4 r | % 46
  r8 <g, e>8 <c g e>4 <c g e> | % 47
  <c a e>8 r8 r4 r | % 48
  r8 <f, d>8 <bes f d>4 <bes f d> | % 49
  <bes g c,>2. | % 50
  <bes g c,>2. | % 51
  <bes g c,>2. | % 52
  <bes g c,>2 r8 <g e c>8 | % 53
  <a f c>4 <bes f bes,>8[ <g f d>] <a f c>[ <g e c>] | % 54
  <a f c>4 r4 r | % 55
  r8 <a f>8 <c a f>4 <d a f> | % 56
  <<{<c g>4 r4}\\{f,4( e8) r8}>> r4 | % 57
  r8 <g e>8 <c g e>4 <c a es> | % 58
  <<{c4( bes8) r8}\\{<g d>4 r4}>> r4 | % 59
  r8 <bes g>8 <d g,>4 <e a, g> | % 60
  << <d a>4. \\{g,4( f8)}>> <cis' a e>8 <d a f> <c g> | % 61
  <d a>8 <a f>4 <a f d>8 <g e bes>4 | % 62
  <a e a,>8[ <f d>] <a f c>4 <b g d> | % 63
  <c g c,>8[ <a f>] <c a e>4 <d a f> | % 64
  <e b e,>4 <b e,> <cis a e>8 <cis a e> | %65
  <c a d,>4 <a f> << d4 \\{f,8 a}>> | % 66
  <d bes g>4 <e bes g>2 | %67
  <e c a>4 << <d bes>2 \\{f,4 g}>> | % 68
  <<{cis8[ d e d]}\\{<bes g>4 <bes g>}>> <cis bes g>8 <d a> | % 69
  <es bes g>4. <c g es>8 <<{<d d,>8( <bes es,>)}\\ g4 >> | % 70
  <a e cis>4 r4 r8 <a e cis> | % 71
  <a d,>8 <d a f> <<{<d g,>8( <bes f>) a( g)}\\{d4 <e cis>}>> | % 72
  <f d>4 r8 <<{g8 f e}\\{d4 d8}>> | % 73
  <a d>4 r8 <<{f'16 g a8 a16 bes}\\{d,4 d8}>> | % 74
  <c' d,>4 r8 <<{fis,16 g a8 g16 fis}\\{c4 c8}>> | % 75
  <g' c,>4 <d bes>8 <g d bes>8 <bes g d>4 | % 76
  <bes f d>4( <a f d>8) <d a f>4 <cis g>16 <d a> | % 77
  <d bes g>4 <e bes g>2 | % 78
  <f c a>4 <d bes f>8 bes16[ a bes8] <g d> | % 79
  <bes es, bes>4. g16[ fis g8] <bes es,> | % 80
  <c bes g>4. bes16[ a bes8] <bes g> | % 81
  <e bes g>8 \slurDashed bes16( a bes8) g16( fis g8) \slurSolid <a e cis>8 | % 82
  <a d,>8 <d a f>8 << d4 \\{<g, d>8[ <bes e,>]}>> <d a e>8 <cis a e> | %83
  <d a f>4 r4 r | % 84
  <a f d>4 r4 r | % 85
  <f d a>4 r4 r | % 86
  R2. | % 87
  <f d a>4 r4 r | % 88
  R2. | % 89
  <f d a>4 r4 r | % 90
  R2. | % 91
  r8 <f d>8 <a d,>4 <d a f> | % 92
  <d gis, d>4 <b e, d> r4 | % 93
  <a e c>4 r4 r | % 94
  <a e c>4 r4 r | % 95
  <c a e>4 r4 r | % 96
  R2. | % 97
  <c a e>4 r4 r | % 98
  R2. | % 99
  <c a e c>4 r4 r | % 100
  R2. | % 101
  r8 <c a>8 <e a,>4 <e c a> | % 102
  <dis a>4 <fis b, fis> r4 | % 103
  <e b g>4 r4 r | % 104
  <e b g>4 r4 r | % 105
  r8 <g, e>8 <b e,>4 <e bes g> | % 106
  <e a, e>4 <cis a e> r4 | % 107
  <d a f>4 r4 r | % 108
  r8 <a f>8 <a d,>4 <d a f> | % 109
  r8 <d bes f>8 <bes f>4 <d bes f> | % 110
  r8 <bes g>8 <g d>4 <bes g d> | % 111
  <c g e>4 r4 r | % 112
  <<
    { a8[ c] <bes f d>[ <a f c>] f[ e] }
    \\
    { <f c>4 s4 <g c,> }
  >> | % 113
  <a f c>4 r4 r | % 114
  r8 <a f>8 <c f,>4 <d g, f> | % 115
  <c g e>4 r4 r | % 116
  r8 <g e>8 <c g e>4 <c a d,> | % 117
  <bes g d>4 r4 r | % 118
  r8 <d, bes>8 <g d bes>4 <g es a,> | % 119
  <g d a>8 <f d> <bes f d>4 <bes g c,> | % 120
  <bes f c>8 <a f> <d a f>4 <d bes e,> | % 121
  <<
    { d8( c4) <c a e>8\noBeam a8 fis }
    \\
    {<a e>4. s8 <c d,>4}
  >> | % 122
  <<{c8( bes4)}\\ <g d>4. >> <bes g d>8 <bes g es>4 | % 123
  <bes g es>4 <a f es>2 | %124
  <a f d>4 <g es d>2 | % 125
  <g es c>4 <<{a8 g fis g}\\{<es c>4 <es c>}>> | % 126
  <as es c>2 <<{g8 as}\\ <es c>4 >> | % 127
  <fis d c>4 r4 r8 <a f d>8 | % 128
  <g d>8[ <bes g d>] <c g c,>[ <a g es>] <bes g d>[ <a fis c>] | % 129
  <g d bes>4 <d bes> r4 | % 130
  r8 <d bes>8 <g d bes>4 <bes g d> | % 131
  <fis c>4 <c' fis, c> r4 | % 132
  r8 <fis, c>8 <a d,>4 <a fis d> | % 133
  <g d>4 <d' g, d> r4 | % 134
  r8 <g, d>8 <bes g d>4 <<{a8( b)}\\ <g d>4 >> | % 135
  <c g es>4 <g es> r4 | % 136
  r8 <g es>8 <<{<c es,>4 <c a>}\\{fis,8[ g] e[ g]}>> | % 137
  <c a fis>4 r4 r | % 138
  <bes g e cis>4 r4 r | % 139
  <a fis d c>4 r4 r | % 140
  <g d bes>4 r4 r | % 141
  <fis d a>4 r4 r8 <a fis d>8 | % 142
  <<{bes8[ a] bes[ c]}\\{d,4 <g d>}>> <d' g, d>4 | % 143
  <a g>4 <a g d> r4 | % 144
  r8 <f d>8 <a d,>4 <d a f> | % 145
  <d g, d>4 <b g d> r4 | % 146
  r8 <g es>8 <g c,>4 <c g es> | % 147
  <c f, c>4 <a f c> r4 | % 148
  r8 <f d>8 <f bes,>4 <bes f d> | % 149
  <bes g d>4 <g es> r4 | % 150
  <c f,es>4 <bes f d> r4 | % 151
  <bes es, d>4 <a es c> r4 | % 152
  <a d, c>4 <g d bes> r4 | % 153
  <g es bes>4 <<{g8[ f] es[ g]}\\{<c, bes>4 bes4}>> | % 154
  <f' d a>2 <a f c>4 | % 155
  <bes f d>4 r8 <g es>8 <a f> <bes es,> | % 156
  <c a es>8 <a es>4 <<{c16[ bes c8]}\\ <f, es>4 >> <a f es>8 | % 157
  << <bes d,>4 \\{f8[ g]}>> <bes g c,>4 <a f c> | % 158
  <bes f d>4 r4 r | % 159
  r8 <f d>8 <bes f d>4 <bes g c,> | % 160
  <<{bes4( a)}\\ <f c>2 >> r4 | % 161
  r8 <a f>8 <c a f>4 <d as f> | % 162
  <<
    c2
    \\
    {as4( g)}
    \\
    \voiceFour {f4( es)}
  >> r4 | % 163
  r8 <g es>8 <c g>4 <c a d,> | % 164
  <<
    {c4( bes) c}
    \\
    {d,2 d4}
    \\
    {a'4( g) g8 fis}
  >> | % 165
  <d' g, d>8 <bes g d>4 <bes g d>8 <c a es>4 | % 166
  <d a d,>8[ <bes g>] <d bes f>4 <e c g> | % 167
  <f c f,>8[ <d bes>] <f d a>4 <e bes g> | % 168
  <e a, e>4. <c a g>8 <c a fis>4 | % 169
  <d g, d>4. <bes g d>8 <<{bes8 d}\\ <g, d>4 >> | % 170
  <c g es>4 <a f c>2 | % 171
  <bes f d>4 <g es bes>2 | % 172
  <a es c>4. <g es c>8 <<{fis8 g}\\ <es c>4 >> | % 173
  <<{as2 g8( as)}\\{<es c>4. <f b,>8 <es c>4}>> | % 174
  <fis d a>4 r4 r8 <a fis d> | % 175
  <g d>8[ <bes f d>] <c f ,c>[ <a f es>] <<{bes8 a}\\ <fis d>4 >> | % 176
  <d' g, d>4 r8 <c f,>8 <b g> <d a> | % 177
  <c g>4 <<{d8 b g b}\\{g4 f}>> | % 178
  << c'4 \\{f,8[( es])}>> <g es>8 <g es> <g es>4 | % 179
  <<
    {g4 <g d>8 <bes g d> bes d}
    \\
    {es,8 d s4 <g d>4}
  >> | % 180
  <c g es>4 <a f c>2 | % 181
  <bes g d>4 <g es bes>8 r8 r4 | % 182
  <f c a>4 r4 r | % 183
  <as f c>4 r4 r | % 184
  r8 \slurDashed es'16( d es8) c16( b c8) <a fis d>8 | % 185
  <g d>8 <bes g d> <a g es> <c g es> <<{g8 fis}\\ <a d,>4 >> | % 186
  <bes g d>8 <g d bes>4 <d bes> <g d bes>8 | % 187
  <g e bes>4. e8 f g | % 188
  <a f c>8 <f c a>4 <c a> <f c a>8 | % 189
  <f d a>4. d8 e f | % 190
  <g e b>8 <e b g>4 <b g> <e b g>8 | % 191
  <e cis g>4. cis8 d e | % 191
  <f d a>4 r4 r | % 192
  R2. * 15 | % 208
  <c' f, es>2. | % 209
  <c f, es>2. | % 210
  <c f, es>2. | % 211
  <f, d>8 <bes f d> <bes g c,>4 <<{bes8 a}\\ <f c>4 >> | % 212
  <bes f d>8 r8 r4 r4 | % 213
  r8 <f d>8 <bes f d>4 <bes g c,> | % 214
  <<{bes8[( a])}\\ <f c>4 >> r4 r | % 215
  r8 <fis c>8 <c' fis, c>4 <c a d,> | % 216
  <<{c8[( bes])}\\ <g d>4 >> r4 r | % 217
  r8 <g d bes>8 <bes g d>4 <bes g d> | % 218
  <bes g e>8 r8 r4 r | % 219
  r8 <a f d>8 <f d a>4 <a f d> | % 220
  <b f d>8 r8 r4 r | % 221
  <a e cis>8 r8 r4 r | % 222
  R2. * 2 | % 224
  r8 <f d>8 <a f d>4 <bes e, d> | % 225
  << a4 \\{<e d>8[ <f c>]}>> <c' f, c>4 <d g, f> | % 226
  << c4 \\{<g f>8[ <a e>]}>> <e' a, e>4 <f b, a> | % 227
  << <e b>4. \\{a,8( g4)}>> <e' b g>8 <e a, g> <cis a g> | % 228
  <d a f>8 r8 r4 r | % 229
  r4 r8 <a f>8 <<{d8 bes}\\ <g f>4 >> | % 230
  <c g e>4 r8 <g e>8 <<{c8 a}\\ <f e>4 >> | % 231
  <bes f d>4 r8 <f d>8 <<{bes8 g}\\ <e d>4 >> | % 232
  <a e cis>4 r4 r | % 233
  <cis a e>4 r4 r | % 234
  r8 <cis a e>8 <<{cis8 e cis e}\\{<a, g>4 <a g>}>> | % 235
  <d a fis>4 r4 r | % 236
  r8 <b g d>8 <<{b8 d b d}\\{<g, f>4 <g f>}>> | % 237
  <c g e>4 r4 r | % 238
  r8 <a f c>8 <<{a8 c a c}\\{<f, es>4 <f es>}>> | % 239
  <bes f d>4 <bes es,> <bes f d> | % 240
  <a e cis>4 r4 r | % 241
  R2. * 2 | % 243
  <d a d,>4 r4 r | % 244
  <a g e>4 r4 r | % 245
  <d a f>4 r4 r | % 246
  <cis a e>4 r4 r | % 247
  <d a f>4 r4 r | % 248
  <d b gis f>4 r4 r | % 249
  <cis a e>4 r4 r | %250
  R2. * 30 | % 280
  R2. | % 281
  r8 <f, d>8 <a f d>4 <bes e, d> | % 2
  << a4 \\{<e d>8[ <f c>]}>> <c' f, c>4 <d g, f> | % 3
  << c4 \\{<g f>8[ <a e>]}>> <e' a, e>4 <f b, a> | % 4
  << <e b>4. \\{a,8( g4)}>> <e' b g>8 <e a, g> <cis a g> | % 5
  << <d a>4. \\{g,8( f4)}>> <a f>8 <d a f>4 | % 6
  <d bes g>4 <e bes g>2 | % 7
  <e c a>4 << <d bes>2 \\{f,4 g}>> | % 8
  <<{cis8[ d e d]}\\{<bes g>4 <bes g>}>> <cis bes g>8 <d a> | % 9
  <es bes g>4. <c g es>8 <<{d8( bes)}\\<g d>4 >> | % 10
  <a e cis>4 r4 r8 <a e cis>8 | % 11
  <a d,>8 <d a f> <d g, d>8[ <bes f d>] <a e cis>[ <cis a e>] | % 12
  <d a f d>4\fermata r4 r | % 13




  \bar "|."
}
