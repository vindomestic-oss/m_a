\version "2.18.0"
\language "nederlands"
scoreBRight = \relative c' {
  \scoreBGlobal
  R2. * 13 | % 13
  <bes' g d>4 <d g, d> <<{bes8 a}\\fis4>> | % 14
  <g d>4 <c g c,> r | % 15
  <fis, es c>4 <a fis es> <c a fis> | % 16
  <c a d,>4 <a fis c> <fis d> | % 17
  <a fis c>4 <a d, c> <fis c> | % 18
  <g d>2 <bes g d>4 | % 19
  <a g es>2 <a g c>4 | % 20
  <a fis c>2 <a d, c>4 | % 21
  <g es bes>4 r8 <g es b>8 <f c> <as f c> | % 22
  <d as f>4 <b as f> <b as d,> | % 23
  <b f d>4 r8 <b f d>8 <c g c,> <g es> | % 24
  <f c>8 <as d, c> <g es c>4 <b g d> | % 25
  <c g es>4 r4 r | % 26
  <es, c>4 <g c,> <c g es> | % 27
  <cis g e>4 <a e> <cis g e> | % 28
  <d a f>4 r4 r4 | % 29
  <d a f>4 <a d,> <<{<a cis,>4}\\{f8 e}>> | % 30
  <bes' f d>4 <bes g d> r4 | % 31
  <bes g cis,>4 <bes e, cis> <g e cis> | % 32
  <a g e>4 <cis a g> <cis a e> | % 33
  <cis a g>4 <e a, e> <cis a g> | % 34
  <d a d,>2 <a f>4 | % 35
  <bes e, d>2 <g e d>4 | % 36
  <cis g e>2 <a g e>4 | % 37
  <bes f d>4 r8 <bes fis d>8 <g c,> <a g es> | % 38
  <c a es>4 <c fis, es> <a fis es> | % 39
  <a f c>4 r8 <c g es>8 <bes f d> <a f es> | % 40
  <<bes4\\{<f d>8[ <g c,>]}>> <bes f d>4 <a f c> | % 41
  <bes f d>4 r4 r | % 42
  <d g, d>4 <b g f> <b g d> | % 43
  <d b f>2 r4 | % 44
  <g, es>4 <c g es> <<{<b g>4}\\{es8 d}>> | % 45
  <c as es>2 r4 | % 46
  <b as f>4 <b as d,> <b f d> | % 47
  <d e, d>4 <b f> <c as es> | % 48
  <b as f>4 <d g, d> <b f d> | % 49
  <<
    {
      <b d,>4( <c c,>) <d f,>8 <c e,> | % 50
      c4( des) d8( c) |% 51
    }
    \\
    {
      g2 as4 | % 50
      <as f>2 <g f>4 | % 51
    }
  >>
  <b g f>2 <d g, f>4 | % 52
  <c as es>4 r8 <as e>8 <bes f> <g des> | % 53
  <bes g des>4 <bes e, bes> <g e des> | % 54
  <g e bes>4 r8 <e bes>8 <f c> <as es c> | % 55
  <as d,>8 <g es> <c g es>4 <b g d> | % 56
  <c g es>4 r4 r | % 57
  <c fis, c>4 <a fis es> <g c,> | % 58
  <a es c>4 <fis c> <a fis d> | % 59
  <a fis c>4 r4 r4 | % 60
  <bes g d>4 <d g, d> <<{bes8 a}\\fis4>> | % 61
  <bes g d>4 <c g c,> r | % 62
  <c fis, es>4 <a fis es> <c a fis> | % 63
  <c a d,>4 <c fis, d> <a fis es> | % 64
  <a fis d>4 <a d, c> <fis c> | % 65
  <g d>2 <a c,>8 <g bes,> | % 66
  <g es a,>2 <a g e>4 | % 67
  <a fis d>2 <a fis c>4 | % 68
  <g es bes>4 r8 <es bes>8 <f c> <as f c> | % 69
  <d as f>4 <b as f> <b as d,> | % 70
  <b f d>4 r8 <b f>8 <c g es> <b f d> | % 71
  <a es c>8 <g d b> <g c, g>4 r4 | % 72
  <g e bes>4 <<{g4( fis)}\\{<d a>2}>> | % 73
  <g d bes>4 r4 r4 | % 74
  R2. * 13

  \bar "|."
}
