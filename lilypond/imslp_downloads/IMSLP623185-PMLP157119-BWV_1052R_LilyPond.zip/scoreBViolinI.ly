\version "2.18.0"
\language "nederlands"
scoreBViolinI = \relative c'' {
  \scoreBGlobal

  g8( g8) bes8( bes8) d8( d8) | % 1
  es,8( d8) es4 r4 | % 2
  a8( a8) c8( c8) es8( es8) | % 3
  fis,8( fis8) a8( a8) c8( c8) | % 4
  d,8( d8) fis8( fis8) a8( a8) | % 5
  bes,8( a8 bes8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 6
  \slurSolid c,8( bes8 c8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 7
  \slurSolid d8( c8 d8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 8
  \slurSolid es4 r8 g8 as8 f8 | % 9
  b,8( b8) d8( d8) f8( f8) | % 10
  as,4 r8 d8 es8 c8 | % 11
  fis8 g8 d4 d4 | % 12
  g,4 r4 r4 | % 13
  d''4\p bes4 fis4 | % 14
  g8( fis8) g4 r4 | % 15
  c4 a4 fis4 | % 16
  d8( c8) d4 r4 | % 17
  a'8( g8) a4 r4 | % 18
  g4 bes4 d4 | % 19
  es4 g4 es4 | % 20
  c4 es4 d8 c8 | % 21
  bes8( fis8) g4 r4 | % 22
  as4 f4 d4 | % 23
  b4 r8 b'8 c8 es8 | % 24
  d8 c8 c4 b4 | % 25
  c4 r4 r4 | % 26
  c4 g4 es4 | % 27
  e'4 cis4 a4 | % 28
  a4 r4 r4 | % 29
  a'4 f4 cis4 | % 30
  d8( cis8) d4 r4 | % 31
  g4 e4 cis4 | % 32
  a8( g8) a4 r4 | % 33
  e'8( d8) e4 r4 | % 34
  d,4 f4 a4 | % 35
  bes4 d4 bes4 | % 36
  g4 bes4 a8( g8) | % 37
  f8 cis8 d4 r4 | % 38
  es'4 c4 a4 | % 39
  f?4 r8 es'8 d8 c8 | % 40
  bes4. c8 a4-\trill | % 41
  bes4 r4 r4 | % 42
  f'8.( g32 as32) g8( f8) es8( d8) | % 43
  \appoggiatura { c8 } b4 r4 r4 | % 44
  g'4 es4 b4 | % 45
  c8( b) c4
  r4 | % 46
  f4 d4 b4 | % 47
  g8( f8) g4 r4 | % 48
  f4 d4 b4 | % 49
  g4 c4 d8( f16 e16) | % 50
  f8( as16 g16) as4 d8( c8) | % 51
  b4 d4 f4 | % 52
  es4 r4 r4 | % 53
  des4 bes4 g4 | % 54
  e4 r8 e'8 f8 es8 | % 55
  d8 c8 es4( f8) d8 | % 56
  c4 r4 r4 | % 57
  es4 c4 a4 | % 58
  c4 a4 fis4 | % 59
  d4 r4 r4 | % 60
  d'4 bes4 fis4 | % 61
  g8( fis8) g4 r4 | % 62
  c4 a4 fis4 | % 63
  d8( c8) d4 r4 | % 64
  a'8( g8) a4 r4 | % 65
  g4 bes8( d8) c8( bes8) | % 66
  es4 g4 es4 | % 67
  c4 es4 d16 es16 c8 | % 68
  bes16 c16 a8 g4 r4 | % 69
  f'2.~ | % 70
  f4 r8 as8 g8 f8 | % 71
  es8( b8) c4 r4 | % 72
  g'8 a16 bes16 g4 fis8. g16 | % 73
  g4 r4 r4 | % 74
  g,8( g8) bes8( bes8) d8( d8) | % 75
  es,8( d8) es4 r4 | % 76
  a8( a8) c8( c8) es8( es8) | % 77
  fis,8( fis8) a8( a8) c8( c8) | % 78
  d,8( d8) fis8( fis8) a8( a8) | % 79
  bes,8( a8 bes8) bes'8-. fis8( g8) | % 80
  c,8( bes8 c8) bes'8-. fis8( g8) | % 81
  d8( c8 d8) bes'8-. fis8( g8) | % 82
  es4 r8 g8 as8 f8 | % 83
  b,8( b8) d8( d8) f8( f8) | % 84
  as,4 r8 d8 es8 c8 | % 85
  fis8 g8 d4 d4 | % 86
  g,4-\fermata r4 r4 | % 87

  \bar "|."

}
