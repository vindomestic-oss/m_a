\version "2.18.2"
\language "nederlands"
scoreCViola = \relative c' {
  \scoreCGlobal

  R4*3*1 | % 1
  r8 f16\paren\f g16 a8 g16 a16 bes8 bes | % 2
  e,8 a16 bes16 c8 bes16 c16 d8 d | % 3
  g,8 c,16 d16 e8 d16 e16 f8 f | % 4
  b,4 r16 b16 cis16 d16 e16 d16 cis16 b16 | % 5
  a4 r8 f'16 g16 a8 d,8 | % 6
  d'8 bes16 a16 g8 e16 f16 g8 c,8 | % 7
  c'8 a16 g16 f8 f8 bes8 d8 | % 8
  bes4 r8 g16( f16 g8) bes16( a16 | % 9
  bes8) a8 bes8 c8 d8 bes8 | % 10
  e,8 cis'8 cis8 cis8 cis8 e,8 | % 11
  a8 f8 d8 g8 e8 a8 | % 12
  f8 r8 r4 r4 | % 13
  r8 f16 g16 a8 g16 a16 bes8 a16 bes16 | % 14
  e,4 r4 r4 | % 15
  r8 c16 d16 e8 d16 e16 f8 e16 f16 | % 16
  b,8 cis16 d16 e16 d16 cis16 d16 e16 d16 cis16 b16 | % 17
  a4 r4 r4 | % 18
  R4*3*3 | % 21
  cis4\paren\p r4 r4 | % 22
  a4 r4 r4 | % 23
  R4*3*6 | % 29
  r8 e'16\f d16 c8 e8 c8 a8 | % 30
  e'8 g16 f16 e8 g8 e8 c8 | % 31
  g'8 b16 a16 g8 b8 g8 e8 | % 32
  b'4 r8 b8 e,8 gis8 | % 33
  a4 r8 e8 a8 g8 | % 34
  a4 r8 d,8 g8 f8 | % 35
  g4 r8 c,8 f8 a8 | % 36
  f4 r8 d16( c16 d8) f16( e16 | % 37
  f8) e8 f8 g8 a8 f8 | % 38
  b,8 gis'8 gis8 gis8 gis8 b8 | % 39
  e,8 e8 a8 f8 b,8 e8 | % 40
  c4 r4 r4 | % 41
  r8 c16 d16 e8 d16 e16 f8 e16 f16 | % 42
  b,4 r4 r4 | % 43
  r8 cis16 d16 e16 d16 cis16 d16 e16 d16 cis16 b16 | % 44
  a4 r8 a'8 d,8 e16 f16 | % 45
  g8 r8 r4 r4 | % 46
  r4 r8 g8 c,8 d16 e16 | % 47
  f8 r8 r4 r4 | % 48
  r4 r8 f8 bes,8 c16 d16 | % 49
  c2.\p~ | % 50
  c2.~ | % 51
  c2.~ | % 52
  c2 r8 c8 | % 53
  c8 c8 f8 d8 c8 g'8 | % 54
  a4\f r4 r4 | % 55
  r8 a,16 bes16 c8 bes16 c16 d8 c16 d16 | % 56
  g,4 r4 r4 | % 57
  r8 g'16 f16 e8 g8 es8 c8 | % 58
  g'8 f16 es16 d8 c8 bes8 a8 | % 59
  bes8 g8 g'8 g8 g8 g8 | % 60
  \slurDashed g16( bes16 a16 \slurSolid g16) f4 r4 | % 61
  r8 f16 g16 a8 g16 a16 bes8 a16 bes16 | % 62
  e,8 f8 c8 bes16 c16 d8 c16 d16 | % 63
  g,8 a'8 e8 d16 e16 f8 e16 f16 | % 64
  b,4 r8 g'16 f16 e16 d16 cis16 b16 | % 65
  a8 b16 cis16 d16 e16 f16 g16 a8 d,8 | % 66
  d'8 bes16 a16 g8 e16 f16 g8 c,8 | % 67
  c'8 a16 g16 f8 f8 bes8 d8 | % 68
  bes4 r8 g16( f16 g8) bes16( a16 | % 69
  bes8) a8 bes8 c8 d8 bes8 | % 70
  e,4 r4 r8 e8 | % 71
  a8 f8 d8 g8 e8 a8 | % 72
  d,8\paren\p c16 bes16 a8 g8 f8 e8 | % 73
  a8 d,8 d'8 d8 d8 d8 | % 74
  d8 c16 bes16 c8 a16 bes16 c8 c8 | % 75
  c8 bes16 a16 bes8 g16 a16 bes8 bes8 | % 76
  bes8 a16 g16 a8 f'16\f e16 d16 c16 bes16 a16 | % 77
  g8 bes'16 a16 g16 f16 e16 d16 c8 bes8 | % 78
  a8 b16 cis16 d8 r8 r4 | % 79
  g4\p r4 r4 | % 80
  bes,4 r4 r4 | % 81
  r8 \slurDashed bes'16(\f a16 bes8) \slurSolid g16( fis16 g8) e8 | % 82
  a8 f8 d8 g8 e8 a8 | % 83
  f4 r4 r4 | % 84
  R4*3*5 | % 89
  r8 d'8\p cis8 d8 e8 cis8 | % 90
  d8 f,8 g8 f8 e8 g8 | % 91
  f8 r8 r4 r4 | % 92
  R4*3*22 | % 114
  r8 a,16\f bes16 c8 bes16 c16 d8 c16 d16 | % 115
  g,4 r4 r4 | % 116
  r8 e'16 f16 g8 fis16 g16 a8 g16 a16 | % 117
  d,4 r4 r4 | % 118
  r8 bes16 c16 d8 c16 d16 es8 d16 es16 | % 119
  a,8 d16 e16 f8 e16 f16 g8 f16 g16 | % 120
  c,8 f16 g16 a8 g16 a16 bes8 a16 bes16 | % 121
  e,4 r16 e16 fis16 g16 a16 g16 fis16 e16 | % 122
  d4 r8 bes16 c16 d8 g,8 | % 123
  g'8 es16 d16 c8 a16 bes16 c8 f,8 | % 124
  f'8 d16 c16 bes8 bes8 es8 g8 | % 125
  es4 r8 \slurDashed c16( b16 c8) es16( d16 | % 126
  es8) d8 es8 f8 g8 es8 | % 127
  a,8 fis'8 fis8 fis8 fis8 a,8 | % 128
  d8 bes8 g8 c8 a8 d8 | % 129
  bes8 bes16\p c16 d8 c8 bes8 a8 | % 130
  g4 g'4 r4 | % 131
  r8 c,16 d16 es8 d8 c8 bes8 | % 132
  a4 a'4 r4 | % 133
  R4*3*1 | % 134
  r8 d,16 c16 bes8 a8 g8 b8 | % 135
  c4 r4 r4 | % 136
  r8 es16 d16 c8 bes8 a8 c8 | % 137
  d4 r4 r8 a'8 | % 138
  g4 r4 r8 e8 | % 139
  fis4 r4 r8 fis8 | % 140
  d4 r4 r8 d8 | % 141
  d8 a16( g16 a8) fis16( e16 fis8) r8 | % 142
  R4*3*1 | % 143
  r8 a'16 bes16 c8 bes8 a8 g8 | % 144
  f4 d'4 r4 | % 145
  r8 g,16 a16 b8 a8 g8 f8 | % 146
  es4 c'4 r4 | % 147
  r8 f,16 g16 a8 g8 f8 es8 | % 148
  d4 bes'4 r4 | % 149
  R4*3*10 | % 159
  r8 d,16\f es16 f8 es16 f16 g8 f16 g16 | % 160
  c,4 r4 r4 | % 161
  r8 c'16 bes16 a8 c8 as8 f8 | % 162
  c'8 bes16 as16 g8 f8 es8 d8 | % 163
  es8 c8 c'8 c8 c8 c8 | % 164
  \slurDashed c16( es16 d16 c16 \slurSolid bes16) c16 bes16 c16 c8.-\trill bes32 c32 | % 165
  d8
  bes,16 c16 d8 c16 d16 es8 d16 es16 | % 166
  a,8 bes'8 f8 e16 f16 g8 f16 g16 | % 167
  c,8 d'8 a8 g16 a16 bes8 a16 bes16 | % 168
  e,4 r8 c'16 bes16 a16 g16 fis16 e16 | % 169
  d8 e16 fis16 g16 a16 bes16 c16 d8 g,8 | % 170
  g8 es16 d16 c8 a16 bes16 c8 f,8 | % 171
  f'8 d16 c16 bes8 bes8 es8 g8 | % 172
  es4 r8 \slurDashed c16( bes16 c8) es16( d16 | % 173
  es8) \slurSolid d8 es8 f8 g8 es8 | % 174
  a,4 r4 r8 a8 | % 175
  d8 bes8 g8 c8 a8 d8 | % 176
  g8\p f16 es16 d8 c8 b8 a8 | % 177
  g16 c16 d16 es16 f8 f8 f8 f8 | % 178
  f8 es16 d16 es8 c16 d16 es8 es8 | % 179
  es8 d16 c16 d8 bes'16\f a16 g16 f16 es16 d16 | % 180
  c8 es'16 d16 c16 bes16 a16 g16 f8 es8 | % 181
  d8 e16 fis16 g8 g16\paren\p( fis16 g8) es8 | % 182
  c8( b8 c8) \slurDashed es16( d16 es8) \slurSolid c8 | % 183
  as8( g8 as8) \slurDashed c16( b16 c8) \slurSolid as8 | % 184
  fis8[ es'16(\f d16] es8) c16( b16 c8) a8 | % 185
  d8 g16 f16 es8 c8 a8 d8 | % 186
  bes4 d2\p | % 187
  e2. | % 188
  c4 f2~ | % 189
  f2. | % 190
  g2. | % 191
  a2. | % 192
  a4 r4 r4 | % 193
  e4 r4 r4 | % 194
  f4 r4 r4 | % 195
  g4 r4 r4 | % 196
  a4 r4 r4 | % 197
  bes4 r4 r4 | % 198
  b4 r4 r4 | % 199
  c4 r4 r4 | % 200
  cis8( cis8 cis8 cis8 cis8 cis8) | % 201
  c!8( c8 c8 c8 c8 c8) | % 202
  b8( b8 b8 b8 b8 b8) | % 203
  bes8( bes8 bes8 bes8 bes8 bes8) | % 204
  a8( a8 a8 a8 a8 a8) | % 205
  as8( as8 as8 as8 as8 as8) | % 206
  g8( g8 g8 g8 g8 g8) | % 207
  ges8( ges8 ges8 ges8 ges8 ges8) | % 208
  f2.~ | % 209
  f2. | % 210
  c2. | % 211
  f8 f8\f g8 es8 c8 f8 | % 212
  d8 r8 r4 r4 | % 213
  r8 d16 es16 f8 e16 f16 g8 f16 g16 | % 214
  c,8 r8 r4 r4 | % 215
  r8 fis16 g16 a16 g16 fis16 g16 a16 g16 fis16 e16 | % 216
  d8 r8 r4 r4 | % 217
  r8 g8\p g8 g8 g8 g8 | % 218
  g8 r8 r4 r4 | % 219
  r8 f8 f8 f8 f8 f8 | % 220
  d8 r8 r4 r4 | % 221
  cis8 r8 r4 r4 | % 222
  R4*3*2 | % 224
  r8 f16\paren\f g16 a8 g16 a16 bes8 a16 bes16 | % 225
  e,8 a16 bes16 c8 bes16 c16 d8 c16 d16 | % 226
  g,8 c,16 d16 e8 d16 e16 f8 e16 f16 | % 227
  b,4
  r8
  cis16 d16 e16 d16 cis16 b16 | % 228
  a8 r8 r4 r4 | % 229
  r4 r4 r8 g'16\paren\p f16 | % 230
  g8 r8 r4 r8 f16 e16 | % 231
  d8 r8 r4 r8 e16 d16 | % 232
  cis8 r8 r4 r4 | % 233
  e4 r4 r4 | % 234
  a8 a8 a8 a8 a8 a8 | % 235
  a8 a8 a8 a8 a8 a8 | % 236
  g8 g8 g8 g8 g8 g8 | % 237
  g8 g8 g8 g8 g8 g8 | % 238
  f8 f8 f8 f8 f8 f8 | % 239
  f8 d8 bes8 d8 g8 bes8 | % 240
  e,4 r4 r4 | % 241
  R4*3*2 | % 243
  f4 r4 r4 | % 244
  e4 r4 r4 | % 245
  d4 r4 r4 | % 246
  cis4 r4 r4 | % 247
  d4 r4 r4 | % 248
  f4 r4 r4 | % 249
  e4 r4 r4 | % 250
  R2. * 30 | % 280
  R2. | % 281
  r8 f16\f g16 a8 g16 a16 bes8 bes | % 282
  e,8 a16 bes16 c8 bes16 c16 d8 d | % 276
  g,8 c,16 d16 e8 d16 e16 f8 f | % 277
  b,4 r16 b16 cis16 d16 e16 d16 cis16 b16 | % 278
  a4 r8 f'16 g16 a8 d,8 | % 279
  d'8 bes16 a16 g8 e16 f16 g8 c,8 | % 280
  c'8 a16 g16 f8 f8 bes8 d8 | % 281
  bes4 r8 g16( f16 g8) bes16( a16 | % 282
  bes8) a8 bes8 c8 d8 bes8 | % 283
  e,8 cis'8 cis8 cis8 cis8 e,8 | % 284
  a8 f8 d8 g8 e8 a8 | % 285
  f4\fermata r4 r4 | % 286
  \bar "|."
}
