\version "2.18.2"
\language "nederlands"
scoreARight = \relative c' {
  \scoreAGlobal

  d16 e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  <d a f>4 r4 r2 | % 7
  r2 <a' f d a>4 r4 | % 8
  R1 | % 9
  <d a f d>4 r4 r2 | % 10
  r2 <a f d>4 r4 | % 11
  R1 | % 12
  <f d a>4 r4 <a f d>8 <a f d>4 <a f d>8 | % 13
  <bes e, cis>8 r8 <a f d>8 r8 <cis g e>8 r8 <bes g e>8 r8 | % 14
  <bes g e>8 r8 <bes g d>8 r8 <bes g cis,>8 r8 <a f cis>8 r8 | % 15
  <a e cis>8 <a e cis>8 <a e cis>8 <a e cis>8 <a e cis>8 <a e cis>8 <a e cis>8 <a e cis>8 | % 16
  <a e cis>4 r4 <a es c>16 g fis8-. <c' fis, es>16 bes a8-. | % 17
  <<{a8( g)}\\ <fis d>4 >> <e cis>8( <f d>) <e cis>8( <f d>) << a4 \\{<e cis>8( d)}>> | % 18
  <<{b'8[( a]) a[( gis])}\\{<f d>2}>> <gis f d>8( <a e>) <<{a( <b g>)}\\e,4>> | % 19
  <b' gis e>4 r4 <e bes g>16 d cis8-. <cis g e>8-. <bes e, d>-. | % 20
  <<a4\\{<e cis>8( d)}>> <gis d b>8( <a e c>8) <a fis c>8 r8 <gis e b>8 r8 | % 21
  <a e c>4 r4 r2 | % 22
  r2 <c a e>4 r4 | %23
  R1 | % 24
  <a e c>4 r4 r2 | % 25
  r2 <e c a>4 r4 | % 26
  R1 | % 27
  <c' a e>2 <cis a e>2 | % 28
  <d a d,>2 <c a d,>2 | % 29
  <bes g d>2 <b g d>2 | % 30
  <c g c,>2 <bes g c,>2 | % 31
  <a f c>2 <c a f>2 | % 32
  <bes f>1 | % 33
  <b gis e>4 r4 <a e> r | %34
  <a fis d>4 r <g d> r | % 35
  <g e c>4 r <f c> <c' f, c> | % 36
  <<
    {
      bes2 a | %37
      <g bes>2
    }
    \\
    {
      <f d>4( <e bes>) <e c>( <d a>) | % 37
      d4( c)
    }
  >>
  <f c a>4 r8 <g c,>8 | % 38
  <a f c>4 r8 <<{a16 g}\\<e c>8>> <f c>8 <g f d> <g e c>4 | % 39
  <a f c>1 | % 40
  <g e bes>1 | % 42
  <a f c>4 r4 r8 <<{fis8 g a}\\{d,4 <d c>8}>> | %43
  <g d bes>4 r 4 r 8 <<{gis8 a b}\\{e,4 <e d>8}>> | % 44
  <a e cis>4 r 4 r 8 <<{cis8 d e}\\{a,4 <a g>8}>> | % 44
  <d a f>8 <<a4\\{e8[ f]}>> <cis' g e>8 <d a d,>4 <d a d,>8 <b a f>8 | % 45
  <b gis e>4 r <b gis d> r | % 46
  <a e c>4 r <c a e> r | % 47
  <cis g e>4 r <cis g e> r | % 48
  <d a f>4 r <d a f> r | % 49
  <dis a fis>4 r <dis a fis> r | % 50
  <e b gis>4 r <b gis e> r | % 51
  <a e c>4 r <a e c> r | % 52
  <a f c>4 r <c a e> r | % 53
  <d a f>4 r <d b e,> r | % 54
  <c a e>4 r 8 <<{<c e>16 <b d>}\\a8>> <a e>8 <b a f> <c a e> <b gis d> | % 55
  <a e c>2 <c a e> | % 56
  <<
    {c8[ b] b[ a] a[ gis]}
    \\
    {<f d>4 <e c> <d b>}
  >>
  <a' e c>8 <b f d> | % 57
  <gis f d>4 <a f d> <b f d> <c f, d> | % 58
  <b f d>4 r4 r 2 | % 59
  r2 <e bes g>16 d cis8-. <g' cis, bes>16 f e8-. | % 60
  <cis bes e,>8( <d a f>) <b gis d>( <c a e>) <a fis c> r <gis e b> r | % 61
  <a e c>4 r4 r 2 | % 62
  <a e c>4 r4 r 2 | % 63
  <a e c>4 r4 r 2 | % 64
  <a e c>4 r4 r 2 | % 65
  <a e c>4 r4 r 2 | % 66
  <a e c>4 r4 r 2 | % 67
  R1 | % 68
  r8 <c a e>8 <<b4\\{<fis dis>8 <g e>}>> <c a e>8 <b fis dis>4 <dis b fis>8 | % 69
  <e b g>4 r4 r2 | % 70
  <b g e>4 r4 r2 | % 71
  <b g e>4 r4 r2 | % 72
  <b g e>4 r4 r2 | % 73
  <b g e>4 r4 r2 | % 74
  <b g e>4 r4 r2 | % 75
  <b g e>4 r4 r2 | % 76
  R1 * 14 | % 90
  <e, c g>1 | % 91
  <f d b g>1 | % 92
  <e c g>4 r4 r8 <g cis, a> <f d a> <e a,> | % 93
  <f d a>4 r4 r8 <fis d c>8 <g d bes> <a d, a> | % 94
  <g d bes>4 <bes g d> <d g, d>8 <bes g> <g d> <bes g d> | % 95
  <a es c>4 <c a es> <es a, es>8 <c a> <a es> <c a es> | % 96
  <d g, d>4 <g, d> <bes g d>4. <bes g es>8 | % 97
  <c g es>4 <g c,> <c g es> <g c,>8 <a g e> | % 98
  <a fis d>4 r4 <a fis d>4 r4 | % 99
  <g e bes>4 r4 <g e bes>4 r4 | % 100
  <fis c a>4 r4 <fis c a>4 r4 | % 101
  <a fis c>4 r4 <a fis c>4 r4 | % 102
  r8 <bes fis>8 <g d> <b g es> <c g c,> <a g es> <bes g d> <a fis c> | % 103
  <g d bes>4 r4 <bes g d>8 <g d>4 <bes g d>8 | % 104
  <c g es>8 r8 <d g, d> r <c fis, es> r <c g es> r | % 105
  <c a es>8 r8 <bes g d> r <c fis, c> r <bes g d> r | % 106
  <a fis d>1 | % 107
  <a fis d>4 r4 <d g, f>16 c b8-. <f' b, as>16 es d 8-. | % 108
  <<{d8( c)}\\<b g>4>> <c a fis>8( <bes g>) <e bes g>8\fermata r8 r4 | % 109
  R1 * 2 | % 111
  r2 r8 <es bes g>8 <es a, g> <d a fis> | % 112
  <bes g d>4. <bes g d>8 <c g e>8 <g e>4 <c g e>8 | % 113
  <a f c>4. <a f c>8 <bes f d>8 <f d>4 <bes f d>8 | % 114
  <g e d>4. <g e d>8 <a e cis>8 <e cis>4 <a e cis>8 | % 115
  <a f d>4. <d a f>8 <cis a e>4. <e cis a>8 | % 116
  <d a f>4. <d a f>8 <cis a e>4. <e cis a>8 | % 117
  <d a f>4 r4 r8 <a f>8 <g d> <bes f d> | % 118
  <c g e>4 r4 r8 <a e c>8 <a f c> <c f, c> | % 119
  <bes f d>4 r4 r8 <a f d>8 <g e d> <bes e, d> | % 120
  <a e cis>4 r4 r8 <cis g>8 <e a, e> <cis a g> | % 121
  <d a f>2 <d a fis> | %122
  <d g, d>2 <d g, f> | % 123
  <c g es>2 <c g e> | % 124
  <c f, c>2 <c f, es> | % 125
  <bes f d>2 <bes f d> | % 126
  <g es bes>1 | % 127
  <a e cis>4 r4 <d a d,> r | % 128
  <b g d>4 r4 <c g c,> r | % 129
  <a f c>4 r4 <f bes> <bes f bes,> | % 130
  <<
    {
      <g bes,>4( <a c,>) <f a,>( <g bes,>) | % 131
      g4( f)
    }
    \\
    {
      es2 d | % 131
      <es c>2
    }
  >>
  <f d bes>4 r8 <c' f, c>8 | % 132
  <bes g d>4 r8 <bes a d,>16 <c g es> <bes f>8 <bes g d> <bes f d> <a f c> | % 133
  <bes f d>4. <f d>8 <g es bes>8 <f d>4 <g es bes>8 | % 134
  <f d bes>4. <f d bes>8 <g es bes>8 <f d>4 <g es bes>8 | % 135
  <f d bes>4 r4 r8 <g d b>8 <g d b>8 <g d b>8 | % 136
  <g es c>4 r4 r2 | % 137
  r8 <a e cis>8 <a e cis>8 <a e cis>8 <a f d>4 r4 | % 138
  r2 r8 <a fis d>8 <a fis d>8 <a fis d>8 | % 139
  <bes g d>4 r8 <bes g es>8 <c fis, es>4 r8 <c fis, es>8 | % 140
  <bes g d>4 r8 <bes g d>8 <a g e>4 r8 <a g e>8 | % 141
  <a f d>4 r4 r8 <<{b8 c d}\\{g,4 <g f>8}>> | % 142
  <c g e>4 r4 r8 <<{a8 bes c}\\{f,4 <f es>8}>> | % 143
  <bes f d>4 <<{<g e>8 <a f>}\\d,4>> <bes' e, c>4. <bes f d>8 | % 144
  <bes g cis,>4. <bes f d>8 <a e>4 <cis a e> | % 145
  <d a d,>8 r8 <bes f d> r <es bes es,> r <cis a e> r | % 146
  <d f, d>8 r8 <a d,> r <bes es, bes> r <g e cis> r | % 147
  <a f d>4 r4 r2 | % 148
  <a f d>4 r4 r2 | % 149
  <a f d>4 r4 r2 | % 150
  <a f d>4 r4 r2 | % 151
  <a f d>4 r4 r2 | % 152
  <a f d>4 r4 r2 | % 153
  R1 * 18 | % 171
  d,16 e16 f8 e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 e'8 | % 173
  g8 bes cis, e g <a e> <cis a e> <e cis g> | % 174
  <d a f>4 r4 <a f d> r | % 175
  c8 es fis, a c, d <fis c> <a fis c> | % 176
  <bes g d>4 r4 <bes g d>4 r4 | % 177
  <d gis, f>8 b gis b gis <f d> <gis d> <b gis d> | % 178
  <a e cis>8\noBeam bes g e cis e g <cis g e> | % 179
  <d a f>4 r4 <a f d> r | % 180
  <bes f d>4 r 4 <d a f> r | % 181
  <d bes e,>4 r4 <e bes g> r | % 182
  <d a f>4 r8 <a f>8 <d a> <e d a> <f d a> <e cis g> | % 183
  <d a f>16 e,16 f8 e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  <a' e cis>8 r8 r4 a16 bes16 c8 c16 d16 es8 | % 188
  <es c a>8( <d bes>) <g e bes>( <f a,>) gis,,8 r8 <<{<cis' a g e>8}\\{a,8}>> r8 | % 189
  <<{<d' a f d>4\fermata}\\{d,,4}>> r4 r2 | % 190
  \bar "|."
}
