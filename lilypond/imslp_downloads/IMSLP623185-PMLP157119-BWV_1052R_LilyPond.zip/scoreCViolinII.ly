\version "2.18.2"
\language "nederlands"
scoreCViolinII = \relative c'' {
  \scoreCGlobal

  d8\paren\f c16 bes16 a8 g8 f8 e8 | % 1
  f8 d8 d'8 d8 d8 d8 | % 2
  d16 c16 d16 e16 f8 f8 f8 f8 | % 3
  f16 e16 f16 g16 a8 a8 a8 a8 | % 4
  a8 g16 f16 g8 e16 f16 g8 g8 | % 5
  g8 f16 e16 f8 d16 e16 f8 g16 a16 | % 6
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 7
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 8
  g8( fis8 g8) bes16 a16 bes8 g8 | % 9
  es8( d8 es8) g16 f16 g8 es8 | % 10
  cis8 bes'16( a16 bes8) g16( fis16 g8) cis,8 | % 11
  d8 f,8 g8 d'8 a8 cis8 | % 12
  d8 r8 r4 r4 | % 13
  r8 d,8 d'8 d8 d8 d8 | % 14
  d8 c16 b16 c8 r8 r4 | % 15
  r8 a8 a'8 a8 a8 a8 | % 16
  a8 g16 f16 g8 e16 f16 g8 g8 | % 17
  g8 f16 e16 f8 r8 r4 | % 18
  R4*3*3 | % 21
  r4 a,,8\p cis16( b16 cis8) e16( d16 | % 22
  e8) e16( d16 e8) a16( g16 a8) r8 | % 23
  R4*3*5 | % 28
  a8\f g16 f16 e8 d8 c8 b8 | % 29
  c8 a8 a'8 a8 a8 a8 | % 30
  a16 g16 a16 b16 c8 c8 c8 c8 | % 31
  c16 b16 c16 d16 e8 e8 e8 e8 | % 32
  e8 d16 c16 d8 b16 c16 d8 d8 | % 33
  d8 c16 b16 c8 a16 b16 c8 d16 e16 | % 34
  f8 d16 c16 b8 g16 a16 b8 c16 d16 | % 35
  e8 c16 b16 a8 a'16 gis16 a8 f8 | % 36
  d8( cis8 d8) f16 e16 f8 d8 | % 37
  bes8( a8 bes8) d16 cis16 d8 bes8 | % 38
  gis8 f'16( e16 f8) d16( cis16 d8) gis,8 | % 39
  a8 c,8 d8 a'8 e8 gis8 | % 40
  a4 r4 r4 | % 41
  r8 a8 a'8 a8 a8 a8 | % 42
  a8 g16 f16 g8 r8 r4 | % 43
  r8 e16 f16 g8 e16 f16 g8 g8 | % 44
  g8 f16 e16 f8 d16 e16 f8 g16 a16 | % 45
  bes8 r8 r4 r4 | % 46
  r8 e,16 d16 e8 c16 d16 e8 f16 g16 | % 47
  a8 r8 r4 r4 | % 48
  r8 d,16 c16 d8 bes16 c16 d8 e16 f16 | % 49
  bes,2.\p~ | % 50
  bes2.~ | % 51
  bes2.~ | % 52
  bes2 r8 e8 | % 53
  f8 a,8 bes8 f'8 c8 e8 | % 54
  f4\f r4 r4 | % 55
  r8 c16 bes16 a8 c8 a8 f8 | % 56
  c'8 bes16 a16 g8 f8 e8 d8 | % 57
  e8 c8 c'8 c8 c8 c8 | % 58
  g8 f16 es16 d8 c8 bes8 a8 | % 59
  bes8 g8 g'8 g8 g8 g8 | % 60
  \slurDashed g16( bes16 a16 \slurSolid g16) f4 r4 | % 61
  r8 d16 e16 f8 e16 f16 g8 f16 g16 | % 62
  a8 f16 g16 a8 g16 a16 b8 a16 b16 | % 63
  c8 a16 b16 c8 b16 c16 d8 c16 d16 | % 64
  e8 e,8 e'8 d8 cis8 a8 | % 65
  d8 d,8 d'8 d16 e16 f8 g16 a16 | % 66
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 67
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 68
  g8( fis8 g8) bes16 a16 bes8 g8 | % 69
  es8( d8 es8) g16 f16 g8 es8 | % 70
  cis4 r8 bes'16 a16 bes8 cis,8 | % 71
  d8 f,8 g8 d'8 a8 cis8 | % 72
  d,2.\p~ | % 73
  d2.~ | % 74
  d2.~ | % 75
  d2.~ | % 76
  d4. d'16\f e16 f8 g16 a16 | % 77
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 78
  a8 f16 e16 d8 r8 r4 | % 79
  bes4\p r4 r4 | % 80
  bes4 r4 r4 | % 81
  r8 bes'16(\f a16 bes8) g16( fis16 g8) cis,8 | % 82
  d8 f,8 g8 d'8 a8 cis8 | % 83
  d4 r4 r4 | % 84
  R4*3*6 | % 90
  r8 d8\p cis8 d8 e8 cis8 | % 91
  d8 r8 r4 r4 | % 92
  R4*3*8 | % 100
  r8 a8 gis8 a8 b8 gis8 | % 101
  a4  r4 r4 | % 102
  R4*3*11  | % 113
  f8\f e16 d16 c8 bes8 a8 g8 | % 114
  a8 c8 f8 f8 f8 f8 | % 115
  e4 r4 r4 | % 116
  r8 g8 c8 c8 c8 c8 | % 117
  bes4 r4 r4 | % 118
  r8 d,8 g8 g8 g8 g8 | % 119
  g16 f16 g16 a16 bes8 bes8 bes8 bes8 | % 120
  bes16 a16 bes16 c16 d8 d8 d8 d8 | % 121
  d8 c16 bes16 c8 a16 bes16 c8 c8 | % 122
  c8 bes16 a16 bes8 g16 a16 bes8 c16 d16 | % 123
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 124
  d8 bes16 a16 g8 g'16 fis16 g8 es8 | % 125
  c8( b8 c8) es16 d16 es8 c8 | % 126
  as8( g8 as8) c16 bes16 c8 as8 | % 127
  fis8 es'16( d16 es8) c16( bes16 c8) fis,8 | % 128
  g8 bes,8 c8 g'8 d8 fis8 | % 129
  g8 bes,16\p c16 d8 c8 bes8 a8 | % 130
  g4 g'4 r4 | % 131
  r8 c,16 d16 es8 d8 c8 bes8 | % 132
  a4 a'4 r4 | % 133
  r8 bes16 c16 d8 c8 bes8 a8 | % 134
  g8 d16 c16 bes8 a8 g8 d''8 | % 135
  es8 c16 d16 es8 d8 c8 bes8 | % 136
  a8 es16 d16 c8 bes8 a8 g''8 | % 137
  fis8 a,16( g16 a8) fis16( e16 fis8) c'8 | % 138
  bes8 g16( fis16 g8) e16( d16 e8) bes'8 | % 139
  a8 fis16( e16 fis8) d16( c16 d8) a'8 | % 140
  g8 e16( d16 e8) cis16( b16 cis8) g'8 | % 141
  fis8 d16( c16 d8) a16( g16 a8) r8 | % 142
  R4*3*1 | % 143
  r8 a'16 bes16 c8 bes8 a8 g8 | % 144
  f4 d'4 r4 | % 145
  r8 g,16 a16 b8 a8 g8 f8 | % 146
  es4 c'4 r4 | % 147
  r8 f,16 g16 a8 g8 f8 es8 | % 148
  d4 bes'4 r4 | % 149
  R4*3*9 | % 158
  bes'8\f a16 g16 f8 es8 d8 c8 | % 159
  d8 f16 es16 d8 f8 d8 bes8 | % 160
  f'8 e16 d16 c8 bes8 a8 g8 | % 161
  a8 f8 f'8 f8 f8 f8 | % 162
  c8 bes16 as16 g8 f8 es8 d8 | % 163
  es8 c8 c'8 c8 c8 c8 | % 164
  c16( es16 d16 c16 bes16) c16 bes16 c16 c8.-\trill bes32 c32 | % 165
  d8
  g,16 a16 bes8 a16 bes16 c8 bes16 c16 | % 166
  d8 bes16 c16 d8 c16 d16 e8 d16 e16 | % 167
  f8 d16 e16 f8 e16 f16 g8 f16 g16 | % 168
  a8 a,8 a'8 g8 fis8 d8 | % 169
  g8 g,16 fis16 g8 g16 a16 bes8 c16 d16 | % 170
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 171
  d8 bes16 a16 g8 g'16 fis16 g8 es8 | % 172
  c8( b8 c8) es16 d16 es8 c8 | % 173
  as8( g8 as8) c16 b16 c8 as8 | % 174
  fis8 es16 d16 es8 c16 bes16 c8 fis8 | % 175
  g8 bes,8 c8 g'8 d8 fis8 | % 176
  g,2.\p~ | % 177
  g2.~ | % 178
  g2.~ | % 179
  g4. g'16\f a16 bes8 c16 d16 | % 180
  es8 c16 bes16 a8 f16 g16 a8 bes16 c16 | % 181
  d8 bes16 a16 g8 r8 r4 | % 182
  c,4\paren\p r4 r4 | % 183
  c4 r4 r4 | % 184
  r8 es'16(\f d16 es8) c16( b16 c8) fis8 | % 185
  g8 bes,8 a8 g'8 a,8 fis'8 | % 186
  g2.\p~ | % 187
  g2. | % 188
  f2.~ | % 189
  f2. | % 190
  e2.~ | % 191
  e2. | % 192
  d4 r4 r4 | % 193
  cis4 r4 r4 | % 194
  d4 r4 r4 | % 195
  d4 r4 r4 | % 196
  c4 r4 r4 | % 197
  d4 r4 r4 | % 198
  d4 r4 r4 | % 199
  e4 r4 r4 | % 200
  e8( e8 g8 g8 e8 e8) | % 201
  fis8( fis8 fis8 fis8 fis8 fis8) | % 202
  f8( f8 f8 f8 f8 f8) | % 203
  e8( e8 e8 e8 e8 e8) | % 204
  es8( es8 es8 es8 c8 c8) | % 205
  d8( d8 d8 d8 d8 d8) | % 206
  bes8( bes8 bes8 bes8 bes8 bes8) | % 207
  c8( c8 c8 c8 bes8 bes8) | % 208
  c2.~ | % 209
  c2.~ | % 210
  c2. | % 211
  bes8 bes8\f es,8 bes'8 f8 a8 | % 212
  bes8 r8 r4 r4 | % 213
  r8 f'8 bes8 bes8 bes8 bes8 | % 214
  bes8 a16 g16 a8 r8 r4 | % 215
  r8 a16 bes16 c8 a16 bes16 c8 c8 | % 216
  c8 bes16 a16 bes8 r8 r4 | % 217
  r8 d,,16\p( c16 d8) g16( fis16 g8) bes16( a16 | % 218
  bes8) r8 r4 r4 | % 219
  r8 a,16( g a8) d16( cis d8) f16( e | % 220
  f8) r8 r4 r4 | % 221
  e8 r r4 r | % 222
  R4*3*1 | % 223
  d'8\f c16 bes16 a8 g8 f8 e8 | % 224
  f8 d8 d'8 d8 d8 d8 | % 225
  d16 c16 d16 e16 f8 f8 f8 f8 | % 226
  f16 e16 f16 g16 a8 a8 a8 a8 | % 227
  a8 g16 f16 g8 e16 f16 g8 g8 | % 228
  g8 f16 e16 f8 r8 r4 | % 229
  r4 r8 d16\p cis16 d8 r8 | % 230
  r4 r8 c16 b16 c8 r8 | % 231
  r4 r8 bes16 a16 bes8 r8 | % 232
  r4 a8 cis16( b16 cis8) r8 | % 233
  r4 a8 cis16( b16 cis8) r8 | % 234
  g4 r4 r4 | % 235
  r8 c8 a8 fis8 d8 fis8 | % 236
  f4 r4 r4 | % 237
  r8 bes8 g8 e8 c8 e8 | % 238
  es4 r4 r4 | % 239
  r8 bes'8 bes8 bes8 bes8 bes8 | % 240
  a4 r4 r4 | % 241
  R4*3*2 | % 243
  a4 r4 r4 | % 244
  a4 r4 r4 | % 245
  a4 r4 r4 | % 246
  a4 r4 r4 | % 247
  a4 r4 r4 | % 248
  b4 r4 r4 | % 249
  a4 r4 r4 | % 250
  R2. * 30 | % 280
  d8\f c16 bes16 a8 g8 f8 e8 | % 281
  f8 d8 d'8 d8 d8 d8 | % 275
  d16 c16 d16 e16 f8 f8 f8 f8 | % 276
  f16 e16 f16 g16 a8 a8 a8 a8 | % 277
  a8 g16 f16 g8 e16 f16 g8 g8 | % 278
  g8 f16 e16 f8 d16 e16 f8 g16 a16 | % 279
  bes8 g16 f16 e8 c16 d16 e8 f16 g16 | % 280
  a8 f16 e16 d8 d'16 cis16 d8 bes8 | % 281
  g8( fis8 g8) bes16 a16 bes8 g8 | % 282
  es8( d8 es8) g16 fis16 g8 es8 | % 283
  cis8 bes'16( a16 bes8) g16( fis16 g8) cis,8 | % 284
  d8 f,8 g8 d'8 a8 cis8 | % 285
  d4\fermata r4 r4 | % 286
  \bar "|."
}
