\version "2.20.0"
\language "nederlands"

\include "parenthesized_dynamics.ly"

first_pg_no = 1
instrument = "Harpsichord"

\include "BWV_1052R_header.ly"
\include "BWV_1052R_paper_parts.ly"

scoreAGlobal = {
  \key d \minor
  \time 4/4
  \compressFullBarRests
}

\include "scoreARight.ly"
\include "scoreABc.ly"

scoreAHarpsichordPart = \new PianoStaff \with {
  instrumentName = ""
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 5/4)
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
  } \scoreARight
  \new Staff = "left" \with {
    midiInstrument = "harpsichord"
  } { \clef bass \scoreABc }
>>

\score {
  \scoreAHarpsichordPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceA}}
  }
  \midi {
    \tempo 4 = 100
  }
}

\pageBreak

scoreBGlobal = {
  \key g \minor
  \time 3/4
  \tempo "Adagio"
  \compressFullBarRests
}

\include "scoreBRight.ly"
\include "scoreBBc.ly"

scoreBHarpsichordPart = \new PianoStaff \with {
  instrumentName = ""
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
  } \scoreBRight
  \new Staff = "left" \with {
    midiInstrument = "harpsichord"
  } { \clef bass \scoreBBc }
>>

\score {
  \scoreBHarpsichordPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceB}}
  }
  \midi {
    \tempo 4 = 50
  }
}

\pageBreak

scoreCGlobal = {
  \key d \minor
  \time 3/4
  \tempo "Allegro"
  \compressFullBarRests
}

\include "scoreCRight.ly"
\include "scoreCBc.ly"

scoreCHarpsichordPart = \new PianoStaff \with {
  instrumentName = ""
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 4/4)
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
  } \scoreCRight
  \new Staff = "left" \with {
    midiInstrument = "harpsichord"
  } { \clef bass \scoreCBc }
>>

\score {
  \scoreCHarpsichordPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceC}}
  }
  \midi {
    \tempo 4 = 110
  }
}
