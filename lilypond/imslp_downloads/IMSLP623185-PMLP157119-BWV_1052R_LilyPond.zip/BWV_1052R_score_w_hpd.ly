\version "2.20.0"
\language "nederlands"

\include "parenthesized_dynamics.ly"

first_pg_no = 1
instrument = ""

\include "BWV_1052R_header.ly"
\include "BWV_1052R_paper_scores.ly"

scoreAGlobal = {
  \key d \minor
  \time 4/4
}

\include "scoreAViolinConc.ly"
\include "scoreAViolinI.ly"
\include "scoreAViolinII.ly"
\include "scoreAViola.ly"
\include "scoreARight.ly"
\include "scoreABc.ly"

scoreAViolinConcPart = \new Staff \with {
  instrumentName = "Violino Concertino"
  midiInstrument = "violin"
} \scoreAViolinConc

scoreAViolinIPart = \new Staff \with {
  instrumentName = "Violino I"
  midiInstrument = "violin"
} \scoreAViolinI

scoreAViolinIIPart = \new Staff \with {
  instrumentName = "Violino II"
  midiInstrument = "violin"
} \scoreAViolinII

scoreAViolaPart = \new Staff \with {
  instrumentName = "Viola"
  midiInstrument = "viola"
} { \clef alto \scoreAViola }

scoreAHarpsichordPart = \new PianoStaff \with {
  instrumentName = "Continuo"
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
    \tiny
  } \scoreARight
  \new Staff = "left" \with {
    midiInstrument = "cello"
  } { \clef bass \scoreABc }
>>

\score {
  <<
    \scoreAViolinConcPart
    \new StaffGroup <<
      \scoreAViolinIPart
      \scoreAViolinIIPart
      \scoreAViolaPart
      \scoreAHarpsichordPart
    >>
  >>
  \layout {
    indent = 3 \cm
  }
  \header {
    piece = \pieceA
  }
  \midi {
    \tempo 4 = 100
  }
}

\pageBreak

scoreBGlobal = {
  \key g \minor
  \time 3/4
  \tempo "Adagio"
}

\include "scoreBViolinConc.ly"
\include "scoreBViolinI.ly"
\include "scoreBViolinII.ly"
\include "scoreBViola.ly"
\include "scoreBRight.ly"
\include "scoreBBc.ly"

scoreBViolinConcPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreBViolinConc

scoreBViolinIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreBViolinI

scoreBViolinIIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreBViolinII

scoreBViolaPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "viola"
} { \clef alto \scoreBViola }

scoreBHarpsichordPart = \new PianoStaff \with {
  instrumentName = ""
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
    \tiny
  } \scoreBRight
  \new Staff = "left" \with {
    midiInstrument = "cello"
  } { \clef bass \scoreBBc }
>>

\score {
  <<
    \scoreBViolinConcPart
    \new StaffGroup <<
      \scoreBViolinIPart
      \scoreBViolinIIPart
      \scoreBViolaPart
      \scoreBHarpsichordPart
    >>
  >>
  \layout {
    indent = 0 \cm
  }
  \header {
    piece = \pieceB
  }
  \midi {
    \tempo 4 = 50
  }
}

\pageBreak

scoreCGlobal = {
  \key d \minor
  \time 3/4
  \tempo "Allegro"
}

\include "scoreCViolinConc.ly"
\include "scoreCViolinI.ly"
\include "scoreCViolinII.ly"
\include "scoreCViola.ly"
\include "scoreCRight.ly"
\include "scoreCBc.ly"

scoreCViolinConcPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreCViolinConc

scoreCViolinIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreCViolinI

scoreCViolinIIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreCViolinII

scoreCViolaPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "viola"
} { \clef alto \scoreCViola }

scoreCHarpsichordPart = \new PianoStaff \with {
  instrumentName = ""
} <<
  \new Staff = "right" \with {
    midiInstrument = "harpsichord"
    \tiny
  } \scoreCRight
  \new Staff = "left" \with {
    midiInstrument = "cello"
  } { \clef bass \scoreCBc }
>>

\score {
  <<
    \scoreCViolinConcPart
    \new StaffGroup <<
      \scoreCViolinIPart
      \scoreCViolinIIPart
      \scoreCViolaPart
      \scoreCHarpsichordPart
    >>
  >>
  \layout {
    indent = 0 \cm
    \context {
      \Staff
      \remove  Dot_column_engraver
    }
    \context {
      \Voice
      \consists Dot_column_engraver
    }
  }
  \header {
    piece = \pieceC
  }
  \midi {
    \tempo 4 = 110
  }
}
