\version "2.18.0"
\language "nederlands"
scoreAViolinI = \relative c' {
  \scoreAGlobal

  d16\paren\f e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  d8 r8 d'8(\p cis8) r4 f8( e8) | % 7
  r4 a8( g8) r4 f8( e8) | % 8
  r4 d8( cis8) r4 f8( e8) | % 9
  r4 d8( cis8) r4 f,8( e8) | % 10
  r4 d8( cis8) d4 r4 | % 11
  R4*4*1 | % 12
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 13
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 14
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 15
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 16
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 17
  fis,8( g8) r4 e8( f8) r4 | % 18
  f'4 r4 d4 r4 | % 19
  e,8     fis16 gis16 a16 b16 c16 d16 e16 f16 g8-. g16 a16 bes8-. | % 20
  cis,8-. d8-. gis,8-. a8-. dis,8 r8 e8 r8 | % 21
  a,8 r8 a'8(\p gis8) r4 c8( b8) | % 22
  r4 e8( d8) r4 c8( b8) | % 23
  r4 a8( gis8) r4 a8( gis8) | % 24
  r4 d8( b8) r4 b8( gis8) | % 25
  a4 r4 r2 | % 26
  R4*4*1 | % 27
  a'16\p b16 c8 b8 a8 e'8 a4 cis,8 | % 28
  d8 r8 f8 r8 d8 r8 a8 r8 | % 29
  g16 a16 bes8 a8 g8 d'8 g4 b,8 | % 30
  c8 r8 e8 r8 c8 r8 g8 r8 | % 31
  f16 g16 a8 g8 f8 c'8 f4 a,8 | % 32
  bes8 r8 d8 r8 bes8 r8 f8 r8 | % 33
  e8 e8 gis8 gis8 a8 a8 c8 c8 | % 34
  d,8 d8 fis8 fis8 g8 g8 bes8 bes8 | % 35
  c,8 c8 e8 e8 f8 f8 a8 a8 | % 36
  bes2 a2 | % 37
  g2 f4 r8 g8 | % 38
  a16 c16\f d16 e16 f16 g16 a16 bes16 c8 f,8 g,8 e'8 | % 39
  f1\p | % 40
  g2 e2 | % 41
  f8 f,8\f a8 c8 d,8 a''16( g16 fis16 e16 d16 c16) | % 42
  bes8 g8 bes8 d8 e,8 b''16( a16 gis16 fis16 e16 d16) | % 43
  cis8 cis8 e8 g8 a,8 e'16( d16 cis16 b16 a16 g16) | % 44
  \phrasingSlurUp \phrasingSlurDashed f16\(( g16 a16\) \phrasingSlurNeutral \phrasingSlurSolid g16) f16 e16 d16 cis16 d4 r8 d'8~\p | % 45
  d8 f,16 d16 gis,8 d''8~ d8 f,16 d16 gis,8 gis'8 | % 46
  \slurDashed a8( e8) c8( e8) a8( e8) c8 g''8~ | % 47
  g8 bes,16 g16 cis,8 g''8~ g8 bes,16 g16 cis,8 cis'8 | % 48
  d8( a8) f8( a8) d8( a8) \slurSolid f8 a'8~ | % 49
  a8 c,16 a16 dis,8 a''8~ a8 c,16 a16 dis,8 b'8~ | % 50
  b8 f16 d16 gis,8 b'8~ b8 f16 d16 gis,8 e''8 | % 51
  e8( c8) a8( c8) e8( c8) a8( c8) | % 52
  f8( c8) a8( c8) e8( c8) a8( c8) | % 53
  f8( e8) d8( c8) b8( a8) gis8( fis8) | % 54
  e8 r8 r4 r2 | % 55
  a16\f b16 c8 b8 a8 e'8 a4 e8 | % 56
  f8 d16 b16 e8 c16 a16 d8 b16 gis16 e8 f'8~ | % 57
  f8 d16 b16 e,8 gis'8~ gis8 f16 d16 e,8 b''8~ | % 58
  b8 gis16 e16 f16 d16 e16 c16 d16 b16 c16 a16 b16 gis16 a16 fis16 | % 59
  gis16 e16 fis16 gis16 a16 b16 c16 d16 e16 f16 g8-. g16 a16 bes8-. | % 60
  cis,8-. d8-. gis,8-. a8-. dis,8 r8 e8 r8 | % 61
  a,8 a8\p b8 c8 d8 f8 e8 d8 | % 62
  c8 a8 b8 c8 d8 f8 e8 d8 | % 63
  c8 a'8 gis8 a8 b8 a8 b8 gis8 | % 64
  a8 a8 gis8 a8 b8 a8 b8 gis8 | % 65
  a8 e8 f8 d8 e8 a8 f8 d8 | % 66
  e8 e4 d8 c8 c4 b8 | % 67
  a4 r r2 |
  r8 e''8\f fis8 g8 a8 r8 fis8 r8 | % 69
  e8 e,8\p fis8 g8 a8 c8 b8 a8 | % 70
  g8 e8 fis8 g8 a8 c8 b8 a8 | % 71
  g8 e'8 dis8 e8 fis8 e8 fis8 dis8 | % 72
  e8 e8 dis8 e8 fis8 e8 fis8 dis8 | % 73
  e8 b8 c8 a8 b8 e8 c8 a8 | % 74
  b8 b4 a8 g8 g4 fis8 | % 75
  e4 r4 r2 | % 76
  r8 e'4 b16 g16 e8 e'4 c16 a16 | % 77
  e8 e'4 b16 g16 e8 e'4 c16 a16 | % 78
  e8 r8 r4 r2 | % 79
  R4*4*11 | % 90
  c'1\p | % 91
  d2 b2 | % 92
  c8 c,8\f e8 g8 a,8 e''16( d16 cis16 b16 a16 g16) | % 93
  f8 d8 fis8 a8 c8 a'16( g16 fis16 e16 d16 c16) | % 94
  bes4 r4 r8 d8\p g8 bes8 | % 95
  c,4 r4 r8 es8 a8 c8 | % 96
  d,4 r4 r8 d8 bes8 g8 | % 97
  es'4 r4 r8 es8 c8 a8 | % 98
  fis8 r8 r4 r8 d8 fis8 a8 | % 99
  e'8 r8 r4 r8 bes8 g8 e8 | % 100
  a,8 r8 r4 r8 c'8 a8 fis8 | % 101
  d8 r8 r4 r8 a''8 fis8 c8 | % 102
  fis,4 r4 r2 | % 103
  g16\f a16 bes8 a8 g8 d'8 g4 d8 | % 104
  es8 c16 a16 d8 bes16 g16 c8 a16 fis16 d8 es'8~ | % 105
  es8 c16 a16 d,8 fis'8~ fis8 es16 c16 d,8 a''8~ | % 106
  a8 fis16 d16 es16 c16 d16 bes16 c16 a16 bes16 g16 a16 fis16 g16 e16 | % 107
  fis16 d16 e16 fis16 g16 a16 bes16 c16 d16 es16 f8-. f16 g16 as8-. | % 108
  b,8-. c8-. fis,8-. g8-. cis,8-\fermata r8 r4 | % 109
  R4*4*2 | % 111
  r2 r8 g''8\f a8 fis8 | % 112
  g4 r4 g16 f16 e d16 c16 bes16 a16 g16 | % 113
  f8 f'8 r4 f16 e16 d16 c16 bes16 a16 g16 f16 | % 114
  e8 e'8 r4 e16 d16 cis16 b16 a16 g16 f16 e16 | % 115
  d8 d'8 r8 d8\p e8 g8 r8 e8 | % 116
  f8 a8 r8 f8 e8 g8 r8 e8 | % 117
  f8 a16 f16 d8 a'8~ a a16 f16 d8 bes'8~ | % 118
  bes8 e,16 c16 a8 a'8~ a e16 c16 a8 a'8~ | % 119
  a8 a16 f16 d8 a'8~ a a16 f16 d8 bes'8~ | % 120
  bes8 bes16 g16 e8 g8~ g e16 cis16 a8 e'8 | % 121
  f8 r8 a8 r8 fis8 r8 d8 r8 | % 122
  g,16 a16 bes8 a8 g8 d'8 g4 d8 | % 123
  g,8 r8 g'8 r8 e8 r8 c8 r8 | % 124
  f,16 g16 a8 g8 f8 c'8 f4 c8 | % 125
  f,8 r8 f'8 r8 d8 r8 bes8 r8 | % 126
  es,16 f16 g8 f8 es8 bes'8 es4 bes8 | % 127
  a8 a8 cis8 cis8 d8 d8 f8 f8 | % 128
  g,8 g8 b8 b8 c8 c8 es8 es8 | % 129
  f,8 f8 a8 a8 bes8 bes8 d8 d8 | % 130
  es2 d2 | % 131
  c2 bes4 r8 c8 | % 132
  d16 f,16\f g16 a16 bes16 c16 d16 es16 f8 bes,8 f8 a8 | % 133
  bes4 r8 f8\p g8( f8) as8( g8) | % 134
  f4 r8 d8 es8( d8) f8( es8) | % 135
  d4 r4 r8 b'8\f b8 b8 | % 136
  c4 r4 r2 | % 137
  r8 cis8 cis8 cis8 d4 r4 | % 138
  r2 r8 fis8 fis8 fis8 | % 139
  g4 r8 bes8\p c4 r8 c8 | % 140
  d4 r8 d,8 a'8( g8) f8( e8) | % 141
  d8( e8) d8( c8) b8 d8 g4~ | % 142
  g8 f8( e8 d8) c a( bes c) | % 143
  bes4 r8 d8 e4 r8 f8 | % 144
  g4 r8 d8 e4 r8 e8 | % 145
  f8 r8 r8 f8 es8 r8 cis8 r8 | % 146
  d8 r8 r8 a8 g8 r8 g8 r8 | % 147
  f8 a8 g8 a8 bes8 a8 bes8 g8 | % 148
  a8 d,8 g8 a8 bes8 a8 bes8 g8 | % 149
  a8 d4 cis8 d8 a8 bes8 g8 | % 150
  a8 f8 e8 e8 d8 d'8 e8 e8 | % 151
  a,4 r4 r2 | % 152
  a4 r4 r2 | % 153
  R4*4*18 | % 171
  d,16\f e16 f8     e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 e''8~ | % 173
  e8 bes16\p g16 cis,8 e'8~ e bes16 g16 cis,8 cis'8 | % 174
  d8( a8) f8( a8) \slurDashed d8( a8) \slurSolid f8 c''8~ | % 175
  c8 es,16 c16 fis,8 c''8~ c es,16 c16 fis,8 fis'8 | % 176
  g8( d8) bes8( d8) g8( d8) bes8 d8~ | % 177
  d8 f,16 d16 gis,8 d''8~ d f,16 d16 gis,8 e''8~ | % 178
  e8 bes16 g16 cis,8 e'8~ e bes16 g16 cis,8 a''8 | % 179
  a8( f8) d8( f8) a8( f8) d8( f8) | % 180
  bes8( f8) d8( f8) a8( f8) d8( f8) | % 181
  bes8( a8) g8( f8) e8( d8) cis8( b8) | % 182
  a8 r8 r4 r2 | % 183
  d,16\f e16 f8 e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8 c16 d16 es8 | % 188
  fis,8-. g8-. cis,8-. d8-. gis,8 r8 a8 r8 | % 189
  d4\fermata r4 r2 | % 190
  \bar "|."
}
