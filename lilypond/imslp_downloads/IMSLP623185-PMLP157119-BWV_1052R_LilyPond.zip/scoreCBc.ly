\version "2.18.2"
\language "nederlands"
scoreCBc = \relative c' {
  \scoreCGlobal

  R4*3*1 | % 1
  r8 d,16\paren\f e16 f8 e16 f16 g8 f16 g16 | % 2
  a8 f16 g16 a8 g16 a16 bes8 a16 bes16 | % 3
  c8 a16 b16 c8 b16 c16 d8 c16 d16 | % 4
  e8 e,8 e'8 d8 cis8 a8 | % 5
  d8 d,8 d'8 c8 bes8 a8 | % 6
  g8 a16 bes16 c8 bes8 a8 g8 | % 7
  f8 g16 a16 bes8 a8 g8 f8 | % 8
  e8 d8 cis8 d8 e8 f8 | % 9
  g8 f8 g8 a8 bes8 g8 | % 10
  a4 r4 r8 g8 | % 11
  f8 e16 d16 bes'8 a16 g16 a8 a,8 | % 12
  d4 r4 r4 | % 13
  r8 d16 e16 f8 e16 f16 g8 f16 g16 | % 14
  f4 r4 r4 | % 15
  r8 a16 b16 c8 b16 c16 d8 c16 d16 | % 16
  e8 e,8 e'8 d8 cis8 a8 | % 17
  d8 r8 r4 r4 | % 18
  r4 r8 d8\p^\markup"(Solo)" bes8 g8 | % 19
  c4 r8 c8 a8 f8 | % 20
  bes4 r8 bes8 g8 e8 | % 21
  a4^\markup"(Tutti)" r4 r4 | % 22
  g4 r4 r4 | % 23
  fis4^\markup "(Solo)" r4 r4 | % 24
  f4 r4 r4 | % 25
  e4 r4 r4 | % 26
  g4 r8 e8 cis8 a8 | % 27
  d8 c8 bes4 bes'4 | % 28
  a4 r4 r4 | % 29
  r8 a,16\f^\markup "(Tutti)" b16 c8 b16 c16 d8 c16 d16 | % 30
  e8 c16 d16 e8 d16 e16 f8 e16 f16 | % 31
  g8 e16 fis16 g8 fis16 g16 a8 g16 a16 | % 32
  b8 b,8 b'8 a8 gis8 e8 | % 33
  a8 a,8 a'8 g8 f8 e8 | % 34
  d8 e16 f16 g8 f8 e8 d8 | % 35
  c8 d16 e16 f8 e8 d8 c8 | % 36
  b8 a8 gis8 a8 b8 c8 | % 37
  d8 c8 d8 e8 f8 d8 | % 38
  e4 r4 r8 d8 | % 39
  c8 b16 a16 f'8 e16 d16 e8 e,8 | % 40
  a4 r4 r4 | % 41
  r8 a'16 b16 c8 b16 c16 d8 c16 d16 | % 42
  e4 r4 r4 | % 43
  r8 e,8[ e'8 d8 cis8 a8] | % 44
  d8 d,8 d'8 c8 bes8 a8 | % 45
  g8 r8 r4 r4 | % 46
  r8 c,8 c' bes8 a8 g8 | % 47
  f8 r8 r4 r4 | % 48
  r8 bes,8[ bes'8 a8 g8 f8] | % 49
  e8(\p e8 e8 e8 e8 e8) | % 50
  e8( e8 e8 e8 e8 e8) | % 51
  e8( e8 e8 e8 e8 e8) | % 52
  e2 r8 c8 | % 53
  f8 e8 d8 c16 bes16 c8 c,8 | % 54
  f4\f r4 r4 | % 55
  r8 f'16 g16 a8 g16 a16 b8 a16 b16 | % 56
  c4 r4 r4 | % 57
  r8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | % 58
  g4 r4 r4 | % 59
  r8 g,16 a16 b8 a16 b16 cis8 b16 cis16 | % 60
  d8 c16 bes16 a8 g8 f8 e8 | % 61
  f8 d8 d'8 d8 d8 d8 | % 62
  d16 c16 d16 e16 f8 f8 f8 f8 | % 63
  f16 e16 f16 g16 a8 a8 a8 a8 | % 64
  a8 g16 f16 g8 e16 f16 g8 g8 | % 65
  g8 f16 e16 f8 d'8 d,8 e16 f16 | % 66
  g8 a16 bes16 c8 bes8 a8 g8 | % 67
  f8 g16 a16 bes8 a8 g8 f8 | % 68
  e8 d8 cis8 d8 e8 f8 | % 69
  g8 f8 g8 a8 bes8 g8 | % 70
  a4 r4 r8 g8 | % 71
  f8 e16 d16 bes'8 a16 g16 a8 a,8 | % 72
  bes4\p r8 bes8 a8 g8 | % 73
  f4 r8 d16 e16 f8 f16 g16 | % 74
  a4 r8 a16 g16 fis8 e16 d16 | % 75
  g8 d'8 g8 g8 g8 f16 e16 | % 76
  f8 f16 e16 f8 d16\f cis16 d8 e16 f16 | % 77
  g8 a16 bes16 c8 bes8 a8 g8 | % 78
  f8 g16 a16 bes8 d16\p cis16 d8 bes8 | % 79
  g8( fis8 g8) bes16 a16 bes8 g8 | % 80
  es8( d8 es8) g16 fis16 g8 es8 | % 81
  cis8 \slurDashed bes'16\f( a16 bes8) g16( fis16 g8) \slurSolid g,8 | % 82
  f8 e16 d16 bes'8 a16 g16 a8 a8 | % 83
  d,4 r4 r4 | % 84
  d4\p^\markup"(Solo)" r4 r4 | % 85
  d4 r4 r4 | % 86
  R4*3*1 | % 87
  d4 r4 r4 | % 88
  R4*3*1 | % 89
  d4^\markup "(Tutti)" r4 r4 | % 90
  R4*3*1 | % 91
  r8 d'16^\markup"(Solo)" e16 f8 e8 d8 c8 | % 92
  b4 gis'4 r4 | % 93
  a,4 r4 r4 | % 94
  a4 r4 r4 | % 95
  a4 r4 r4 | % 96
  R4*3*1 | % 97
  a4 r4 r4 | % 98
  R4*3*1 | % 99
  a4^\markup "(Tutti)" r4 r4 | % 100
  R2. | % 101
  r8 a'16^\markup"(Solo)" b16 c8 b8 a8 g8 | % 102
  fis4 dis'4 r4 | % 103
  e,4 r4 r4 | % 104
  e4 r4 r4 | % 105
  r8 e16 f16 g8 f8 e8 d8 | % 106
  cis4 a'4 r4 | % 107
  d,4 r4 r4 | % 108
  r8 d16 e16 f8 e8 d8 c8 | % 109
  r8 bes16 c16 d8 c8 bes8 a8 | % 110
  r8 g16 a16 bes8 a8 g8 f8 | % 111
  c'4 r4 r4 | % 112
  f8 a,8 bes8 f'8 c8 e8 | % 113
  f,4 r4 r4 | % 114
  r8 f16\f^\markup "(Tutti)" g16 a8 g16 a16 b8 a16 b16 | % 115
  c4 r4 r4 | % 116
  r8 c16 d16 e8 d16 e16 fis8 e16 fis16 | % 117
  g4 r4 r4 | % 118
  r8 g,16 a16 bes8 a16 bes16 c8 bes16 c16 | % 119
  d8 bes16 c16 d8 c16 d16 e8 d16 e16 | % 120
  f8 d16 e16 f8 e16 f16 g8 f16 g16 | % 121
  a8 a,8 a'8 g8 fis8 d8 | % 122
  g8 g,8 g'8 f8 es8 d8 | % 123
  c8 d16 es16 f8 es8 d8 c8 | % 124
  bes8 c16 d16 es8 d8 c8 bes8 | % 125
  a8 g8 fis8 g8 a8 bes8 | % 126
  d8 bes8 c8 d8 es8 c8 | % 127
  d4 r4 r8 c8 | % 128
  bes8 a16 g16 es'8 d16 c16 d8 d,8 | % 129
  g4 g'4\paren\p r4 | % 130
  r8 g16 f16 es8 d8 c8 bes8 | % 131
  a4 a'4 r4 | % 132
  r8 a16 g16 fis8 e8 d8 c8 | % 133
  bes4 bes'4 r4 | % 134
  r8 bes16 a16 g8 f8 es8 d8 | % 135
  c4 c'4 r4 | % 136
  r8 c16 bes16 a8 g8 fis8 e8 | % 137
  d4 r4 r4 | % 138
  d4 r4 r4 | % 139
  d4 r4 r4 | % 140
  d4 r4 r4 | % 141
  d4 r4 r8 d8 | % 142
  g8 fis8 g8 a8 bes8 c8 | % 143
  d4 d,4 r4 | % 144
  r8 a'16 g16 f8 es8 d8 c8 | % 145
  b4 g'4 r4 | % 146
  r8 g16 f16 es8 d8 c8 bes8 | % 147
  a4 f'4 r4 | % 148
  r8 f16 es16 d8 c8 bes8 a8 | % 149
  g4 c4 r4 | % 150
  a4^\markup"(Solo)" bes4 r4 | % 151
  g4 a4 r4 | % 152
  f4 g4 r4 | % 153
  c8 d8 es8 f8 g8 es8 | % 154
  f4 f, f' | % 155
  bes,4 r8 bes'8 a8 g8 | % 156
  f8 c16 bes16 c8 a16 g16 a8 f8 | % 157
  bes8 g'8 es8 c8 f8 f,8 | % 158
  bes4 r4 r4 | % 159
  r8 bes16\f^\markup "(Tutti)" c16 d8 c16 d16 e?8 d16 e16 | % 160
  f4 r4 r4 | % 161
  r8 f16 g16 a8 g16 a16 b8 a16 b16 | % 162
  c4 r4 r4 | % 163
  r8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | % 164
  g8 f16 es16 d8 c8 bes8 a8 | % 165
  bes8 g8 g'8 g8 g8 g8 | % 166
  g16 f16 g16 a16 bes8 bes8 bes8 bes8 | % 167
  bes16 a16 bes16 c16 d8 d8 d8 d8 | % 168
  d8 c16 bes16 c8 a16 bes16 c8 c8 | % 169
  c8 bes16 a16 bes8 g,8 g8 a16 bes16 | % 170
  c8 d16 es16 f8 es8 d8 c8 | % 171
  bes8 c16 d16 es8 d8 c8 bes8 | % 172
  a8 g8 fis8 g8 a8 bes8 | % 173
  c8 bes8 c8 d8 es8 c8 | % 174
  d4 r4 r8 c8 | % 175
  bes8 a16 g16 es'8 d16 c16 d8 c8 | % 176
  b4\p r8 d8 g8 f8 | % 177
  es8 d16 c16 b8 d8 b8 g8 | % 178
  c8 g'8 c8 c8 c8 bes16 a16 | % 179
  bes8 bes16 a16 bes8 g,16\f fis16 g8 a16 bes16 | % 180
  c8 d16 es16 f8 es8 d8 c8 | % 181
  bes8 c16 d16 es8 r8 r4 | % 182
  f4\paren\p r4 r4 | % 183
  es4 r4 r4 | % 184
  r8 \slurDashed es'16(\f d16 es8) c16( bes16 \slurSolid c8) c,8 | % 185
  bes8 g8 c8 a8 d8 d,8 | % 186
  g8 d'16\p c16 d8 g16 fis16 g8 g,8 | % 187
  c8 d8 e8 c8 d8 e8 | % 188
  f,8 c'16 bes16 c8 f16 e16 f8 f,8 | % 189
  bes8 c8 d8 bes8 c8 d8 | % 190
  e,8 b'16 a16 b8 e16 d16 e8 e,8 | % 191
  a8 b8 cis8 a8 b8 cis8 | % 192
  d,4 r4 r4 | % 193
  R4*3*15 | % 208
  a'8( a8 a8 a8 a8 a8) | % 209
  a8( a8 a8 a8 a8 a8) | % 210
  a8( a8 a8 a8 a8 a8) | % 211
  bes8 d8\f es8 c8 f8 f,8 | % 212
  bes8 r8 r4 r4 | % 213
  r8 bes16 c16 d8 c16 d16 e8 d16 e16 | % 214
  f8 r8 r4 r4 | % 215
  r8 a,8[ a'8 g8 fis8 d8] | % 216
  g8 r8 r4 r4 | % 217
  r8 g,8\p g'8 f8 e8 d8 | % 218
  cis8 r8 r4 r4 | % 219
  r8 d,8 d'8 c8 b8 a8 | % 220
  gis8 r8 r4 r4 | % 221
  a8 r8 r4 r4 | % 222
  R4*3*2 | % 224
  r8 d16\f e16 f8 e16 f16 g8 f16 g16 | % 225
  a8 f16 g16 a8 g16 a16 b8 a16 b16 | % 226
  c8 a16 b16 c8 b16 c16 d8 c16 d16 | % 227
  e8 e,8 e'8 d8 cis8 a8 | % 228
  d8 r8 r4 r4 | % 229
  r4 r8 d8\p bes8 g8 | % 230
  c4 r8 c8 a8 f8 | % 231
  bes4 r8 bes8 g8 e8 | % 232
  a4 r4 r4 | % 233
  g4 r4 r4 | % 234
  r8 g8[ e8 cis8 a8 cis8] | % 235
  d4 r4 r4 | % 236
  r8 f8[ d8 b8 g8 b8] | % 237
  c4 r4 r4 | % 238
  r8 es8[ c8 a8 f8 a8] | % 239
  bes8 d8 g,8 g8 g8 g8 | % 240
  g4 r4 r4 | % 241
  R4*3*2 | % 243
  f4 r4 r4 | % 244
  cis'4 r4 r4 | % 245
  d4 r4 r4 | % 246
  a4 r4 r4 | % 247
  a4 r4 r4 | % 248
  a4 r4 r4 | % 249
  a4 r4 r4 | % 250
  R2. * 30 | % 280
  R2. | % 281
  r8 d16\f e16 f8 e16 f16 g8 f16 g16 | % 282
  a8 f16 g16 a8 g16 a16 bes8 a16 bes16 | % 276
  c8 a16 b16 c8 b16 c16 d8 c16 d16 | % 277
  e8 e,8 e'8 d8 cis8 a8 | % 278
  d8 d,8 d'8 c8 bes8 a8 | % 279
  g8 a16 bes16 c8 bes8 a8 g8 | % 280
  f8 g16 a16 bes8 a8 g8 f8 | % 281
  e8 d8 cis8 d8 e8 f8 | % 282
  g8 f8 g8 a8 bes8 g8 | % 283
  a4 r4 r8 g8 | % 284
  f8 e16 d16 bes'8 a16 g16 a8 a,8 | % 285
  d4\fermata r4 r4 | % 286
  \bar "|."
}
