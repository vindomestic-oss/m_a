\version "2.20.0"
\language "nederlands"

\include "parenthesized_dynamics.ly"

first_pg_no = 1
instrument = "Violino I"

\include "BWV_1052R_header.ly"
\include "BWV_1052R_paper_parts.ly"

scoreAGlobal = {
  \key d \minor
  \time 4/4
  \compressFullBarRests
}

\include "scoreAViolinI.ly"

scoreAViolinIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 5/4)
} \scoreAViolinI

\score {
  \scoreAViolinIPart
  \layout {}
  \header {
    piece = \markup {\hspace #9 {\pieceA}}
  }
  \midi {
    \tempo 4 = 100
  }
}

\pageBreak

scoreBGlobal = {
  \key g \minor
  \time 3/4
  \tempo "Adagio"
  \compressFullBarRests
}

\include "scoreBViolinI.ly"

scoreBViolinIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreBViolinI

\score {
  \scoreBViolinIPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceB}}
  }
  \midi {
    \tempo 4 = 50
  }
}

\pageBreak

scoreCGlobal = {
  \key d \minor
  \time 3/4
  \tempo "Allegro"
  \compressFullBarRests
}

\include "scoreCViolinI.ly"

scoreCViolinIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 4/4)
} \scoreCViolinI

\score {
  \scoreCViolinIPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceC}}
  }
  \midi {
    \tempo 4 = 110
  }
}
