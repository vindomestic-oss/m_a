\version "2.18.2"
\language "nederlands"
scoreAViolinConc = \relative c' {
  \scoreAGlobal

  d16\paren\f e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  d16^"(Solo)" f a16 e16 f16 d16 e16 cis16 d16 a16 bes16 g16 a16 d16 e16 cis16 | % 7
  d16 f16 g16 e16 f16 a16 bes16 g16 a16 d16 f cis16 d16 a16 bes16 g16 | % 8
  a16 f16 g16 e16 f16 a16 bes16 g16 a16 d16( e16 cis16) d16 f16( g16 e16) | % 9
  f16 a d16 a16 bes16 g16 a16 e16 f16 d16 e16 cis16 d16 f16 g16 e16 | % 10
  f16 a16 bes16 g16 a16 d16 bes16 g16 a16 d16 g,16 e16 f16 d'16 e,16 cis16 | % 11
  d16 d'16 a16 f16 d16 a'16 f16 d16 a16 f'16 d16 a16 f16 d'16 a16 f16 | % 12
  d16^"(Tutti)" e16 f8 e8 d8 a'8 d4 a8 | % 13
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 14
  bes8 g16 e16 a,8 cis'8~ cis bes16 g16 a,8 e''8~ | % 15
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 16
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 17
  fis,8[( g8]) cis8[(^"(Solo)" d8]) e,8[(^"(Tutti)" f8]) cis'8[(^"(Solo)" d8]) | % 18
  f8. e16 d16 c16 b16 a16 d8. c16 b16 a16 gis16 fis16 | % 19
  e8^"(Tutti)" fis16 gis16 a16 b16 c16 d16 e16 f16 g8-. g16 a16 bes8-. | % 20
  cis,8 d8-. gis,8-. a8 dis,8 r8 e8 r8 | % 21
  a16^"(Solo)" c e16 b16 c16 a16 b16 gis16 a16 e16 f16 d16 e16 a16 b16 gis16 | % 22
  a16 c16 d16 b16
  c16 e16 f16 d16 e16 a16 c16 gis16 a16 e16 f16 d16 | % 23
  e16 c16 d16 b16 c16 e16 f16 d16 e16 a16 b16 gis16 a16 c16 d16 b16 | % 24
  c16 gis16 a16 e16 f16 d16 e16 b16
  c16 gis16 a16 e16 f16 d16 e16 b16 | % 25
  c16 gis16 a16 c16 e16 b16 c16 e16 a16 dis,16 e16 a16 c16 gis16 a16 c16 | % 26
  e16 b16 c16 e16 a16 a,16 c'16 a,16 e''16 a,,16 a'16 a,16 c'16 a,16 e''16 a,,16 | % 27
  a''16 a,16 c16 e16 a16 a,16 c16 e16 a16 a,16 cis16 e16 a16 a,16 cis16 e16 | % 28
  a16 a,16 d16 f16 a16 a,16 d16 f16 a16 a,16 c16 fis16 a16 fis16 c16 a16 | % 29
  bes16 g16 bes16 d16 g16 g,16 bes16 d16 g16 g,16 b16 d16 g16 g,16 b16 d16 | % 30
  g16 g,16 c16 e16 g16 g,16 c16 e16 g16 g,16 bes16 e16 g16 e16 bes16 g16 | % 31
  a16 f16 a16 c16 f16 f,16 a16 c16 f16 f,16 a16 c16 f16 f,16 a16 c16 | % 32
  f16 f,16 bes16 d16 f16 f,16 bes16 d16 f16 f,16 bes16 d16 f16 d16 bes16 d16 | % 33
  gis,16 e16 gis16 b16 e16 e,16 gis16 b16 e16 e,16 a16 c16 e16 c16 a16 c16 | % 34
  fis,16 d16 fis16 a16 d16 d,16 fis16 a16 d16 d,16 g16 bes16 d16 bes16 g16 bes16 | % 35
  e,16 c16 e16 g16 c16 c,16 e16 g16 c16 c,16 f16 a16 c16 a16 f16 a16 | % 36
  d,16 bes16 d16 f16 bes16 g16 e16 g16 c,16 a16 c16 e16 a16 f16 d16 f16 | % 37
  bes,16 g16 bes16 d16 g16 e16 c16 e16 a,16 f16 g16 a16 bes16 c16 d16 e16 | % 38
  f16 c16^"(Tutti)" d16 e16 f16 g16 a16 bes16 c8 f,8 g,8 e'8 | % 39
  f,16^"(Solo)" g16 a8 g8 f8 c'8 a'4 c,8 | % 40
  e,16 f16 g8 f8 e8 bes'8 g'4 bes,8 | % 41
  a16 bes16 c8-. c16 d16 es8-. fis,8 a'16(^"(Tutti)" g16 fis16 e16 d16 c16) | % 42
  bes16^"(Solo)" c16 d8-. d16 e16 f8-. gis,8 b'16(^"(Tutti)" a16 gis16 fis16 e16 d16) | % 43
  cis16^"(Solo)" d16 e16 f16 g16 a16 bes16 g16 cis,8 \slurDashed e16(^"(Tutti)" d16 cis16 b16 a16 g16) | % 44
  \slurSolid f16( g16 a16) g16 f16 e16 d16 cis16 d16^"(Solo)" f16 a16 cis16 d16 a16 f16 d16 | % 45
  \phrasingSlurUp \phrasingSlurDashed gis,16\( f'16( b16\) a16) b16 f16( e16 d16) gis,16\( f'16( b16\) a16) b16 f16( e16 d16) | % 46
  c16\( e16( a16\) gis16) a16 f16( e16 d16) c16\( e16( a16\) gis16) a16 f16( e16 d16) | % 47
  cis16\( bes'16( e16\) d16) e16 bes16( a16 g16) cis,16\( bes'16( e16\) d16) e16 bes16( a16 g16) | % 48
  f16\( a16( d16\) cis16) d16 bes16( a16 g16) f16\( a16 d16\) cis16 \slurDashed d16 g,16( f16 e16) | % 49
  dis16\( c'16 fis16\) e16 fis16 c16( b16 a16) dis,16\( c'16 fis16\) e16 fis16 c16( b16 a16) \slurSolid | % 50
  \phrasingSlurDown gis16\( f'16( b16\) a16) b16 f16( e16 d16) gis,16\( f'16( b16\) a16) b16 f16( e16 d16) | % 51
  c16\( e16( a16\) gis16) a16 d,16( c16 b16) a16\( c16( a'16\) gis16) a16 bes,16( a16 g16) | % 52
  f16\(  c'16( a'16\) gis16) a16  f,16( e16 d16) c16\( e'16( a16\) gis16) a16 e16( d16 c16) | % 53
  f16 d16( c16 b16) d16 b16( a16 gis16) b16 gis16( fis16 e16) f16 d16( c16 b16) | % 54
  c16 e16 a16 gis16 a16 e16 c'16 a16 e'8 a,8 e8 gis8 | % 55
  a16^"(Tutti)" b16 c8 b8 a8  e'8 a4 e8 | % 56
  \allowPageTurn f8 d16 b16 e8 c16 a16 d8  b16 gis16 e8  f'8~ | % 57
  f8 d16 b16  e,8  gis'8~ gis8 f16 d16  e,8  b''8~ | % 58
  b8 gis16 e16 f16 d16 e16 c16  d16 b16 c16 a16 b16 gis16 a16 fis16 | % 59
  gis16 e16 fis16 gis16 a16 b16 c16 d16  e16 f16 g8-. g16 a16 bes8-. | % 60
  cis,8 d8 gis,8 a8 dis,8 r8 e8 r8 | % 61
  <<
    {
      a16[^"(Solo)" s16 a16] s16 gis16[ s16 a16] s16 bes16[ s16 a16] s16 gis16[ s16 a16] s16 | % 62
      e16[ s16 a16] s16 gis16[ s16 a16] s16 bes16[ s16 a16] s16 gis16[ s16 a16] s16 | % 63
      e16[ s16 <c' e,>16] s16 <b d,>16[ s16 <c e,>16] s16 <d f,>16[ s16 <c e,>16] s16 <d f,>16[ s16 <b d,>16] s16 | % 64
      <c e,>16[ s16 <c e,>16] s16 <b d,>16[ s16 <c e,>16] s16 <d f,>16[ s16 <c e,>16] s16 <d f,>16[ s16 <b d,>16] s16 | % 65
      <c e,>16[ s16 <a c,>16] s16 <bes d,>16[ s16 <gis b,>16] s16 <a c,>16[ s16 <c e,>16] s16 <bes d,>16[ s16 <gis b,>16] s16 | % 66
      <a c,>16[ s16 <e c>16] s16 <fis d>16[ s16 <gis b,>16] s16 <a c,>16[ s16 <e c>16] s16 <fis d>16[ s16 <gis b,>16] s16 | % 67
      <a c,>16[ s16 <e c>16] s16 <fis d>16[ s16 <gis e>16] s16 <a fis>16[ s16 <b gis>16] s16 <c a>16[ s16 <d b>16] s16 | % 68
    }
    \\
    {
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 62
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 63
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 64
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 65
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 66
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 67
      s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] s16 a16[ s16 a16] | % 68
    }
  >>
  <<
    {
      e'16  a,16 c16 e16
    }
    \\
    {
      c16 s8.
    }
  >>
  a'16 g16 fis16 e16 dis16 fis16 a16 c16 dis,16 c'16 b16 a16 | % 69
  <<
    {
      g16[ s16 e16] s16 dis16[ s16 e16] s16 f16[ s16 e16] s16 dis16[ s16 e16] s16 | % 70
      b16[ s16 e16] s16 dis16[ s16 e16] s16 f16[ s16 e16] s16 dis16[ s16 e16] s16 | % 71
      b16[ s16 <g' b,>16] s16 <fis a,>16[ s16 <g b,>16] s16 <a c,>16[ s16 <g b,>16] s16 <a c,>16[ s16 <fis a,>16] s16 | % 72
      <g b,>16[ s16 <g b,>16] s16 <fis a,>16[ s16 <g b,>16] s16 <a c,>16[ s16 <g b,>16] s16 <a c,>16[ s16 <fis a,>16] s16 | % 73
      <g b,>16[ s16 <e g,>16] s16 <f a,>16[ s16 <dis fis,>16] s16 <e g,>16[ s16 <g b,>16] s16 <f a,>16[ s16 <dis fis,>16] s16 | % 74
      <e g,>16[ s16 <b g>16] s16 <cis a>16[ s16 <dis fis,>16] s16 <e g,>16[ s16 <b g>16] s16 <cis a>16[ s16 <dis fis,>16] s16 | % 75
      <e g,>16[ s16 <b g>16] s16 <cis a>16[ s16 <dis b>16] s16 <e cis>16[ s16 <fis dis>16] s16 <g e>16[ s16 <a fis>16] s16 | % 76
      <b g>16[ s16 <b g>16] s16 <c a>16[ s16 <b g>16] s16 <c a>16[ s16 <a fis>16] s16 <b g>16[ s16 <a fis>16] s16 | % 77
      <b g>16[ s16 <g e>16] s16 <a fis>16[ s16 <g e>16] s16 <a fis>16[ s16 <fis dis>16] s16 <g e>16[ s16 <fis dis>16] s16 | % 78
      <g e>16[ s16 <gis d>16] s16 <a c,>16[ s16 <g b,>16] s16 <fis a,>16[ s16 <e g,>16] s16 <e fis,>16[ s16 <d fis,>16] s16 | % 79
      <d gis,>16[ s16 <c a>16] s16 <b a>16[ s16 <e g,>16] s16 <e f,>16[ s16 <d f,>16] s16 <d e,>16[ s16 <c e,>16] s16 | % 80
      <c d,>16[ s16 <a d,>16] s16 <b d,>16[ s16 <b g>16] s16 <c g>16[ s16 <bes c>16] s16 <c a>16[ s16 <bes g>16] s16 | % 81
    }
    \\
    {
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 70
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 71
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 72
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 73
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 74
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 75
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 76
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 77
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 78
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 79
      s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 80
      s16 f16[ s16 f16] s16 f16[ s16 f16] s16 e16[ s16 e16] s16 e16[ s16 e16] | % 81
    }
  >>
  <<
    {
      a,16 b16 c16 e16 a16 e16 f16 d16 a16 b16 c16 e16 a16 e16 f16 d16 | % 82
      b16 c16 d16 f16 g16 d16 e16 c16 b16 c16 d16 f16 g16 d16 e16 b16 | % 83
      a16 b16 c16 es16 a16 c,16 a'16 c,16 a16 b16 c16 es16 a16 c,16 a'16 c,16 | % 84
      b16 c16 d16 f16 as16 b,16 as'16 b,16 b16 c16 d16 f16 as16 b,16 as'16 b,16 | % 85
      fis16 g16 a16 c16 es16 fis,16 es'16 fis,16 fis16 g16 a16 c16 es16 fis,16 es'16 fis,16 | % 86
      f16 g16 as16 b16 d16 f,16 d'16 f,16 f16 g16 as16 b16 d16 f,16 d'16 f,16 | % 87
      es16 f16 g16 b16 c16 es,16 c'16 es,16 es16 f16 g16 b16 c16 es,16 c'16 es,16 | % 88
      d16 es16 f16 b16 c16 d,16 c'16 d,16 d16 es16 f16 b16 c16 d,16 c'16 d,16 | % 89
      d16 es16 f16 as16 b16 d,16 b'16 d,16 d16 es16 f16 as16 b16 d,16 b'16 d,16 | % 90
    }
    \\
    {
      f16 s8. s4 f16 s8. s4 | % 82
      f16 s8. s4 f16 s8. s4 | % 83
      es16 s8. s4 es16 s8. s4 | % 84
      d16 s8. s4 d16 s8. s4 | % 85
      a16 s8. s4 a16 s8. s4 | % 86
      g16 s8. s4 g16 s8. s4 | % 87
      g16 s8. s4 g16 s8. s4 | % 88
      g16 s8. s4 g16 s8. s4 | % 89
      g16 s8. s4 g16 s8. s4 | % 90
    }
  >>
  c16 d16 e8 d8 c8 g'8 e'4 g,8 | % 91
  b,16 c16 d8 c8 b8 f'8 d'4 f,8 | % 92
  e16 f16 g8-. g16 a16 bes8-. cis,8 \slurDashed e'16(^"(Tutti)" d16 cis16 b16 a16 g16) | % 93
  <<{a16^"(Solo)" bes16 c8-. c16 d16 es8-.}\\{f,16 s16 s8 s4}>> fis8 a'16(^"(Tutti)" g16 fis16 e16 d16 c16) | % 94
  <<
    {
      bes16 s8. s4 bes16 s8. s4 | % 95
      \slurDashed c16( bes16 c16) d16 es16 fis16 g16 a16 c,16( bes16 c16) d16 es16 fis16 g16 a16 | % 96
      d,16( c16 d16) fis16 g16 a16 bes16 g16 d16( c16 d16) fis16 g16 a16 bes16 g16 | % 97
      es16 s8. s4 es16 s8. s4 | % 98
      d16 s8. s4 d16 s8. s4 | % 99
      bes16( a16 bes16) s16 s8. a16 bes16( a16 bes16) s16 s4 | % 100
      c16( bes16 c16) a,16 c16 es16 fis16 a16 c16( bes16 c16) a,16 c16 fis16 a16 c16 | % 101
      fis16( e16 fis16)  d,16 fis16 a16 c16  fis16 a16( g16 a16)  d,,16 a'16 c16  fis16 a16 | % 102
    }
    \\
    {
      \slurDashed g,16(^"(Solo)" fis16 g16) a16 bes16  d16 fis16 g16  g,16( fis16 g16) a16 bes16  d16 fis16 g16 | % 95
      g,16 s8. s4 g16 s8. s4 | % 96
      g16 s8. s4 g16 s8. s4 | % 97
      g16( fis16 g16) a16 bes16  c16 d16 es16  g,16( fis16 g16) a16 bes16  c16 d16 es16 | % 98
      fis,16( e16 fis16) a16 c16 a16 fis16 d16 fis16( e16 fis16) a16 c16 a16 fis16 d16 | % 99
      g16( fis16 g16) cis,16 e16 g16 bes16 fis16 g16( fis16 g16) cis,16 e16 g16 bes16 g16 | % 100
      fis16 s8. s4 fis16 s8. s4 | % 101
      c'16 s8. s4 c16 s8. s4 | % 102
    }
  >>
  \slurSolid c'16( a16) bes16( fis16) g16( d16) es16( b16) c16( a'16) fis16( g16) bes,16 g'16 a,16 fis'16 | % 103
  g4 r4 bes16 c16 d8 c8 bes8~ | % 104
  bes8[ a8~] a8 g8~ g8 c,8~ c a16 fis16 | % 105
  c8 es'~ es c16 a16 c,8 fis'~ fis es16 c16 | % 106
  d,8 a''~ a fis16 d16 es16 c16 d16 bes16 c16 a16 bes16 g16 | % 107
  d'1~ | % 108
  d8 r8 r4 bes'8~-\fermata bes32 c32 bes32 a32 g32( a32 bes32 a32 g32 f32 e32 f32) | % 109
  g32 f32 e32 d32 cis32 d32 e32 d32 \stemUp cis32 b32 a32 b32 cis32 bes32 a32 g32 \stemNeutral bes32 a32 g32 f32 e32 f32 g32 f32 e32 d32 cis32 d32 e32 d32 cis32 b32 | % 110
  a8~-\prall a32 b32 cis32 d32 e32 f32 g32 e32 cis32 d32 e32 f32 g32 a32 bes32 g32 e32 f32 g32 a32 \stemUp bes32 cis32 d32 e32 d32 cis32 b32 a32 | % 111
  \stemDown g32 a32 b32 cis32 d32 e32 f32 g32 \stemNeutral a32 bes32 a32 g32 f32 e32 d32 cis32 d8\noBeam g8^"(Tutti)" a8 fis8 | % 112
  g4 bes2.^"(Solo)" | % 113
  a1 | % 114
  g1 | % 115
  f16 a16 a16 a16 g16 a16 f16 a16 e16 a16 g16 f16 e16 d16 cis16 b16 | % 116
  a16 a16 a16 a16 g16 a16 f16 a16 e16 a16 g16 f16 e16 d16 cis16 b16 | % 117
  a16 d16 e16 f16 g16 e16 f16 d16 a16 d16 e16 f16 g16 e16 f16 d16 | % 118
  e16 a16 b16 c16 d16 b16 c16 a16 e16 a16 b16 c16 d16 b16 c16 a16 | % 119
  d,16  d'16 e16 f16 g16 e16 f16 d16  d,16  d'16 e16 f16 g16 e16 f16 d16 | % 120
  cis16 e16 f16 g16 a16 f16 g16 e16 cis16 e16 f16 g16 a16 f16 g16 e16 | % 121
  f16 d16 f16 a16 d16 d,16 f16 a16 d16 d,16 fis16 a16 d16 d,16 fis16 a16 | % 122
  d16 d,16 g16 bes16 d16 d,16 g16 bes16 d16 d,16 f16 b16 d16 b16 f16 d16 | % 123
  es16 c16 es16 g16 c16 c,16 es16 g16 c16 c,16 e16 g16 c16 c,16 e16 g16 | % 124
  c16 c,16 f16 a16 c16 c,16 f16 a16 c16 c,16 es16 a16 c16 a16 es16 c16 | % 125
  d16 bes16 d16 f16 bes16 bes,16 d16 f16 bes16 bes,16 d16 f16 bes16 bes,16 d16 f16 | % 126
  bes16 bes,16 es16 g16 bes16 bes,16 es16 g16 bes16 bes,16 es16 g16 bes16 g16 es16 g16 | % 127
  cis,16 a16 cis16 e16 a16 a,16 cis16 e16 a16 a,16 d16 f16 a16 f16 d16 f16 | % 128
  b,16 g16 b16 d16 g16 g,16 b16 d16 g16 g,16 c16 es16 g16 es16 c16 es16 | % 129
  a,16 f16 a16 c16 f16 f,16 a16 c16 f16 f,16 bes16 d16 f16 d16 bes16 d16 | % 130
  g,16 es16 g16 bes16 es16 c16 a16 c16 f,16 d16 f16 a16 d16 bes16 g16 bes16 | % 131
  es,16 c16 es16 g16 c16 a16 f16 a16 d,16 bes16 c16 d16 es16 f16 g16 a16 | % 132
  bes16 f16^"(Tutti)" g16 a16 bes16 c16 d16 es16 f8 bes,8 f8 a8 | % 133
  bes,1~^"(Solo)" | % 134
  bes1~ | % 135
  bes16 a16 bes16 c16 d16 es16 f16 g16 as16 b16( c16 d16 c16 b16 a16 g16) | % 136
  es'16 c16 b16 c16 g16 c16 es,16 g16 c,16 b16 c16 d16 es16 f16 g16 a16 | % 137
  bes16 cis16( d16 e16 d16 cis16 b16 a16) f'16 d16 cis16 d16 a16 d16 f,16 a16 | % 138
  d,16 e16 f16 g16 a16 bes16 c16 d16 es16 fis16( g16 a16 g16 fis16 e16 d16) | % 139
  bes'16 g16( a16 bes16 a16 g16 fis16 e16) c'16 a16( bes16 c16 bes16 a16 g16 fis16) | % 140
  d'16 bes16( c16 d16 c16 bes16 a16 g16) e'16 cis16( d16 e16 d16 cis16 b16 a16) | % 141
  f'16 d16 cis16 d16 bes16 d16 a16 d16 g,16 d'16 e16 f16 e16 d16 c16 b16 | % 142
  e16 c16 bes16 c16 a16 c16 g16 c16 f,16 c'16 d16 es16 d16 c16 bes16 a16 | % 143
  d16 bes16 a16 bes16 g16 bes16 f16 bes16 e,16 g16 f16 g16 e16 g16 d16 g16 | % 144
  cis,16 g'16 d16 g16 cis,16 g'16 b,16 g'16 a,16 g'16 cis,16 g'16 e16 g16 cis,16 e16 | % 145
  <<{f8 s8}\\{d8 d16  d,}>>  cis'  d,  d'  d,  es'  d,  d'  d,  cis'  d,  d'  d, | % 146
  f16 d  d'  d,  cis'  d,  d'  d,  es'  d,  d'  d,  cis'  d,  d'  d, | % 147
  <<
    {
      s8 f'8 e[ f] g[ f] g[ e] |
      f8[ f] e[ f] g[ f] g[ e] |
      f8[ a] bes[ g] a[ f] g[ e] |
      f8[ a] b[ cis] d[ f,] g[ e] |
      f8[ f] g[ a] b[ cis] d[ e] |
      f8[ f] a[ a] a[ a] g[ g] |
      g8[ g] f[ f] f[ f] e[ e] |
      e8[ e] d[ d] d[ d] c[ c] |
      c8[ c] bes[ bes] a[ a] d[ d] |
      d8[ d] c[ c] bes[ bes] bes[ bes] |
      a8[ a] a[ a] g[ g] g[ g] |
      f8[ f] f[ f] e[ e] e[ e] |
      fis8[ fis] g[ g] e[ e] f[ f] |
      d8[ d] es[ es] cis[ cis] d[ d] |
    }
    \\
    {
      a16 d, d' d, cis' d, d' d, e' d, d' d, e' d, cis' d, | % 148
      d' d, d' d, cis' d, d' d, e' d, d' d, e' d, cis' d,  | % 149
      d' d, f' d, g' d, e' d, f' d, d' d, e' d, cis' d, | % 150
      d' d, f' d, g' d, e' d, f' d, a' d, b' d, cis' d, | % 151
      d' d, d' d, e' d, f' d, g' d, a'' d,, b'' d,, cis'' d,, | % 152
      d'' d,, d'' d,, c''  d,, c'' d,, b'' d,, b'' d,, bes'' d,, bes'' d,, | % 153
      a'' d,, a'' d,, a'' d,, a'' d,, gis' d, gis' d, g' d, g' d, | % 154
      fis' d, fis' d, f' d, f' d, e' d, e' d, es' d, es' d, | % 155
      d' d, d' d, g' d, g' d, g' d, g' d, f' d, f' d, | % 156
      e' d, e' d, a'' d,, a'' d,, a'' d,, a'' d,, g' d, g' d, | % 157
      g' d, g' d, f' d, f' d, f' d, f' d, e' d, e' d, | % 158
      e' d, e' d, d' d, d' d, d' d, d' d, cis' d, cis' d, | % 159
      c' d, c' d, b' d, b' d, bes' d, bes' d, a' d, a' d, | % 160
      as' d, as' d, g d g d g d g d f d f d | % 161
    }
  >>
  <<
    {
      d16 e16 f16 b16 d16 a16 b16 gis16 d16 e16 f16 b16 d16 b16 gis16 e16 | % 162
      f16 g16 a16 cis16 d16 a16 bes16 g16 f16 g16 a16 cis16 d16 a16 f16 d16 | % 163
      e16 f16 g16 cis16 d16 a16 bes16 g16 e16 f16 g16 cis16 d16 bes16 g16 e16 | % 164
      f16 e16 f16 a16 d16 a16 bes16 g16 f16 e16 f16 a16 d16 a16 f'16 d16 | % 165
    }
    \\
    {
      gis,,16 s8. s4 gis16 s8. s4 | % 162
      a16 s8. s4 a16 s8. s4 | % 163
      bes16 s8. s4 bes16 s8. s4 | % 164
      a16 s8. s4 a16 s8. s4 | % 165
    }
  >>
  <<
    {
      b''2^"arpeggio" b2 | % 166
      bes2 a2 | % 167
      a2 b2 | % 168
      cis2 d2 | % 169
      d2 d2 | % 170
      d2 cis2 | % 171
    }
    \\
    {
      gis,2 gis2 | % 166
      g2 g2 | % 167
      fis2 f2 | % 168
      bes2 a2 | % 169
      gis2 gis2 | % 170
      a2 a2 | % 171
    }
    \\
    {
      f'2 e4 d4 | % 166
      cis2 cis2 | % 167
      d2 d2 | % 168
      e2 f2 | % 169
      f2 e2 | % 170
      e2 e2 | % 171
    }
  >>
  <<
    {
      d'16 s16 s8
    }
    \\
    {
      d,,16 e16^"(Tutti)" f8
    }
    \\
    {
      f'16 s16 s8
    }
    \\
    {
      a,16 s16 s8
    }
  >>
  e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8^"(Solo)" | % 173
  \phrasingSlurUp \phrasingSlurDashed cis,16\( bes'16( e16\) d16) e16 \slurDashed bes16( a16 g16) \slurSolid cis,16\( bes'16( e16\) d16) e16 \slurDashed bes16( a16 g16) | % 174
  \slurSolid f16\( a16( d16\) cis16) d16 \slurDashed bes( a16 g16) \slurSolid f16\( a16( d16\) cis16) d16 \slurDashed bes( a16 g16) | % 175
  fis(  es'16 a16) g16 a16 es16( d16 c16) fis,16( es'16 a16) g16 a16 es16( d16 c16) | % 176
  bes16( d16 g16) fis16 g16 es16( d16 c16) bes16( d16 g16) fis16 g16 c,16( bes16 a16) | % 177
  gis16( f'16 b16) a16 b16 f16( e16 d16) gis,16( f'16 b16) a16 b16 f16( e16 d16) | % 178
  cis16( bes'16 e16) d16 e16 bes16( a16 g16) cis,16( bes'16 e16) d16 e16 bes16( a16 g16) | % 179
  f16( a16 d16) cis16 d16 g,16( f16 e16) d16( f16 d'16) cis16 d16 e,16( d16 c16) | % 180
  \slurSolid \phrasingSlurDown bes16\( f'16( d'16\) cis16) d16  bes,16 a16 g16 f16\( a'16( d16\) cis16) d16 a16 g16 f16 | % 181
  bes16 g16( f16 e16) g16 e16( d16 cis16) e16 \slurDashed cis16( b16 a16) bes16 g16( f16 e16) | % 182
  f16 a16  d16 cis16 d16 a16 f'16 d16 a'8 d,8 a8 cis8 | % 183
  <<{d8 s}\\{d,16 e16^"(Tutti)" f8}>> e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8 c16 d16 es8 | % 188
  fis,8-. g8-. cis,8-. d8-. gis,8 r8 a8 r8 | % 189
  d4\fermata r4 r2 \bar "|." | % 190

}
