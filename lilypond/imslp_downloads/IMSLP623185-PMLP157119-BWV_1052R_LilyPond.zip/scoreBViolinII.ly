\version "2.18.0"
\language "nederlands"
scoreBViolinII = \relative c'' {
  \scoreBGlobal

  g8( g8) bes8( bes8) d8( d8) | % 1
  es,8( d8) es4 r4 | % 2
  a8( a8) c8( c8) es8( es8) | % 3
  fis,8( fis8) a8( a8) c8( c8) | % 4
  d,8( d8) fis8( fis8) a8( a8) | % 5
  bes,8( a8 bes8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 6
  \slurSolid c,8( bes8 c8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 7
  \slurSolid d8( c8 d8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 8
  \slurSolid es4 r8 g8 as8 f8 | % 9
  b,8( b8) d8( d8) f8( f8) | % 10
  as,4 r8 d8 es8 c8 | % 11
  fis8 g8 d4 d4 | % 12
  g,4 r4 r4 | % 13
  bes'4\p g4 d8 c8 | % 14
  bes4 r4 r4 | % 15
  fis'4 fis8( a8) c,8( es8) | % 16
  a,4 r4 r4 | % 17
  fis'4 r4 r4 | % 18
  d4 g4 bes4 | % 19
  a2.~ | % 20
  a4 c4 a4 | % 21
  g4 r4 r4 | % 22
  f4 d4 b4 | % 23
  f'4 r8 d8 g8 g8 | % 24
  as8 as8 g2 | % 25
  g4 r4 r4 | % 26
  g4 es4 c4 | % 27
  cis'4 a4 g4 | % 28
  f4 r4 r4 | % 29
  f'4 d4 a8 g8 | % 30
  f4 r4 r4 | % 31
  cis'4 cis8( e8) g,8( bes8) | % 32
  e,4 r4 r4 | % 33
  cis'4 r4 r4 | % 34
  a4 d,4 f4 | % 35
  e2.~ | % 36
  e4 g4 e4 | % 37
  d4 r4 r4 | % 38
  c'4 a4 fis4 | % 39
  c4 r8 c'8 bes8 a8 | % 40
  bes4 f?4 f4 | % 41
  f4 r4 r4 | % 42
  d'4 b4 g4 | % 43
  g4 r4 r4 | % 44
  es'4 c4 g8( f8) | % 45
  es4 r4 r4 | % 46
  b'4 b8( d8) f,8( as8) | % 47
  d,4 r4 r4 | % 48
  as'4 f4 d4 | % 49
  g4 r4 r4 | % 50
  f4 r4 r4 | % 51
  d'2. | % 52
  c4 r4 r4 | % 53
  bes4 g4 e4 | % 54
  bes'4 r8 g8 f8 f8 | % 55
  f8 es8 g4 g4 | % 56
  g4 r4 r4 | % 57
  c4 a4 g4 | % 58
  es4 c4 a4 | % 59
  a4 r4 r4 | % 60
  bes'4 g4 d8( c8) | % 61
  bes4 r4 r4 | % 62
  fis'4 fis8( a8) c,8( es8) | % 63
  a,4 r4 r4 | % 64
  d4 r4 r4 | % 65
  d4 g4 a8 bes8 | % 66
  a2.~ | % 67
  a4 c4 a4 | % 68
  g4 r4 r4 | % 69
  d'2.~ | % 70
  d4 r8 f8 es8 d8 | % 71
  c8( g8) g4 r4 | % 72
  e'4 d4 d4 | % 73
  d4 r4 r4 | % 74
  g,8( g8) bes8( bes8) d8( d8) | % 75
  es,8( d8) es4 r4 | % 76
  a8( a8) c8( c8) es8( es8) | % 77
  fis,8( fis8) a8( a8) c8( c8) | % 78
  d,8( d8) fis8( fis8) a8( a8) | % 79
  bes,8( a8 bes8) bes'8-. fis8( g8) | % 80
  c,8( bes8 c8) bes'8-. fis8( g8) | % 81
  d8( c8 d8) bes'8-. fis8( g8) | % 82
  es4 r8 g8 as8 f8 | % 83
  b,8( b8) d8( d8) f8( f8) | % 84
  as,4 r8 d8 es8 c8 | % 85
  fis8 g8 d4 d4 | % 86
  g,4-\fermata r4 r4 | % 87

  \bar "|."

}
