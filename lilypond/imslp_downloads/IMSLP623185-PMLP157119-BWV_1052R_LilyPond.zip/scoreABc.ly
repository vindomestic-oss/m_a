\version "2.18.2"
\language "nederlands"
scoreABc = \relative c' {
  \scoreAGlobal

  d,16\paren\f e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  d,4 r4 r2 | % 7
  r2 d4\paren\p r4 | % 8
  R4*4*1 | % 9
  d4 r4 r2 | % 10
  r2 d4 r4 | % 11
  R4*4*1 | % 12
  d4\f r4 d'16 e16 f8 e8 d8 | % 13
  g8 r8 f8 r8 e8 r8 d8 r8 | % 14
  cis8 r8 d8 r8 e8 r8 f8 r8 | % 15
  g8 g8 g8 g8 g8 g8 g8 g8 | % 16
  g4 r4 fis16 g16 a8-. a16 bes16 c8-. | % 17
  c8[( bes8]) bes8[( a8]) a8[( g8]) g8[( f8]) | % 18
  gis,8[( a8]) a8[( b8]) b8[( c8]) c8[( d8]) | % 19
  d4 r4 cis16 d16 e8-. e16 f16 g8-. | % 20
  g8( f8) f8( e8) dis8 r8 e8 r8 | % 21
  a,4 r4 r2 | % 22
  r2 a4\p r4 | % 23
  R1 | % 24
  a4 r4 r2 | % 25
  r2 a4 r4 | % 26
  R1 | % 27
  a'8(\p a8 a8 a8) g8( g8 g8 g8) | % 28
  f8( f8 f8 f8) fis8( fis8 fis8 fis8) | % 29
  g8( g8 g8 g8) f8( f8 f8 f8) | % 30
  e8( e8 e8 e8) e8( e8 e8 e8) | % 31
  f8( f8 f8 f8) es8( es8 es8 es8) | % 32
  d8( d8 d8 d8) d8( d8 d8 d8) | % 33
  d4 r4 c4 r4 | % 34
  c4 r4 bes4 r4 | % 35
  bes4 r4 a4 a'4~ | % 36
  a4 g2 f4~ | % 37
  f4 e4 f4 r8 e8 | % 38
  d4 r8 c16\f bes16 a8 bes8 c8 c,8 | % 39
  f8\p f8 f8 f8 f8 f8 f8 f8 | % 40
  f8 f8 f8 f8 f8 f8 f8 f8 | % 41
  f4 r4 r8 d'8\f e8 fis8 | % 42
  g4 r4 r8 e8 fis8 gis8 | % 43
  a4 r4 r8 a,8 b8 cis8 | % 44
  d8 cis8 d8 e8 f8 e8 f8 d8 | % 45
  e4\p r4 e4 r4 | % 46
  a,4 r4 a4 r4 | % 47
  a'4 r4 a4 r4 | % 48
  d,4 r4 d4 r4 | % 49
  b'4 r4 b4 r4 | % 50
  e,4 r4 e4 r4 | % 51
  a4 r4 g4 r4 | % 52
  f4 r4 e4 r4 | % 53
  d4 r4 gis,4 r4 | % 54
  a4 r8 a16 b16 c8 d8 e8 e,8 | % 55
  a8\paren\f a8 a8 a8 a8 a8 a8 a8 | % 56
  a8 a8 a8 a8 a8 a8 a8 a8 | % 57
  a8 a8 a8 a8 a8 a8 a8 a8 | % 58
  a4 r4 r2 | % 59
  r2 cis16 d16 e8-. e16 f16 g8-. | % 60
  g8( f8) f8( e8) dis8 r8 e8 r8 | % 61
  a,4 r4 r2 | % 62
  a4\paren\p r4 r2 | % 63
  a4 r4 r2 | % 64
  a4 r4 r2 | % 65
  a4 r4 r2 | % 66
  a4 r4 r2 | % 67
  R1 |
  r8 a'4\f g8 fis8 b4 b,8 | % 69
  e4 r4 r2 | % 70
  e4\paren\p r4 r2 | % 71
  e4 r4 r2 | % 72
  e4 r4 r2 | % 73
  e4 r4 r2 | % 74
  e4 r4 r2 | % 75
  e4 r4 r2 | % 76
  R1*14 |
  c,8\paren\p c8 c8 c8 c8 c8 c8 c8 | % 91
  c8 c8 c8 c8 c8 c8 c8 c8 | % 92
  c4 r4 r8 a'8\f b8 cis8 | % 93
  d4 r4 r8 d8 e8 fis8 | % 94
  g8 fis8\p g8 a8 bes8 d8 bes8 g8 | % 95
  a8 g8 a8 bes8 c8 es8 c8 a8 | % 96
  bes8 c8 bes8 a8 g8 bes8 g8 es8 | % 97
  c8 g'8 es8 d8 c8 g8 es8 c8 | % 98
  c'4 r4 c4 r4 | % 99
  cis4 r4 cis4 r4 | % 100
  es4 r4 es4 r4 | % 101
  d4 r4 d4 r4 | % 102
  r8 d'8 bes8 g8 es8 c8 d8 d,8 | % 103
  g4 r4 g'16\f a16 bes8 a8 g8 | % 104
  c8 r8 bes8 r8 a8 r8 g8 r8 | % 105
  fis8 r8 g8 r8 a8 r8 bes8 r8 | % 106
  c8 c8 c8 c8 c8 c8 c8 c8 | % 107
  c4 r4 b,16 c16 d8-. d16 es16 f8-. | % 108
  f8( es8) es8( d8) cis8-\fermata r8 r4 | % 109
  R4*4*2 | % 111
  r2 r8 es8\f c8 d8 | % 112
  g,16 a16 bes8 a8 g8 c8 g'4 c,8 | % 113
  f,16 g16 a8 g8 f8 bes8 f'4 bes,8 | % 114
  e,16 f16 g8 f8 e8 a8 e'4 a,8 | % 115
  d,16\p e16 f8 e8 d8 a'16 b16 cis8 b8 a8 | % 116
  d16 e16 f8 e8 d8 a'16 b16 cis8 b8 a8 | % 117
  d4 r4 r8d8 bes8 g8 | % 118
  c4 r4 r8 c,8 f8 a8 | % 119
  bes,4 r4 r8 bes8 e8 g8 | % 120
  a,4 r4 r8 e'8 cis8 a8 | % 121
  d8 d8 d8 d8 c8 c8 c8 c8 | % 122
  bes8 bes8 bes8 bes8 b8 b8 b8 b8 | % 123
  c8 c8 c8 c8 bes8 bes8 bes8 bes8 | % 124
  a8 a8 a8 a8 a8 a8 a8 a8 | % 125
  bes8 bes8 bes8 bes8 as8 as8 as8 as8 | % 126
  g8 g8 g8 g8 g8 g8 g8 g8 | % 127
  g4 r4 f4 r4 | % 128
  f4 r4 es4 r4 | % 129
  es4 r4 d4 d'4~ | % 130
  d4 c2 bes4~ | % 131
  bes4 a4 bes4 r8 a8 | % 132
  g4 r8 f16\f es16 d8 es8 f8 f8 | % 133
  bes16\p c16 d8 c8 bes8 es8 bes'4 es,8 | % 134
  bes16 c16 d8 c8 bes8 es8 bes'4 es,8 | % 135
  bes4 r4 r8 g8\f g8 g8 | % 136
  c4 r4 r2 | % 137
  r8 a8 a8 a8 d4 r4 | % 138
  r2 r8 d8 d8 d8 | % 139
  g4 r8 g8\p a4 r8 a8 | % 140
  bes4 r8 bes8 cis,4 r8 cis8 | % 141
  d4 r4 r8 g8 a8 b8 | % 142
  c4 r4 r8 f,8 g8 a8 | % 143
  bes8 c8( bes8 a8) g8 a8( g8 f8) | % 144
  e8 \slurDashed f8( e8 d8) cis8 b8 a8 g8 | % 145
  f8 r8 bes8 r8 g8 r8 a8 r8 | % 146
  bes8 r8 f8 r8 g8 r8 a8 r8 | % 147
  d,4 r4 r2 | % 148
  d4 r4 r2 | % 149
  d4 r4 r2 | % 150
  d4 r4 r2 | % 151
  d4 r4 r2 | % 152
  d4 r4 r2 | % 153
  R4*4*18 | % 171
  d'16\f e16 f8 e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 cis8 | % 173
  e8\p g8 bes8 g8 e8 cis8 a8 a'8 | % 174
  d,4 r4 d4 r4 | % 175
  a8 c8 es8 c8 a8 fis8 d8 d'8 | % 176
  g,4 r4 g4 r4 | % 177
  b8 d8 f8 d8 b8 gis8 e8 e'8 | % 178
  a,8 g'8 bes8 g8 e8 cis8 a8 a'8 | % 179
  d,4 r4 c4 r4 | % 180
  bes4 r4 a4 r4 | % 181
  g4 r4 cis,4 r4 | % 182
  d4 r8 d'16 e16 f8 g8 a8 a,8 | % 183
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8 c16 d16 es8 | % 188
  fis,8-. g8-. cis,8-. d8-. gis,8 r8 a8 r8 | % 189
  d,4\fermata r4 r2 | % 190
  \bar "|."

}
