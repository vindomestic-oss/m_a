\version "2.18.0"
\language "nederlands"
scoreBBc = \relative c' {
  \scoreBGlobal

  g8( g8) bes8( bes8) d8( d8) | % 1
  es,8( d8) es4 r4 | % 2
  a8( a8) c8( c8) es8( es8) | % 3
  fis,8( fis8) a8( a8) c8( c8) | % 4
  d,8( d8) fis8( fis8) a8( a8) | % 5
  bes,8( a8 bes8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 6
  \slurSolid c,8( bes8 c8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 7
  \slurSolid d8( c8 d8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 8
  \slurSolid es4 r8 g8 as8 f8 | % 9
  b,8( b8) d8( d8) f8( f8) | % 10
  as,4 r8 d8 es8 c8 | % 11
  fis8 g8 d4 d,4 | % 12
  g4 r4 r4 | % 13
  g'8\p( g8) bes8( bes8) d8( d8) | % 14
  es,8( d8) es4 r4 | % 15
  a8( a8) c8( c8) es8( es8) | % 16
  fis,8( fis8) a8( a8) c8( c8) | % 17
  d,8( d8) fis8( fis8) a8( a8) | % 18
  bes,8( a8 bes8) bes'8 fis8 g8 | % 19
  c,8( bes8 c8) bes'8 fis8 g8 | % 20
  d8( c8 d8) bes'8 fis8 g8 | % 21
  es4 r8 g8 as8 f8 | % 22
  b,8( b8) d8( d8) f8( f8) | % 23
  as,4 r8 d8 es8 c8 | % 24
  as'8 f8 g4 g,4 | % 25
  c4 r4 r4 | % 26
  c8( c8) es8( es8) g8( g8) | % 27
  a,8( a8) cis8( cis8) e8( e8) | % 28
  d,4 r4 r4 | % 29
  d'8( d8) f8( f8) a8( a8) | % 30
  bes,8( a8) bes4 r4 | % 31
  e8( e8) g8( g8) bes8( bes8) | % 32
  cis,8( cis8) e8( e8) g8( g8) | % 33
  a,8( a8) cis8( cis8) e8( e8) | % 34
  f,8( e8 f8) f'8 cis8 d8 | % 35
  g,8( f8 g8) f'8 cis8 d8 | % 36
  a8( g8 a8) f'8 cis8 d8 | % 37
  bes4 r8 d8 es8 c8 | % 38
  fis,8( fis8) a8( a8) c8( c8) | % 39
  es,4 r8 a8 bes8 c8 | % 40
  d8 es8 f4 f,4 | % 41
  bes4 r4 r4 | % 42
  b8( b8) d8( d8) f8( f8) | % 43
  g,8( f8) g4 r4 | % 44
  c8( c8) es8( es8) g8( g8) | % 45
  as,8( g8) as4 r4 | % 46
  d8( d8) f8( f8) as8( as8) | % 47
  b,8( b8) d8( d8) f8( f8) | % 48
  g,8( g8) b8( b8) d8( d8) | % 49
  es8( d8 es8) es'8 b8 c8 | % 50
  f,8( es8 f8) es'8 b8 c8 | % 51
  g8( f8 g8) es'8 b8 c8 | % 52
  as4 r8 c8 des8 bes8 | % 53
  e,8( e8) g8( g8) bes8( bes8) | % 54
  des,4 r8 g8 as8 f8 | % 55
  b8 c8 g4 g,4 | % 56
  c4 r4 r4 | % 57
  a8( a8) c8( c8) es8( es8) | % 58
  fis,8( fis8) a8( a8) c8( c8) | % 59
  d,4 r4 r4 | % 60
  g'8( g8) bes8( bes8) d8( d8) | % 61
  es,8( d8) es4 r4 | % 62
  a8( a8) c8( c8) es8( es8) | % 63
  fis,8( fis8) a8( a8) c8( c8) | % 64
  d,8( d8) fis8( fis8) a8( a8) | % 65
  bes,8( a8 bes8) bes'8 fis8 g8 | % 66
  c,8( bes8 c8) bes'8 fis8 g8 | % 67
  d8( c8 d8) bes'8 fis8 g8 | % 68
  es4 r8 g8 as8 f8 | % 69
  b,8( b8) d8( d8) f8( f8) | % 70
  as,4 r8 d8 es8 c8 | % 71
  \tag #'cantata { \slurDashed } fis8( \tag #'cantata { \slurSolid } g8) es4 r4 | % 72
  cis4 d4 d,4 | % 73
  g4 r4 r4 | % 74
  g'8( g8) bes8( bes8) d8( d8) | % 75
  es,8( d8) es4 r4 | % 76
  a8( a8) c8( c8) es8( es8) | % 77
  fis,8( fis8) a8( a8) c8( c8) | % 78
  d,8( d8) fis8( fis8) a8( a8) | % 79
  bes,8( a8 bes8) bes'8-. fis8( g8) | % 80
  c,8( bes8 c8) bes'8-. fis8( g8) | % 81
  d8( c8 d8) bes'8-. fis8( g8) | % 82
  es4 r8 g8 as8 f8 | % 83
  b,8( b8) d8( d8) f8( f8) | % 84
  as,4 r8 d8 es8 c8 | % 85
  fis8 g8 d4 d,4 | % 86
  g4-\fermata r4 r4 | % 87
  \bar "|."

}
