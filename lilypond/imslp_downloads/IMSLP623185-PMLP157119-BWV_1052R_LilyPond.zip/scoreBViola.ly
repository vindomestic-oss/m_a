\version "2.18.0"
\language "nederlands"
scoreBViola = \relative c' {
  \scoreBGlobal

  g'8( g8) bes8( bes8) d8( d8) | % 1
  es,8( d8) es4 r4 | % 2
  a8( a8) c8( c8) es8( es8) | % 3
  fis,8( fis8) a8( a8) c8( c8) | % 4
  d,8( d8) fis8( fis8) a8( a8) | % 5
  bes,8( a8 bes8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 6
  \slurSolid c,8( bes8 c8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 7
  \slurSolid d8( c8 d8) bes'8-\parenthesize -. \slurDashed fis8( g8) | % 8
  \slurSolid es4 r8 g8 as8 f8 | % 9
  b,8( b8) d8( d8) f8( f8) | % 10
  as,4 r8 d8 es8 c8 | % 11
  fis8 g8 d4 d,4 | % 12
  g4 r4 r4 | % 13
  g'4\p d4 bes8 a8 | % 14
  g4 r4 r4 | % 15
  c4 es4 a,4 | % 16
  d4 r4 r4 | % 17
  c4 r4 r4 | % 18
  bes4 d4 g4 | % 19
  g2. | % 20
  fis4
  a4 d,4 | % 21
  g4 r4 r4 | % 22
  d4 b4 as4 | % 23
  d4 r8 f8 es8 es8 | % 24
  f8 c8 g'8 es8 f8 d8 | % 25
  es4 r4 r4 | % 26
  es4 c4 g4 | % 27
  e'4 e4 e8 cis8 | % 28
  d4 r4 r4 | % 29
  d'4 a4 f8 e8 | % 30
  d4 r4 r4 | % 31
  g4 bes4 e,4 | % 32
  a4 r4 r4 | % 33
  g4 r4 r4 | % 34
  f4 a,4 d4 | % 35
  d2. | % 36
  cis4 e4 a,4 | % 37
  d4 r4 r4 | % 38
  a'4 fis4 es4 | % 39
  a,4 r8 g'8 f8 es8 | % 40
  d8( c8) d8( es8) f8( c8) | % 41
  d4 r4 r4 | % 42
  g4 d4 b4 | % 43
  d4 r4 r4 | % 44
  c'4 g4 es8( d8) | % 45
  c4 r4 r4 | % 46
  f4 as4 d,4 | % 47
  g4 r4 r4 | % 48
  d4 b4 g4 | % 49
  es4 r4 r4 | % 50
  c'4 r4 r4 | % 51
  f2. | % 52
  c4 r4 r4 | % 53
  g'4 e4 des4 | % 54
  g4 r8 bes8 as8 as8 | % 55
  d,8( es8) b8( c8) d8( f8) | % 56
  es4 r4 r4 | % 57
  a,4 es'4 c4 | % 58
  a4 fis4 d4 | % 59
  fis'4 r4 r4 | % 60
  g4 d4 \tag #'cantata { \slurDashed } bes8( \tag #'cantata { \slurSolid } a8) | % 61
  g4 r4 r4 | % 62
  c4 es4 a,4 | % 63
  d4 r4 r4 | % 64
  fis4 r4 r4 | % 65
  bes,8 c8 d8 bes'8 a8 g8 | % 66
  g2. | % 67
  fis4 a4 d,4 | % 68
  g4 r4 r4 | % 69
  b,4 as'4 f4 | % 70
  d4 r8 b'8 c8 g8 | % 71
  a8( g8) c,4 r4 | % 72
  cis4 a8( bes8) c8( d8) | % 73
  bes4 r4 r4 | % 74
  g'8( g8) bes8( bes8) d8( d8) | % 75
  es,8( d8) es4 r4 | % 76
  a8( a8) c8( c8) es8( es8) | % 77
  fis,8( fis8) a8( a8) c8( c8) | % 78
  d,8( d8) fis8( fis8) a8( a8) | % 79
  bes,8( a8 bes8) bes'8-. fis8( g8) | % 80
  c,8( bes8 c8) bes'8-. fis8( g8) | % 81
  d8( c8 d8) bes'8-. fis8( g8) | % 82
  es4 r8 g8 as8 f8 | % 83
  b,8( b8) d8( d8) f8( f8) | % 84
  as,4 r8 d8 es8 c8 | % 85
  fis8 g8 d4 d,4 | % 86
  g4-\fermata r4 r4 | % 87
  \bar "|."
}
