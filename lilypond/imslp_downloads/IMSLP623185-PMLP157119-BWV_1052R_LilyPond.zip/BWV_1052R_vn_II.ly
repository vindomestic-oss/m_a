\version "2.20.0"
\language "nederlands"

\include "parenthesized_dynamics.ly"

first_pg_no = 1
instrument = "Violino II"

\include "BWV_1052R_header.ly"
\include "BWV_1052R_paper_parts.ly"

scoreAGlobal = {
  \key d \minor
  \time 4/4
  \compressFullBarRests
}

\include "scoreAViolinII.ly"

scoreAViolinIIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 5/4)
} \scoreAViolinII

\score {
  \scoreAViolinIIPart
  \layout {}
  \header {
    piece = \markup {\hspace #9 {\pieceA}}
  }
  \midi {
    \tempo 4 = 100
  }
}

\pageBreak

scoreBGlobal = {
  \key g \minor
  \time 3/4
  \tempo "Adagio"
  \compressFullBarRests
}

\include "scoreBViolinII.ly"

scoreBViolinIIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
} \scoreBViolinII

\score {
  \scoreBViolinIIPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceB}}
  }
  \midi {
    \tempo 4 = 50
  }
}

\pageBreak

scoreCGlobal = {
  \key d \minor
  \time 3/4
  \tempo "Allegro"
  \compressFullBarRests
}

\include "scoreCViolinII.ly"

scoreCViolinIIPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "violin"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 4/4)
} \scoreCViolinII

\score {
  \scoreCViolinIIPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceC}}
  }
  \midi {
    \tempo 4 = 110
  }
}
