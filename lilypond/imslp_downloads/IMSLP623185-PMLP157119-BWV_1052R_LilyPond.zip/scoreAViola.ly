\version "2.18.0"
\language "nederlands"
scoreAViola = \relative c' {
  \scoreAGlobal

  d16\paren\f e16 f8 e8 d8 a'8 d4 a8 | % 1
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 2
  bes8 g16 e16 a,8 cis'8~ cis8 bes16 g16 a,8 e''8~ | % 3
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 4
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8-. c16 d16 es8-. | % 5
  fis,8-. g8-. cis,8-. d8-. gis,8-. r8 a8-. r8 | % 6
  d8\p d8 d8 d8 d8 d8 d8 d8 | % 7
  d8 d8 d8 d8 d8 d8 d8 d8 | % 8
  d8 d8 d8 d8 d8 d8 d8 d8 | % 9
  d8 d8 d8 d8 d8 d8 d8 d8 | % 10
  d8 d8 d8 d8 d8 d8 d8 d8 | % 11
  d4 r4 r2 | % 12
  r2 f16\paren\f g16 a8 g8 f8~ | % 13
  f8 e4 d8~ d g8~ g e16 cis16 | % 14
  g8 bes'8~ bes8 g16 e16 g,8 cis'8~ cis8 bes16 g16 | % 15
  g,8 e''8~ e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 | % 16
  a'1~ | % 17
  a8 bes8 r4 cis,8( d8) r4 | % 18
  b'4 r4 gis4 r4 | % 19
  gis,16 e''16 d16 c16 b16 a16 gis16 fis16 e2~ | % 20
  e8 f8-. b,8-. c8-. dis,8 r8 e8 r8 | % 21
  a8\p a8 a8 a8 a8 a8 a8 a8 | % 22
  a8 a8 a8 a8 a8 a8 a8 a8 | % 23
  a8 a8 a8 a8 a8 a8 a8 a8 | % 24
  a8 a8 a8 a8 a8 a8 a8 a8 | % 25
  a8 a8 a8 a8 a8 a8 a8 a8 | % 26
  a4 r4 r2 | % 27
  r4 a'4\p r4 g4 | % 28
  r4 f4 r4 fis4 | % 29
  r4 g4 r4 f4 | % 30
  r4 e4 r4 e4 | % 31
  r4 f4 r4 es4 | % 32
  r4 d4 r4 d4 | % 33
  e8 b'4 e,8~ e c4 a8~ | % 34
  a8 a'4 d,8~ d bes4 g8~ | % 35
  g8 g'4 c,8~ c a4 f8~ | % 36
  f8 bes'4 g8 e8 a4 f8 | % 37
  d8 g4 e8 c4 r8 g8 | % 38
  d'4 r16 e16\f f16 g16 a8 d8 c8 bes8 | % 39
  a1\p | % 40
  e2 g2 | % 41
  c,4 r4 r8 c8\f bes8 a8 | % 42
  g4 r4 r8 d'8 c8 b8 | % 43
  a4 r4 r8 g'8 f8 e8 | % 44
  d8 e8 f8 g8 a8 g8 a8 b8 | % 45
  b,4\p e4 r4 e4 | % 46
  r4 a,4 r4 a4 | % 47
  r4 a'4 r4 a4 | % 48
  r4 d,4 r4 d4 | % 49
  r4 b'4 r4 b4 | % 50
  r4 e,4 r4 e4 | % 51
  r4 a4 r4 g4 | % 52
  r4 f4 r4 e4 | % 53
  r4 d4 r4 gis,4 | % 54
  a8 r8 r4 r2 | % 55
  r2 a16\f b16 c8 b8 a8 | % 56
  d8 r8 c8 r8 b8 r8 a8 r8 | % 57
  gis8 r8 a8 r8 b8 r8 c8 r8 | % 58
  d8 d8 d8 d8 d8 d8 d8 d8 | % 59
  d4 r4 r2 | % 60
  bes8( a8) d8( e8) dis8 r8 e8 r8 | % 61
  a,8 r8 r4 r2 | % 62
  R1*6 |
  r8 g'8\f fis8 b8 c8 r8 b8 r8 | % 69
  b8 r8 r4 r2 | % 70
  R4*4*8 | % 78
  r8 e,8\paren\p dis8 e8 c8 a8 b8 b'8 | % 79
  e,8 f8 d8 e8 a,8 b8 c8 a8 | % 80
  f8 d'8 b8 g8 c8 c,8 d8 e8 | % 81
  f8 e8 f8 g8 a8 g8 f8 d8 | % 82
  g8 g8 g8 g8 g8 g8 g8 g8 | % 83
  fis8 fis8 fis8 fis8 fis8 fis8 fis8 fis8 | % 84
  g8 g8 g8 g8 g8 g8 g8 g8 | % 85
  g8 g8 g8 g8 g8 g8 g8 g8 | % 86
  g8 g8 g8 g8 g8 g8 g8 g8 | % 87
  g8 g8 g8 g8 g8 g8 g8 g8 | % 88
  g8 g8 g8 g8 g8 g8 g8 g8 | % 89
  g8 g8 g8 g8 g8 g8 g8 g8 | % 90
  e'1\p |
  b2 d |
  g,4 r r8 cis8\f d8 e8 | % 93
  a,8 r8 r4 r8 fis'8 g8 a8 | % 94
  d,4 r4 r8 bes'8\p g8 d8 | % 95
  a'4 r4 r8 c8 a8 c,8 | % 96
  g'4 r4 r8 bes,8 d8 g8 | % 97
  g4 r4 r8 es8 g8 c8 | % 98
  d4 r4 a4 r4 | % 99
  g4 r4 e4 r4 | % 100
  c4 r4 es4 r4 | % 101
  a,4 r4 fis'4 r4 | % 102
  R4*4*1 | % 103
  bes,16\paren\f c16 d8 c8 bes8 g'16 fis16 g8 a8 bes8 | % 104
  g8 es8 d8\noBeam r8 es8 c8 g'8\noBeam r8 | % 105
  a8 r8 bes8 r8 c8 r8 bes8 r8 | % 106
  a8 a8 a8 a8 a8 a8 a8 a8 | % 107
  a4 r4 g8 r8 d8 r8 | % 108
  d8( g8) a8( bes8) cis,8-\fermata r8 r4 | % 109
  R4*4*2 | % 111
  r2 r8 g'8\f c8 a8 | % 112
  bes4 r4 c,16 d16 e8 d8 c8 | % 113
  f8 c'4 f,8 bes,16 c16 d8 c8 bes8 | % 114
  e8 bes'4 e,8 a,16 b16 cis8 b8 a8 | % 115
  d8\paren\p a'4 d,8 cis8 a'4 cis,8 | % 116
  d8 a'4 d,8 cis8 a'4 cis,8 | % 117
  d8 d8 d8 d8 d8 d8 d8 d8 | % 118
  c8 c8 c8 c8 c8 c8 c8 c8 | % 119
  bes8 bes8 bes8 bes8 bes8 bes8 bes8 bes8 | % 120
  a8 a8 a8 a8 a8 a8 a8 a8 | % 121
  a4 d4 r4 c4 | % 122
  r4 bes4 r4 b4 | % 123
  r4 c4 r4 bes4 | % 124
  r4 a4 r4 a4 | % 125
  r4 bes4 r4 as4 | % 126
  r4 g4 r4 g4 | % 127
  a8 e''4 a,8~ a f4 d8~ | % 128
  d8 d'4 g,8~ g es4 c8~ | % 129
  c8 c'4 f,8~ f d4 bes8~ | % 130
  bes8 es4 c8 a8 d4 bes8 | % 131
  g8 c4 a8 f4 r8 c'8 | % 132
  g'4 r8 bes,16\f c16 d8 g8 f8 es8 | % 133
  d16\p es16 f8 es8 d8 bes'8 bes,8 d8 es8 | % 134
  f4 r8 f,8 g8( f8) as8( g8) | % 135
  f4 r4 r8 d'8\f d8 d8 | % 136
  c4 r4 r2 | % 137
  r8 e8 e8 e8 d4 r4 | % 138
  r2 r8 a'8 a8 a8 | % 139
  g4 r8 bes8\p fis4 r8 a8 | % 140
  d,4 r8 d8 e4 r8 e8 | % 141
  a,4 r4 r8 g'8 c,8 g8 | % 142
  c4 r4 r8 f8 bes,8 f8 | % 143
  bes8 d8 g8 a8 bes8 a8 bes8 d,8 | % 144
  e8 d8 e8 f8 g8 e8 cis8 a8 | % 145
  d8 r8 r8 d8 bes'8 r8 e,8 r8 | % 146
  d8 r8 r8 d8 bes8 r8 a8 r8 | % 147
  a8 d8 d8 d8 d8 d8 d8 d8 | % 148
  d8 d8 d8 d8 d8 d8 d8 d8 | % 149
  d8 d8 d8 d8 d8 d8 d8 d8 | % 150
  d8 d8 d8 d8 d8 d8 d8 d8 | % 151
  d4 r4 r2 | % 152
  d4 r4 r2 | % 153
  R4*4*18 | % 171
  d16\f e16 f8 e8 d8 a'8 d4 a8 | % 172
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 g'8 | % 173
  g8\p g8 g8 g8 g8 g8 a8 a8 | % 174
  a4 d,4 r4 d4 | % 175
  c8 c8 c8 c8 c8 c8 d8 d8 | % 176
  d4 g,4 r4 g4 | % 177
  d'8 d8 d8 d8 d8 d8 e8 e8 | % 178
  e8 e8 g8 g8 g8 g8 a8 a8 | % 179
  a4 d,4 r4 c4 | % 180
  r4 bes4 r4 a4 | % 181
  r4 g4 r4 cis,4 | % 182
  d8r8 r4 r2 | % 183
  d'16\f e16 f8 e8 d8 a'8 d4 a8 | % 184
  bes8 g16 e16 a8 f16 d16 g8 e16 cis16 a8 bes'8~ | % 185
  bes8 g16 e16 a,8 cis'8~ cis bes16 g16 a,8 e''8~ | % 186
  e8 cis16 a16 bes16 g16 a16 f16 g16 e16 f16 d16 e16 cis16 d16 b16 | % 187
  cis16 a16 b16 cis16 d16 e16 f16 g16 a16 bes16 c8 c16 d16 es8 | % 188
  fis,8-. g8-. cis,8-. d8-. gis,8 r8 a8 r8 | % 189
  d,4\fermata r4 r2 | % 190
  \bar "|."

}
