\version "2.20.0"
\language "nederlands"

\include "parenthesized_dynamics.ly"

first_pg_no = 1
instrument = "Viola"

\include "BWV_1052R_header.ly"
\include "BWV_1052R_paper_parts.ly"

scoreAGlobal = {
  \key d \minor
  \time 4/4
  \compressFullBarRests
}

\include "scoreAViola.ly"

scoreAViolaPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "viola"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 5/4)
} { \clef alto \scoreAViola}

\score {
  \scoreAViolaPart
  \layout {}
  \header {
    piece = \markup {\hspace #9 {\pieceA}}
  }
  \midi {
    \tempo 4 = 100
  }
}

\pageBreak

scoreBGlobal = {
  \key g \minor
  \time 3/4
  \tempo "Adagio"
  \compressFullBarRests
}

\include "scoreBViola.ly"

scoreBViolaPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "viola"
} { \clef alto \scoreBViola}

\score {
  \scoreBViolaPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceB}}
  }
  \midi {
    \tempo 4 = 50
  }
}

\pageBreak

scoreCGlobal = {
  \key d \minor
  \time 3/4
  \tempo "Allegro"
  \compressFullBarRests
}

\include "scoreCViola.ly"

scoreCViolaPart = \new Staff \with {
  instrumentName = ""
  midiInstrument = "viola"
  \consists "Page_turn_engraver"
  minimumPageTurnLength = #(ly:make-moment 4/4)
} { \clef alto \scoreCViola}

\score {
  \scoreCViolaPart
  \layout { }
  \header {
    piece = \markup {\hspace #9 {\pieceC}}
  }
  \midi {
    \tempo 4 = 110
  }
}
