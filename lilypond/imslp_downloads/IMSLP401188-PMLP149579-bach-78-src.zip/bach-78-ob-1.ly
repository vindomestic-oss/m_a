\include "bach-78-1.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Oboe I"
}

\score {
    \new Staff <<
        \mvtIobI
    >>

    \header {
        piece = \mvtIpiece
    }
}


\markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}

\score {
    \new Staff <<
        \mvtVIob
    >>

    \header {
        piece = \mvtVIpiece
        % breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIIsoprano
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
