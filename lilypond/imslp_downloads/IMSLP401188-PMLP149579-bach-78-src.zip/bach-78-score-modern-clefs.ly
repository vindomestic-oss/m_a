\version "2.19.15"

\include "bach-78-score-common.ly"
