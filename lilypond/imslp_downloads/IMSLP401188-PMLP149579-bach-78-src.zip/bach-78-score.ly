\version "2.19.15"

\include "baroque-clefs.ly"

\include "bach-78-score-common.ly"
