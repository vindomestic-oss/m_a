\version "2.19.15"

\include "bach-78-1.ly"
\include "bach-78-2.ly"
\include "bach-78-3.ly"
\include "bach-78-4.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"

transpChorton = d


% #(set-global-staff-size 14)

\header {
    instrument = "Continuo, beziffert"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
    \transpose \transpChorton c <<
        % \new Dynamics { \mvtIbreaks }
        \new Staff = staffK <<
            \keepWithTag ORGAN { \dynamicUp \mvtIbc }
            \mvtIfigs
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtIpiece
    }
}


% %{
\score {
   \transpose \transpChorton c <<
        % \new Dynamics { \mvtIIbreaks }

        \new Staff = staffC <<
            \keepWithTag ORGAN { \dynamicUp \mvtIIbc }
            \mvtIIfigs
        >>
   >>

    \layout {
    }

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \transpose \transpChorton c \new StaffGroup <<
	\new Staff = mvtIIItenor \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize "Tenore"}

            \new Voice = mvtIIItenor { \clefTenor \mvtIIItenor }
	    \new Lyrics \with {
		alignBelowContext = "mvtIIItenor"
		\override LyricText #'font-size = #-1
	    } {
                \lyricsto mvtIIItenor \mvtIIItenorLyrics
            }
        >>
        \new Staff = staffB <<
	    \set Staff.instrumentName = \markup{\center-column{
						"Basso" "Continuo"}}

            \keepWithTag ORGAN { \dynamicUp \mvtIIIbc }
            \mvtIIIfigs
        >>
   >>

    \layout {
	indent = #15
    }

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \transpose \transpChorton c <<
        % \new Dynamics { \mvtIVbreaks }
        \new Staff = staffC <<
            \stretchHorizontalSpacing #1
            \keepWithTag ORGAN { \dynamicUp \mvtIVbc }
            \mvtIVfigs
        >>
       
   >>

    \layout {
    }

    \header {
        piece = \mvtIVpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \transpose \transpChorton c \new StaffGroup <<
        % \new Dynamics \mvtVbreaks

	\new Staff = mvtVbass \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize "Basso"}

            \new Voice = mvtVbass { \mvtVbass }
	    \new Lyrics \with {
		alignBelowContext = "mvtVbass"
		\override LyricText #'font-size = #-1
	    } {
                \lyricsto mvtVbass \mvtVbassLyrics
            }
        >>
        \new Staff = staffE <<
	    \set Staff.instrumentName = \markup{\center-column{
						"Basso" "Continuo"}}

            \keepWithTag ORGAN { \dynamicUp \mvtVbc }
            \mvtVfigs
        >>
   >>

    \layout {
	indent = #15
    }

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \transpose \transpChorton c <<
        % \new Dynamics { \mvtVIbreaks }

        \new Staff = staffF <<
            \keepWithTag ORGAN { \dynamicUp \mvtVIbc }
            \mvtVIfigs
        >>
   >>

    \layout {
    }

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    \transpose \transpChorton c <<
        \new Staff <<
            % \keepWithTag ORGAN { \dynamicUp \mvtVIIbc }
            \keepWithTag ORGAN { \dynamicUp \mvtVIIbass }
            \mvtVIIfigs
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtVIIpiece
    }
}
% %}
