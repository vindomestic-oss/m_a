\include "bach-78-1.ly"
\include "bach-78-4.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = "Flauto Traverso"
}

\score {
    \new Staff <<
        \mvtIfl
    >>

    \header {
        piece = \mvtIpiece
    }
}


\markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}

\score {
    \new Staff <<
        \mvtIVfl
    >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}

\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}

\score {
    \new Staff <<
        \transpose c c' \mvtVIIsoprano
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
