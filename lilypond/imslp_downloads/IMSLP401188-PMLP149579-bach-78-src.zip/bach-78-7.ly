\version "2.19.15"

\include "common.ly"

mvtVIItimeLine = {
    \time 4/4
    \key g \minor

    s1*16
    \bar "|."
}

mvtVIIsoprano = <<
\relative c'' {
    \autoBeamOff
    d4 d4 a4 bes4 | % 2
    c4 bes8[ a8] a4 g4\fermata | % 3
    bes4 bes4 a4 g4 | % 4
    fis4 g4 a2\fermata | % 5
    d4 d4 a4 bes4 | % 6
    c4 bes8[ a8] a4 g4\fermata | % 7
    bes4 bes4 a4 g4 | % 8
    fis4 g4 a2\fermata | % 9
    a4 bes4 c4 a4 | \barNumberCheck #10
    bes4 a8[ g8] g4 f4\fermata | % 11
    bes4 c4 d4 d4 | % 12
    es4 d8[ c8] c4 bes4\fermata | % 13
    d4 d4 c4 d4 | % 14
    bes4 c4\trill d2\fermata | % 15
    d4 d4 c4 bes4 | % 16
    a4 a4 g2\fermata | % 17
}
\mvtVIItimeLine
>>


mvtVIIlyrics = \lyricmode {
    Herr! ich glau -- be, hilf mir Schwa -- chen,
    laß mich ja ver -- za -- gen nicht;
    du, du kannst mich stär -- ker ma -- chen,
    wenn mich Sünd und Tod an -- ficht.
    Dei -- ner Gü -- te will ich trau -- en,
    bis ich fröh -- lich wer -- de schau -- en
    dich, Herr Je -- su, nach dem Streit
    in der sü -- ßen E -- wig -- keit.
}


mvtVIIalto = <<
\relative c'' {
    \autoBeamOff
    g4 g4 a4 g4 | % 2
    g4 g4 fis4 d4\fermata | % 3
    d4 es4 es8([ d8]) d8([ c8]) | % 4
    c4 d4 d2\fermata | % 5
    d4 g4 fis4 g4 | % 6
    g4 g4 fis4 d4\fermata | % 7
    d4 es4 es8([ d8]) d8([ c8]) | % 8
    c4 d4 d2\fermata | % 9
    fis4 g4 g4 f4 | \barNumberCheck #10
    f4 f4 e4 c4\fermata | % 11
    f4 g8[ a8] bes4 bes4 | % 12
    bes4 bes4 a4 f4\fermata | % 13
    f4 f4 f8[ es8] d4 | % 14
    d4 g4 fis2\fermata | % 15
    g4 g4 a4 g4 | % 16
    g4 fis4 d2\fermata | % 17
}
\mvtVIItimeLine
>>


mvtVIItenor = <<
\relative c' {
    \autoBeamOff
    bes8[ c8] d4 d4 d4 | % 2
    c8[ d8] es4 d8[ c8] bes4\fermata | % 3
    g4 g4 g8[ fis8] g4 | % 4
    a4 bes4 fis2\fermata | % 5
    bes8[ c8] d4 d4 d4 | % 6
    c8[ d8] es4 d8[ c8] bes4\fermata | % 7
    g4 g4 g8[ fis8] g4 | % 8
    a4 bes4 fis2\fermata | % 9
    d'4 d4 c4 c4 | \barNumberCheck #10
    bes8[ c8] d4 c8[ bes8] a4\fermata | % 11
    bes4 es4 f4 f4 | % 12
    es8[ f8] g4 f8[ es8] d4\fermata | % 13
    bes4 bes4 a4 a4 | % 14
    g8([ bes8]) a8([ g8]) a2\fermata | % 15
    bes8[ c8] d4 es4 d4 | % 16
    es4 d8[ c8] b2\fermata | % 17
}
\mvtVIItimeLine
>>


mvtVIIbass = <<
\relative c' {
    \autoBeamOff
    \clef bass
    g8[ a8] bes4 fis4 g | % 2
    es4 c4 d4 g,4\fermata | % 3
    g'8[ f8] es8[ d8] c8[ d8] es4 | % 4
    a,4 g4 d'2\fermata | % 5
    g,8[ a8] bes8[ c8] d4 g4 | % 6
    es4 c4 d4 g,4\fermata | % 7
    g'8[ f8] es8[ d8] c8[ d8] es4 | % 8
    a,4 g4 d'2\fermata | % 9
    d4 g8[ f8] e4 f4 | \barNumberCheck #10
    d4 bes4 c4 f4\fermata | % 11
    d4 c4 bes4 bes'8[ a8] | % 12
    g4 es4 f4 bes,4\fermata | % 13
    bes8[ c8] d8[ es8] f4 fis4 | % 14
    g8[ f8] es4 d2\fermata | % 15
    g8[ a8] bes4 fis4 g4 | % 16
    c,4 d4 g,2\fermata | % 17
}
\mvtVIItimeLine
>>


mvtVIIbc = <<
\relative c' {
    \clef bass
    g8 a8 bes4 fis4 g8 f8 | % 2
    es8 d8 c4 d4 g,4\fermata | % 3
    g'8 f8 es8 d8 c8 d8 es4 | % 4
    a,4 g4 d'2\fermata | % 5
    g,8 a8 bes8 c8 d4 g8 f8 | % 6
    es8 d8 c4 d4 g,4\fermata | % 7
    g'8 f8 es8 d8 c8 d8 es4 | % 8
    a,4 g4 d'2\fermata | % 9
    d4 g8 f8 e4 f8 es8 | \barNumberCheck #10
    d8 c8 bes4 c4 f,4\fermata | % 11
    d'4 c4 bes4 bes'8 a8 | % 12
    g8 f8 es4 f4 bes,4\fermata | % 13
    bes8 c8 d8 es8 f4 fis4 | % 14
    g8 f8 es4 d2\fermata | % 15
    g8 a8 bes4 fis4 g4 | % 16
    c,4 d4 g,2\fermata | % 17
}
\mvtVIItimeLine
>>

mvtVIIfigs = \figuremode {
    s4 <6> <6> s |
    <6> <7 5> <_+> s |
    s <5> <6 5>8 <_+> <7> <6> |
    <6\\>4 s <_+>2 |

    s4 <6> <_+> s |
    <6> <7 5> <_+> s |
    s <5> <6 5>8 <_+> <7> <6> |
    <6\\>4 s s2 |
    <_+>4 s <6> s |
    <6>4 <7 5> <_!> s |

    <6> <5>8 <6> s2 |
    <6>4 <7 5> s s |
    s <6> s <6 5> |
    s <6> <_+>2 |
    s4 <6> <7- 5> s |
    <6 5> <_+> <_!>2 |
}
