\version "2.19.15"

\include "bach-78-1.ly"
\include "bach-78-2.ly"
\include "bach-78-3.ly"
\include "bach-78-4.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"


% #(set-global-staff-size 14)

\header {
    instrument = "Basso Continuo"
}

\paper {
    % ragged-last-bottom = ##f
    % page-count = #9
}


\score {
    <<
        % \new Dynamics { \mvtIbreaks }
        \new Staff = staffK <<
            \keepWithTag CELLO { \mvtIbc }
        >>
    >>

    \header {
        piece = \mvtIpiece
    }
}


% %{
\score {
   <<
        % \new Dynamics { \mvtIIbreaks }

        \new Staff = staffC <<
            \keepWithTag CELLO { \mvtIIbc }
        >>
   >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \new StaffGroup <<
	\new Staff = mvtIIItenor \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize "Tenore"}

            \new Voice = mvtIIItenor { \clefTenor \mvtIIItenor }
	    \new Lyrics \with {
		alignBelowContext = "mvtIIItenor"
		\override LyricText #'font-size = #-1
	    } {
                \lyricsto mvtIIItenor \mvtIIItenorLyrics
            }
        >>
        \new Staff = staffB <<
	    \set Staff.instrumentName = \markup{\center-column{
						"Basso" "Continuo"}}

            \keepWithTag CELLO { \mvtIIIbc }
        >>
   >>

    \layout {
	indent = #15
    }

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   <<
        % \new Dynamics { \mvtIVbreaks }
        \new Staff = staffC <<
            \stretchHorizontalSpacing #1
            \keepWithTag CELLO { \mvtIVbc }
        >>
       
   >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}
% %}


% %{
\score {
   \new StaffGroup <<
        % \new Dynamics \mvtVbreaks

	\new Staff = mvtVbass \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize "Basso"}

            \new Voice = mvtVbass { \mvtVbass }
	    \new Lyrics \with {
		alignBelowContext = "mvtVbass"
		\override LyricText #'font-size = #-1
	    } {
                \lyricsto mvtVbass \mvtVbassLyrics
            }
        >>
        \new Staff = staffE <<
	    \set Staff.instrumentName = \markup{\center-column{
						"Basso" "Continuo"}}

            \keepWithTag CELLO { \mvtVbc }
        >>
   >>

    \layout {
	indent = #15
    }

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   <<
        % \new Dynamics { \mvtVIbreaks }

        \new Staff = staffF <<
            \keepWithTag CELLO { \mvtVIbc }
        >>
   >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    <<
        \new Staff <<
            \keepWithTag CELLO { \mvtVIIbc }
        >>
    >>

    \header {
        piece = \mvtVIIpiece
        breakbefore = ##t
    }
}
% %}
