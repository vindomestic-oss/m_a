\version "2.18.0"

\include "common.ly"


mvtVItimeLine = {
    \time 4/4
    \key bes \major
    \partial 8

    s8 |
    \segno
    s1*53 |
    \dalSegno
    \bar "||"
}

mvtVIbreaks = {
    <>^"BGA breaks left in"
    s8 |
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \bar "||"
}


mvtVIob = <<
\relative c''' {
    g8 | %0
    es8.( f16) \once \slurDashed f8.\trill( es32 f32) g8 c,8 es16( d16 c16 b16) | %1
    c8 g16( f16 g16 a16 b16 c16) d16( es16 f16 d16 f16 es16 d16 c16) | %2
    b16( c16 d16 b16 d16 c16 b16 a16) f'16( g16 as16 f16 as16 g16 f16 es16) | %3
    d16( c16 b16 a16 g8) g'8 es8.( f16) f8.\trill( es32 f32) | %4
    g8 c,8 es16( d16 c16 b16) c8 c,16( d16 es16 f16 g16 as16) | %5
    g16( as16 bes16 g16 bes16 as16 g16 f16) d'16( es16 f16 d16 f16 es16 d16 c16) | %6
    b16( c16 d16 b16 d c b a) f'( g as f as g f es) | %7
    f16( es16 d16 c16) es16( d16 c16 b16) c4\fermata r4 | %8
    R1 | %9
    r4 r8 es8\Pia d16( es16 f16 d16 f16 es16 d16 c16) | %10
    b16( c16 d16 b16 d16 c16 b16 a16) f'16( g16 as16 f16 as16 g16 f16 es16) | %11
    d16( c16 b16 a16 g8) g'8\For \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es16) | %12
    g8 c,8 es16( d16 c16 b16) c8 c,16( d16 es16 f16 g16 as16) | %13
    g16( as16 bes16 g16 bes16 as16 g16 f16) d'16( es16 f16 d16 f16 es16 d16 c16) | %14
    b16( c16 d16 b16 d16 c16 b16 a16) f'16( g16 as16 f16 as16 g16 f16 es16) | %15
    f16( es16 d16 c16) es16( d16 c16 b16) c4 r8 g'8\Pia | %16
    es16( f16 g16) es16 g16( f16 es16 f16 g16 f16 es16 d16) c4~ | %17
    c16 d16( es16) c16 as'16( g16 f16 es16) d16( es16 f16 d16 f16 es16 d16 c16) | %18
    b( c d b d c b a) f'( g as f as16 g16 f16 es16) | %19
    d16( c16 b16 a16 g8) g'8 \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) | %20
    g8 f16( es16) g16( f16 es16 d16) es8 es,16( f16 g16 as16 bes16 c16) | %21
    d( es f d f es d c) a'( b c a c b a g) | %22
    fis16( g16 a16 fis16 g16 fis16 e16 d16) c16( d16 es16 c16 es16 d16 c16 bes?16) | %23
    c16( bes16 a16 g16) bes16( a16 g16 fis16) g4 r8 d'8\For | %24
    \once \slurDashed bes8.( c16) \once \slurDashed c8.\trill( bes32 c32) d8 g,8 bes16( a16 g16 fis16) | %25
    g8 d16( c16 d e fis g) a( bes c a c16 bes16 a16 g16) | %26
    fis( g a fis a g fis e) c'( d es c es d c bes) | %27
    a16( g16 fis16 e16 d8) d'8 \once \slurDashed bes8.( c16) \once \slurDashed c8.\trill( bes32 c32) | %28
    d8 g,8 bes16( a16 g16 fis16) g16 d( e fis g a bes c) | %29
    d16( es?16 f16 d16 f16 es16 d16 c16) a'16( bes16 c16 a16 c16 bes16 a16 g16) | %30
    fis16( g16 a16 fis16 g16 f16 es16 d16) c16( d16 es16 c16 es16 d16 c16 bes16) | %31
    c16( bes16 a16 g16) bes16( a16 g16 fis16) g4 r4 | %32
    R1 | %33
    r4 r8 d'8\Pia es16( f16 g16 es16 g16 f16 es16 d16) | %34
    es8 bes16( as bes c d es) f( g as f as g f e) | %35
    f4 r8 c8 \once \slurDashed as8.( bes16) \once \slurDashed bes8.\trill( as32) bes32 | %36
    c8 f,8 as16( g16 f16 e16) f8 c16( d16 e16 f16 g16 as16) | %37
    g16( as bes g bes as g f) e( f g e g f e d) | %38
    bes'16( c16 des16 bes16 des16 c16 bes16 as16) g16( f16 e16 d16 c8) c'8 | %39
    \once \slurDashed as8.( bes16) \once \slurDashed bes8.\trill( as32 bes32) c8 f,8 as16( g16 f16 e16) | %40
    f4 r4 r2 | %41
    r2 r4 r8 g'8\For | %42
    \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f) g8 c, es16( d c b) | %43
    c16 g16\Pia( a16 b16 c16 b16 c16 d16) es16( f16 g16 es16 g16 f16 es16 f16) | %44
    \once \slurDashed g16( f16 es16 d16) c4~ c16 d16( es16 c16 as'16 g16 f16 es16) | %45
    d16( es16 f16 d16  f es d c) b( c d b d c b a) | %46
    f'16( g16 as16 f16 as16 g16 f16 es16) d16( c16 b16 a16 g8) g'8 | %47
    \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) g8 c,8 \once \slurDashed es16( d16 c16 b16) | %48
    c8 c,16( d16 es16 f16 g16 es16) f( g as f as g f es) | %49
    d'16( es16 f16 d16 f16 es16 d16 c16) b16( c16 d16 b16 d16 c16 b16 a16) | %50
    f'16( g16 as16 f16 as16 g16 f16 es16) f16( es16 d16 c16) es16( d16 c16 b16) | %51
    c4 r4 r2 | %52
    r2 r4 r8 g'8 | %53
}
\mvtVItimeLine
>>


mvtVIvlnI = <<
\relative c''' {
    g8 | %0
    \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) g8 c,8 es16( d16) c16( b16) | %1
    c8 r8 r4 r2 | %2
    R1 | %3
    r4 r8 g'8 \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) | %4
    g8 c,8 es16( d16) c16( b16) c4 r4 | %5
    R1 | %6
    r2 r4 r8 g'8 | %7
    f16( es16) d16( c16) es16( d16) c16( b16) c4\fermata r4 | %8
    R1*3 | %9
    r4 r8 g'8\f \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) | %12
    g8 c,8 es16( d16) c16( b16) c8 r8 r4 | %13
    R1 | %14
    r2 r4 r8 g'8 | %15
    f16( es16) d16( c16) es16( d16) c16( b16) c4 r4 | %16
    R1 | %17
    r2 r8 d,16\Pia c16 d8 r8 | %18
    r8 as'16 g16 as8 r8 r8 es16 d16 es8 r8 | %19
    r4 r8 g'8\Pia \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) | %20
    g8 f16( es16) g16( f16) es16( d16) es8 r8 r4 | %21
    R1*2 | %22
    r2 r4 r8 d8\For | %24
    bes8.( c16) c8.\trill( bes32 c32) d8 g,8 bes16( a16) g16( fis16) | %25
    g8 r8 r4 r2 | %26
    R1 | %27
    r4 r8 d'8 \once \slurDashed bes8.( c16) c8.\trill( bes32 c32) | %28
    d8 g,8 bes16( a16) g16( fis16) g8 r8 r4 | %29
    R1 | %30
    r2 r4 r8 d'8 | %31
    c16( bes16) a16( g16) bes16( a16) g16( fis16) g4 r4 | %32
    R1*3 | %33
    r4 r8 c8\Pia \once \slurDashed as8.( bes16) bes8.\trill( as32 bes32) | %36
    c8 f,8 as16( g16) f16( e16) f8 r8 r4 | %37
    R1 | %38
    r2 r4 r8 c'8\Pia | %39
    \once \slurDashed as8.( bes16) \once \slurDashed bes8.\trill( as32 bes32) c8 f,8 as16( g16) f16( e16) | %40
    f4 r4 r2 | %41
    r2 r4 r8 g'8\For | %42
    \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f) g8 c, es16( d) c( b) | %43
    c8 r8 r4 r2 | %44
    R1 | %45
    r8 g16\p f16 g8 r8 r8 f16 es16 f8 r8 | %46
    r8 f16 es16 f8 r8 r4 r8 g'8\Pia | %47
    \once \slurDashed es8.( f16) \once \slurDashed f8.\trill( es32 f32) g8 c,8 es16( d16) c16( b16) | %48
    c8 r8 r4 r2 | %49
    R1 | %50
    r4 r8 g'8\p f16( es16) d16( c16) es16( d16) c16( b16) | %51
    c4 r4 r2 | %52
    r2 r4 r8 g'8 | %53
}
\mvtVItimeLine
>>


mvtVIvlnII = <<
\relative c'' {
    es8 | %0
    c4 c4 c8 c8 as8 g8 | %1
    g4 r4 r2 | %2
    R1 | %3
    r4 r8 b8 c4 c4 | %4
    c8 c8 as8 g8 g4 r4 | %5
    R1 | %6
    r2 r4 r8 d'8 | %7
    c8 es,8 f8 d8 es4\fermata r4 | %8
    R1*3 | %9
    r4 r8 b'8\f c4 c4 | %12
    c8 c8 as8 g8 g4 r4 | %13
    R1 | %14
    r2 r4 r8 d'8 | %15
    c8 es,8 f8 d8 es4 r4 | %16
    R1 | %17
    r2 r8 d16\Pia c16 d8 r8 | %18
    r8 as'16 g16 as8 r8 r8 es16 d16 es8 r8 | %19
    r4 r8 d'8\Pia c4 bes4 | %20
    bes8 c8 c8 bes8 bes8 r8 r4 | %21
    R1*2 | %22
    r2 r4 r8 bes8\For | %24
    g4 g4 g8 g8 es8 d8 | %25
    d8 r8 r4 r2 | %26
    R1 | %27
    r4 r8 a'8 g4 g4 | %28
    g8 g8 es8 d8 d8 r8 r4 | %29
    R1 | %30
    r2 r4 r8 fis8 | %31
    g8 bes,8 c8 a8 bes4 r4 | %32
    R1*3 | %33
    r4 r8 as'8\Pia f4 es4 | %36
    es8 f8 e8 g8 f8 r8 r4 | %37
    R1 | %38
    r2 r4 r8 g8\p | %39
    f4 f4 f8 f8 des8 c8 | %40
    c4 r4 r2 | %41
    r2 r4 r8 d'8\For | %42
    c4 c4 c8 c8 as8 g8 | %43
    g8 r8 r4 r2 | %44
    R1 | %45
    r8 g16\Pia f16 g8 r8 r8 f16 es16 f8 r8 | %46
    r8 f16 es16 f8 r8 r4 r8 b8\Pia | %47
    c4 b4 c8 c8 as8 g8 | %48
    g8 r8 r4 r2 | %49
    R1 | %50
    r4 r8 d'8\Pia c8 c8 as8 g8 | %51
    g4 r4 r2 | %52
    r2 r4 r8 es'8 | %53
}
\mvtVItimeLine
>>


mvtVIvla = <<
\relative c'' {
    \clef C
    c8 | %0
    g4 f4 es8 es8 f8 d8 | %1
    es4 r4 r2 | %2
    R1 | %3
    r4 r8 g8 g4 f4 | %4
    es8 es8 f8 d8 es4 r4 | %5
    R1 | %6
    r2 r4 r8 g8 | %7
    g8 as8 as8 g8 g4\fermata r4 | %8
    R1*3 | %9
    r4 r8 g8\For g4 f4 | %12
    es8 es8 f8 d8 es4 r4 | %13
    R1 | %14
    r2 r4 r8 g8 | %15
    g8 as8 as8 g8 g4 r4 | %16
    R1 | %17
    r2 r8 d16\Pia c16 d8 r8 | %18
    r8 as'16 g16 as8 r8 r8 es16 d16 es8 r8 | %19
    r4 r8 b'8\Pia g4 f4 | %20
    es8 g8 as8 as8 g8 r8 r4 | %21
    R1*2 | %22
    r2 r4 r8 g8\For | %24
    d4 c4 bes8 bes8 c8 a8 | %25
    bes8 r8 r4 r2 | %26
    R1 | %27
    r4 r8 fis'8 d4 c4 | %28
    bes8 bes8 c8 a8 bes8 r8 r4 | %29
    R1 | %30
    r2 r4 r8 d8 | %31
    d8 es8 es8 d8 d4 r4 | %32
    R1*3 | %33
    r4 r8 c8\Pia des4 bes4 | %36
    as8 c8 c8 c8 c8 r8 r4 | %37
    R1 | %38
    r2 r4 r8 c8\Pia | %39
    c4 des4 c8 c8 es,8 bes'8 | %40
    as4 r4 r2 | %41
    r2 r4 r8 b'8\For | %42
    g4 f4 es8 es8 f8 d8 | %43
    es8 r8 r4 r2 | %44
    R1 | %45
    r8 g16\Pia f16 g8 r8 r8 f16 es16 f8 r8 | %46
    r8 f16 es16 f8 r8 r4 r8 g8\Pia | %47
    g4 g4 g8 es8 c8 f8 | %48
    es8 r8 r4 r2 | %49
    R1 | %50
    r4 r8 g8\Pia g8 as8 c,8 f8 | %51
    e4 r4 r2 | %52
    r2 r4 r8 c'8 | %53
}
\mvtVItimeLine
>>


mvtVIbass = <<
\relative c' {
    \autoBeamOff
    \clef F
    r8 | %0
    R1*7 | %1
    r2 r4\fermata r8 g8 | %8
    c4 b8.\trill[ a32 b32] c8 g8 bes16([ as16)] g16[( f16)] | %9
    g4 c,8 c'8 b8 a8 b8 c8 | %10
    d,16([ es16 f16 d16] f16[ es16 d16 c16] b'8) c16 b16 c8 d8 | %11
    g,4 r4 r2 | %12
    R1*3 | %13
    r2 r4 r8 g8 | %16
    c4 b8.[ a32 b32] c8 g8 bes16([ as16)] g16[ f16] | %17
    g4 c,8 c'8 b8 a8 b8 c8 | %18
    d,16([ es16 f16 d16] f16[ es16 d16 c16] b'8) c16 b16 c8 d8 | %19
    b4 r8 g8 c4 d,4 | %20
    es8 c'8 bes16[ as16] g16[ f16] g16([ as16 bes16 g16)] es8 g8 | %21
    g8 b, c c' c16([ d es c] es[ d c bes] | %22
    a8) fis8 d'8 fis,8 g8([ fis8]) g8([ a8)] | %23
    d,8 d'8 d16([ c16 bes16 a16] bes16[ c16 d16 bes16] d16[ c16 bes16 a16] | %24
    g16[ a16 bes16 g16] bes16[ a16 g16 fis16] g16[ f16)] es16 d16 c8 d8 | %25
    g,4 r4 r2 | %26
    R1*5 | %27
    r2 r4 r8 d''8 | %32
    bes8.[ c16] c8.\trill[ bes32 c32] d8([ c16 bes16] d16[ c16]) bes16[ a16] | %33
    bes4 bes,8 f'8 as8 as8 as8 as8 | %34
    as8([ g16 f16 g8)] f16 es16 bes'8 bes8 bes8 bes8 | %35
    bes8([ as16 g16 as8)] g16 f16 des'8 des8 es,8 des'8 | %36
    c1~ | %37
    c2~ c8 des16([ c16]) bes16([ as16]) g16([ f16]) | %38
    g16([ as16]) bes16([ g16]) bes16([ as16)] g16([ f16]) e16[ \melisma g16 c16 bes16] as16[ g16 f16 e16] | %39
    f[ g as f] as[ g f g] as[ bes c as] c[ bes as g] | %40
    as8 \melismaEnd g16[ as f8] c'8 b8.[ c16] c8.[ b32 c] | %41
    d8([ c16 d16] es8) c8 d16[ b16 c16 d16] g,8 r8 | %42
    R1 | %43
    r4 r8 g8 c4 b8.[ a32 b32] | %44
    c8 g8 bes16([ as16 g16 f16] g4) c,8 c'8 | %45
    b8 c8 b8 a8 g8 a8 b8 c8 | %46
    d8 c8 b8 c8 b16[ \melisma es16 d16 c16] b16[ c16 d16 b16] | %47
    g16[ c16 bes16 a16] g16[ f16 es16 d16] es16[ f16 g16 es16] g16[ f16 es16 d16] | %48
    es8 \melismaEnd g16 f16 es16[ d16] es16[ c16] g'2~ | %49
    g1~ | %50
    g8 c8 b8 d8 g,8 f16([ es16]) g16([ f16)] es16([ d16]) | %51
    e16[ \melisma c16 bes16 c16] d16[ e16 f16 g16] as16[ g16 f16 g16] as16[ bes16 c16 d16] | %52
    es16[ d16 c16 a16] b8.\trill[ c16] \melismaEnd c4 r4 | %53
}
\mvtVItimeLine
>>


mvtVIlyrics = \lyricmode {
    Nun du wirst mein Ge -- wis -- sen stil -- len,
    so wi -- der mich um Ra -- che, um Ra -- che schreit,
    nun du wirst mein Ge -- wis -- sen stil -- len,
    so wi -- der mich um Ra -- che, um Ra -- che schreit,

    ja, dei -- ne Treu -- e wirds er -- fül -- len,
    weil mir dein Wort die Hoff -- nung beut,
    weil mir dein Wort die Hoff -- nung, die Hoff -- nung beut.

    Wenn Chris -- ten __ an __ dich glau -- ben,
    wenn Chris -- ten an dich glau -- ben,
    wenn Chris -- ten an dich glau -- ben,
    wird sie kein Feind in E -- wig -- keit
    aus dei -- nen Hän -- den rau -- ben,
    aus dei -- nen Hän -- den rau -- ben.

    Wenn Chris -- ten an dich glau -- ben,
    wird sie kein Feind in E -- wig -- keit
    aus dei -- nen Hän -- den rau -- ben,
    kein Feind in E -- wig -- keit
    aus dei -- nen Hän -- den rau -- ben.
}


mvtVIbc = <<
\relative c {
    \clef F
    c8 | %0
    c'4 as4 es8 as8 f8 g8 | %1
    c,4 r8 c'8\Pia b8 g8 c8 c,8 | %2
    g'8 g,16 a16 b8 c8 d8 c8 b8 c8 | %3
    g'8 a8 b8 g8\For c4 as4 | %4
    es8 as8 f8 g8 c,4 r8 c'8\Pia | %5
    e,8 c8 f8 d8 b8 g8 c as8 | %6
    g8 g'8 f8 es8 d8 c8 b8 g8\For | %7
    c8 as8 f8 g8 c,4\fermata r8 c'16\Pia b16 | %8
    c8 es8 d8 f8 es8 c8 f8 f,8 | %9
    c'8 d8 es8 c8 g'4 r8 g,16 fis | %10
    g4 r8 g16 fis16 g4 r8 g16 fis16 | %11
    g8 g'16 a16 b8 g8\For c4 as4 | %12
    es8 as8 f8 g8 c,4 r8 c'8\Pia | %13
    e,8 c8 f8 d8 b8 g8 c8 as8 | %14
    g8 g'8 f8 es8 d8 c8 b8 g8\For | %15
    c8 as8 f8 g8 c16( d16 es16 c16 es16\Pia d16 c16 b16) | %16
    c8 g8 d'8 g,8 es'8 c8 f8 f,8 | %17
    c'8 d8 es c8 g'4 r8 g,16 fis | %18
    g4 r8 g16 fis16 g4 r8 g16 fis | %19
    g8 g'16 a16 b8 g8 c4 d,4 | %20
    es8 c8 as8 bes8 es4 r8 es8 | %21
    b8 g8 c8 a8 fis8 d8 g8 c8 | %22
    d8 c8 bes8 d8 es8 d8 c8 a8 | %23
    fis8 g8 d'8 d,8 g4 r8 g8\For | %24
    g'4 es4 bes8 es8 c8 d8 | %25
    g,4 r8 g'8\Pia fis8 d8 g8 g,8 | %26
    d8 d'16 e16 fis8 g8 a8 g8 fis8 g8 | %27
    d8 e8 fis8 d8\For g4 es4 | %28
    bes8 es8 c8 d8 g,4 r8 a8\Pia | %29
    b8 g8 c8 a8 fis8 d8 g8 es8 | %30
    d8 c'8 bes8 g8 a8 g'8 fis8 d8\For | %31
    g8 es8 c8 d8 g,8 g'8 fis8 d8\Pia | %32
    g8 bes8 a8 c8 bes8 g8 es8 f8 | %33
    bes,8 c8 d8 bes8 c8 c'8 d8 bes8 | %34
    es,8 es,8 es'8 c8 des8 c8 bes8 c8 | %35
    f,8 f'16 e16 f8 f,8 f'8 des8 g8 es8 | %36
    as8 as,8 bes8 g8 as8 as'8( g8 f8) | %37
    e8 c8 f8 f,8 c'4 r8 d8 | %38
    e8 c8 f8 f,8 c'8 d8 e8 c8 | %39
    f4 des as8 as'( bes c) | %40
    f,8( g8 as8) f8 d16( es16 f16 d16) f16( es16 d16 c16) | %41
    b8 g8 c8 c,8 g'8 a8 b8 g8\For | %42
    c4 as'4 es8 as8 f8 g8 | %43
    c,8 f8\Pia es8 d8 c8 g8 d'8 g,8 | %44
    es'8 c8 f8 f,8 c'8 d8 es8 c8 | %45
    g'4 r8 g,16 fis16 g4 r8 g16 fis16 | %46
    g4 r8 g16 fis16 g8 g'16 a16 b8 g8 | %47
    c,4 d4 es8 es,8 f8 g8 | %48
    c,4 r8 c'8 b8 g8 es8 c8 | %49
    b'8 g8 c8 es8 g8 f8 es8 c8 | %50
    b8 c8 d8 b8 c8 as'8 f8 g8 | %51
    bes,4 r8 e,8 f16( g16 as16 bes16) c8 as8 | %52
    fis4 g4 c,4 r8 c'8 | %53
}
\mvtVItimeLine
>>

mvtVIfigs = \figuremode {
    s8 |
    s4 <6> <6> <6 5 _->8 <_!> |
    s2 <6>8 <7 _!> s4 |
    <_!> <6> <6\\>8 <6- 4> <7- 5> s |

    <_!>4 <6>8 <_!> s4 <6> |
    <6> <6 5 _->8 <_!> s2 |
    <6>8 <7> <_-> <5-> <6 5> <7 _!> s <6> |
    <_!>4 <4\+ 2> <6\\ 5-> <6 5> |

    % p281
    s4 <6 5>8 <_!> s2 |
    s8 <6> <6\\> <4\+ 2> <6>4 <_-> |
    s <6> <_!> s8 <6 4> |

    <5 _!>4 s8 <\markup\vstrut>16 \bassFigureExtendersOn <\markup\vstrut>16 <_!>4 s8 <\markup\vstrut>16 <\markup\vstrut>16 \bassFigureExtendersOff |
    <_!>4 <6>8 <[_!]> s4 <6> |
    <6> <6 5 _->8 <_!> s2 |

    <6 5>4 <_->8 <5-> <6 5> <7 _!> s <6> |
    <[_!]>4 <4\+ 2>8 <6> <6\\ 5->4 <6 5> |
    s <6 5 _->8 <_!> s <6> s4 |

    % p282
    s8 <6 4> <6\\> <7 _!> <6>4 <_-> |
    s <6> <_!> s8 <6 4> |
    <5 _!>4 s8 <\markup\vstrut>16 \once \bassFigureExtendersOn <\markup\vstrut> <_!>4 s8 <\markup\vstrut>16 \once \bassFigureExtendersOn <\markup\vstrut> |

    <_!>4 <6> s <6-> |
    <5> <6 5> s2 |
    <6>8 <_!> s <5-> <6 5> s s <6 5> |

    <_+> <\FBx> <6> <7 _+> <5> s <5> <5-> |
    <6 5> s <6 4> <5 _+> s2 |
    s4 <6> <6> <6 5>8 <_+> |

    % p283
    s2 <6>8 <7 _+> s4 |
    <_+> <6> <6\\ 5-> <7- 5> |
    <_+> <6>8 <[_+]> s4 <6> |

    <6> <6 5>8 <_+> s4 s8 <\FBx> |
    <6 5> <\FBx> s4 <6 5> s8 <6> |
    <_+> <4\+ 2> <6> s <6\\ 5-> <6 4> <6> <7 _+> |

    s4 <6 5>8 <_+> s4 <6>8 <_+> |
    s4 <6>8 <6\\ 4 3> s4 <6 5> |
    s4 <6> <6-> <6 5-> |

    % p284
    s2 <6>8 <6- 4> <6 5 _-> <_!> |
    <4> <3-> s4 <6->8 <5- 3> <6 5->4 |
    <5>8 <6> <4\+ 2> <6\\ 4 3> <6> <\FBx> <6\\> <_-> |

    <6 5>4 <_-> <_!> <\FBx> |
    <6 5>4 <6- 4>8 <5 3-> <_!>4 <6> |
    <_-> <6> <6> <6 5 _->8 <_!> |

    <_->4 <6> <6\\> <5 2> |
    <6>8 <7 _!> s4 <_!> <6> |
    s <6> <6> <6 5 _->8 <_!> |

    % p285
    s8 <4\+ 2> <6> <6\\> s <6 4> <6\\> <7 _!> |
    <6>4 <_-> s <6> |
    <5 _!> s8 <6 4> <5 _!>4 s8 <6 4> |

    <5 _!>4 s8 <6 4> <5 _!>4 <6>8 <7 _!> |
    s4 <6\\> <6> <6 5 _->8 <_!> |
    s2 <6 5>8 <_!> <6>4 |

    <6>8 <7 _!> s4 <_!> <6> |
    <6> <6\\>8 <6 5> s4 <6 5 _->8 <_!> |
    <4\+ 2>4 s8 <6 5> <_->4 <6- 4>8 <6> |
    <7- 5>4 <_!> s2 |
}
