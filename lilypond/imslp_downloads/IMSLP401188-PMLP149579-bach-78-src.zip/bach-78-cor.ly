\include "bach-78-1.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = "Corno in C"
}

\addQuote mvtIbc { \mvtIbc }
mvtIcues = \new CueVoice {
    s2.*16 | %16
    \cueDuringWithClef mvtIbc #DOWN #"bass" { s2.*4^"Continuo" } | %20
    s2.*28 | %48
    \cueDuringWithClef mvtIbc #DOWN #"bass" { s2.*4^"Continuo" } | %52
    s2.*58 | %110
    \cueDuringWithClef mvtIbc #UP #"bass" { s2.*7^"Continuo" } | %117
}

\score {
    \new Staff <<
        \mvtIsoprano
        \mvtIcues
        % { s2.*108 | \pageBreak }
    >>

    \header {
        piece = \mvtIpiece
    }
}


% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}

\score {
    \new Staff <<
        \mvtVIIsoprano
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
