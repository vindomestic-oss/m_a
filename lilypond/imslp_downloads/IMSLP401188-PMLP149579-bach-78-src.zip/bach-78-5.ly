\version "2.18.0"

\include "common.ly"


mvtVtimeLine = {
    \key bes \major
    \time 4/4

    s1*7 | %7
    \tempo "Vivace"
    s1*2 | %9
    \tempo "Adagio"
    s1*7 | %16
    \bar "||"
    \tempo "Andante (a tempo)"
    s1*11 | %27
    \bar "|."
}

mvtVbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak
}

mvtVvlnI = <<
\relative c'' {
    es1\Pia~ | %1
    es2 f4 d,4 | %2
    es2 g2~ | %3
    g2 f2 | %4
    c'2 bes2~ | %5
    bes2 c2 | %6
    r4 d4 es2 | %7
    r16 c'16\For c16 c16 c8 r8 r16 a16 a16 a16 a8 r8 | %8
    r16 fis16 fis16 fis16 fis8 r8 r16 g16 g16 d16 d16 bes16 bes16 g16 | %9
    as2\Pia d,2 | %10
    g1 | %11
    f4 c'4 d4 f4 | %12
    es1 | %13
    f1 | %14
    es1 | %15
    as,8( bes16 c16) bes8( c16 des16) as4( g8.)\trill as16 | %16
    as8( c8) e,8( f8)\trill g4 r8 f'8 | %17
    e8( g8) bes,8( as8) d8( f8) as,8( g8) | %18
    b8( d8) g,8( b8) c8( g'8) c,8( bes8) | %19
    as4 r8 << es'8 \\ { \teeny des_"?" } >> es8( c8) bes8( as8) | %20
    f'8( des8) c8( bes8) as'8( des,8) c8( bes8) | %21
    as8( c8) e,8( f8) g8( as8) bes8( c8) | %22
    des4 c2 bes4~ |
    bes8 e( f g) c,( f) e( f) |
    bes,( as') g( f) e( f) c( e) |
    f4 des,~ des8 bes' g( as) |
    e( f) c( e) f4\fermata r |
}
\mvtVtimeLine
>>


mvtVvlnII = <<
\relative c'' {
    bes1\Pia | %1
    as2. as,4 | %2
    bes2 des2~ | %3
    des2 c2 | %4
    as'2 f2 | %5
    g1 | %6
    r4 f4 g2 | %7
    r16 es'16\For es16 es16 es8 r8 r16 d16 d16 d16 d8 r8 | %8
    r16 a16 a16 a16 a8 r8 r16 d16 d16 bes16 bes16 g16 g16 d16 | %9
    d2\Pia f2 | %10
    e4 bes'2 g4 | %11
    as1 | %12
    g2 bes2 | %13
    c2 bes2~ | %14
    bes2 as4 ges4 | %15
    f2 c8 des8 es4 | %16
    es4 bes8( as8) g4 r8 c'8 | %17
    c4 g8( f8) f4 f8( es) | %18
    d4. g8 g8( es8) f8( g8) | %19
    c,4 r8 bes'8 as4 r8 as8 | %20
    bes4 r8 g8 c8( f,8) es8( des8) | %21
    c4 bes8( as8) g8( c8) e8( f8) | %22
    g2~ g8 f e( f) |
    g4 as8( e) f4 r8 bes |
    c4 r8 c bes4 r8 bes |
    as( g) e( f) g4 r8 c, |
    c4 bes as\fermata r |
}
\mvtVtimeLine
>>


mvtVvla = <<
\relative c'' {
    \clef C
    g1\Pia | %1
    c,2 d4 f,4 | %2
    g2 bes2~ | %3
    bes4 g4 as2 | %4
    f'2 d2 | %5
    es1 | %6
    r4 bes4 bes2 | %7
    r16 fis'16\For fis16 fis16 fis8 r8 r16 c'16 c16 c16 c8 r8 | %8
    r16 c16 c16 c16 c8 r8 r16 bes16 bes16 g16 g16 d16 d16 bes16 | %9
    as2\Pia g2 | %10
    c4 des2. | %11
    c4 f~ f d4 | %12
    bes2 g'2 | %13
    a2 f2 | %14
    g2 es2 | %15
    des2 es4 des4 | %16
    c4 des4~ des4 r8 as'8 | %17
    g4 des8( c8) b4~ b8 c8 | %18
    d8( f8) b,8( d8) c4 d8( e8) | %19
    f4 r8 bes,8 c4 r8 des8 | %20
    des4 r8 es8 es8( as,8) es'8 es8 | %21
    es8( as,8) des4~ des8 c8 des8( c8) | %22
    bes4. as16( g) as4 bes |
    g c c r8 f |
    g4 r8 as g4 r8 c, |
    f( des) bes( as) g4 r8 f |
    as4 g8( c,) c4\fermata r4 |
}
\mvtVtimeLine
>>


mvtVbass = <<
\relative c {
    \autoBeamOff
    \clef F
    r4 r8 es8 des'8 des8 r4 | %1
    c8 as8 r4 d4 r8 as,8 | %2
    as8([ g8]) r8 g'8 e8 e8 r8 g16 as16 | %3
    bes8 bes8 des8 c8 as4 r8 c8 | %4
    f,8. g16 as16 bes16 c16 f,16 d'8 d8 r8 bes8 | %5
    es8 bes8 g8 es8 c'8 bes8 as8 g8 | %6
    es8 es8 r4 r8 es8^"col' ardore" g8 bes8 | %7
    es8. fis,16 fis8 a8 d,4 r8 d8 | %8
    c'8 r16 c,16 es16 es16 es16 c16 bes4 r8 bes'8 | %9
    d,8^\markup\upright\bold\large{Lento} f8 as8 g8 g8 g8 r8 g8 | %10
    g8 e8 des'8 r16 bes16 e,8 g8 bes8 as8 | %11
    as8 as8 r8 f8 d8 bes8 as'16([ bes32 c32)] bes8 | %12
    \grace as8 g4 r8 bes,8 es8 f8 g8 es8 | %13
    c8 c8 a'8. bes16 bes4 r8 bes8 | %14
    g8 g8 f8 es8 as8 as8 r8 es8 | %15
    f8 des8 g8 as8 c,4( bes8\trill[ as8)] | %16
    as4^\markup\upright\bold\large{a tempo} r4 g'8([ as8)] as8\trill([ g16 as16)] | %17
    bes4 r8 c,8 as'4 r8 g8 | %18
    f16([ d'16 b16 g16] f8.\trill[ es16)] es4 r4 | %19
    as4 bes8([ c16 des16)] c8([ as8)] g8([ f8)] | %20
    des'4 r8 es,8 es16([ des'16 c16 bes16] g8.\trill[ as16)] | %21
    as4 r4 g4 r8 as8 | %22
    c([ bes]) r c as([ f des]) c'16([ bes]) | %23
    c4 r c8([ as]) g([ f]) |
    e([ bes']) r as des([ c]) as([ g16\trill f]) |
    f4 r r2 |
    R1\fermataMarkup |
}
\mvtVtimeLine
>>

mvtVbassLyrics = \lyricmode {
    Die Wun -- den, Nä -- gel, Kron und Grab,
    die Schlä -- ge, so man dort dem Hei -- land gab,
    sind ihm nun -- meh -- ro Sie -- ges -- zei -- chen
    und kön -- nen mir ver -- neu -- te Kräf -- te rei -- chen.

    Wenn ein er -- schreck -- li -- ches Ge -- richt
    den Fluch vor die Ver -- damm -- ten spricht,
    % für
    so kehrst du ihn in Se -- gen.

    Mich kann kein Schmerz und kei -- ne Pein be -- we -- gen,
    weil sie mein Hei -- land kennt;
    und da dein Herz vor mich in Lie -- be brennt,
    % für
    so le -- ge ich hin -- wie -- der
    das mei -- ne vor dich nie -- der. 

    Dies mein Herz, mit Leid ver -- men -- get,
    so dein teu -- res Blut be -- spren -- get,
    so am Kreuz ver -- gos -- sen ist,
    geb ich dir, Herr Je -- su Christ. 
}


mvtVbc = <<
\relative c {
    \clef F
    es1~\Pia^"coll'arco" | %1
    es1~ | %2
    es2 bes2 | %3
    e,2 f2~ | %4
    f2 as2 | %5
    g2 as2 | %6
    r4 bes4 es,2 | %7
    r16 a16\For a16 a16 a8 r8 r16 fis16 fis16 fis16 fis8 r8 | %8
    r16 d16 d16 d16 d8 r8 r16 g16 g16 bes16 bes16 d16 d16 g16 | %9
    f2\Pia b,2 | %10
    bes4 e,2. | %11
    f2 bes2 | %12
    es1~ | %13
    es2 d2 | %14
    des2 c2 | %15
    des4 f,4 es2 | %16
    as8( as'8) g8( f8) e4 r8 f8 | %17
    c8( d8) e8( f8) b,8( c8) d8( es8) | %18
    as,8( f8) g4 c8( bes8) as8( g8) | %19
    f4 r8 g8 as8( bes8) c8( des8) | %20
    bes8( c8) des8( es8) c8( des8) es8( es,8) | %21
    as8( as'8) g8( f8) e8( c'8) bes8( as8) | %22
    g8( f) e( c) f( as,) g( f) | %23
    e( des') c( bes) as4 r8 des | %24
    c( d) e( f) bes,4 r8 c | %25
    des( bes) g( f) e4 r8 f |
    c'4 c, f\fermata r |
}
\mvtVtimeLine
>>

mvtVfigs = \figuremode {
    <8>2 <7-> |
    <6 4-> <7\\ 4- 2> |
    <5 3> <6 4\+ 3-> |
    <7- 5> <_-> |

    <\FBx> <6 4 2> |
    <6> <7 5> |
    s s |

    s16 <6\\ 5->8. <\FBx>8 s s16 <6 5>8. <\FBx>8 s |
    s16 <7 _+>8. s4 s <6>8 <6 4> |
    <6 _->2 <6 5> |

    % p279
    <4\+ 2>4 <7- 5>2. |
    <_->2 <7-> |
    s1 |
    <6 4\+ 2>2 <6> |

    <4 2> <6-> |
    <5- 3>4 <6-> <6 4-> <5 3> |
    <5 3> <6\\>8 <_-> <6>4 s8 <_-> |
    <7 _!>4 <7- 5>8 <_-> <7->4 \once \bassFigureExtendersOn <7->8 <6> |

    <6 4 2\+>4 <7 _!> <5 _-> <6>8 <6\\> |
    <_->4 s8 <6 5-> <5 3>4 \once \bassFigureExtendersOn <5 3>8 <3> |
    <_->4 <6> <6->8 <7 5-> <6 3> \once \bassFigureExtendersOn <5 3> |
    <5 3>4 <6\\>8 <_-> <6> <_!> <\FBx> <6> |

    % p280
    <6 5->4 <6 5> <_-> <6\\ 5->8 <6- 4> |
    <6> <4 2\+> <6- 4> <6 4\+ 2> <6>4 s8 <6> |
    <7 _!>4 <6 5>8 <_-> <6 4\+ 3->4 <5 7->8 <7 _!> |
    <5-> <_-> <6\\ 5-> <6- 4> <7- 5> <6> s <_-> |
    <6- _!> <4> <5 4> <_!> <[_-]>4 s |
}
