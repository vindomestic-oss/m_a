\version "2.18.0"

\include "common.ly"

mvtIVtimeLine = {
    \partial 8
    \time 6/8
    \key g \minor

    s8 |
    \segno
    s2.*11 | %11
    s4. s4 s8 | %12
    s2.*49 | %61
    \dalSegno
    \bar "||"
}


mvtIVbreaks = {
    <>^"BGA breaks left in"
    s8 |
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \pageBreak

    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \pageBreak

    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \bar "||"
}


mvtIVfl = <<
\relative c'' {
    g8 | %0
    d'4 es8 \grace d8 c8 bes16 a16 bes16 c16 | %1
    d8 g,8 g'8 fis16 d16 \once \set suggestAccidentals = ##t e16 fis16 g16 a16 | %2
    bes4 c8 a16 fis16 g16 a16 bes16 c16 | %3
    d8 g,16( fis16 g16 a16) d,8 e16 fis16 g16 a16 | %4
    bes8-. es,4~ es16 d16 c16 d16 es16 f16 | %5
    g8-. c,4~ c16 bes16 a16 bes16 c16 d16 | %6
    es8-. as,4~ as16 g16 fis16 g16 a16 bes16 | %7
    c16-. es16( d16 c16) a'16-. fis16 c4.~ | %8
    c16 es16( d16 c16) a'16-. fis16-. bes,16-. d16( c16 bes16) g'16-. es16-. | %9
    a,16-. c16( bes16 a16) f'16-. d16-. g,16 bes16( a16 g16) es'16-. c16-. | %10
    fis,16 g16 a16 bes16 c16 d16 e16 fis16 g16 a16 bes16 c16 | %11
    d8 c16 bes16 a16 bes16 \grace a8 g4\fermata r8 | %12
    R2. | %13
    r4 r8 c,4.~ | %14
    c16 es16( d16 c16) a'16-. fis16-. bes,16-. d16( c16 bes16) g'16-. es16-. | %15
    a,16-. c16( bes16 a16) f'16-. d16-. g,16-. bes16( a16 g16) es'16-. c16-. | %16
    fis,16( g16 a16 bes16 c16 d16) e16( fis16 g16 a16 bes16 c16) | %17
    d8 c16 bes16 a16 bes16 g16 d16( e16 fis16 g16 a16) | %18
    \grace a8 bes4 c8 a4 g16 fis16 | %19
    g16 a16 bes16 c16 d16 es16 \grace bes8 a4 r8 | %20
    bes,16-\parenthesize-. d16( c16 bes16) f'16-. d16-. bes16-. d16( c16 bes16) f'16-. d16-. | %21
    bes16-. d16( c16 bes16) f'16-. d16-. bes16-. d16( c16 bes16) f'16-. d16-. | %22
    bes4.~ bes16 d16( c16 bes16) g'16-. e16-. | %23
    bes4.~ bes16 c16( bes16 a16) a'16-. f16-. | %24
    bes4.~ bes16 a16( g16 f16 es16 d16) | %25
    c16 bes16 c8 a8 bes4 bes8 | %26
    f'4 g8 \grace f8 es8 d16 c16 d16 es16 | %27
    f8 bes,8 bes'8 a16 f16 g16 a16 bes16 c16 | %28
    d8 es,4~ es16 c16 d16 es16 f16 g16 | %29
    f8 es16 d16 c16 d16 bes4 r8 | %30
    r16 a16 bes16 c16 d16 es16 f4 r8 | %31
    r16 b,16 c16 d16 es16 f16 g16 f16 es16 d16 es16 c16 | %32
    d16-. f16( es16 d16) b'16-. g16-. es16 g16 f16 es16 c'16 as16-. | %33
    f16-. as16( g16 f16) d'16-. b16-. es,16-. g16( f16 es16) c'16-. g16-. | %34
    d16( es16 f16) b16-. d8-. es,16( f16 g16) c16-. es8-. | %35
    f,16( g16 as16) d16-. f8-. g,16( b16 c16) es16-. g8 | %36
    R2. | %37
    r4 r8 bes,,4.~ | %38
    bes8 g'8-. bes,8-. as8-. f'8-. as,8-. | %39
    g8-. es'8-. g,8-. f8 d'16 f16 d16 bes16 | %40
    bes'2. | %41
    r4 r8 r8 r8 bes,8 | %42
    g'4 as8 \grace g8 f8 es16 d16 es16 f16 | %43
    g8 c,8 c'8 b4 r8 | %44
    r16 g,16 a16 b16 c16 d16 es4 r8 | %45
    r16 d16 e16 fis16 g16 a16 bes16( g16 a8) r8 | %46
    r16 d,16( c16 bes16) bes'16-. g16-. c,16-. es16( d16 c16) c'16-. a16-. | %47
    d,16-. d'16( c16 bes16) g'16-. d16 bes16-. d16( c16 bes16 a16 g16) | %48
    fis16( g16 a16) fis16-. d16-. fis16-. g16( a16 bes16) g16-. d16-. g16-. | %49
    fis16( g16 a16) fis16 d16-. fis16-. g16( f16 es16) d16-. es16-. c16 | %50
    d16( es16 f16) d16-. b16-. d16-. es16( f16 g16) es16-. c16-. es16-. | %51
    d16( es16 f16) d16-. b16-. d16-. es16( d16 c16 bes16 a16 g16) | %52
    c16-. es16( d16 c16) a'16-. fis16-. c16-. es16( d16 c16) a'16-. fis16-. | %53
    c16-. es16( d16 c16) a'16-. fis16-. c16-. es16( d16 c16) a'16-. fis16-. | %54
    bes,16-. d16( c16 bes16) g'16 d16-. bes16-. d16( c16 bes16) g'16-. d16-. | %55
    bes16-. d16( c16 bes16) g'16-. d16-. bes16( c16 d16 e16 fis16 g16) | %56
    a16( bes16 c16 d16 es?16) fis,16 g4 r8 | %57
    r4 r8 d4.~ | %58
    d8 bes'8-. d,8-. c8-. a'8-. c,8-. | %59
    bes8-. g'8-. bes,8-. a8 r8 r8 | %60
    r4 r8 r8 r8 g8 | %61
   
}
\mvtIVtimeLine
>>


mvtIVtenor = <<
\relative c' {
    \autoBeamOff
    r8 | %0
    R2.*11 | %1
    r4 r8 r4\fermata g8 | %12
    d'4 es8 \grace d16 c8([ bes16 a16)] bes16[ c16] | %13
    d8[ g,8] g'8 fis4 r8 | %14
    R2.*3 | %15
    r4 r8 r8 r8 g,8 | %18
    d'4 es8 c8([ bes16 a16]) bes16[ c16] | %19
    d8[ g,8] g'8 fis4 r8 | %20
    d8 es16([ c16)] d8 d8 f4 | %21
    d8([ es16 c16)] d8 d4 r8 | %22
    e8 f16([ d16)] e8 e8 g4 | %23
    e8([ f16 d16)] e8 f4 r8 | %24
    f8 g8 as8 g8 c,8 f8 | %25
    r8 es16([ d16 c16 d16)] bes4 r8 | %26
    R2.*3 | %27
    r4 r8 r8 r8 bes8 | %30
    f'4 f8 as,8([ g8]) as | %31
    g8([ g'16 f16)] es16[ d16] es8 c8 g'8 | %32
    g8 g,8 r8 r8 r8 g'8 | %33
    g8 g,8 r8 r8 r8 c8 | %34
    b16[ \melisma c16 d16 b16 g16 b16] c16[ d16 es16 c16 a16 c16] | %35
    d16[ es16 f16 d16 b16 d16] es8 \melismaEnd c8 es8 | %36
    f8([ g16 as16)] g8 f8([ es16 d16)] es8 | %37
    as,8 g16([ f16 g16 as16)] f8 g8 as8 | %38
    bes8. g16 es'8 r8 r16 bes16 f'8 | %39
    r8 r16 bes,16 g'8 r8 r8 bes,8 | %40
    bes16([ c16 d16 es16 f16 g16] as8) g16 f16 g8 | %41
    bes,8 g'16[ f16] es16[ d16] es4 r8 | %42
    R2. | %43
    r4 r8 r8 r8 g8 | %44
    es4 c8 fis,8[ g16 a16] bes16[ c16] | %45
    d8[ g,8] g'8 fis8 d8 fis8 | %46
    g8 g,8 r8 r8 r8 fis'8 | %47
    g8 g,8 r8 r8 r8 bes8 | %48
    a16[ \melisma bes16 c16 a16 fis16 a16] bes16[ c16 d16 bes16 g16 bes16] | %49
    a16[ bes16 c16 a16 fis16 a16] bes8 \melismaEnd g8 c8 | %50
    b16[ \melisma c16 d16 b16 g16 b16] c16[ d16 es16 c16 g16 c16] | %51
    b16[ c16 d16 b16 g16 b16] c8 \melismaEnd g8 es'8 | %52
    d2.~ | %53
    d2.~ | %54
    d2.~ | %55
    d4 d8 d8[ g8] d8 | %56
    es8 d8 c8 d8[ c16 bes16] a16[ g16] | %57
    fis8 g16[ a16 bes16 g16] a8 d,8 a'8 | %58
    bes8. es,16 es'8 r8 r16 f,16 f'8 | %59
    d8 g16[ fis16] g8 a8 c,16 a16 es'8 | %60
    d8 c16[ bes16] a16[ bes16] g4 r8 | %61
   
}
\mvtIVtimeLine
>>


mvtIVtenorLyrics = \lyricmode {
    Das Blut, so mei -- ne Schuld durch -- streicht,
    das Blut, so mei -- ne Schuld durch -- streicht,
    macht mir das Her -- ze wie -- der leicht,
    macht mir das Her -- ze wie -- der leicht
    und spricht mich frei,
    und spricht mich frei.

    Ruft mich der Höl -- len Heer zum Strei -- te,
    zum Strei -- te,
    zum Strei -- te,
    zum Strei -- te,
    so ste -- het Je -- sus mir zur Sei -- te,
    daß ich be -- herzt, be -- herzt, be -- herzt und sieg -- haft,
    be -- herzt und sieg -- haft sei. 
    Ruft mich der Höl -- len Heer zum Strei -- te,
    zum Strei -- te,
    zum Strei -- te,
    zum Strei -- te,
    zum Strei -- te,
    so ste -- het Je -- sus,
    so ste -- het Je -- sus mir zur Sei -- te,
    daß ich be -- herzt, be -- herzt,
    daß ich be -- herzt, ich be -- herzt und sieg -- haft sei. 
}


mvtIVbc = <<
\relative c {
    \clef F
    r8 | %0
    r8 g8^"pizzicato" g'8~ g8 fis8 g8 | %1
    bes,4 c8 d8 c8 d8 | %2
    g,8 g'8 es8 c8 bes8 a8 | %3
    bes8 es8 c8 d4 r8 | %4
    r8 g8 g,8 f4 r8 | %5
    r8 es'8 es,8 d4 r8 | %6
    r8 <\tag CELLO c \tag ORGAN c'> <\tag CELLO c' \tag ORGAN c> bes4 r8 | %7
    r8 a'8 g8 fis8 g8 a8 | %8
    d,8 e8 fis8 g8 es8 r8 | %9
    f8 d8 r8 es8 c8 r8 | %10
    d8 d'8 c8 bes8 a8 g8 | %11
    bes,8 c8 d8 g,4-\fermata r8 | %12
    r8 g8 g'8~ g8 fis8 g8 | %13
    bes,4 c8 d16 d'16( c16 bes16 a16 g16) | %14
    fis8 a8 d,8 g8 es8 r8 | %15
    f8 d8 r8 es8 c8 r8 | %16
    d8 d'8 c8 bes8 a8 g8 | %17
    bes,8 c8 d8 g,4 r8 | %18
    r8 g8 g'8~ g8 fis8 g8 | %19
    bes,4 c8 d8 e16 fis16 g16 a16 | %20
    bes8 bes8 bes8 a8 a8 a8 | %21
    g8 g8 g8 f8 f8 f8 | %22
    g8 g8 g8 c8 c8 c8 | %23
    c,8 c8 c8 f8 f8 es8 | %24
    d8 c8 bes8 es4 a,8 | %25
    bes8 f'8 f,8 bes4 r8 | %26
    r8 bes8 bes'8~ bes8 a8 bes8 | %27
    d,4 es8 f4 a8 | %28
    bes16( a16 g16 f16 es16 d16) c8 a'8 c,8 | %29
    d8 es8 f8 bes,4 r8 | %30
    r8 bes4 d8 es8 f8~ | %31
    f8 es8 g8 c,8 es8 c8 | %32
    g'8 b8 g8 g8 c8 g8 | %33
    g8 d'8 g,8 g8 es'8 g,8 | %34
    g8 g,8 g'8 g8 g,8 g'8 | %35
    g8 g,8 g'8 c,8 c'8 bes8 | %36
    as4 bes8 as4 g8 | %37
    f4 es8 d8 es8 f8 | %38
    g16( as16 bes16) g16-. es16-. g16-. f16( g16 as16) f16-. d16-. f16-. | %39
    es16( f16 g16) es16-. c16-. es16-. d16( es16 f16) d16-. bes16-. d16-. | %40
    as4. r16 bes16( c16 d16 es16 f16) | %41
    g8 as8 bes8 es,4 r8 | %42
    r8 es8 c'8~ c8 b8 c8~ | %43
    c8 es,16( d16 es16 f16) g8 a8 b8 | %44
    c8 c,8 es8 a,4 r8 | %45
    r16 bes16 c16 d16 es16 c16 d8 fis8 d8 | %46
    g8 d8 g8 a8 d,8 a'8 | %47
    bes8 d,8 bes'8 g8 d8 g8 | %48
    d'8 d,8 d'8 d8 d,8 d'8 | %49
    d8 d,8 d'8 g,8 a16 bes16 c8 | %50
    g g,8 g'8 g8 g, g'8 | %51
    g8 g,8 g'8 c,8 es8 c8 | %52
    fis8 g16 e16 fis8 fis8 a4 | %53
    fis8 g16 e16 fis8 fis4 r8 | %54
    g8 a16 fis g8 g bes4 | %55
    g8 a16 fis16 g8 g8 a8 bes8 | %56
    c8 bes8 a8 bes4 es,8 | %57
    d8 bes8 g8 d'8 fis8 d8 | %58
    g16( a16 bes16) g16-. es16-. g16-. a16( bes16 c16) a16-. f16-. a16-. | %59
    bes16( c16 d16) bes16-. g16-. bes16-. fis16( g16 a16) fis16-. d16-. fis16-. | %60
    bes,8 c8 d8 g,4 r8 | %61
   
}
\mvtIVtimeLine
>>


mvtIVfigs = \figuremode {
    s8 |
    s s <6 4> <4 2> <6 5> s |
    <6>4 <7 5>8 <_+>4 \once \bassFigureExtendersOn <_+>8 |
    s4 <6>8 <4\+ 2> <6> <6\\> |
    <6>4 <6 5>8 <_+>4 s8 |

    s8 <6-> s <7> <6> s |
    s <6> s <7> <6> s |
    s <6-> s <7-> <6> s |
    s <5-> <5-> <6 5>4 \once \bassFigureExtendersOn <6 5>8 |
    <7 _+>4. s8 <6 5> s |

    s <6 5> s s <6 5> s |
    <_+>4 \once \bassFigureExtendersOn <_+>8 <4\+ 2> <6\\> s |
    <6> <6 5> <_+> s4. |
    s8 s <6 4> <4 2> <6 5> s |

    <6>4 <7 5>8 <_+>4. |
    <6 5>8 <6\\> <7 _+> s <6 5> s |
    s <6 5> s s <6 5> s |
    <_+>4 \once \bassFigureExtendersOn <_+>8 <4\+ 2> <6\\> s |

    <6>8 <6 5> <_+> s4. |
    s8 s <6 4> <4 2> <6 5> s |
    <6>4 <7 5>8 <_+>4. |
    <5 3> <4 2> |

    %p276
    <7 5> <6 4> |
    <6\\> <7 _!> |
    <7 _!> <4>8 <3> <4 2> |
    <6> s <7-> <7> <6> <6 5> |

    <4> s <3> s4. |
    s8 s <6 4> <4 2> <6 5> s |
    <6>4 <7 5>8 s4 <6>8 |
    s <6> s <6 4 3>4. |

    <6>8 <6 5> s s4. |
    s <6 5->8 s <7 5> |
    <4\+ 2> <6> <_!> s <6> s |
    <_!> <6> s <6 4>4. |

    <7 _!> <6 4> |
    <5 _!> <6 4> |
    <7 _!> s4 <4 2>8 |
    <6>4 <6 4>8 <4 2>4 <6>8 |

    <7 _-> <6> s <6 5-> s <6 _-> |
    <6>4. <6 4 3->16*5 \once \bassFigureExtendersOn <6 4 3->16 |
    s4. <6> |
    <4 2> s16 <7-> s8 <5 3> |

    %p277
    <6>8 <7 5> s s4. |
    s8 <5> <6> <4 2> <6 5> s |
    s <6> s <_!> \once \bassFigureExtendersOn <_!> <6> |
    s s <6> <6\\ 5->4. |

    s16 <6> s8 <6> <6 _+> <6> s |
    s <6 4> s <6\\ 4>4. |
    <6> s |
    <_+> <6 4> |

    <5 _+> s |
    <5 _!> <6 4> |
    <5 _!> s8 <6> s |
    <6 5>4 \once \bassFigureExtendersOn <6 5>8 <6 5> <6\\ 4 3>4 |

    <6 5>4. <6 5> |
    s s8 <6>4 |
    s4. s4 <6>8 |
    <6> <6> <6\\> <6>4 <6>8 |

    <_+> <6> s <_+> <6> s |
    s8 s <5> <6 5>4. |
    s8 <6 4> s <6 5> s <9 7 _+> |
    <6> <6 5> <_+> s4. |
}
