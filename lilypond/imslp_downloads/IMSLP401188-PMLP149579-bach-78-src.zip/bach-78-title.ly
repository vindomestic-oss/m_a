\version "2.19.7"

\header {
    title = \markup{ "Jesu der du meine Seele" }
    subtitle = \markup{ Dominica 14 post F. Trinitatis }
    opus = "BWV 78"
    composer = "J.S. Bach"
    source = \markup{Quelle: D-LEb Thomana 78 \italic{Bach-Archiv Leipzig}}
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2015 Creative Commons Attribution Non-Commercial ShareAlike 4.0}}
}

\layout {
}


mvtIpiece = \markup{I. (Coro)}
mvtIIpiece = \markup{II. Aria: \smallCaps{Duetto}}
mvtIIIpiece = \markup{III. Recit.}
mvtIVpiece = \markup{IV. Aria}
mvtVpiece = \markup{V. Recit.}
mvtVIpiece = \markup{VI. Aria}
mvtVIIpiece = \markup{VII. Chorale}
