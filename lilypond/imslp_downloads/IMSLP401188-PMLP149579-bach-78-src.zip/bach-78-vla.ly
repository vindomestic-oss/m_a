\include "bach-78-1.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Viola"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
    \new Staff <<
        \mvtIvla
    >>

    \header {
        piece = \mvtIpiece
    }
}


% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}

\score {
    \new Staff <<
        \mvtVvla
    >>

    \header {
        piece = \mvtVpiece
        % breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIvla
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \clef alto \mvtVIItenor
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
