\version "2.19.15"

\include "bach-78-1.ly"
\include "bach-78-2.ly"
\include "bach-78-3.ly"
\include "bach-78-4.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"
\include "common-grand-score.ly"

\markup\null\pageBreak

\paper {
    indent = #18
    short-indent = #8
}

#(set-global-staff-size 14)
% #(set-global-staff-size 15)


% %{
\score {
    <<
        % \new Dynamics { \mvtIbreaks }

        \new StaffGroup <<
            \new Staff = staffA <<
                \set Staff.instrumentName = \markup\center-column{"Flauto" "Traverso"}
                \set Staff.shortInstrumentName = \markup{"Fl."}

                \mvtIfl
            >>
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Oboe"}
                \set GrandStaff.shortInstrumentName = \markup{"Ob."}

                \new Staff = staffB <<
                    \set Staff.instrumentName = \markup{"1"}
                    \set Staff.shortInstrumentName = \markup{"1"}

                    \mvtIobI
                >>
                \new Staff = staffC <<
                    \set Staff.instrumentName = \markup{"2"}
                    \set Staff.shortInstrumentName = \markup{"2"}

                    \mvtIobII
                >>
            >>
        >>

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Violino"}
                \set GrandStaff.shortInstrumentName = \markup{"Vln."}

                \new Staff = staffD <<
                    \set Staff.instrumentName = \markup{"I"}
                    \set Staff.shortInstrumentName = \markup{"I"}

                    \mvtIvlnI
                >>
                \new Staff = staffE <<
                    \set Staff.instrumentName = \markup{"II"}
                    \set Staff.shortInstrumentName = \markup{"II"}

                    \mvtIvlnII
                >>
            >>
            \new Staff = staffF <<
                \set Staff.instrumentName = \markup{"Viola"}
                \set Staff.shortInstrumentName = \markup{"Vla."}

                \mvtIvla
            >>
        >>

        \new ChoirStaff <<
            \new Staff = staffG <<
                \set Staff.instrumentName = \markup\bold{"Soprano"}
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = mvtIsoprano { \clefSoprano \mvtIsoprano }
                \new Lyrics \lyricsto mvtIsoprano \mvtIsopranoLyrics
            >>
            \new Staff = staffH <<
                \set Staff.instrumentName = \markup\bold{"Alto"}
                \set Staff.shortInstrumentName = \markup\bold{"A."}

                \new Voice = mvtIalto { \clefAlto \mvtIalto }
                \new Lyrics \lyricsto mvtIalto \mvtIaltoLyrics
            >>
            \new Staff = staffI <<
                \set Staff.instrumentName = \markup\bold{"Tenore"}
                \set Staff.shortInstrumentName = \markup\bold{"T."}

                \new Voice = mvtItenor { \clefTenor \mvtItenor }
                \new Lyrics \lyricsto mvtItenor \mvtItenorLyrics
            >>
            \new Staff = staffJ <<
                \set Staff.instrumentName = \markup\bold{"Basso"}
                \set Staff.shortInstrumentName = \markup\bold{"B."}

                \new Voice = mvtIbass { \mvtIbass }
                \new Lyrics \lyricsto mvtIbass \mvtIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffK <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                { \dynamicUp \mvtIbc }
                \mvtIfigs
            >>
        >>
    >>

    \layout {
        \context {
            \Staff {
                \override VerticalAxisGroup.staff-staff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2)
                       (padding . 1.0)
                       (stretchability . 70))
            }
        }
        \context {
            \Lyrics {
                \override VerticalAxisGroup.nonstaff-unrelatedstaff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2)
                       (padding . 0.6)
                       (stretchability . 70))
                \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
                    #'((basic-distance . 2)
                       (minimum-distance . 1)
                       (padding . 0.3)
                       (stretchability . 40))
            }
        }
    }
    \midi { }

    \header {
        piece = \mvtIpiece
    }
}
% %}


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics { \mvtIIbreaks }

        \new ChoirStaff <<
            \new Staff = staffA <<
                \set Staff.instrumentName = \markup\bold{"Soprano"}
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = mvtIIsoprano { \clefSoprano \mvtIIsoprano }
                \new Lyrics \lyricsto mvtIIsoprano \mvtIIsopranoLyrics
            >>
            \new Staff = staffB <<
                \set Staff.instrumentName = \markup\bold{"Alto"}
                \set Staff.shortInstrumentName = \markup\bold{"A."}

                \new Voice = mvtIIalto { \clefAlto \mvtIIalto }
                \new Lyrics \lyricsto mvtIIalto \mvtIIaltoLyrics
            >>
        >>

        \new GrandStaff <<
            \new Staff = staffC <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                { \dynamicUp \mvtIIbc }
                \mvtIIfigs
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup{Violone}
                \set Staff.shortInstrumentName = \markup{"Vne."}

                \mvtIIcb
            >>
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    \new StaffGroup <<
        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\bold{"Tenore"}
            \set Staff.shortInstrumentName = \markup\bold{"T."}

            \new Voice = mvtIIItenor { \clefTenor \mvtIIItenor }
            \new Lyrics \lyricsto mvtIIItenor \mvtIIItenorLyrics
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = \markup{"B.C."}

            { \dynamicUp \mvtIIIbc }
            \mvtIIIfigs
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    \new StaffGroup <<
        % \new Dynamics { \mvtIVbreaks }

        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\center-column{"Flauto" "Traverso"}
            \set Staff.shortInstrumentName = \markup{"Fl."}

            \mvtIVfl
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\bold{"Tenore"}
            \set Staff.shortInstrumentName = \markup\bold{"T."}

            \new Voice = mvtIVtenor { \clefTenor \mvtIVtenor }
            \new Lyrics \lyricsto mvtIVtenor \mvtIVtenorLyrics
        >>
        \new Staff = staffC <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = \markup{"B.C."}

            { \dynamicUp \mvtIVbc }
            \mvtIVfigs
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtIVpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    <<
        % \new Dynamics \mvtVbreaks

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Violino"}
                \set GrandStaff.shortInstrumentName = \markup{"Vln."}

                \new Staff = staffA <<
                    \set Staff.instrumentName = \markup{"I"}
                    \set Staff.shortInstrumentName = \markup{"I"}

                    \mvtVvlnI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = \markup{"II"}
                    \set Staff.shortInstrumentName = \markup{"II"}

                    \mvtVvlnII
                >>
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = \markup{"Viola"}
                \set Staff.shortInstrumentName = \markup{"Vla."}

                \mvtVvla
            >>
        >>

        \new Staff = staffD <<
            \set Staff.instrumentName = \markup\bold{"Basso"}
            \set Staff.shortInstrumentName = \markup\bold{"B."}

            \new Voice = mvtVbass { \mvtVbass }
            \new Lyrics \lyricsto mvtVbass \mvtVbassLyrics
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                { \dynamicUp \mvtVbc }
                \mvtVfigs
            >>
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}
% %}


% %{
\score {
    <<
    % \new Dynamics { \mvtVIbreaks }

        \new StaffGroup <<
            \new Staff = staffA <<
                \set Staff.instrumentName = \markup{"Oboe"}
                \set Staff.shortInstrumentName = \markup{"Ob."}

                \mvtVIob
            >>
        >>

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Violino"}
                \set GrandStaff.shortInstrumentName = \markup{"Vln."}

                \new Staff = staffB <<
                    \set Staff.instrumentName = \markup{"I"}
                    \set Staff.shortInstrumentName = \markup{"I"}

                    \mvtVIvlnI
                >>
                \new Staff = staffC <<
                    \set Staff.instrumentName = \markup{"II"}
                    \set Staff.shortInstrumentName = \markup{"II"}

                    \mvtVIvlnII
                >>
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup{"Viola"}
                \set Staff.shortInstrumentName = \markup{"Vla."}

                \mvtVIvla
            >>
        >>

        \new Staff = staffE <<
            \set Staff.instrumentName = \markup\bold{"Basso"}
            \set Staff.shortInstrumentName = \markup\bold{"B."}

            \new Voice = mvtVIbass \mvtVIbass
            \new Lyrics \lyricsto mvtVIbass \mvtVIlyrics
        >>

        \new StaffGroup <<
            \new Staff = staffF <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                { \dynamicUp \mvtVIbc }
                \mvtVIfigs
            >>
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtVIpiece
        % breakbefore = ##t
    }
}
% %}


% %{
\score {
    <<
        \new ChoirStaff <<
            \new Staff << 
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Soprano"}
                                                \line{Fl. in 8va}
                                                \line{Ob.I, Corno, V.I}
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = "mvtVIIsoprano" { \clefSoprano \mvtVIIsoprano }
                \new Lyrics \lyricsto "mvtVIIsoprano" \mvtVIIlyrics
            >>
            \new Staff << 
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Alto"}
                                                \line{Ob.II,V.II}
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"A."}

                \new Voice = "mvtVIIalto" { \clefAlto \mvtVIIalto }
                \new Lyrics \lyricsto "mvtVIIalto" \mvtVIIlyrics
            >>
            \new Staff <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Tenore"}
                                                \line{Vla.}
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"T."}

                \new Voice = "mvtVIItenor" { \clefTenor \mvtVIItenor }
                \new Lyrics \lyricsto "mvtVIItenor" \mvtVIIlyrics
            >>
            \new Staff <<
                \set Staff.instrumentName = \markup\bold{"Basso"}
                \set Staff.shortInstrumentName = \markup\bold{"B."}

                \new Voice = "mvtVIIbass" { \mvtVIIbass }
                \new Lyrics \lyricsto "mvtVIIbass" \mvtVIIlyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                { \dynamicUp \mvtVIIbc }
                \mvtVIIfigs
            >>
        >>
    >>

    \layout {
    }

    \header {
        piece = \mvtVIIpiece
        breakbefore = ##t
    }
}
% %}
