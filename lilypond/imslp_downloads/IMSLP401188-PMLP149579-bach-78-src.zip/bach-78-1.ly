\version "2.18.0"

\include "common.ly"


mvtItimeLine = {
    \time 3/4
    \key bes \major

    s2.*144 |
    \bar "|."
}

mvtIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 7 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 7 { s2.\noBreak }
    \pageBreak

    \repeat unfold 6 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 7 { s2.\noBreak }
    \pageBreak

    \repeat unfold 7 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s2.\noBreak }
    \pageBreak

    \repeat unfold 7 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak }
    \pageBreak

    \repeat unfold 7 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak }
    \pageBreak

    \repeat unfold 6 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 7 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s2.\noBreak }
    \bar "|."
}


mvtIfl = <<
\relative c'' {
    r4 d4. bes'8 | %1
    a4 d,4. d8 | %2
    g4 c,4. c8 | %3
    c8.( bes16) c8.( a16) d8.( c16) | %4
    bes8. g16 d'4.\Pia bes'8 | %5
    a4 d,4. d8 | %6
    g2.~ | %7
    g8. a16 fis4. g8 | %8
    g4 r4 r4 | %9
    R2.*11 | %10
    d'2\f d4 | %21
    a2 bes4 | %22
    c2 bes8 a8 | %23
    bes8 c8 a4. g8 | %24
    g2. | %25
    R2.*7 | %26
    bes2\f bes4 | %33
    a2 g4~ | %34
    g4 fis8( g8) g8\trill( fis16 g16) | %35
    a2. | %36
    r4 d,4.\Pia bes'8 | %37
    a4 d,4. d8 | %38
    g2.~ | %39
    g8. a16 fis4. g8 | %40
    g4 r4 r4 | %41
    R2.*11 | %42
    d'2\f d4 | %53
    a2 bes4 | %54
    c2 bes8 a8 | %55
    bes8 c8 a4. g8 | %56
    g2. | %57
    R2.*7 | %58
    bes2\f bes4 | %65
    a2 g4~ | %66
    g4 fis8( g8) g\trill( fis16 g16) | %67
    a2.~ | %68
    a8 d,8 g8 a8 bes4~ | %69
    bes8 e,8 a8 g8 a4~ | %70
    a8 d,8 g8 f8 g8 e8 | %71
    f8 g8 e4. d8 | %72
    d4 r4 r4 | %73
    R2.*7 | %74
    a'2\f bes4 | %81
    c2 a4 | %82
    bes2. | %83
    a8 g8 g2\trill | %84
    f4 c4.\p a'8 | %85
    g4 c,4. c8 | %86
    f2.~ | %87
    f8. g16 e4. f8 | %88
    f4 r4 r4 | %89
    R2.*5 | %90
    bes2\f c4 | %95
    d2 d4 | %96
    es2. | %97
    d8 c8 c4. bes8 | %98
    bes4 d,4.\p bes8 | %99
    f'4 c4. d8 | %100
    es4 bes4. c8 | %101
    d8. es16 c4. bes8 | %102
    \phrasingSlurDotted bes8\( f'8\f( bes8)\) bes8 bes8 bes8 | %103
    a8\( c,8( f8)\) f8 f8 f8 | %104
    es8\( g8( c8)\) c8 c8 c8 | %105
    bes\( d,8( g8)\) g8 g8 g | %106
    g8( fis8) r4 r4 | %107
    R2.*10 | %108
    d'2\f d4 | %118
    c2 d4 | %119
    bes8 c8 c4. d8 | %120
    d2. | %121
    r4 a4 a4 | %122
    a4( gis4) g4 | %123
    g4( fis8) g8 g8.\trill fis32 g32 | %124
    a8\( d,8( c'8)\) c8 c8 c8 | %125
    c8( b8 f8) f8 f8 f8 | %126
    f8( e8 bes'8) bes8 bes8 bes8 | %127
    bes8( a8 es8) es8 es8 es8 | %128
    es8( d8) r4 r4 | %129
    R2.*7 | %130
    d'2\f d4 | %137
    c2 bes8 a8 | %138
    bes8 c8 a4. g8 | %139
    g4 d4.\p bes'8 | %140
    a4 d,4. d8 | %141
    g2.~ | %142
    g8. a16 fis4. g8 | %143
    g2. | %144
}
\mvtItimeLine
>>


mvtIobI = <<
\relative c'' {
    r4 d4. bes'8 | %1
    a4 d,4. d8 | %2
    g4 c,4. c8 | %3
    c8.( bes16) c8.( a16) d8.( c16) | %4
    bes8. g16 d'4.\Pia bes'8 | %5
    a4 d,4. d8 | %6
    g2.~ | %7
    g8. a16 fis4. g8 | %8
    g4 g4\For g4 | %9
    fis4 f4 f4 | %10
    e4 es4 es4 | %11
    d2.~ | %12
    d4 bes4 es4~ | %13
    es4 a,4 d4~ | %14
    d4 g,4 c4~ | %15
    c8. bes16 a4.\trill g8 | %16
    g4 r4 r4 | %17
    r4 d'4\Pia bes'4~ | %18
    bes4 a8 g8 a4 | %19
    r4 a4 d4~ | %20
    d8 c8 bes8 a8 bes8 g8 | %21
    a4 d,4.\For d8 | %22
    g4 c,4. c8 | %23
    d8( es8) d8( c8) bes8( a8) | %24
    bes4 r4 r4 | %25
    c2.\Pia~ | %26
    c2. | %27
    bes8 c d es f4~ | %28
    f4 es8 d8 es8 f8 | %29
    d8 c8 d8 es8 d8 es8 | %30
    c8 b8 c8 d8 c8 d8 | %31
    b8 g8 c8 bes8 c8 a8 | %32
    bes8 g8\For es'8 d8 es8 f8 | %33
    es8 f8 d8 c8 d8 es8 | %34
    d8 es8 c8 bes8 c8 d8 | %35
    c8 d8 c8 es8 d8 c8 | %36
    bes8. g16 d'4.\Pia bes'8 | %37
    a4 d,4. d8 | %38
    g2.~ | %39
    g8. a16 fis4. g8 | %40
    g4 g,8\For a8 bes8 c8 | %41
    d4 d,8 e8 f8 g8 | %42
    a8 g8 a8 bes8 a8 g8 | %43
    fis8 e8 fis8 d8 e8 fis8 | %44
    g8 bes8 es8 d8 c8 bes8 | %45
    a8 bes16 c16 d8 c8 bes8 a8 | %46
    g8 a16 bes16 c8 bes8 a8 g8 | %47
    fis8 g8 d8 c8 d4 | %48
    g4 d'4-. g4-. | %49
    r4 f4-. bes4-. | %50
    r4 es,4-. c'4-. | %51
    r4 d,4-. d'4-. | %52
    r4 d,4.\f bes'8 | %53
    a4 d,4. d8 | %54
    g4 c,4. c8 | %55
    d8( es8) d8( c8) bes8( a8) | %56
    bes4 r4 r4 | %57
    R2.*7 | %58
    r4 bes'4.\f es,8 | %65
    es4 d4. d8 | %66
    g4 c,4. c8 | %67
    c8.( bes16) c8.( es16) d8.( c16) | %68
    bes8 d8 g8 a8 bes4~ | %69
    bes8 e,8 a8 g8 a4~ | %70
    a8 d,8 g8 f8 g8 e8 | %71
    f8 g e4. d8 | %72
    d16 a16\Pia b16 cis16 d8 a'8~ a8 g16 f16 | %73
    e16 d16 cis16 b16 a4 r4 | %74
    r16 b16 cis16 d16 e8 bes'8~ bes16 a16 g16 f16 | %75
    e16 d cis16 b a4 r4 | %76
    r4 f'4.\For bes8 | %77
    e,4 e4. a8 | %78
    d,4 d4. bes'8 | %79
    e,8 d8 cis8 d8 e8 cis8 | %80
    a'8 f16 g16 a8 bes16 c16 d4 | %81
    r8 e,16 f16 g8 a16 bes16 c4 | %82
    r8 d,16 e16 f8 g16 a16 bes4 | %83
    r8 c,16 d16 e16 f16 g16 a16 bes16 a16 bes16 g16 | %84
    a4 c,4.\Pia a'8 | %85
    g4 c,4. c8 | %86
    f2.~ | %87
    f8. g16 e4. f8 | %88
    f4 c4-.\For g'4-. | %89
    r4 e4-. a,4-. | %90
    r4 d4-. a'4-. | %91
    r4 f4-. bes,4-. | %92
    r4 a4-. es'4-. | %93
    r4 d4-. a4-. | %94
    r4 d4 r8 c16 bes16 | %95
    f'4 f4 r8 f8 | %96
    bes4 es,4 r8 c8 | %97
    d8.( es16) c8.( d16) es8.( f16) | %98
    d4 d4.\Pia bes8 | %99
    f'4 c4. d8 | %100
    es4 bes4. c8 | %101
    d8. es16 c4. bes8 | %102
    bes8 f'8\For( bes8) bes8 bes8 bes8 | %103
    a8 r8 r4 r4 | %104
    r8 g8( c8) c8 c8 c8 | %105
    bes8 r8 r4 r4 | %106
    r8 fis16\Pia g16 a8 g16 a16 bes8 a16 bes16 | %107
    e,16 d16 e16 fis16 g8 fis16 g16 a8 g16 a16 | %108
    d,4 r4 r4 | %109
    R2. | %110
    r8 es,16 f16 g8 f16 g16 as8 g16 as | %111
    d,16 c16 d16 es16 f8 es16 f16 g8 f16 g16 | %112
    c,4 r4 r4 | %113
    R2. | %114
    r4 bes'4\For bes4 | %115
    bes4 a4 as4 | %116
    as4 g8 a8 a8.\trill g32 a32 | %117
    bes4 d4.\For bes'8 | %118
    a4 c,4. a8 | %119
    bes8.( d16) g8.( fis16) g8.( a16) | %120
    fis4 r4 r4 | %121
    r4 a4 a4 | %122
    a4( gis4) g4 | %123
    g4( fis8) g8 g8. fis32 g32 | %124
    a4 r4 r4 | %125
    r8 g,8( f'8) f8 f8 f8 | %126
    f8( e8) r4 r4 | %127
    r8 f,8( es'8) es8 es8 es8 | %128
    es8( d8) r4 r4 | %129
    R2. | %130
    r4 bes4.\Pia g'8 | %131
    f4 bes,4. as'8 | %132
    g4 r4 r4 | %133
    R2. | %134
    r4 c,8( bes8) a8( c8) | %135
    bes4 d4.\For bes'8 | %136
    a4 d,4. d8 | %137
    g4 c,4. c8 | %138
    \slurDashed d8( es8) d8( c8) bes8( a8) \slurSolid | %139
    bes8. g16 d'4.\Pia bes'8 | %140
    a4 d,4. d8 | %141
    g2.~ | %142
    g8. a16 fis4. g8 | %143
    g2. | %144
}
\mvtItimeLine
>>


mvtIobII = <<
\relative c'' {
    r4 bes4. g8 | %1
    d'4 a4. bes8 | %2
    c4 g4. a8 | %3
    fis4 fis4.\trill fis8 | %4
    g4 bes4.\Pia g8 | %5
    d'4 a4. b8 | %6
    c4 g4. a8 | %7
    bes8. c16 a4. bes8 | %8
    bes4 r4 r4 | %9
    r4 a4\f d4~ | %10
    d4 c8 bes8 c4~ | %11
    c4 a8.( bes16) c8.( a16) | %12
    bes4 g4 g4 | %13
    fis4 f4 f4 | %14
    e4 es4 es4 | %15
    d8. g16 fis4. g8 | %16
    g4-. g4\Pia es'4~ | %17
    es4 d8 c8 d4 | %18
    r4 c4 a'4~ | %19
    a8 g8 fis8 \once \set suggestAccidentals = ##t e8 d4 | %20
    r4 g,4.\For bes8 | %21
    d4 a4. bes8 | %22
    c4 g4. a8 | %23
    bes8 g8 fis4.\trill g8 | %24
    g4 bes2\Pia~ | %25
    bes2. | %26
    as8( g8) fis8( \once \set suggestAccidentals = ##t e8) d4~ | %27
    d4 g4 d'4~ | %28
    d4 g,4 es4 | %29
    f4 d4 g4 | %30
    c,4 f4 as4 | %31
    d,4 g4. fis8 | %32
    g8 bes8\For es8 d8 es8 f8 | %33
    es8 f8 d8 c8 d8 es8 | %34
    d8 es8 c8 bes8 c8 d8 | %35
    c8 d8 c8 es8 d8 c8 | %36
    bes4 bes4.\Pia g8 | %37
    d'4 a4. \once \set suggestAccidentals = ##t b8 | %38
    c4 g4. a8 | %39
    bes8. c16 a4. g8 | %40
    g4 g8\For a8 bes8 c8 | %41
    d4 d,8 e8 f8 g8 | %42
    a8 g8 a8 bes8 a8 g8 | %43
    fis8 e8 fis8 d8 e8 fis8 | %44
    g8 bes8 es8 d8 c8 bes8 | %45
    a8 bes16 c16 d8 c8 bes8 a8 | %46
    g8 a16 bes16 c8 bes8 a8 g8 | %47
    fis8 g8 d8 c8 d4 | %48
    g4 bes4-. es4-. | %49
    r4 d4-. g4-. | %50
    r4 c,4-. a'4-. | %51
    r4 d,4-. a'4-. | %52
    r4 bes,4.\For d8 | %53
    d4 a4. bes8 | %54
    c4 g4. a8 | %55
    bes8 g8 fis4. g8 | %56
    g4 r4 r4 | %57
    R2.*7 | %58
    r4 bes4.\For bes8 | %65
    c4 a4. g8 | %66
    g4 a4. g8 | %67
    fis4 fis4. fis8 | %68
    g4 r8 d'8 g8 f8 | %69
    e4 r8 a,8 d8 c8 | %70
    d4 r8 bes'8 e,4~ | %71
    e8 d8 cis4. d8 | %72
    d4 r4 r4 | %73
    r16 e,16\Pia f16 g16 a8 e'8 d16 c16 \once \set suggestAccidentals = ##t b!16 a16 | %74
    g16 f16 e16 d16 cis'4 r4 | %75
    r16 bes16 cis16 d16 e8 a8~ a16 g16 f16 e16 | %76
    d4 f4.\For bes8 | %77
    e,4 e4. a8 | %78
    d,4 d4. bes'8 | %79
    e,8 d8 cis8 d8 e8 cis8 | %80
    a'8 f16 g16 a8 bes16 c16 d4 | %81
    r8 e,16 f16 g8 a16 bes16 c4 | %82
    r8 d,16 e16 f8 g16 a16 bes4 | %83
    r8 c,16 d16 e16 f16 g16 a16 bes16 a16 bes16 g16 | %84
    a4 a,4.\Pia f8 | %85
    c'4 g4. a8 | %86
    bes4 f4. g8 | %87
    a8. bes16 g4.\trill a8 | %88
    a4 a4-.\For d,4-. | %89
    r4 g4-. d'4-. | %90
    r4 bes4-. es,4-. | %91
    r4 a4-. d,4-. | %92
    r4 fis4-. c'4-. | %93
    r4 a4-. d,4-. | %94
    r4 d'4 r8 c16 bes16 | %95
    f'4 f4 r8 f8 | %96
    bes4 es,4 r8 c8 | %97
    d8.( es16) c8.( d16) es8.( f16) | %98
    d4 f,4.\Pia d'8 | %99
    c4 f4. f,8 | %100
    bes2.~ | %101
    bes8. c16 a4.\trill bes8 | %102
    bes8 d16\For es16 f8 es16 f16 g8 f16 g16 | %103
    c,8 r8 r4 r4 | %104
    r8 es16 f16 g8 fis16 g16 a8 g16 a16 | %105
    d,8 r8 r4 r4 | %106
    R2.*2 | %107
    r8 bes16\Pia c16 d8 c16 d16 es8 d16 es16 | %109
    a,16 g16 a16 b16 c8 b16 c16 d8 c16 d16 | %110
    g,8 c,16 d16 es8 d16 es16 f8 es16 f16 | %111
    g8 f16 es16 d8 c16 d16 e8 d16 e16 | %112
    f4 f4\For f4 | %113
    f4 e4 es4 | %114
    es4 d8. e16 e8.\trill d32 e32 | %115
    f4 c8 d8 d8.\trill c32 d32 | %116
    es8 d8 es8 f8 es8 f8 | %117
    d4 bes'4.\f d8 | %118
    es4 a,4. d8 | %119
    g,4. bes8 a8. g16 | %120
    d'4 d4 d4 | %121
    d4( cis4) c4 | %122
    c4( b8) cis8 cis8.\trill( b32 cis32) | %123
    d4~ d16 e16 d16 e16 e8.\trill d32 e32 | %124
    fis4 r4 r4 | %125
    r8 b,16( c16 d8) d8 d8 d8 | %126
    d8( c8) r4 r4 | %127
    r8 a16( bes16 c8) c8 c8 c8 | %128
    c8( bes8) r4 r4 | %129
    R2. | %130
    r4 g4.\Pia es8 | %131
    c'4 d,4. bes'8 | %132
    bes4 r4 r4 | %133
    R2. | %134
    r8 es,16 f16 g8 fis16 g16 a8 g16 a16 | %135
    d,4 bes'4.\For d8 | %136
    d4 a4. bes8 | %137
    c4 g4. a8 | %138
    bes8 c8 fis,4. fis8 | %139
    g4 bes4.\Pia g8 | %140
    d'4 a4. b8 | %141
    c4 g4. a8 | %142
    bes?8. c16 a4. g8 | %143
    g2. | %144
}
\mvtItimeLine
>>


mvtIvlnI = <<
\relative c'' {
    r4 d4. bes'8 | %1
    a4 d,4. d8 | %2
    g4 c,4. c8 | %3
    c8.( bes16) c8.( a16) d8.( c16) | %4
    bes8. g16 d'4.\Pia bes'8 | %5
    a4 d,4. d8 | %6
    g2.~ | %7
    g8. a16 fis4. g8 | %8
    g4 g,,8\For a8 bes8 c8 | %9
    d8 cis8 d8 e8 f8 g8 | %10
    a8 g8 a8 bes8 a8 g8 | %11
    fis8 e8 fis8 d8 e8 fis8 | %12
    g8 g,8 a8 bes8 c8 bes8 | %13
    a8 bes16 c16 d8 c8 bes8 a8 | %14
    g8 a16 bes16 c8 bes8 a8 g8 | %15
    fis'8 g8 d8 c8 d8 c'8 | %16
    bes4-. d4-. g4-. | %17
    r4 f4-. bes4-. | %18
    r4 es,4-. c'4-. | %19
    r4 d,4-. d'4-. | %20
    r4 d,4. bes'8 | %21
    a4 d,4. d8 | %22
    g4 c,4. c8 | %23
    d8( es8) d8( c8) bes8( a8) | %24
    bes4 r4 r4 | %25
    R2.*7 | %26
    r4 bes'4.\f es,8 | %33
    es4 d4. d8 | %34
    g4 c,4. c8 | %35
    \slurDashed c8.( bes16) c8.( es16) d8.( c16) \slurSolid | %36
    bes8. g16 d'4.\Pia bes'8 | %37
    a4 d,4. d8 | %38
    g2.~ | %39
    g8. a16 fis4. g8 | %40
    g4 r4 r4 | %41
    r4 a4\For d4~ | %42
    d4 c8 bes8 c4~ | %43
    c4 a8.( bes16) c8.( a16) | %44
    bes4 g4 g4 | %45
    fis4 f4 f4 | %46
    e4 es4 es4 | %47
    d8. g16 fis4. g8 | %48
    g4 r4 r4 | %49
    r4 d4\Pia bes'4~ | %50
    bes4 a8 g8 a4 | %51
    r4 a4 d4~ | %52
    d8 c8 bes8 a8 bes8 g8 | %53
    a4 d,4.\For d8 | %54
    g4 c,4. c8 | %55
    d8( es8) d8( c8) bes8( a8) | %56
    bes4 r4 r4 | %57
    c2.\Pia~ | %58
    c2. | %59
    bes8 c8 d8 es8 f4~ | %60
    f4 es8 d8 es8 f8 | %61
    d8 c8 d8 es8 d8 es8 | %62
    c8 b8 c8 d8 c8 d8 | %63
    b8 g8 c8 bes8 c8 a8 | %64
    bes8 g8\For es'8 d8 es8 f8 | %65
    es8 f8 d8 c8 d8 es8 | %66
    d8 es8 c8 bes8 c8 d8 | %67
    c8 d8 c8 es8 d8 c8 | %68
    bes8 g8 d'4 d4 | %69
    cis4 c4 c4 | %70
    b4 bes4 bes4 | %71
    a8 d8 cis4. d8 | %72
    d4 d,4\Pia d4 | %73
    cis4 c4 c4 | %74
    b4 bes4 bes4 | %75
    a4 a'4 a4 | %76
    d,8 d16 e16 f8 g16 a16 bes4~ | %77
    bes8 e,16 d16 e8 f16 g16 a4~ | %78
    a8 d,16 cis16 d8 e16 f16 g4~ | %79
    g8 cis,16 d16 e16 f16 g16 a16 bes8 a16 g | %80
    f4 d4 r8 d'8\For | %81
    g,4 g4 r8 c8 | %82
    f,4 f4 r8 bes8 | %83
    a8 g8 g4. f8 | %84
    f4 c'4.\Pia a'8 | %85
    g4 c,4. c8 | %86
    f2.~ | %87
    f8. g16 e4. f8 | %88
    f4 r4 d4\Pia | %89
    d8( g,8) r4 a4 | %90
    a8( d,8) r4 es'4 | %91
    es8( a,8) a4 r8 bes8 | %92
    bes8( a8) fis4\trill r8 g8 | %93
    a8( es8) d4 r8 a'8 | %94
    bes8 bes16\For c16 d8 d16 es16 f4 | %95
    r8 d16 es16 f8 g16 as16 bes4 | %96
    r8 g,16 a?16 bes8 c16 d16 es4 | %97
    r8 f,16 g16 a16 bes16 c16 d16 es16 d16 es16 c16 | %98
    d4 d4.\Pia bes8 | %99
    f'4 c4. d8 | %100
    es4 bes4. c8 | %101
    d8. es16 c4. bes8 | %102
    bes8 bes,16\For c16 d8 c16 d16 e8 d16 e16 | %103
    f8 c'8( f8) f8 f8 f8 | %104
    es?8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | %105
    g8 d'8( g8) g8 g8 g8 | %106
    g8( fis8) r4 r4 | %107
    R2. | %108
    r8 g,,16\Pia a16 bes8 a16 bes16 c8 bes16 c16 | %109
    d8 c16 \once \set suggestAccidentals = ##t b16 a8 g16 a16 b!8 a16 b16 | %110
    c4 g'4\For r8 es'8 | %111
    d4 << as \\ { \teeny g4_"?" } >> r8 g8 | %112
    c4~ c8 b16 c16 d8 c16 d16 | %113
    g,16 f16 g16 a16 bes8 a16 bes16 c8 bes16 c16 | %114
    f,4 bes4 bes4 | %115
    bes4 a4 as4 | %116
    as4 g8 a8 a8. g32 a32 | %117
    bes4 d4.\f bes'8 | %118
    a4 c,4. a8 | %119
    bes8.( d16) g8.( fis16) g8.( a16) | %120
    fis8 d,16 e16 fis8 e16 fis16 g8 fis16 g16 | %121
    a8 g16 \once \set suggestAccidentals = ##t fis16 e8 d16 e16 fis!8 e16 fis16 | %122
    g8 f16 e16 d8 \once \set suggestAccidentals = ##t cis16 d16 e8 d16 e16 | %123
    a,8 d'8 c8 d16 c16 bes8 c16 bes16 | %124
    a8 d,8( c'8) c8 c8 c8 | %125
    c8( b8) r4 r4 | %126
    r8 c,8( bes'8) bes8 bes8 bes8 | %127
    bes8( a8) r4 r4 | %128
    r4 d4.\Pia bes'8 | %129
    a4 d,4. c'8 | %130
    bes4 r4 r4 | %131
    R2. | %132
    r4 g,4.\Pia es'8 | %133
    d4 g,4. f'8 | %134
    es4 r4 r4 | %135
    r4 d4.\For bes'8 | %136
    a4 d,4. d8 | %137
    g4 c,4. c8 | %138
    \slurDashed d8( es8) d8( c8) bes8( a8) \slurSolid | %139
    bes8. g16 d'4.\Pia bes'8 | %140
    a4 d,4. d8 | %141
    g2.~ | %142
    g8. a16 fis4. g8 | %143
    g2. | %144
}
\mvtItimeLine
>>


mvtIvlnII = <<
\relative c'' {
    r4 bes4. g8 | %1
    d'4 a4. bes8 | %2
    c4 g4. a8 | %3
    fis4 fis4.\trill fis8 | %4
    g4 bes4.\Pia g8 | %5
    d'4 a4. b8 | %6
    c4 g4. a8 | %7
    bes8. c16 a4. g8 | %8
    g4 g,8\For a8 bes8 c8 | %9
    d8 cis8 d8 e8 f8 g8 | %10
    a8 g8 a8 bes8 a8 g8 | %11
    fis8 e8 fis8 d8 e8 fis8 | %12
    g8 g,8 a8 bes8 c8 bes8 | %13
    a8 bes16 c16 d8 c8 bes8 a8 | %14
    g8 a16 bes16 c8 bes8 a8 g8 | %15
    fis'8 g8 d8 c8 d8 fis8 | %16
    g4-. bes4-. es4-. | %17
    r4 d4-. g4-. | %18
    r4 c,4-. a'4-. | %19
    r4 d,4-. a'4-. | %20
    r4 bes,4. d8 | %21
    d4 a4. bes8 | %22
    c4 g4. a8 | %23
    bes8 g8 fis4. g8 | %24
    g4 r4 r4 | %25
    R2.*7 | %26
    r4 bes4.\f bes8 | %33
    c4 a4. g8 | %34
    g4 a4. g8 | %35
    fis4 fis4.\trill fis8 | %36
    g4 bes4.\Pia g8 | %37
    d'4 a4. b8 | %38
    c4 g4. a8 | %39
    bes8. c16 a4. d8 | %40
    d4 g4\For g4 | %41
    fis4 f4 f4 | %42
    e4 es4 es4 | %43
    d2.~ | %44
    d4 bes4 es4~ | %45
    es4 a,4 d4~ | %46
    d4 g,4 c4~ | %47
    c8. bes16 a4. g8 | %48
    g4 g4\Pia es'4~ | %49
    es4 d8 c d4 | %50
    r4 c4 a'4~ | %51
    a8 g8 fis8 e8 d4 | %52
    r4 g,4.\For bes8 | %53
    d4 a4. bes8 | %54
    c4 g4. a8 | %55
    bes8 g8 fis4. g8 | %56
    g4 bes2\Pia~ | %57
    bes2. | %58
    as8( g8) fis8 e8 d4~ | %59
    d4 g4 d'4~ | %60
    d4 g,4 es4 | %61
    f4 d4 g4 | %62
    c,4 f4 as4 | %63
    d,4 g4. fis8 | %64
    g4 bes4.\For bes8 | %65
    c4 a4. g8 | %66
    g4 a4. g8 | %67
    fis4 fis4. fis8 | %68
    g2.~ | %69
    g4 a2 | %70
    fis4 g2 | %71
    f8 d8 e4.\trill f8 | %72
    f4 d4\Pia d4 | %73
    cis4 c4 c4 | %74
    b4 bes4 bes4 | %75
    a4 a'4 a4 | %76
    d,8 d16 e16 f8 g16 a16 bes4~ | %77
    bes8 e,16 d16 e8 f16 g16 a4~ | %78
    a8 d,16 cis16 d8 e16 f16 g4~ | %79
    g8 cis,16 d16 e16 f16 g16 a16 bes8 a16 g16 | %80
    f4 f4 r8 d8\For | %81
    c4 c4 r8 c8 | %82
    bes4 bes4 r8 e8 | %83
    f8 g8 e4. f8 | %84
    f4 a4.\Pia f8 | %85
    c'4 g4. a8 | %86
    bes4 f4. g8 | %87
    a8. bes16 g4. a8 | %88
    a4 r4 f4\Pia | %89
    f8( e8) r4 c4 | %90
    c8( bes8) r4 g'4 | %91
    g4-. f4-. r8 d8 | %92
    d8( c8) es4 r8 es8 | %93
    es8( a,8) a4 r8 d8 | %94
    g8 bes16\For c16 d8 d16 es16 f4 | %95
    r8 d16 es16 f8 g16 as16 bes4 | %96
    r8 g,16 a?16 bes8 c16 d16 es4 | %97
    r8 f,16 g16 a16 bes16 c16 d16 es16 d16 es16 c16 | %98
    d4 f,4.\Pia d'8 | %99
    c4 f4. f,8 | %100
    bes2.~ | %101
    bes8. c16 a4.\trill f8 | %102
    f8 bes,16\For c16 d8 c16 d16 e8 d16 e16 | %103
    f8 a16 bes16 c8 bes16 c d8 c16 d | %104
    g,8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | %105
    g8 bes16 c16 d8 c16 d16 es8 d16 es16 | %106
    a,4 r4 r4 | %107
    R2.*3 | %108
    r4 es4\For r8 c'8 | %111
    g4 d4 r8 e8 | %112
    f4 f4 f4 | %113
    f4 e4 es4 | %114
    es8 bes16 c16 d8 c16 d e8 d16 e16 | %115
    f8 es16 d16 c8 bes16 c16 d8 c16 d16 | %116
    es8 d8 es8 f8 es8 f8 | %117
    d4 bes'4.\f d8 | %118
    es4 a,4. d8 | %119
    g,4. bes8 a8. g16 | %120
    d'8 fis,16 g16 a8 g16 a16 bes8 a16 bes16 | %121
    e,16 d16 e16 fis16 g8 fis16 g16 a8 g16 a16 | %122
    d,16 cis16 d16 e16 f8 e16 f16 g8 f16 g16 | %123
    a8 bes8 a8 bes16 a16 g8 a16 g16 | %124
    fis16 e16 fis16 g16 a8 a8 a8 a8 | %125
    a8( g8) r4 r4 | %126
    r8 e16( f16 g8) g8 g8 g8 | %127
    g8( f8) r4 r4 | %128
    r4 bes4.\Pia g8 | %129
    es'4 fis,4. d'8 | %130
    d4 r4 r4 | %131
    R2. | %132
    r4 es,4.\Pia c8 | %133
    as'4 b,4. g'8 | %134
    g4 r4 r4 | %135
    r4 bes4.\For d8 | %136
    d4 a4. bes8 | %137
    c4 g4. a8 | %138
    bes8 c8 fis,4. fis8 | %139
    g4 bes4.\Pia g8 | %140
    d'4 a4. b8 | %141
    c4 g4. a8 | %142
    bes?8. c16 a4. b8 | %143
    b2. | %144
}
\mvtItimeLine
>>


mvtIvla = <<
\relative c'' {
    \clef C
    r4 g4. d8 | %1
    d4 d4. a'8 | %2
    g4 g4. g,8 | %3
    a4 d4. d8 | %4
    d4 g4.\Pia d8 | %5
    d4 d4. as'8 | %6
    g4 c,8.( a?16) bes8.( c16) | %7
    d8.( c16) d8.( es16) d8.( c16) | %8
    bes4 g8\For a8 bes8 c8 | %9
    d8 cis8 d8 e8 f8 g8 | %10
    a8 g8 a8 bes8 a8 g8 | %11
    fis8 e8 fis8 d8 e8 fis8 | %12
    g8 g,8 a8 bes8 c8 bes8 | %13
    a8 bes16 c16 d8 c8 bes8 a8 | %14
    g8 a16 bes16 c8 bes8 a8 g8 | %15
    fis8 g8 d'8 c8 d8 d,8 | %16
    g4-. g'4-. g,4-. | %17
    r4 a'4-. d,4-. | %18
    r4 c'4-. c,4-. | %19
    r4 a'4-. fis4-. | %20
    r4 g4. g8 | %21
    d4 d4. g8 | %22
    g4 es4. es8 | %23
    bes8 a16 bes16 c8 es8 d8 c8 | %24
    bes4 r4 r4 | %25
    R2.*7 | %26
    r4 g'4.\f g8 | %33
    a4 f4. d8 | %34
    e4 fis4.\trill g8 | %35
    a4 d,4. d8 | %36
    d4 g4.\Pia d8 | %37
    d4 d4. as'8 | %38
    g4 c,8.( a?16) bes8.( c16) | %39
    d8.( c16) d8.( es16) d8.( c16) | %40
    bes4 r4 r4 | %41
    R2.*7 | %42
    r4 g'4-.\For g,4-. | %49
    r4 a'4-. d,4-. | %50
    r4 c'4-. c,4-. | %51
    r4 a'4-. fis4-. | %52
    r4 g4. g8 | %53
    d4 d4. g8 | %54
    g4 es4. es8 | %55
    bes8 a16 bes16 c8 es8 d8 c8 | %56
    bes4 r4 r4 | %57
    R2.*7 | %58
    r4 g'4.\For g8 | %65
    a4 f4. d8 | %66
    e4 fis4.\trill g8 | %67
    a4 d,4. d8 | %68
    d2. | %69
    e4 fis2\trill | %70
    d2 e4 | %71
    a,4 a4 a4 | %72
    a4 d4\Pia d4 | %73
    cis4 c4 c4 | %74
    b4 bes4 bes4 | %75
    a4 a'4 a4 | %76
    d,8 a16 g16 a8 bes16 c16 d8 e16 f16 | %77
    g4~ g8 a,16 bes16 c8 d16 e | %78
    f4~ f8 g,16 a16 bes8 c16 d | %79
    cis16 d e f g4. f16 e16 | %80
    d4 a4 r8 g8\For | %81
    g4 g4 r8 f8 | %82
    f4 f4 r8 bes8 | %83
    c4 c4 c4 | %84
    c4 f4.\Pia c8 | %85
    c4 c4. f8 | %86
    f4 bes,4. bes8 | %87
    c8.( bes16) c8.( d16) c8.( bes16) | %88
    a4 r4 g4-.\Pia | %89
    g4-. r4 d4-. | %90
    d4-. r4 a'4-. | %91
    a4-. d4-. r8 g,8 | %92
    e4-. c'4-. r8 c8 | %93
    \once \slurDashed c8( es?8) fis,4 r8 d'8 | %94
    d4 r8 f?16\For g f8 es8 | %95
    d8 bes8 r8 bes16 c16 d8 es16 f16 | %96
    g4 r8 es16 f16 ges8 es8 | %97
    f4 r8 es16 d16 c8 f8 | %98
    f4 bes,4.\Pia f8 | %99
    f4 f4. bes8 | %100
    bes4 es4. es8 | %101
    f8.( es16) f8.( g16) f8.( es16) | %102
    d8 bes16\For c16 d8 c16 d16 e8 d16 e16 | %103
    f8 f8 f8 c8 g'8 g8 | %104
    g8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | %105
    g8 g8 g8 d8 a'8 a8 | %106
    a4 r4 r4 | %107
    R2.*3 | %108
    r4 c,4\For r8 as'8 | %111
    d,4 b4 r8 c8 | %112
    c4 es4 d4 | %113
    c4 bes4 f'4 | %114
    f4. e16 f16 g8 f16 g16 | %115
    c,16 bes16 c16 d16 es8 f16 es16 d8 es16 f16 | %116
    bes,4 g'4 fis4 | %117
    g4 g4.\f g8 | %118
    c,4 es4. a,8 | %119
    d4 e4 c4 | %120
    a'4 c4 bes4 | %121
    g4 bes4 a4 | %122
    g4 f4 e4 | %123
    d4 a4 bes4 | %124
    r8 d16 e16 fis8 fis16 g16 a8 d,8 | %125
    d8 g,16 a16 b8 b16 c d8 g,8 | %126
    g'8 c,16 d16 e8 e16 f16 g8 c,8 | %127
    c8 f,16 g16 a8 a16 bes16 c8 f,8 | %128
    f'8 d16\Pia e16 fis8 g16 a16 bes4 | %129
    r8 fis16 g16 a8 bes16 c16 d8 fis,8 | %130
    g8 bes,16 c16 d8 es16 f16 g4 | %131
    r8 d16 es16 f8 g16 as16 bes8 d,8 | %132
    es8 g,16 as bes8 c16 d es4 | %133
    r8 b16 c16 d8 es16 f16 g8 d8 | %134
    c4 r4 r4 | %135
    r4 g'4.\For d8 | %136
    d4 d4. d8 | %137
    e8 fis8 g4. g8 | %138
    g8 es8 a,4 d4 | %139
    d4 g4.\Pia d8 | %140
    d4 d4. as'8 | %141
    g4 c,8.( a?16) bes8.( c16) | %142
    d8. es16 d4 d4 | %143
    d2. | %144
}
\mvtItimeLine
>>


mvtIsoprano = <<
\relative c'' {
    \autoBeamOff
    R2.*20 | %1
    d2 d4 | %21
    a2 bes4 | %22
    c2( bes8[ a8]) | %23
    bes8[ c8] a4.( g8) | %24
    g2. | %25
    R2.*7 | %26
    bes2 bes4 | %33
    a2 g4~ | %34
    g4 fis8[ g] g8[ fis16 g16] | %35
    a2. | %36
    R2.*16 | %37
    d2 d4 | %53
    a2 bes4 | %54
    c2 bes8[ a] | %55
    bes8[( c8] a4. g8) | %56
    g2. | %57
    R2.*7 | %58
    bes2 bes4 | %65
    a2 g4~ | %66
    g4 fis8[ g8] g8\trill[ fis16 g16] | %67
    a2. | %68
    R2.*12 | %69
    a2 bes4 | %81
    c2 a4 | %82
    bes2. | %83
    a8[ g8] g2 | %84
    f2. | %85
    R2.*9 | %86
    bes2 c4 | %95
    d2 d4 | %96
    es2. | %97
    d8[ c8] c4.( bes8) | %98
    bes2. | %99
    R2.*18 | %100
    d2 d4 | %118
    c2 d4 | %119
    bes8[( c8)] c4.( bes16[ c16]) | %120
    d2. | %121
    R2.*15 | %122
    d2 d4 | %137
    c2 bes8[( a)] | %138
    bes8[( c8)] a4.( g8) | %139
    g2. | %140
    R2.*4 |
}
\mvtItimeLine
>>

mvtIsopranoLyrics = \lyricmode {
    Je -- su, der du mei -- ne See -- le
    hast durch dei -- nen __ bit -- tern Tod
    aus des Teu -- fels fin -- stern Höh -- le
    und der schwe -- ren See -- len -- not
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen
    und mich sol -- ches las -- sen wis -- sen
    durch dein an -- ge -- neh -- mes __ Wort,
    sei doch itzt, o Gott, mein __ Hort!
}


mvtIalto = <<
\relative c'' {
    \autoBeamOff
    R2.*16 | %1
    r4 g4 g4 | %17
    fis4 f2 | %18
    e8([ d8 es8 g8]) f8[ es8] | %19
    d8[ \melisma e8 fis8 g8] a4~ | %20
    a4 g8[ fis8] \melismaEnd g4 | %21
    r4 a4 g4 | %22
    g4. fis8 g4~ | %23
    g8 a8 fis4.( g8) | %24
    g4 d4 d4 | %25
    es4 e2 | %26
    f4 fis2 | %27
    g2.~ | %28
    g4 es4 as4~ | %29
    as4 g8[ f8] g4~ | %30
    g4 f8[ es] f4 | %31
    g4.( fis8[ g8 a8] | %32
    d,4) g4 g4 | %33
    a4 d,2~ | %34
    d4 a'4 g4 | %35
    fis2. | %36
    R2.*12 | %37
    r4 g4 g4 | %49
    fis4 f2 | %50
    e8[ d8 es8 g8] f8[ es8] | %51
    d8[ \melisma e8 fis8 g8] a4~ | %52
    a4 g8[ fis8] \melismaEnd g4 | %53
    r4 a4 g4 | %54
    g4. fis8 g4~ | %55
    g8 a fis4.( g8) | %56
    g4 d4 d4 | %57
    es4 e2 | %58
    f4 fis2 | %59
    g2.~ | %60
    g4 es4 as4~ | %61
    as4 g8([ f] g4)~ | %62
    g4 f8([ es8] f4) | %63
    g4.( fis8) g8[ a8] | %64
    d,4 g4 g4 | %65
    a4 d,2~ | %66
    d4 a'4 g4 | %67
    fis2. | %68
    R2.*5 | %69
    r4 e4 f4 | %74
    g8 a8 bes4 g4 | %75
    a2.~ | %76
    a8 d,16 e f8[ \melisma g16 a16] bes4~ | %77
    bes8 \melismaEnd e,16[ d] e8[ \melisma f16 g] a4~ | %78
    a8 \melismaEnd d,16 cis d8[ \melisma \once \set suggestAccidentals = ##t e16 f16] g4~ | %79
    g16[ e16 cis16 d16] e16[ f16 g16 a16 bes8] \melismaEnd a16[ g16] | %80
    f8 f r8 d g16([ f e d16] | %81
    c8) r8 r8 c8 f16[( es16 d16 c16] | %82
    bes4) r8 bes8 f'16([ \once \set suggestAccidentals = ##t eis16 f16 g16] | %83
    a8) f8 e4.( f8) | %84
    f4 r4 r4 | %85
    R2.*3 | %86
    c8 f8 f8 f8 f8 f8 | %89
    f8 e16 f16 g8[ \melisma fis16 g16] a8[ g16 a16] | %90
    d,8[ \once \set suggestAccidentals = ##t e16 fis16 g8] \melismaEnd bes8 a8 c8 | %91
    c8[ a8] d,8 d8 g4~ \melisma | %92
    g8[ fis16 \once \set suggestAccidentals = ##t e fis8] \melismaEnd fis8 g8 g8 | %93
    a2.~ \melisma | %94
    a8 \melismaEnd g16 fis16 g8 g8 a8 a8 | %95
    bes2.~ \melisma | %96
    bes2.~ | %97
    bes8[ c8] a4. bes8 | %98
    \melismaEnd bes2. | %99
    R2.*9 | %100
    r4 g4 g4 | %109
    g4( fis4) f4 | %110
    f4( es8[ f8)] f8.[ es32 f32] | %111
    g4 d4 e4 | %112
    f4( es4) d4 | %113
    g2 f4 | %114
    f4 bes4 bes4 | %115
    bes4( a4) as4 | %116
    as4( g8[ a8)] a8.[ g32 a32] | %117
    bes4 bes4 g4 | %118
    a2 a4 | %119
    g4.( bes8) a8[ g8] | %120
    d'4 r4 r4 | %121
    R2.*9 | %122
    r4 bes8 a8 g8 bes8 | %131
    as4 f2\trill | %132
    g4 es4 a4~ | %133
    a8[ b8] b2 | %134
    c4. bes8 a8 c8 | %135
    bes4 bes8 a8 bes8 g8 | %136
    a4. g8 a8 f8 | %137
    g2.~ | %138
    g8 a8 fis4. g8 | %139
    g2. | %140
    R2.*4 |
}
\mvtItimeLine
>>

mvtIaltoLyrics = \lyricmode {
    Je -- su, der du mei -- ne See -- le,
    Je -- su, der du mei -- ne See -- le
    hast durch dei -- nen bit -- tern Tod, __
    hast durch dei -- nen __ bit -- tern Tod, __
    hast durch dei -- nen __ bit -- tern Tod
    aus des Teu -- fels fin -- stern Höh -- le,
    aus des Teu -- fels fin -- stern Höh -- le
    und der schwe -- ren See -- len -- not, __
    und der schwe -- ren See -- len -- not,
    und der schwe -- ren See -- len -- not
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    her -- aus -- ge -- ris -- sen,
    her -- aus -- ge -- ris -- sen, her -- aus, __ her -- aus, __
    her -- aus -- ge -- ris -- sen
    und mich sol -- ches las -- sen wis -- sen,
    mich sol -- ches las -- sen wis -- sen,
    mich sol -- ches las -- sen wis -- sen,
    mich sol -- ches las -- sen wis -- sen
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    sei doch itzt, o Gott, mein Hort,
    o Gott, __ mein Hort,  o Gott, mein Hort,
    sei doch itzt, o Gott, o Gott, mein Hort, __
    o Gott, mein Hort!
}


mvtItenor = <<
\relative c' {
    \autoBeamOff
    R2.*17 | %1
    r4 d4 d4 | %18
    cis4 c2~ | %19
    c8[ a8] d[ c] bes8[ a8] | %20
    bes8[ a8 bes8 c8] d4 | %21
    r4 d4 d4 | %22
    c4. d8 es4 | %23
    bes4 c8([ es8 d8 c8)] | %24
    bes4 r4 r4 | %25
    r4 g4 g4 | %26
    as4 a2\trill | %27
    bes4 b2\trill | %28
    c4 r4 c4 | %29
    d4( g,4) d'4 | %30
    es4( c4) f4 | %31
    f4( es8[ d8 es8 c8] | %32
    d4) es4 es4 | %33
    es4( a,4) b4~ | %34
    b4 c4 g4 | %35
    d'2. | %36
    R2.*13 | %37
    r4 d4 d4 | %50
    cis4 c2 | %51
    c8([ a8 d8 c8)] bes8([ a8]) | %52
    bes8([ a8 bes8 c8)] d4 | %53
    r4 d4 d4 | %54
    c4. d8 es4 | %55
    bes4 c8([ es8 d8 c8)] | %56
    bes4 r4 r4 | %57
    r4 g4 g4 | %58
    as4 a2\trill | %59
    bes4 b2\trill | %60
    c4 r4 c4 | %61
    d4( g,4) d'4 | %62
    es4( c4) f4 | %63
    f4 \melisma es8([ d8 es8 c8]) | %64
    d4 \melismaEnd es4 es4 | %65
    es4( a,4) b4~ | %66
    b4 c4 g4 | %67
    d'2. | %68
    R2.*4 | %69
    r4 a4 b4 | %73
    cis8 d8 e4 a,4 | %74
    e'8[ \melisma f8] g2~ | %75
    g8 \melismaEnd f8 e8 d8 e8 a,8 | %76
    d8[ \melisma a16 g16] a8[ bes16 c16] d8[ e16 f16] | %77
    g4. \melismaEnd a,16[ bes16] c8[ \melisma d16 e] | %78
    f4. \melismaEnd g,16 a16 bes8[ \melisma c16 d16] | %79
    cis16[ d e f] g4. \melismaEnd f16[ e16] | %80
    d8 a16 a16 d16([ c16 bes16 a16] g8) r8 | %81
    r8 g c16([ bes16 a16 g16] f8) r8 | %82
    r8 f8 bes16[( a16 g16 f16] des'8) r8 | %83
    r8 g,8 c4 c4 | %84
    c8 a8 r4 r4 | %85
    R2.*4 | %86
    g8 c8 c8 c8 c8 c8 | %90
    c8 bes16 c16 d8[ \melisma c16 d] es8[ d16 es16] | %91
    a,8[ bes16 c16 d8] \melismaEnd d8 d8 d8 | %92
    d8[ \melisma c16 bes16] c2~ | %93
    c8[ bes16 a16 d8] \melismaEnd d8 c8 c8 | %94
    bes16([ a16 bes16 a16 g8]) d'8 es8 es8 | %95
    f2 f4 | %96
    r4 bes,8 a8 bes8 c8 | %97
    d8([ c16 bes16 c8]) f,8 f'4 | %98
    f2. | %99
    R2.*7 | %100
    r4 d4 d4 | %107
    d4( cis4) c4 | %108
    c4( bes8[ c8)] c8.\trill[ bes32 c32] | %109
    d4 a4 b4 | %110
    c8[( b8 c8 d8)] b8([ c8)] | %111
    d4( as'4) g4 | %112
    c,4 f4 f4 | %113
    f4( e4) es4 | %114
    es4( d8[ e8]) e8.\trill[ d32 e32] | %115
    f4 c4 d4 | %116
    es8 d8 es8[( f8)] es8([ f8)] | %117
    d4 d4 bes4 | %118
    es2 d4 | %119
    d4( c8[ d8)] es4 | %120
    a,4 r4 r4 | %121
    R2.*7 | %122
    r4 d8 c8 bes8 es8 | %129
    c4 a2\trill | %130
    bes4 g4 c4~ | %131
    c8[ d] d2\trill | %132
    es4 es8 d8 c8 es8 | %133
    d4. c8 d8 g,8 | %134
    g'4 g,4 d'4 | %135
    d4 d8 c8 d8 g8 | %136
    d8 e8 f4. d8 | %137
    g,4. a8 bes8 c8 | %138
    bes8 a8 d4 d4 | %139
    d2. | %140
    R2.*4 |
}
\mvtItimeLine
>>

mvtItenorLyrics = \lyricmode {
    Je -- su, der du __ mei -- ne See -- le,
    Je -- su, der du __ mei -- ne See -- le
    hast durch dei -- nen bit -- tern Tod,
    durch dei -- nen bit -- tern Tod, __
    hast durch dei -- nen __ bit -- tern Tod
    aus des Teu -- fels fin -- stern Höh -- le,
    aus des Teu -- fels fin -- stern Höh -- le
    und der schwe -- ren See -- len -- not,
    der __ schwe -- ren See -- len -- not, __
    und der schwe -- ren See -- len -- not
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    her -- aus -- ge -- ris -- sen, her -- aus, __ her -- aus, __ her -- aus, __
    her -- aus -- ge -- ris -- sen
    und mich sol -- ches las -- sen wis -- sen,
    mich sol -- ches las -- sen wis -- sen,
    und mich sol -- ches las -- sen wis -- sen,
    und mich sol -- ches las -- sen wis -- sen
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    sei doch itzt, o Gott, mein Hort, o Gott, mein Hort,
    sei doch itzt, o Gott, o Gott, mein Hort, Gott, mein Hort,
    sei doch itzt, o Gott, mein Hort,
    o Gott, o Gott, mein Hort, o Gott, mein Hort!
}


mvtIbass = <<
\relative c' {
    \autoBeamOff
    \clef F
    R2.*20 | %1
    r4 g4 g4 | %21
    fis4 f2 | %22
    e4 es2 | %23
    d2. | %24
    g,2 r4 | %25
    R2.*3 | %26
    r4 c4 c4 | %29
    b4 bes2 | %30
    a4 as2 | %31
    g2.~ | %32
    g4 g'4 g4 | %33
    fis4 f2 | %34
    e4 es2 | %35
    d2. | %36
    R2.*16 | %37
    r4 g4 g4 | %53
    fis4 f2 | %54
    e4 es2 | %55
    d2. | %56
    g,2 r4 | %57
    R2.*3 | %58
    r4 c4 c4 | %61
    b4 bes2 | %62
    a4 as2 | %63
    g2.~ | %64
    g4 g'4 g4 | %65
    fis4 f2 | %66
    e4 es2 | %67
    d2. | %68
    R2.*6 | %69
    r4 cis4 d4 | %75
    e8 f8 g4 a4 | %76
    f8 d8 d'4 d4 | %77
    cis4 r8 c,8 c' c | %78
    b8[( a8)] bes8 bes,8 bes'8 bes8 | %79
    a4 a,4 r4 | %80
    r4 f'4 f4 | %81
    e4 es2 | %82
    d4 des2 | %83
    c4.( bes8 c4) | %84
    f4 r4 r4 | %85
    R2.*5 | %86
    d8 g8 g8 g8 g8 g8 | %91
    g8 f16 g16 a8[ \melisma g16 a16] bes8[ a16 bes16] | %92
    e,8[ fis16 g16 a8] \melismaEnd bes8 a g | %93
    fis4~ \melisma fis8[ d16 e] fis8[ e16 fis] | %94
    g8 \melismaEnd a8 bes4 bes4 | %95
    a4 as2 | %96
    g4 ges2 | %97
    f4.( es8 f4) | %98
    bes,2. | %99
    R2.*11 | %100
    r4 c'4 c4 | %111
    c4( b4) bes4 | %112
    bes4( a8[ b8)] b8.\trill[ a32 b32] | %113
    c4 g4 a4 | %114
    bes?4( a4) g4 | %115
    f4 f4 bes4 | %116
    es,8 g8 es4 c4 | %117
    g4 g'4 g4 | %118
    g4( fis4) f4 | %119
    f4( e4) es4 | %120
    d2. | %121
    R2.*11 | %122
    r4 g8 f es g | %133
    f4 d2\trill | %134
    c4 e4 fis4 | %135
    g4 g4 g4 | %136
    fis4 r4 f4 | %137
    e4 r4 es4 | %138
    d8[ c] d2 | %139
    g,2. | %140
    R2.*4 |
}
\mvtItimeLine
>>

mvtIbassLyrics = \lyricmode {
    Je -- su, der du mei -- ne See -- le
    hast durch dei -- nen bit -- tern Tod,
    hast durch dei -- nen bit -- tern Tod
    aus des Teu -- fels fin -- stern Höh -- le
    und der schwe -- ren See -- len -- not, __
    und der schwe -- ren See -- len -- not
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    her -- aus -- ge -- ris -- sen,
    kräf -- tig -- lich her -- aus -- ge -- ris -- sen,
    und mich sol -- ches las -- sen wis -- sen,
    mich sol -- ches las -- sen wis -- sen,
    und mich sol -- ches las -- sen wis -- sen
    durch dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes,
    dein an -- ge -- neh -- mes Wort,
    durch dein an -- ge -- neh -- mes Wort,
    sei doch itzt, o Gott, mein Hort,
    Gott, mein Hort,
    sei doch itzt, o Gott, o Gott, mein Hort!
}


mvtIbc = <<
\relative c {
    \clef F
    g4 g'4 g4 | %1
    fis4 f4 f4 | %2
    e4 es4 es4 | %3
    d8 es8 d8 c8 bes8 a8 | %4
    g4 g'4\Pia g4 | %5
    fis4 f4 f4 | %6
    e4 es4 es4 | %7
    d4 d,4 d4 | %8
    g4 r4 r4 | %9
    R2.*7 | %10
    r8 g16\Pia a16 bes8 a16 bes16 c8 bes16 c16 | %17
    d8 d16 e16 f8 e16 f16 g8 f16 g16 | %18
    a4~ a8 bes16 a16 g8 a16 g16 | %19
    fis4~ fis8 d16 e fis8 e16 fis | %20
    g4 g4\For g4 | %21
    fis4 f4 f4 | %22
    e4 es4 es4 | %23
    d4 d,4 d4 | %24
    g8 d'8\Pia g8 f8 es8 d8 | %25
    c8 g'8 c8 bes8 as8 g8 | %26
    f8 es8 d8 c8 bes8 a8 | %27
    g8 as8 g8 f8 es8 d8 | %28
    <\tag CELLO c \tag ORGAN c'4> c'4 c4 | %29
    b4 bes4 bes4 | %30
    a4 as4 as4 | %31
    g2.~ | %32
    g4 g'4\For g4 | %33
    fis4 f4 f4 | %34
    e4 es4 es4 | %35
    d8 es8 d8 c8 bes8 a8 | %36
    g4 g'4\Pia g4 | %37
    fis4 f4 f4 | %38
    e4 es4 es4 | %39
    d4 d,4 d4 | %40
    g4 r4 r4 | %41
    R2.*7 | %42
    r8 g16\Pia a16 bes8 a16 bes16 c8 bes16 c16 | %49
    d8 d16 e16 f8 e16 f16 g8 f16 g16 | %50
    a4~ a8 bes16 a16 g8 a16 g16 | %51
    fis4~ fis8 d16 e16 fis8 e16 fis16 | %52
    g4 g4\For g4 | %53
    fis4 f4 f4 | %54
    e4 es4 es4 | %55
    d4 d,4 d4 | %56
    g8 d'8\Pia g8 f8 es8 d8 | %57
    c8 g'8 c8 bes8 as8 g8 | %58
    f8 es8 d8 c8 bes8 a?8 | %59
    g8 as8 g8 f8 es8 d8 | %60
    <\tag CELLO c \tag ORGAN c'>4 c'4 c4 | %61
    b4 bes4 bes4 | %62
    a4 as4 as4 | %63
    g2.~ | %64
    g4 g'4\For g4 | %65
    fis4 f4 f4 | %66
    e4 es4 es4 | %67
    d2.~ | %68
    d2.~ | %69
    d2.~ | %70
    d2 cis4 | %71
    d4 a'4 a,4 | %72
    d,8 d'16\Pia e16 f8 e16 f16 g8 f16 g16 | %73
    a8 a,16 b16 c8 b16 c16 d8 c16 d16 | %74
    e4~ e8 f16 e16 d8 e16 d16 | %75
    cis4~ cis8 a16 b16 cis8 b16 cis16 | %76
    d4 d'4 d4 | %77
    cis4 c4 c4 | %78
    b4 bes4 bes4 | %79
    a4 a,4 a4 | %80
    d8 e8 f4\For f4 | %81
    e4 es4 es4 | %82
    d4 des4 des4 | %83
    c4 <\tag CELLO c, \tag ORGAN c'> <\tag CELLO c \tag ORGAN c'> | %84
    <\tag CELLO f \tag ORGAN f'> f'4\Pia f4 | %85
    e4 es4 es4 | %86
    d4 des4 des4 | %87
    c4 <\tag CELLO c, \tag ORGAN c'> <\tag CELLO c \tag ORGAN c'> | %88
    f8 f'16\Pia g16 a8 g16 a16 b8 a16 b16 | %89
    c8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | %90
    g8 g,16 a16 bes8 a16 bes16 c8 bes16 c16 | %91
    d8 d,16 e16 f8 e16 f16 g8 f16 g16 | %92
    a4~ a8 bes16 a16 g8 f16 g16 | %93
    fis4~ fis8 d16 e16 fis8 e16 fis16 | %94
    g4 bes'4\For bes4 | %95
    a4 as4 as4 | %96
    g4 ges4 ges4 | %97
    f4 f,4 f4 | %98
    bes4 bes'4\Pia bes4 | %99
    a4 as4 as4 | %100
    g4 ges4 ges4 | %101
    f4 f,4 f4 | %102
    bes8 r8 r4 r4 | %103
    r8 f'16\For g16 a8 g16 a16 b8 a16 b16 | %104
    c8 r8 r4 r4 | %105
    r8 g16 a16 bes8 a16 bes16 c8 bes16 c16 | %106
    d8 d,16\Pia e16 fis8 e16 fis16 g8 fis16 g16 | %107
    a8 g16 \once \set suggestAccidentals = ##t fis16 e8 d16 e16 fis!8 e16 fis16 | %108
    g4 f4 es4 | %109
    d4 r4 d4 | %110
    c4 c'4 c4 | %111
    c4 b4 bes4 | %112
    bes8 f16 g16 a8 g16 a16 b8 a16 b16 | %113
    c8 bes16 a16 g8 f16 g16 a8 g16 a16 | %114
    bes4. bes16 a16 g8 a16 g16 | %115
    f4~ f16 es16 d16 c16 bes8 d16 bes16 | %116
    es4~ es16 f es d c8 bes16 c | %117
    g4 g'4\For g4 | %118
    g4 fis4 f4 | %119
    f4 e4 es4 | %120
    d2.~ | %121
    d2.~ | %122
    d2.~ | %123
    d2.~ | %124
    d4. d,16 e16 fis8 e16 fis | %125
    g4. g'16 a16 b8 a16 b16 | %126
    c4. c,16 d16 e8 d16 e16 | %127
    f4. f,16 g16 a8 g16 a16 | %128
    bes8 bes16\Pia c16 d8 e16 fis16 g4 | %129
    r8 a,16 bes16 c8 d16 e16 fis4 | %130
    r8 g,16 a16 bes8 c16 d16 es4 | %131
    r8 f,16 g16 as8 bes16 c16 d4 | %132
    r8 es,16 f16 g8 a16 b16 c4 | %133
    r8 d,16 es16 f8 g16 a16 b4 | %134
    r8 c,16 d16 e8 d16 e16 fis8 e16 fis16 | %135
    g4 g'4\For g4 | %136
    fis4 f4 f4 | %137
    e4 es4 es4 | %138
    d4 d,4 d4 | %139
    g4 g'4\Pia g4 | %140
    fis4 f4 f4 | %141
    e4 es4 es4 | %142
    d8. c16 d4 d,4 | %143
    g2. | %144
}
\mvtItimeLine
>>

mvtIfigs = \figuremode {
    s2. |
    \bassFigureExtendersOn
    <6>2 <6>4 |
    <6\!>2 <6>4 |
    <7 _+>8*5 <7 _+>8 |
    s2. |
    <6\!>2 <6>4 |
    <6\!>2 <6>4 |
    \bassFigureExtendersOff

    <6 4> <5 _+> s |
    s2.*8 |

    % p258
    s4 <6> <6 5> |
    <_+> <6> <7 5> |
    <5\+ _+> <5- _!>4.. \bassFigureExtendersOn <5- _!>16 |
    <6 5>16*11 <6 5>16 |
    \bassFigureExtendersOff

    <9>4 <8> s |
    <6> <6> s |
    <6> s <5>8 <4> |
    <6 4>4 <5 _+> s |
    s2. |
    <7 _->4 <7 _!>4. \bassFigureExtendersOn <7 _!>8 |
    <_-\!>4 <_+>4. <_+>8 |

    % p259
    <_->4 <_!>4. <_!>8 |
    \bassFigureExtendersOff
    <_->4 s <6-> |
    <7-> <6> s |
    <7> <6> s |
    <7 _!> <6 4> s |
    <5 3> <6> s |
    <7-> <6> <4\+ 2> |

    <7 5\+> <6 4 2\+> <6 3> |
    <_+>2. |
    s |
    \bassFigureExtendersOn
    <6>2 <6>4 |
    \bassFigureExtendersOff
    <6> <6> s |
    <6 4> <5 _+> s |
    s2.*8 |

    % p260
    s4 <6> <6 5> |

    <_+> <6> <7 5> |
    <5\+ _+> \bassFigureExtendersOn <5- _!>4.. <5- _!>16 |
    <6 5>16*11 <6 5>16 |
    \bassFigureExtendersOff
    <9>4 <8> s |
    <6> <6> s |
    \bassFigureExtendersOn
    <6> <6> <5>8 <4> |
    \bassFigureExtendersOff

    % p261
    <6 4>4 <5 _+> s |
    s2. |
    <7 _->4 <7 _!>4. \bassFigureExtendersOn <7 _!>8 |
    <_->4 <_+>4. <_+>8 |
    <_->4 <_!>4. <_!>8 |
    \bassFigureExtendersOff
    <_->4 s <6-> |
    <7-> <6> s |

    <7>4 <6> s |
    <7 _!> <6 4> s |
    <5 3> <6> s |
    <7-> <6> <4\+ 2> |
    <7 5\+> <6 4 2\+> <6 3> |
    <7 _+>2. |

    % p262
    <6 4> |
    <7\\ 6 4 2\+>4 <7! 5 _+> s |
    <6\\ 5> <6- 4> <7- 5> |
    <_!> <5\+ _+> s |
    s <6> <7 _!> |
    <_+> <6> <7> |

    <5\+> <5-> <6- 4 2\+> |
    <6 5>16*11 \bassFigureExtendersOn <6 5>16 |
    \bassFigureExtendersOff
    s4 s <6> |
    <7-> <6> s |

    % p263
    <7> <6> s |
    <7 _+> s s |
    s <6> <4 2> |
    <6> \bassFigureExtendersOn <6> <4 2> |
    <6>2 <6>4 |
    \bassFigureExtendersOff

    <6 4> <5 _!> s |
    s2. |
    <6>4 <6> s |
    <6>2 \bassFigureExtendersOn <6>4 |
    \bassFigureExtendersOff
    <6 4> <5 _!> s |
    s <6> <6 5> |
    <4>8 <_!> <6>4 <6 5> |

    % p264
    <4>8 <3> <6>4 <6 5> |
    <5 4> <6> s |
    <7> <6\\> <6 4> |
    <6 5> \bassFigureExtendersOn <6>8 \bassFigureExtendersOff s <6 5>4 |
    s <6> <4 2> |

    <6 4 2>2 \bassFigureExtendersOn <6 4 2>4 |
    <6\!>2 <6>4 \bassFigureExtendersOff |
    <6 4> <5 3> s |
    s2. |
    <6>2 \bassFigureExtendersOn <6>4 |
    <6\!>2 <6>4 |
    \bassFigureExtendersOff

    % p265
    <6 4> <5 3> s |
    s2. |
    s4 <6> <6 5> |
    s2. |
    s4 <6> <6 5> |

    <4>8 <_+> <6>4 s |
    <5\+ 4> <6\\> <6 5!> |
    <[5 4]> <6 4 2> <6> |
    <4> <_+> <6\\ _!> |
    <5 4> <3> <6-> |

    % p266
    <5 2> <7- 5> <4\+ 2> |
    <5 2> <6 5> <6 5> |
    <5 4> <6\\> <6 5-> |
    <5 4> <3> <6\\> |
    <5 4> <3> <7-> |

    <4-> <3> <6\\> |
    <5 3> s s |
    <6 4 2> <7- 5> <6> |
    <6 4 2> <6> \bassFigureExtendersOn <6> |
    \bassFigureExtendersOff
    <8 _+> <7> <6 4> |

    % p267
    <6 4 2\+> <7\\> <7! _+> |
    <7 5 4> <6\\ 4\+> <7\\ 4! 2\+> |
    <5 4> <_+> <7\\ 4 2\+> |
    <5 _+>4. <7 _+>8 <6 5>4 |
    <4>8 <_!>4 <7 _!>8 <6 5>4 |

    <4>8 <_!>4 <7 _!>8 <6 5>4 |
    <4>8 <3>4 <7- 3>8 <6 5>4 |
    s <6 _+> s |
    s8 <7> <4\+ 2>4 <6 5> |
    s <6> <6> |

    % p268
    s8 <7 _-> <4 2>4 <6 5-> |
    s8 <5> <6>4 <6\\> |
    s8 <6\\> <4\+ 2>4 <6 5> |
    s <6> <6 5> |
    s2. |

    <6>4 <6> s |
    <6> \bassFigureExtendersOn <6> \bassFigureExtendersOff <5>8 <4> |
    <6 4>4 <5 _+> s |
    s2. |
    <6>2 \bassFigureExtendersOn <6>4 |
    <6\!>2 <6>4 |
    \bassFigureExtendersOff
    <6 4> <5 _+> s |
    <_!>2. |
}
