\version "2.18.0"

\include "common.ly"


mvtIIItimeLine = {
    \time 4/4
    \key g \minor

    s1*19 | %19
    s2 \tempo "a tempo" s2 | %20
    s1*3 | %23
    s2 s2\fermata | %24
    \bar "|."
}


mvtIIItenor = <<
\relative c' {
    \autoBeamOff
    cis4 r8 g8 e'8 f8 g8 a,8 | %1
    bes8 bes8 es8 r16 d16 fis,8 fis8 a'8 fis8 | %2
    \grace e16 dis4 r8 a8 c?8 c8 fis8 a,8 | %3
    r8 fis16 g16 a8 fis8 gis8 gis8 r8 e8 | %4
    d'8. e16 f8 d8 f,8 f8 f8 e8 | %5
    c4 r16 e'16 g16 e16 cis8 cis8 d8 e8 | %6
    f8 f8 r16 d16 d16 b16 gis4 f'4 | %7
    r8 e8 g8 cis,16 d16 e8 e8 r4 | %8
    r4 es8 es8 r8 c16 a16 a'8 c,8 | %9
    b8 b8 r8 b16 c16 d8 d8 es8 f8 | %10
    g,8 g8 r16 d'16 as'16 g16 es8 d8 f8 es8 | %11
    c4 r4 r8 g8 es8 f8 | %12
    g8 g8 g8 as8 bes8 es,8 r16 bes'16 des16 c16 | %13
    c4 r8 c8 ges'8 f8 e8 f8 | %14
    f8 c8 r4 r4 r8 c8 | %15
    as8 bes8 c8 f,8 c'8 c8 c8 des8 | %16
    es4 r8 f8 ges8 ges8 ges8 f8 | %17
    des8 des8 r16 f,16 f16 f16 ces'8 ces8 ces8 bes8 | %18
    g8 g8 r8 g8 e'8 e8 e8 f8 | %19
    g8 \set melismaBusyProperties = #'() \schleifer bes,8 des8 r16 c16 \grace bes8 as4 r8 as'16 f16 | %20
    \set melismaBusyProperties = #'( melismaBusy slurMelismaBusy tieMelismaBusy beamMelismaBusy )
    des8 des8 f8 des8 b8 r8 r8 d8 | %21
    g8 c,8 r8 c8 f8[ \melisma as,8~] as16[ g16 fis16 g16] | %22
    g8[ f'8~] f16[ es16 d16 es16~] es16[ c16 des8~] des16[ c16 b16 c16] | %23
    c16 \melismaEnd g16 g8 r4 r2 | %24
}
\mvtIIItimeLine
>>


mvtIIItenorLyrics = \lyricmode {
    Ach! ich bin ein Kind der Sün -- den,
    ach! ich ir -- re weit und breit.
    Der Sün -- den Aus -- satz, so an mir zu fin -- den,
    ver -- läßt mich nicht in die -- ser Sterb -- lich -- keit.
    Mein Wil -- le trach -- tet
    nur nach Bö -- sen.
    Der Geist zwar spricht: ach! wer wird mich er -- lö -- sen?
    A -- ber Fleisch und Blut zu zwin -- gen
    und das Gu -- te zu voll -- brin -- gen,
    ist ü -- ber al -- le mei -- ne Kraft.
    Will ich den Scha -- den nicht ver -- heh -- len,
    so kann ich nicht, wie oft ich feh -- le, zäh -- len.
    Drum nehm ich nun der Sün -- den Schmerz und Pein
    und mei -- ner Sor -- gen Bür -- de,
    so mir sonst un -- er -- träg -- lich wür -- de,
    ich lief -- re sie dir, Je -- su, seuf -- zend ein.
    Rech -- ne nicht die Mis -- se -- tat,
    die dich, Herr, er -- zür -- net hat! 
}


mvtIIIbc = <<
\relative c' {
    \clef F
    g1\Pia | %1
    cis,4 c4~ c2 | %2
    fis,4 dis'2.~ | %3
    dis2 d2 | %4
    gis,1 | %5
    bes1 | %6
    b1 | %7
    bes2 a2 | %8
    fis1 | %9
    as1 | %10
    b2 c4 as4 | %11
    r4 g4 c2 | %12
    bes2 g2 | %13
    e'4 es4 a,4 des4 | %14
    r4 c4 f,2~ | %15
    f2 es'2 | %16
    a,1 | %17
    bes2 d2 | %18
    des2 bes2 | %19
    e,2 f8( f8 f8 f8) | %20
    f8( f8 f8 f8) f8( f8 f8 f8) | %21
    es8( es8 es'8 es8) d8( d8 c8 c8) | %22
    b8( b8 c8 c8) as8( as8 fis8 fis8) | %23
    g8( g8 g8 g8) c,2 | %24
}
\mvtIIItimeLine
>>


mvtIIIfigs = \figuremode {
    <6\\ 4\+ 3>1 |
    <7- 5>4 <3- 4\+ 6>8 <[2 \FBx \FBx]> s2 |
    <6\\>4 <7- 5>2. |

    s2 <6\\ 4\+ 2\+> |
    <7- 5->1 |
    <6 4\+ 2>2 <2\+> |

    <6\\ 5->1 |
    <6! 4\+ 3>2 <_+> |
    <7- 5>1 |

    <6 4 2\+>1 |
    <6 5>2 s4 <6> |
    s <_!> <_->2 |
    <6 _->2 <6>4 <5-> |

    <6> <6 4\+ 2> <7- 5-> <6 2\+ 4> |
    s <_!> <_->2 |
    s <6 4\+ 3-> |
    <7- 5>1 |

    <_->2 <5- 7-> |
    <6 4\+ 2> <6 4\+ 2> |
    <7- 5> <_-> |

    <6-> <6\\ 4\+ 2> |
    <6> <7 5->4 <6- 4> |
    <6 5> <_-> <6 4-> <7- 5> |
    <6 4>4 <5 _!> s2 |
}
