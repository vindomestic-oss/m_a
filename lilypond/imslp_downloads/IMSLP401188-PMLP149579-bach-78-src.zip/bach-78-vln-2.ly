\include "bach-78-1.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Violino II"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
    \new Staff <<
        \mvtIvlnII
    >>

    \header {
        piece = \mvtIpiece
    }
}


% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}

\score {
    \new Staff <<
        \mvtVvlnII
    >>

    \header {
        piece = \mvtVpiece
        % breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIvlnII
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIIalto
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
