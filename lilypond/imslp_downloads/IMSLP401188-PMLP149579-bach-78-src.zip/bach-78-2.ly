\version "2.18.0"

\include "common.ly"


mvtIItimeLine = {
    \partial 4
    \key bes \major

    s4 |
    s1*97 | %97
    s2.
    \daCapo
    \bar "||"
}

mvtIIbreaks = {
    <>^"BGA breaks left in"
    s4 |
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \pageBreak

    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \pageBreak

    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 6 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 5 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    s2.
    \bar "||"
}


mvtIIsoprano = <<
\relative c'' {
    \autoBeamOff
    r4 | %0
    R1*7 | %1
    r2 r4 bes4 | %8
    c8[ \melisma d16 c16 bes8 c8] d8[ es16 d16 c8 d8] | %9
    es8[ f16 es16 d8 es8] f4 \melismaEnd es8 d8 | %10
    c4 d8 c8 c4 d8 c8 | %11
    c4 d8 c8 f4 f4 | %12
    r4 bes,4 es4 es4 | %13
    r4 a,4 d4 es8 d8 | %14
    c4 d8 c8 bes4 c8 d8 | %15
    a2 r4 d4 | %16
    bes8([ a8)] bes4 r4 c4 | %17
    a8([ g8)] a4 r4 bes4 | %18
    g8[ \melisma a16 g16 f8 g8] a8[ bes16 a16 g8 a8] | %19
    bes8[ c16 bes16 a8 bes8] c8[ d16 c16 bes8 c8] | %20
    d4 \melismaEnd bes4 r2 | %21
    r2 r4 bes4 | %22
    c8[ \melisma d16 c16 bes8 c8] d8[ es16 d16 c8 d8] | %23
    es8[ f16 es16 d8 es8] f4 \melismaEnd es8 d8 | %24
    c4 d8 c8 c4 d8 c8 | %25
    bes4 c8 bes8 bes4 c8 bes8 | %26
    as4 bes8 as8 g4 as8 bes8 | %27
    f4 d'4 bes8([ a8)] bes4 | %28
    r4 c4 a8([ g]) a4 | %29
    r4 bes4 g8[ \melisma a16 g16 f8 g8] | %30
    a8[ bes16 a16 g8 a8] bes8[ c16 bes16 a8 bes8] | %31
    c8[ d16 c16 bes8 c8] d4 \melismaEnd es8 d8 | %32
    d4 es8 d8 d4 es8 d8 | %33
    c4 d8 c8 c4 d8 c8 | %34
    bes4 c8 d8 f,4 bes8 a8 | %35
    bes4 r4 r4 bes4 | %36
    f'4 r4 r4 d4 | %37
    g4 g4 es4 f8 es8 | %38
    es4 f8 es8 d4 es8 d8 | %39
    d4 es8 d8 d8[ es16 d16] c8 bes8 | %40
    f'4 g8 f8 es8[ d8] c8 d8 | %41
    bes4 f'4 d4 r4 | %42
    R1*7 | %43
    r2 r4\fermata d4 | %50
    d4 c8 d8 es4 d8 es8 | %51
    c4 bes8 c d4 g,8 f' | %52
    f2~ f4 es8 f8 | %53
    b,8[ \melisma c8] d2 \melismaEnd c8 d8 | %54
    es2~ es4 d8 c8 | %55
    des2~ des4 c8 b8 | %56
    c4 \melisma b2 g'4~ | %57
    g4 \melismaEnd as8 b,8 c4 g8 b8 | %58
    c8[ d8] d8 es8 es8[ f8] f8 d8 | %59
    c4( b4) c4 r4 | %60
    R1*3 | %61
    r2 r4 es4 | %64
    r2 es8[ d8] d4 | %65
    r2 c4 r4 | %66
    r2 c8[ bes8] bes4 | %67
    r4 es4 d4 c8 bes8 | %68
    a4 r4 r2 | %69
    R1 | %70
    r4 g4 d'4 e8 f8 | %71
    g8[ \melisma a16 g16 f8 g8] a8[ bes16 a16 g8 a8] | %72
    f4 \melismaEnd e8 d e4 g,4 | %73
    r4 g'4 g8[ f8] f4 | %74
    r4 d4 g,4 a8 bes8 | %75
    c2~ c4 bes8 a | %76
    g8[ f8] e8 g8 f8[ e8] d8 a'8 | %77
    bes8[ a8] g8 bes8 a8[ g8] f8 g'8 | %78
    f8[ e8] d8 cis8 e8[ d8] g,8 bes8 | %79
    f4( e4) d4 r4 | %80
    R1*3 | %81
    r2 r4 c'4 | %84
    d4 c8 d8 e4 d8 e8 | %85
    f8[ g16 f16] e8 f8 g8[ e8] c8 f8 | %86
    d4 es8 d8 d4 es8 d8 | %87
    c4 d8 c8 c8[ \melisma d16 c16] bes8[ c16 a16] | %88
    bes8[ c16 bes16] a8[ bes16 g16] c4 \melismaEnd d8 bes8 | %89
    a4( g4) f4 r8 a8 | %90
    g8[ \melisma a16 g16 f8 g8] a4 r8 f'8 | %91
    e8[ f16 e16 d8 e8] f8([ c8)] \melismaEnd a8 f8 | %92
    c'8.[ \melisma d16] c4~ c16[ bes16 a16 bes16] c16[ d16 c16 d16] | %93
    c2~ c8[ f16 es16] \melismaEnd f8 c8 | %94
    d4 es8 d8 d4 es8 d8 | %95
    c4 d8 c8 c8[ \melisma d16 c16] bes8[ c16 a16] | %96
    bes8[ c16 bes16] a8[ bes16 g16] c4 \melismaEnd d8 bes8 | %97
    a4( g4) f4 %98
}
\mvtIItimeLine
>>

mvtIIsopranoLyrics = \lyricmode {
    Wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    o Je -- su, o Meis -- ter,
    wir ei -- len,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    o Je -- su, o Meis -- ter,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    zu dir, zu dir,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir, zu dir.

    Du su -- chest die Kran -- ken und Ir -- ren -- den treu -- lich,
    die Kran -- ken und Ir -- ren -- den treu -- lich,
    die Kran -- ken und Ir -- ren -- den treu -- lich,
    die Kran -- ken und Ir -- ren -- den treu -- lich.

    Ach hö -- re,
    ach hö -- re,
    ach hö -- re, wie wir
    die Stim -- men er -- he -- ben,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe,
    um Hül -- fe zu bit -- ten!

    Es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    er -- freu -- lich,
    er -- freu -- lich,
    er -- freu -- lich,
    es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    er -- freu -- lich!
}


mvtIIalto = <<
\relative c' {
    \autoBeamOff
    r4 | %0
    R1*9 | %1
    r2 r4 f4 | %10
    g8[ \melisma a16 g16 f8 g8] a8[ bes16 a16 g8 a8] | %11
    bes8[ c16 bes16 a8 bes8] c4 \melismaEnd bes8 a8 | %12
    g4 a8 g8 g4 a8 g8 | %13
    f4 g8 f8 f4 g8 f8 | %14
    es4 f8 es8 d4 es8 f8 | %15
    c4 a'4 f8([ es8]) f4 | %16
    r4 g4 es8([ d8)] es4 | %17
    r4 f4 d8[ \melisma es16 d16 c8 d8] | %18
    es8[ f16 es16 d8 es8] c8[ d16 c16 bes8 c8] | %19
    d8[ es16 d16 c8 d8] es8[ f16 es16 d8 es8] | %20
    f8[ g16 f16 es8 f8] g8[ as16 g16 f8 g8] | %21
    as8[ bes16 as16 g8 as8] bes4 \melismaEnd as8 g8 | %22
    f4 g8 f8 f4 g8 f8 | %23
    f4 g8 f8 bes4 bes4 | %24
    r4 es,4 as4 as4 | %25
    r4 d,4 g4 as8 g8 | %26
    f4 g8 f8 es4 f8 g8 | %27
    d2 r4 g4 | %28
    es8([ d8)] es4 r4 f4 | %29
    d8([ c8]) d4 r4 es4 | %30
    c8[ \melisma d16 c16 bes8 c8] d8[ es16 d16 c8 d8] | %31
    es8[ f16 es16 d8 es8] f4 \melismaEnd g8 f8 | %32
    f4 g8 f8 f4 g8 f8 | %33
    es4 f8 es8 es4 f8 es8 | %34
    d4 es8 f8 d4 es8 c8 | %35
    bes4 f'4 bes4 r4 | %36
    r4 a4 d4 r4 | %37
    r4 d4 c4 d8 c8 | %38
    c4 d8 c8 bes4 c8 bes8 | %39
    bes4 f8 as8 g8([ f8)] es8 d8 | %40
    c8[ a'8] bes8 c8 f,4 bes8 a8 | %41
    bes4 d4 bes4 r4 | %42
    R1*7 | %43
    r2 r4\fermata r4 | %50
    R1 | %51
    r2 r4 g4 | %52
    g4 f8 g8 as4 g8 as8 | %53
    f4 es8 f8 g4 c,4 | %54
    r4 c'4 f,4 g8 as8 | %55
    bes2~ bes4 as8 g8 | %56
    f8[ es8] d8 f8 es8[ d8] c8 g'8 | %57
    as8[ g8] f8 as8 g8[ f8] es8 f8 | %58
    g8[ as8] as8 g8 b8[ c8] c8 as8 | %59
    es4( d4) c4 r4 | %60
    R1*3 | %61
    r2 r4 c'4 | %64
    r2 c8[ bes8] bes4 | %65
    r2 a4 r4 | %66
    r2 a8[ g8] g4 | %67
    r4 c4 bes4 a8 g8 | %68
    fis4 d4 g4 a8 bes8 | %69
    c8[ \melisma d16 c16 bes8 c8] d8[ es16 d16 c8 d8] | %70
    bes4 \melismaEnd a8 g8 a4 d,4 | %71
    r4 d'4 d8[ cis] cis4 | %72
    r4 a4 bes2~ | %73
    bes4 a8 g8 a4 d,8 e8 | %74
    f2~ f4 e8 d8 | %75
    es2~ es4 d8 cis8 | %76
    d4 \melisma cis2 a'4~ | %77
    a4 \melismaEnd bes8 cis,8 d4 a8 cis8 | %78
    d8[ e8] e8 f8 f8[ g8] g8 e8 | %79
    d4( cis4) d4 r4 | %80
    R1 | %81
    r2 r4 f4 | %82
    g4 f8 g8 a4 g8 a8 | %83
    bes8[ c16 bes16] a8 bes8 c8[ a8] f8 c8 | %84
    g'8.[ \melisma a16] g4~ g16[ f16 \once \set suggestAccidentals = ##t e16 f16] g16[ a16 g16 a16] | %85
    g2~ g4 \melismaEnd bes8 a8 | %86
    bes4 c8 bes8 bes4 c8 bes8 | %87
    a4 bes8 a8 a8[ \melisma bes16 a16] g8[ a16 f16] | %88
    g8[ a16 g16] f8[ g16 e16] a8[ bes16 a16] g8[ a16 f16] | %89
    f4( e8.[ f16)] \melismaEnd f4 r8 f8 | %90
    e8[ \melisma f16 e16 d8 e8] f4 r8 a8 | %91
    g8[ a16 g16 f8 g8] a8[ f8] \melismaEnd c8 f8 | %92
    g4 f8 g8 a4 g8 a8 | %93
    bes8[ c16 bes16] a8 bes8 c8([ a8]) f8 a8 | %94
    bes4 c8 bes8 bes4 c8 bes8 | %95
    a4 bes8 a8 a8[ \melisma bes16 a16] g8[ a16 f16] | %96
    g8[ a16 g16] f8[ g16 e16] a8[ bes16 a16] g8[ a16 f16] | %97
    f4( e8.[ f16)] \melismaEnd f4 %98
}
\mvtIItimeLine
>>

mvtIIaltoLyrics = \lyricmode {
    Wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    o Je -- su, o Meis -- ter,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    o Je -- su, o Meis -- ter,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir,
    zu dir, zu dir,
    wir ei -- len mit schwa -- chen, doch em -- si -- gen Schrit -- ten,
    o Je -- su, o Meis -- ter zu hel -- fen zu dir, zu dir.

    Du su -- chest die Kran -- ken und Ir -- ren -- den treu -- lich,
    du su -- chest die Kran -- ken,
    du su -- chest die Kran -- ken und Ir -- ren -- den treu -- lich,
    die Kran -- ken und Ir -- ren -- den treu -- lich.

    Ach hö -- re,
    ach hö -- re,
    ach hö -- re, wie wir
    die Stim -- men er -- he -- ben,
    um Hül -- fe zu bit -- ten,
    zu bit -- ten,
    zu bit -- ten,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe zu bit -- ten,
    um Hül -- fe,
    um Hül -- fe zu bit -- ten!

    Es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    er -- freu -- lich,
    es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    er -- freu -- lich,
    es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich,
    es sei uns dein gnä -- di -- ges Ant -- litz er -- freu -- lich!
}


mvtIIbc = <<
\relative c' {
    \clef F
    bes4 | %0
    a8 f8 f8 a8 bes8 f8 f8 bes8 | %1
    c8 f,8 f8 c'8 d8 f,8 f8 d'8 | %2
    g,8 es8 es8 g8 c8 es,8 es8 c'8 | %3
    f,8 d8 d8 f8 bes8 d,8 d8 bes'8 | %4
    g8 es8 es8 bes'8 f8 d8 d8 bes'8 | %5
    es,8 c8 c8 bes'8 d,8 bes8 bes8( c8) | %6
    d8( es8) es8( f8) f8( g8) g8 es8 | %7
    f4 f,4 bes4 bes'4\Pia | %8
    a8 f8 f8 a8 bes8 f8 f8 bes8 | %9
    c8 f,8 f8 c'8 d8 f,8 f8 bes8 | %10
    e,8 c8 c8 e8 f8 c8 c8 f8 | %11
    g8 c,8 c8 g'8 a8 c,8 c8 a'8 | %12
    bes8 g8 g8 bes8 c8 g8 g8 c8 | %13
    a8 f8 f8 a8 bes8 f8 f8 bes8 | %14
    bes8 f8 f8 a8 bes8 f8 f8 bes8 | %15
    c8 f,8 f8 a8 d8 f,8 f8 d'8 | %16
    g,8 es8 es8 g8 c8 es,8 es8 c'8 | %17
    f,8 d8 d8 f8 bes8 d,8 d8 bes'8 | %18
    es,4 c4 f4 f,4 | %19
    bes4 r4 r4 f'4 | %20
    bes8 bes,8 bes8 d8 es8 bes8 bes8 es8 | %21
    f8 bes,8 bes8 f'8 g8 bes,8 bes8 es8 | %22
    a,8 f8 f8 a8 bes8 f8 f8 bes8 | %23
    c8 f,8 f8 c'8 d8 f,8 f8 d'8 | %24
    es8 c8 c8 es8 f c c8 f8 | %25
    d8 bes8 bes8 d8 es8 bes8 bes8 es8 | %26
    es8 bes8 bes8 d8 es8 bes8 bes8 es8 | %27
    bes'8 bes,8 bes8 d8 g8 bes,8 bes8 g'8 | %28
    c,8 a8 a8 c8 f8 f,8 f8 f'8 | %29
    bes,8 g8 g8 bes8 es8 bes8 bes8 es8 | %30
    f8 f,8 f8 f'8 d8 bes8 bes8 f'8 | %31
    a8 f8 f8 a8 bes8 f8 f8 bes8 | %32
    as8 f8 f8 as8 b8 g8 g8 b8 | %33
    c8 g8 g8 bes8 a8 f8 f8 a8 | %34
    bes8 g8 g8 es8 f4 f,4 | %35
    bes4 r4 r4 bes'4 | %36
    a8 f8 f8 a8 bes8 f8 f8 d'8 | %37
    bes8 g8 g8 b8 c8 g8 g8 bes8 | %38
    a8 f8 f8 a8 bes8 f8 f8 as8 | %39
    g8 d8 d8 f8 es8 c8 c8 es8 | %40
    f8 es8 d8 es8 f4 f,4 | %41
    bes4 r4 r4 bes'4\For | %42
    a8 f8 f8 a8 bes8 f8 f8 bes8 | %43
    c8 f,8 f8 c'8 d8 f,8 f8 d'8 | %44
    g,8 es8 es8 g8 c8 es,8 es8 c'8 | %45
    f,8 d8 d8 f8 bes8 d,8 d8 bes'8 | %46
    g8 es8 es8 bes'8 f8 d8 d8 bes'8 | %47
    es,8 c8 c8 bes'8 d,8 bes8 bes8( c8) | %48
    d8( es8) es8( f8) f8( g8) g8 es8 | %49
    f4 f,4 bes4\fermata g'4\Pia | %50
    fis8 d8 d8 fis8 g8 d8 d8 g8 | %51
    a8 d,8 d8 a'8 bes8 g8 g8 a8 | %52
    b8 g8 g8 b8 c8 g8 g8 c8 | %53
    d8 g,8 g8 d'8 es8 c8 c8 es8 | %54
    as,8 f8 f8 as8 d8 f,8 f8 d'8 | %55
    g,8 es8 es8 g8 c8 e,8 e8 c'8 | %56
    as8 f8 f8 c'8 g8 es8 es8 c'8 | %57
    f,8 d8 d8 c'8 es,8 c8 c8( d8) | %58
    es8( f8) f8( g8) g8( as8) as8( f8) | %59
    g4 g,4 c8 g'8\For g8 c8 | %60
    as8 f8 f8 c'8 g8 es8 es8 c'8 | %61
    f,8 d8 d8 c'8 es,8 c8 c8( d8_)| %62
    es8( f8) f8( g8) g8( as8) as8( f8) | %63
    g4 g,4 c8 c'8\Pia c8 bes8 | %64
    a?8 f8 f8 a8 bes8 f8 f8 a8 | %65
    g8 e8 e8 g8 a8 e8 e8 g8 | %66
    fis8 d8 d8 fis8 g8 d8 d8 g8 | %67
    a8 d,8 d8 a'8 bes8 d,8 d8 bes'8 | %68
    c8 d,8 d8 c'8 bes8 d,8 d8 bes'8 | %69
    a8 d,8 d8 g8 fis8 d8 d8 fis8 | %70
    g8 d8 d8 g8 f8 d8 d8 a'8 | %71
    bes8 d,8 d8 bes'8 a8 e8 e8 a8 | %72
    d8 d,8 d8 f8 g8 d8 d8 g8 | %73
    a8 cis,8 cis8 a'8 d8 d,8 d8 d'8 | %74
    bes8 g8 g8 bes8 e8 g,8 g8 e'8 | %75
    a,8 f8 f8 a8 d8 fis,8 fis8 d'8 | %76
    bes8 g8 g8 d'8 a8 f8 f8 d'8 | %77
    g,8 e8 e8 d'8 f,8 d8 d8( e8) | %78
    f8( g8) g8( a8) a8( bes8) bes8( g8) | %79
    a4 a,4 d8 a'8\For a8 d8 | %80
    bes8 g8 g8 bes8 c8 e,8 e8 c'8 | %81
    a8 f8 f8 a8 bes8 d,8 d8 bes'8\Pia | %82
    e,8 c8 c8 e8 f8 c8 c8 f8 | %83
    g8 c,8 c8 g'8 a8 f8 f8 a8 | %84
    b8 g8 g8 b8 c8 g8 g8 c8 | %85
    d8 g,8 g8 d'8 e8 c8 a8 f8 | %86
    bes8 f8 f8 a8 g8 e8 e8 g8 | %87
    a8 e8 e8 g8 f8 c8 c8 f8 | %88
    e8 c8 c8 e8 f4 bes,4 | %89
    c4 c,4 f8 f'8 f8 c8 | %90
    c8 g'8 g8 c,8 c8 a'8 a8 c,8 | %91
    c8 bes'8 bes8 c,8 c8 a'8 a8 c,8 | %92
    e8 c8 c8 e8 f8 c8 c8 f8 | %93
    g8 c,8 c8 g'8 a8 f8 f8 d8 | %94
    bes8 f'8 f8 a,8 g8 e'8 e8 g,8 | %95
    a8 e'8 e8 g,8 f8 d'8 d8 f,8 | %96
    e8 c'8 c8 e,8 f4 bes4 | %97
    c4 c,4 f4 %98
}
\mvtIItimeLine
>>


mvtIIcb = <<
\relative c' {
    \clef F
    bes4-\markup"staccato e pizzacato" | %0
    a4 f4 bes4 f4 | %1
    c'4 f,4 d'4 f,4 | %2
    g4 es4 c'4 es,4 | %3
    f4 d4 bes'4 d,4 | %4
    g4 es4 f4 d4 | %5
    es4 c4 d4 bes8 c8 | %6
    d4 es4 f4 g8 es8 | %7
    f4 f,4 bes4 bes'4\Pia | %8
    a4 f4 bes4 f4 | %9
    c'4 f,4 d'4 bes4 | %10
    e,4 c4 f4 c4 | %11
    g'4 c,4 a'4 f4 | %12
    bes4 g4 c4 g4 | %13
    a4 f4 bes4 f4 | %14
    bes4 a4 bes4 bes,4 | %15
    f4 f'4 d'4 f,4 | %16
    g4 es4 c'4 es,4 | %17
    f4 d4 bes'4 d,4 | %18
    es4 c4 f4 f,4 | %19
    bes4 r4 r4 f'4 | %20
    bes4 bes,4 es4 bes4 | %21
    f'4 bes,4 g'4 es4 | %22
    a,4 f4 bes4 f4 | %23
    c'4 f,4 d'4 bes4 | %24
    es4 c4 f4 c4 | %25
    d4 bes4 es4 bes4 | %26
    es4 d4 es4 es,4 | %27
    bes'4 bes'4 g4 bes,4 | %28
    c4 a4 f4 f'4 | %29
    bes,4 g8 bes8 es4 es,4 | %30
    f4 f'4 d4 bes'4 | %31
    a4 f4 bes4 f4 | %32
    as4 f4 b4 g4 | %33
    c4 g4 a4 f4 | %34
    bes4 es,4 f4 f,4 | %35
    bes4 r4 r4 bes'4 | %36
    a4 f4 bes4 bes,4 | %37
    bes'4 g4 c4 g4 | %38
    a4 f4 bes4 f4 | %39
    g4 d4 es4 c4 | %40
    f4 d8 es8 f4 f,4 | %41
    bes4 r4 r4 bes'4\For | %42
    a4 f4 bes4 f4 | %43
    c'4 f,4 d'4 f,4 | %44
    g4 es4 c'4 es,4 | %45
    f4 d4 bes'4 d,4 | %46
    g4 es4 f4 d4 | %47
    es4 c4 d4 bes8 c8 | %48
    d4 es4 f4 g8 es8 | %49
    f4 f,4 bes4\fermata g'4\Pia | %50
    fis4 d4 g4 d4 | %51
    a'4 d,4 bes'4 g8 a8 | %52
    b4 g4 c4 g4 | %53
    d'4 g,4 es'4 c4 | %54
    as4 f4 d'4 f,4 | %55
    g4 es4 c'4 e,4 | %56
    as4 f4 g4 es4 | %57
    f4 d4 es4 c8 d | %58
    es4 f4 g4 as8 f8 | %59
    g4 g,4 c4 c'4\For | %60
    as4 f4 g4 es4 | %61
    f4 d4 es4 c8 d8 | %62
    es4 f4 g4 as8 f8 | %63
    g4 g,4 c4 c'8\Pia bes8 | %64
    a?4 f4 bes4 f4 | %65
    g4 e4 a4 e4 | %66
    fis4 d4 g4 d4 | %67
    a'4 d,4 bes'4 d,4 | %68
    c'4 d,4 bes'4 d,4 | %69
    a'4 g4 fis4 d4 | %70
    g4 f8 e f4 d4 | %71
    bes'4 bes,4 a4 a'4 | %72
    d4 d,4 g4 d4 | %73
    cis4 a'4 d,4 d'4 | %74
    bes4 g4 e'4 g,4 | %75
    a4 f4 d'4 fis,4 | %76
    bes4 g4 a4 f4 | %77
    g4 e4 f4 d8 e8 | %78
    f4 g4 a4 bes8 g8 | %79
    a4 a,4 d4 d'4\For | %80
    bes4 g4 c4 e,4 | %81
    a4 f4 bes4 d,4\Pia | %82
    e4 c4 f4 c4 | %83
    g'4 c,4 a'4 f4 | %84
    b4 g4 c4 g4 | %85
    d'4 g,4 e4 f4 | %86
    bes4 f4 g4 e4 | %87
    a4 e4 f4 c4 | %88
    e4 c8 e8 a,4 bes4 | %89
    c4 c,4 f4 f'4 | %90
    c4 c'4 f,4 a4 | %91
    c4 c,4 f4 a4 | %92
    e4 c4 f4 c4 | %93
    g'4 c,4 a'4 f4 | %94
    bes4 f4 g4 e4 | %95
    a4 e4 f4 d4 | %96
    e4 c4 a4 bes4 | %97
    c4 c,4 f4 %98
}
\mvtIItimeLine
>>


mvtIIfigs = \figuremode {
    s4 |
    \bassFigureExtendersOn
    <6>4. <6>8 <[5 3]>4. <5 3>8 |
    <6 4>4. <6 4>8 <6\!>4. <6>8 |
    <6\! 5>4. <6 5>8 <[5\! 3]>4. <5 3>8 |
    <6 5\!>4. <6 5>8 <[5\! 3]>4. <5 3>8 |

    <6>4. <6>8 <6\! 4>4. <6 4>8 |
    <6\! 5>4. <6 5>8 \bassFigureExtendersOff <6>2 |
    <6>4 <6 5> s <6>8 <6 5> |
    <6 4>4 <5 3> s2 |
    <6> s |
    <6> <6> |

    <6 5>1 |
    <6\\ 4 3>2 <6> |
    <6 5>1 |
    <6 5> |
    <4 2>4 <7 5> <[5 3]>4. \once \bassFigureExtendersOn <5 3>8 |

    <6 4>1 |
    <5 3>2 <5 3> |
    <7>4 <6> s2 |
    s1*2 |

    % p270
    s4. <6>8 <5 3>4. \once \bassFigureExtendersOn <5 3>8 |
    <6 _->2 <6>4 <6 4> |
    <6 5>1 |
    <6 4 3>2 <6> |
    <6 5> <_->4. \once \bassFigureExtendersOn <_->8 |

    <6 5->2 <5 3> |
    <5 4-> <5 3> |
    s <7>4. \once \bassFigureExtendersOn <7>8 |
    <5 3>2 <7> |
    <5 3>4 <7 5> <5 3>4. \once \bassFigureExtendersOn <5 3>8 |

    <5 3>2 <6>4. \once \bassFigureExtendersOn <6>8 |
    <6 5>2 s |
    <6 4 2\+> <6 5> |
    s <6 5> |
    s4 <6 4 3> <6 4> <5 3> |

    s1 |
    <6> |
    <6>4 <_!> <_->2 |
    <6 5>1 |
    <5>4 <6> <7> <8> |

    % p271
    s <6> <6 4> <5 3> |
    s1 |
    \bassFigureExtendersOn
    <6>4. <6>8 <[5 3]>4. <5 3>8 |
    <6 [4]>4. <6 4>8 <6\!>4. <6>8 |
    <6\! 5>4. <6 5>8 s2 |

    <6\! 5>4. <6 5>8 <[5\! 3]>4. <5 3>8 |
    <6>4. <6>8 <6\! 4>4. <6 4>8 |
    <6\! 5>4. <6 5>8 \bassFigureExtendersOff <6>2 |
    <6>4 <6 5> s <6>8 <6 5> |
    <6 4>4 <5 3> s2 |
    <6 5> <6 4>4 <6 4> |

    <6\\>2 <6> |
    <6 5> <6- 4> |
    <6\\ 4 3> <9 7>4 <8 6> |
    <5 3> <7 5> <9-> <6 5> |
    <6 5->2 <9- 7>4 <6 5> |

    <6> <4\+ 3-> <6- _!> <6> |
    <9 _-> <5->8 <7/ 4 2> <6>4. <6\\>8 |
    <6> <6 _-> s <6 4> <6 _!> <6> s <6 5 _-> |
    <6 4>4 <5 _!> s2 |

    % p272
    <6>2 <6 4> |
    <6 5 _-> <6> |
    <6>4 <6 5 _-> <_!> <6>8 <6 5 _-> |
    <6 4>4 <5 _!> s2 |
    <6 5>4 <7> <9 4> <6 4> |
    <6\\ 5> s <7 5> <6 4> |

    <6 5>2 <9 4>4 <6 4> |
    <6\\ 5->2 <6> |
    <4\+ 2> <6> |
    <7>4 <7 _+> <6> <7 _+> |
    s2 <6> |

    <6>4 <6 4> <5\+ 4> <6\\> |
    s2 <6\\>4 <6 4> |
    <9 _+> <6> <5 4> <3> |
    s1 |
    <6 5->2 <9- _+>4. \once \bassFigureExtendersOn <9- _+>8 |

    <6>4 <4\+ 3> <6 4> <6> |
    <9> <6\\> <6>4. <6\\>8 |
    <6>4 <6\\ 5> <6 4> <6>8 <6\\ 5> |
    <6 4>4 <5\+ _+> s2 |

    % p273
    <6> <_!> |
    <6 5-> s |
    <6 5> s |
    <6\\> <6> |
    <6 5> <_!> |

    <6\\> <6>4 <6> |
    s2 <6\\ 5> |
    <5\+>4. <6\\>8 <5 3>4. \once \bassFigureExtendersOn <5 3>8 |
    <6 5>2 s4 <6 5> |

    <6 4>4 <5 _!> s8 <" ">4 \once \bassFigureExtendersOn <" ">8 |
    <5 _!>4 <6\\ 4> <6 4> s |
    <5 _!> <4\+ 2> <6 4> s |
    <6 5>2 s |

    <6> <6>4 <" ">8 \once \bassFigureExtendersOn <" ">8 |
    s4 <6 4>8 <4 2> <6\\ 5>2 |
    <5\+>4 s8 <4 2> <6 5>4 <6 4> |
    <6 5> <7 _!> s <6 5> |
    <6 4> <5 _!> s
}
