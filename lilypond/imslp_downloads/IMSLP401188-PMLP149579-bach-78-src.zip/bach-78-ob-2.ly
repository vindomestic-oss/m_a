\include "bach-78-1.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = "Oboe II"
}

\score {
    \new Staff <<
        \mvtIobII
        { s2.*108 | \pageBreak }
    >>

    \header {
        piece = \mvtIpiece
    }
}


% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}

\score {
    \new Staff <<
        \mvtVIIalto
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
