\include "bach-78-1.ly"
\include "bach-78-5.ly"
\include "bach-78-6.ly"
\include "bach-78-7.ly"

\include "bach-78-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Violino I"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
    \new Staff <<
        \mvtIvlnI
    >>

    \header {
        piece = \mvtIpiece
    }
}


% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}

\score {
    \new Staff <<
        \mvtVvlnI
    >>

    \header {
        piece = \mvtVpiece
        % breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIvlnI
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIIsoprano
    >>

    \header {
        piece = \mvtVIIpiece
    }
}
