\version "2.19.7"

\include "common.ly"


mvtItimeLine = {
    \time 9/8
    \key b \minor

    s8*9*1 | %1
    \segno
    s8*9*122 | %123
    \dalSegno
    \bar "|."
}


mvtIflI = <<
\relative c''' {
    R8*9*2 | % bar 2
    b4. b4. b4. | % bar 3
    ais4.~\trill ais4 gis8 fis4. | % bar 4
    R8*9*6 | % bar 5
    d'4. d4. d4. | % bar 11
    cis4.~\trill cis4 b8 a4. | % bar 12
    b4. b4. b4. | % bar 13
    a4.~\trill a4 g8 fis4. | % bar 14
    g4. g4. g4. | % bar 15
    fis8 e8 fis8 d8 e8 fis8 g8 a8 b8~ | % bar 16
    b8 g8 e8 cis8 d8 e8 fis8 g8 a8 | % bar 17
    b8( a8 g8) \once \slurDashed g8( fis8 e8) e8( d8 cis8) | % bar 18
    cis8( b8 ais8) ais8( b8 cis8) d8( e8 fis8) | % bar 19
    g8( fis8 e8) \once \slurDashed d8( cis8 b8) fis8( b8 ais8) | % bar 20
    b4.\fermata r4. r4. | % bar 21
    R8*9*3 | % bar 22
    b'4. b4. b4. | % bar 25
    a4.~\trill a4 g8 fis4. | % bar 26
    \once \slurDashed g8( a8 b8) a4.~ a8 g8 a8 | % bar 27
    b8( a8 g8) g8( fis8 e8) \once \slurDashed fis8( a8 cis8) | % bar 28
    d4 a8 fis8 e8 d8 b'4.~ | % bar 29
    b8 cis8 b8 a8 b8 gis8 a4.~ | % bar 30
    a8 d8 a8 fis8 e8 d8 g4.~ | % bar 31
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 32
    fis8 b8 a8 b8 g8 e8 cis8 e8 a8~ | % bar 33
    a8 d8 cis8 d8 a8 g8 fis8 a8 d8 | % bar 34
    g,4.~ g8 fis8 e8 cis'8 d8 e8 | % bar 35
    a,4 b8 \once \slurDashed a8( g8 fis8) \once \slurDashed e8( d8 e8) | % bar 36
    d8 fis8 a8 fis4.~ fis8 a8 d8 | % bar 37
    e,4 r8 r4. r4. | % bar 38
    g4. g4. g4. | % bar 39
    fis4.~\trill fis4 e8 d8 e8 cis8 | % bar 40
    d4.~ d8 e8 d8 cis8 d8 b8 | % bar 41
    fis'2.~ fis4.~ | % bar 42
    fis2.~ fis4. | % bar 43
    fis4. fis4. fis4. | % bar 44
    e4.~\trill e4 d8 cis4. | % bar 45
    d4. r4. r4. | % bar 46
    R8*9 | % bar 47
    b'4. b4. b4. | % bar 48
    ais4.~\trill ais4 gis8 fis4. | % bar 49
    R8*9*6 | % bar 50
    d'4. d4. d4. | % bar 56
    cis4.~\trill cis4 b8 a4. | % bar 57
    b4. b4. b4. | % bar 58
    a4.~\trill a4 g8 fis4. | % bar 59
    g4. g4. g4. | % bar 60
    fis8( e8 fis8) d8( e8 fis8) \once \slurDashed g8( a8 b8)~ | % bar 61
    b8 g8 e8 cis8( d8 e8) fis8( g8 a8) | % bar 62
    b8( a8 g8) g8( fis8 e8) e8( d8 cis8) | % bar 63
    cis8( b8 ais8) ais8( b8 cis8) d8( e8 fis8) | % bar 64
    g8( fis8 e8) d8( cis8 b8) \once \slurDashed fis8( b8 ais8) | % bar 65
    b4. r4. r4. | % bar 66
    R8*9*3 | % bar 67
    b'4. b4. b4. | % bar 70
    a4.~\trill a4 g8 fis4. | % bar 71
    g8 a8 b8 a4.~ a8 g8 a8 | % bar 72
    b8( a8 g8) g8( fis8 e8) \once \slurDashed fis8( a8 cis8) | % bar 73
    d4 a8 fis8 e8 d8 b'4.~ | % bar 74
    b8 cis8 b8 a8 b8 gis8 a4.~ | % bar 75
    a8 d8 a8 fis8 e8 d8 g4.~ | % bar 76
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 77
    fis8 b8 a8 b8 g8 e8 cis8 e8 a8~ | % bar 78
    a8 d8 cis8 d8 a8 g8 fis8 a8 d8 | % bar 79
    g,4.~ g8 fis8 e8 cis'8 d8 e8 | % bar 80
    a,4 b8 \once \slurDashed a8( g8 fis8) \once \slurDashed e8( d8 e8) | % bar 81
    d8 fis8 a8 fis4.~ fis8 a8 d8 | % bar 82
    e,4 r8 r4. r4. | % bar 83
    g4. g4. g4. | % bar 84
    fis4.~\trill fis4 e8 d8 e8 cis8 | % bar 85
    d4.~ d8 e8 d8 cis8 d8 b8 | % bar 86
    fis'2.~ fis4.~ | % bar 87
    fis2.~ fis4. | % bar 88
    fis4. fis4. fis4. | % bar 89
    e4.~\trill e4 d8 cis4. | % bar 90
    d8 e8 fis8 d8 e8 fis8 g8 a8 b8~ | % bar 91
    b8 g8 e8 cis8( d8 e8) fis8( g8 a8) | % bar 92
    b8( a8 g8) g8( fis8 e8) e8( d8 cis8) | % bar 93
    cis8( b8 ais8) \slurDashed ais8( b8 cis8) d8( e8 fis8) | % bar 94
    g8( fis8 e8) d8( cis8 b8) fis8( b8 ais8) | % bar 95
    b4 b'8 d4 b8 r4. | % bar 96
    \slurSolid fis8( ais8 b8) fis8( ais8 b8) fis8( ais8 b8) | % bar 97
    fis4 r8 r4. r4. | % bar 98
    R8*9*3 | % bar 99
    b4. b4. b4. | % bar 102
    a4.\trill~ a4 g8 fis4. | % bar 103
    g4. r4. r4. | % bar 104
    R8*9*4 | % bar 105
    b4. b4. b4. | % bar 109
    a4.\trill~ a4 g8 fis4. | % bar 110
    g4 a8 b8( g8 a8) b8( a8 g8) | % bar 111
    fis4( b,8) b'4( a8) gis8( fis8 gis8) | % bar 112
    a8( cis8 b8) a8( cis8 b8) a8( b8 cis8) | % bar 113
    e,2.~ e4. | % bar 114
    r8 d8( e8) fis8( g8 e8) d8( e8 fis8) | % bar 115
    cis4.~ cis8 \once \slurDashed d8( e8) fis8( e8 d8) | % bar 116
    e8( fis8 g8) fis8( e8 d8) cis8( d8 e8) | % bar 117
    d8( ais8 b8) d8( ais8 b8) d8( ais b) | % bar 118
    e8( fis g) e( fis g) a( g fis) | % bar 119
    e4. e4. e4. | % bar 120
    d4.\trill~ d4 cis8 b4. | % bar 121
    \slurDashed cis8( ais8 b8) cis8( d8 e8) fis8( gis8 ais8) | % bar 122
    \slurSolid b4 r8 r4. r4. | % bar 123
}
\mvtItimeLine
>>


mvtIflII = <<
\relative c''' {
    R8*9*2 | % bar 2
    b4. b4. b4. | % bar 3
    ais4.~\trill ais4 gis8 fis4. | % bar 4
    R8*9*6 | % bar 5
    b4. b4. b4. | % bar 11
    a4.~\trill a4 gis8 fis4.~ | % bar 12
    fis4. eis8( fis8 gis8) gis4.~ | % bar 13
    gis4 cis,8 fis4 e8 d4.~ | % bar 14
    d4. \once \slurDashed cis8( d8 e8) e4. | % bar 15
    d8 cis8 d8 b8 cis8 d8 e8 fis8 g8~ | % bar 16
    g8 e8 cis8 a8 b8 cis8 d8 e8 fis8 | % bar 17
    b8( a8 g8) g8( fis8 e8) e8( d8 cis8) | % bar 18
    cis8( b8 ais8) ais8( b8 cis8) d8( e8 fis8) | % bar 19
    g8( fis8 e8) d8( cis8 b8) fis8( b8 ais8) | % bar 20
    b4.\fermata r4. r4. | % bar 21
    R8*9*3 | % bar 22
    b'4. b4. b4. | % bar 25
    a4.~\trill a4 g8 fis4. | % bar 26
    \once \slurDashed g8( a8 b8) a4.~ a8 g8 a8 | % bar 27
    b8( a8 g8) g8( fis8 e8) \once \slurDashed fis8( a8 cis8) | % bar 28
    d4 a8 fis8 e8 d8 b'4.~ | % bar 29
    b8 cis8 b8 a8 b8 gis8 a4.~ | % bar 30
    a8 d8 a8 fis8 e8 d8 g4.~ | % bar 31
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 32
    fis8 b8 a8 b8 g8 e8 cis8 e8 a8~ | % bar 33
    a8 d8 cis8 d8 a8 g8 fis8 a8 d8 | % bar 34
    g,4.~ g8 fis8 e8 cis'8 d8 e8 | % bar 35
    a,4 b8 \once \slurDashed a8( g8 fis8) \once \slurDashed e8( d8 e8) | % bar 36
    d8 fis8 a8 fis4.~ fis8 a8 d8 | % bar 37
    e,4 r8 r4. r4. | % bar 38
    g4. g4. g4. | % bar 39
    fis4.~\trill fis4 e8 d8 e8 cis8 | % bar 40
    d4.~ d8 e8 d8 cis8 d8 b8 | % bar 41
    fis'4. fis4. fis4. | % bar 42
    e4.~\trill e4 d8 cis4. | % bar 43
    d4. d4. d4. | % bar 44
    cis4.~\trill cis4 b8 ais4. | % bar 45
    b4. r4. r4. | % bar 46
    R8*9 | % bar 47
    b'4. b4. b4. | % bar 48
    ais4.~\trill ais4 gis8 fis4. | % bar 49
    R8*9*6 | % bar 50
    b4. b4. b4. | % bar 56
    a4.~\trill a4 gis8 fis4.~ | % bar 57
    fis4. eis8( fis8 gis8) gis4.~ | % bar 58
    gis4 cis,8 fis4 e8 d4.~ | % bar 59
    d4. cis8( d8 e8) e4. | % bar 60
    \slurDashed d8( cis8 d8) b8( cis8 d8) e8( fis8 g8~) | % bar 61
    g8 e8 cis8 a8( b8 cis8) d8( e8 fis8) | % bar 62
    \slurSolid b8( a8 g8) g8( fis8 e8) e8( d8 cis8) | % bar 63
    cis8( b8 ais8) ais8( b8 cis8) d8( e8 fis8) | % bar 64
    g8( fis8 e8) d8( cis8 b8) fis8( b8 ais8) | % bar 65
    b4. r4. r4. | % bar 66
    R8*9*3 | % bar 67
    b'4. b4. b4. | % bar 70
    a4.~\trill a4 g8 fis4. | % bar 71
    g8 a8 b8 a4.~ a8 g8 a8 | % bar 72
    b8( a8 g8) g8( fis8 e8) \once \slurDashed fis8( a8 cis8) | % bar 73
    d4 a8 fis8 e8 d8 b'4.~ | % bar 74
    b8 cis8 b8 a8 b8 gis8 a4.~ | % bar 75
    a8 d8 a8 fis8 e8 d8 g4.~ | % bar 76
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 77
    fis8 b8 a8 b8 g8 e8 cis8 e8 a8~ | % bar 78
    a8 d8 cis8 d8 a8 g8 fis8 a8 d8 | % bar 79
    g,4.~ g8 fis8 e8 cis'8 d8 e8 | % bar 80
    a,4 b8 \once \slurDashed a8( g8 fis8) \once \slurDashed e8( d8 e8) | % bar 81
    d8 fis8 a8 fis4.~ fis8 a8 d8 | % bar 82
    e,4 r8 r4. r4. | % bar 83
    g4. g4. g4. | % bar 84
    fis4.~\trill fis4 e8 d8 e8 cis8 | % bar 85
    d4.~ d8 e8 d8 cis8 d8 b8 | % bar 86
    fis'4. fis4. fis4. | % bar 87
    e4.~\trill e4 d8 cis4. | % bar 88
    d4. d4. d4. | % bar 89
    cis4.~\trill cis4 b8 ais4. | % bar 90
    b8 cis8 d8 b8 cis8 d8 e8 fis8 g8~ | % bar 91
    g8 e8 cis8 \slurDashed a8( b8 cis8) d8( e8 fis8) | % bar 92
    b8( a8 g8) g8( fis8 e8) e8( d8 cis8) | % bar 93
    \slurSolid cis8( b8 ais8) ais8( b8 cis8) d8( e8 fis8) | % bar 94
    g8( fis8 e8) \once \slurDashed d8( cis8 b8) \once \slurDashed fis8( b8 ais8) | % bar 95
    b4 d8 fis4 d8 r4. | % bar 96
    d8( e8 fis8) d8( e8 fis8) d8( e8 fis8) | % bar 97
    d4 r8 r4. r4. | % bar 98
    R8*9 | % bar 99
    b'4. b4. b4. | % bar 100
    a4.\trill~ a4 g8 fis4. | % bar 101
    g4. g4. g4. | % bar 102
    fis4.\trill~ fis4 e8 dis4. | % bar 103
    e4. r4. r4. | % bar 104
    R8*9*4 | % bar 105
    b'4. b4. b4. | % bar 109
    a4.\trill~ a4 g8 fis4. | % bar 110
    g4 a8 b8( g8 a8) b8( a8 g8) | % bar 111
    \once \slurDashed fis4( b,8) \once \slurDashed b'4( a8) gis8( fis8 gis8) | % bar 112
    \slurDashed a8( e8 d8) cis8( e8 d8) cis8( d8 e8) | % bar 113
    \slurSolid e2.~ e4. | % bar 114
    r8 d8( e8) fis8( g8 e8) d8( e8 fis8) | % bar 115
    cis4.~ cis8 \once \slurDashed d8( e8) fis8( e8 d8) | % bar 116
    e8( fis8 g8) fis8( e8 d8) cis8( d8 e8) | % bar 117
    d8( e8 d8) fis,8( e'8 d8) fis,8( e' d) | % bar 118
    cis8( d e) cis( d e) fis4 a,8 | % bar 119
    e'4. e4. e4. | % bar 120
    d4.\trill~ d4 cis8 b4. | % bar 121
    cis8( ais8 b8) cis8( d8 e8) fis8( gis8 ais8) | % bar 122
    b4 r8 r4. r4. | % bar 123
}
\mvtItimeLine
>>


mvtIobI = <<
\relative c'' {
    \transposition c

    d4. d4. d4. | % bar 1
    cis4.~\trill cis4 b8 a4. | % bar 2
    b4 cis8 d4. e4.\trill | % bar 3
    fis2.~ fis4. | % bar 4
    R8*9*4 | % bar 5
    d4. d4. d4. | % bar 9
    cis4.~\trill cis4 b8 a4.~ | % bar 10
    \partcombineApart a4 fis'8 d8 e8 fis8 b,4 r8 | % bar 11
    r8 r8 e8 cis8 d8 e8 a,4 r8 | % bar 12
    r8 r8 d8 b8 cis8 d8 gis,4 r8 | % bar 13
    r8 r8 cis8 a8 b8 cis8 fis,4 r8 | % bar 14
    r8 r8 b8 g8 a8 b8 e,4 r8 | % bar 15
    r8 r8 \partcombineAutomatic d'8 fis4 d8 r8 r8 b8 | % bar 16
    cis4 e8 g4 e8 r8 r8 a,8 | % bar 17
    g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 18
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 19
    \slurDashed cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 20
    d8\fermata( cis8 b8) fis'2.~ | % bar 21
    fis8 a,8( b8) cis8( d8 e8) fis8( g8 e8) | % bar 22
    \slurSolid d4. d4. d4. | % bar 23
    cis4.~\trill cis4 b8 a4. | % bar 24
    r8 b8( cis8) d8( e8 fis8) g8( a8 b8) | % bar 25
    r8 a,8( b8) cis8( d8 e8) fis8( g8 a8) | % bar 26
    d,8( cis8 b8) e8( d8 cis8) fis8( e8 d8) | % bar 27
    d4 g8 e8( d8 cis8) d8( fis8 a8) | % bar 28
    fis4. fis4. fis4. | % bar 29
    e4.~\trill e4 d8 cis4. | % bar 30
    d4. d4. d4. | % bar 31
    cis4.~\trill cis4 b8 a4. | % bar 32
    g4. g4. g4. | % bar 33
    fis4.~\trill fis4 e8 d4. | % bar 34
    d'8( cis8 b8) e4.~ e8 d8 cis8 | % bar 35
    d4 g8 fis8( e8 d8) cis8( b8 cis8) | % bar 36
    d4. a4. fis4. | % bar 37
    b4.~ b4 cis8 d4.~ | % bar 38
    d4 d8 cis8 d8 b8 e4.~ | % bar 39
    \once \slurDashed e8( d8 cis8) cis8( b8 ais8) ais8( b8 cis8) | % bar 40
    b4.~ b8( ais8 b8) cis8( ais8 b8) | % bar 41
    ais8( b8 cis8) ais8( b8 cis8) b8( cis8 d8) | % bar 42
    cis8( d8 e8) e8( fis8 g8) ais,8( b8 cis8) | % bar 43
    \slurDashed fis,4( b8) d4( b8) fis4( b8) | % bar 44
    ais4( cis8) \slurSolid e4.~ e8 fis8 g8 | % bar 45
    fis4. d4. d4. | % bar 46
    cis4.~\trill cis4 b8 a4. | % bar 47
    b4 cis8 d4. e4.\trill | % bar 48
    fis2.~ fis4. | % bar 49
    R8*9*4 | % bar 50
    d4. d4. d4. | % bar 54
    cis4.~\trill cis4 b8 a4.~ | % bar 55
    \partcombineApart a4 fis'8 d8 e8 fis8 b,4 r8 | % bar 56
    r8 r8 e8 cis8 d8 e8 a,4 r8 | % bar 57
    r8 r8 d8 b8 cis8 d8 gis,4 r8 | % bar 58
    r8 r8 cis8 a8 b8 cis8 fis,4 r8 | % bar 59
    r8 r8 b8 g8 a8 b8 e,4 r8 | % bar 60
    r8 r8 \partcombineAutomatic d'8 fis4 d8 r8 r8 b8 | % bar 61
    cis4 e8 g4 e8 r8 r8 a,8 | % bar 62
    \once \slurDashed g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 63
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 64
    cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 65
    \slurDashed d8( cis8 b8) fis'2.~ | % bar 66
    fis8 a,8( b8) cis8( d8 e8) fis8( g8 e8) | % bar 67
    \slurSolid d4. d4. d4. | % bar 68
    cis4.~\trill cis4 b8 a4. | % bar 69
    r8 b8( cis8) d8( e8 fis8) g8( a8 b8) | % bar 70
    r8 a,8( b8) cis8( d8 e8) fis8( g8 a8) | % bar 71
    d,8( cis8 b8) e8( d8 cis8) fis8( e8 d8) | % bar 72
    d4 g8 e8( d8 cis8) d8( fis8 a8) | % bar 73
    fis4. fis4. fis4. | % bar 74
    e4.~\trill e4 d8 cis4. | % bar 75
    d4. d4. d4. | % bar 76
    cis4.~\trill cis4 b8 a4. | % bar 77
    g4. g4. g4. | % bar 78
    fis4.~\trill fis4 e8 d4. | % bar 79
    \once \slurDashed d'8( cis8 b8) e4.~ e8 d8 cis8 | % bar 80
    d4 g8 fis8( e8 d8) cis8( b8 cis8) | % bar 81
    d4. a4. fis4. | % bar 82
    b4.~ b4 cis8 d4.~ | % bar 83
    d4 d8 cis8 d8 b8 e4.~ | % bar 84
    \slurDashed e8( d8 cis8) cis8( b8 ais8) \slurSolid ais8( b8 cis8) | % bar 85
    b4.~ b8( ais8 b8) cis8( ais8 b8) | % bar 86
    ais8( b8 cis8) ais8( b8 cis8) b8( cis8 d8) | % bar 87
    cis8( d8 e8) e8( fis8 g8) ais,8( b8 cis8) | % bar 88
    fis,4( b8) d4( b8) fis4( b8) | % bar 89
    ais4( cis8) e4.~ e8 fis8 g8 | % bar 90
    \slurDashed fis4( d8) fis4( d8) r8 r8 b8 | % bar 91
    cis4( e8) g4( e8) r8 r8 a,8 | % bar 92
    \slurSolid g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 93
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 94
    cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 95
    d4. r8 r8 d8 fis4 d8 | % bar 96
    R8*9 | % bar 97
    d8( ais8 b8) d8( ais8 b8) \once \slurDashed d8( ais8 b8) | % bar 98
    dis4. r4. r4. | % bar 99
    r8 r8 e8 g4( fis8) e4( cis8) | % bar 100
    dis4( b8) fis4( e8) b'4( a8) | % bar 101
    g8( a8 b8) g8( a8 b8) b8( a8 g8) | % bar 102
    a8( b8 c8) a8( b8 c8) c8( b8 a8) | % bar 103
    e'4. r4. r4. | % bar 104
    R8*9*2 | % bar 105
    fis4. fis4. fis4. | % bar 107
    e4.\trill~ e4 d8 cis4. | % bar 108
    d4 e8 fis8( d8 e8) fis8( e8 d8) | % bar 109
    cis4 fis,8 fis'4 e8 dis( cis dis) | % bar 110
    e8( g8 fis8) e8( g8 fis8) e8( fis8 g8) | % bar 111
    b,2.\trill~ b4. | % bar 112
    a4\trill e8 e'4 e,8 e'4 e,8 | % bar 113
    e'4 b8 g8( a8 b8) e,8 fis'8 e8 | % bar 114
    d4. cis4. b4. | % bar 115
    ais4.\trill~ ais4 fis8 b4. | % bar 116
    cis4( d8) ais4.\trill~ ais4 b8 | % bar 117
    b4. b4. b4. | % bar 118
    a?4.~\trill a4 g8 fis4. | % bar 119
    g4.~ g8 \once \slurDashed g'8( fis8) e8( fis8 g8) | % bar 120
    b,8( d8 e8) fis8( gis8 ais8) \once \slurDashed b8( ais8 b8) | % bar 121
    g4 fis8 e8 fis8 g8 cis,8 fis8 e8 | % bar 122
    d4. d4. d4. | % bar 123
}
\mvtItimeLine
>>


mvtIobII = <<
\relative c'' {
    \transposition c

    d4. d4. d4. | % bar 1
    cis4.~\trill cis4 b8 a4. | % bar 2
    b4 cis8 d4. e4.\trill | % bar 3
    fis2.~ fis4. | % bar 4
    R8*9*4 | % bar 5
    b,4. b4. b4. | % bar 9
    a4.~\trill a4 g8 fis4.~ | % bar 10
    fis4. r8 r8 b8 gis8 a8 b8 | % bar 11
    e,4. r8 r8 e8 fis8 gis8 a8 | % bar 12
    d,4 r8 r8 r8 gis8 eis8 fis8 gis8 | % bar 13
    cis,4 r8 r8 r8 cis'8 d8 e8 fis8 | % bar 14
    b,4 r8 r8 r8 b8 cis8 d8 e8 | % bar 15
    fis4 b,8 d4 b8 r8 r8 g8 | % bar 16
    a4 cis8 e4 cis8 r8 r8 d,8 | % bar 17
    g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 18
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 19
    cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 20
    d8(\fermata cis8 b8) fis'2.~ | % bar 21
    fis8 a,8( b8) cis8( d8 e8) fis8( g8 e8) | % bar 22
    d4. d4. d4. | % bar 23
    cis4.~\trill cis4 b8 a4. | % bar 24
    r8 g8( a8) b8( cis8 d8) e8( fis8 g8) | % bar 25
    r8 fis,8( g8) a8( b8 cis8) d4.~ | % bar 26
    \once \slurDashed d8( cis8 b8) e8( d8 cis8) fis8( e8 d8) | % bar 27
    d4 g8 e8( d8 cis8) d8( fis8 a8) | % bar 28
    fis4. fis4. fis4. | % bar 29
    e4.~\trill e4 d8 cis4. | % bar 30
    d4. d4. d4. | % bar 31
    cis4.~\trill cis4 b8 a4. | % bar 32
    g4. g4. g4. | % bar 33
    fis4.~\trill fis4 e8 d4. | % bar 34
    d'8( cis8 b8) e4.~ e8 d8 cis8 | % bar 35
    d4 g8 fis8( e8 d8) cis8( b8 cis8) | % bar 36
    d4. a4. fis4. | % bar 37
    b4.~ b4 cis8 d4.~ | % bar 38
    d4 d8 cis8 d8 b8 e4.~ | % bar 39
    \once \slurDashed e8( d8 cis8) cis8( b8 ais8) ais8( b8 cis8) | % bar 40
    b4.~ \once \slurDashed b8( ais8 b8) \once \slurDashed cis8( ais8 b8) | % bar 41
    fis8( gis8 ais8) fis8( gis8 ais8) gis8( ais8 b8) | % bar 42
    ais8( b8 cis8) cis8( d8 e8) fis,8( gis8 ais8) | % bar 43
    d,4( fis8) b4( fis8) d4( fis8) | % bar 44
    fis4( ais8) cis4.~ cis8 d8 e8 | % bar 45
    d4. d4. d4. | % bar 46
    cis4.~\trill cis4 b8 a4. | % bar 47
    b4 cis8 d4. e4.\trill | % bar 48
    fis2.~ fis4. | % bar 49
    R8*9*4 | % bar 53
    b,4. b b |
    a4.~\trill a4 g8 fis4.~ | % bar 55
    fis4. r8 r8 b8 gis8 a8 b8 | % bar 56
    e,4 r8 r8 r8 e8 fis8 gis8 a8 | % bar 57
    d,4 r8 r8 r8 gis8 eis8 fis8 gis8 | % bar 58
    cis,4 r8 r8 r8 cis'8 d8 e8 fis8 | % bar 59
    b,4 r8 r8 r8 b8 cis8 d8 e8 | % bar 60
    fis4 b,8 d4 b8 r8 r8 g8 | % bar 61
    a4 cis8 e4 cis8 r8 r8 d,8 | % bar 62
    g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 63
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 64
    cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 65
    d8( cis8 b8) fis'2.~ | % bar 66
    fis8 \once \slurDashed a,8( b8) cis8( d8 e8) fis8( g8 e8) | % bar 67
    d4. d4. d4. | % bar 68
    cis4.~\trill cis4 b8 a4. | % bar 69
    r8 g8( a8) b8( cis8 d8) e8( fis8 g8) | % bar 70
    r8 fis,8( g8) a8( b8 cis8) d4.~ | % bar 71
    \once \slurDashed d8( cis8 b8) e8( d8 cis8) fis8( e8 d8) | % bar 72
    d4 g8 e8( d8 cis8) \once \slurDashed d8( fis8 a8) | % bar 73
    fis4. fis4. fis4. | % bar 74
    e4.~\trill e4 d8 cis4. | % bar 75
    d4. d4. d4. | % bar 76
    cis4.~\trill cis4 b8 a4. | % bar 77
    g4. g4. g4. | % bar 78
    fis4.~\trill fis4 e8 d4. | % bar 79
    d'8( cis8 b8) e4.~ e8 d8 cis8 | % bar 80
    d4 g8 fis8( e8 d8) cis8( b8 cis8) | % bar 81
    d4. a4. fis4. | % bar 82
    b4.~ b4 cis8 d4.~ | % bar 83
    d4 d8 cis8 d8 b8 e4.~ | % bar 84
    \once \slurDashed e8( d8 cis8) cis8( b8 ais8) ais8( b8 cis8) | % bar 85
    b4.~ \once \slurDashed b8( ais8 b8) cis8( ais8 b8) | % bar 86
    fis8( gis8 ais8) fis8( gis8 ais8) gis8( ais8 b8) | % bar 87
    ais8( b8 cis8) cis8( d8 e8) fis,8( gis8 ais8) | % bar 88
    d,4( fis8) b4( fis8) d4( fis8) | % bar 89
    fis4( ais8) cis4.~ cis8 d8 e8 | % bar 90
    d4( b8) d4( b8) r8 r8 g8 | % bar 91
    a4( cis8) e4( cis8) r8 r8 d,8 | % bar 92
    g8( fis8 e8) e'8( d8 cis8) cis8( b8 ais8) | % bar 93
    ais8( gis8 fis8) fis8( gis8 ais8) b8( cis8 d8) | % bar 94
    cis8( d8 e8) ais,8( fis8 b8) cis8( d8 e8) | % bar 95
    d4. r8 r8 b8 d4 b8 | % bar 96
    R8*9 | % bar 97
    b8( e,8 fis8) b8( e,8 fis8) b8( e,8 fis8) | % bar 98
    b4. r4. r4. | % bar 99
    r8 r8 g8 b4( a8) g4( e8) | % bar 100
    fis4( dis8) b4( e8) dis4( fis8) | % bar 101
    \once \slurDashed e8( fis8 g8) e8( fis8 g8) g8( fis8 e8) | % bar 102
    fis8( g8 a8) fis8( g8 a8) a8( g8 fis8) | % bar 103
    b4. r4. r4. | % bar 104
    R8*9*2 | % bar 105
    fis'4. fis4. fis4. | % bar 107
    e4.\trill~ e4 d8 cis4. | % bar 108
    d4 e8 fis8( d8 e8) fis8( e8 d8) | % bar 109
    cis4 fis,8 fis'4 e8 dis8( cis8 dis8) | % bar 110
    e8( b8 a8) g8( b8 a8) g8( a8 b8) | % bar 111
    b2.~ b4. | % bar 112
    a4 e8 e'4 e,8 e'4 e,8 | % bar 113
    e'4 b8 \once \slurDashed g8( a8 b8) e,8 fis'8 e8 | % bar 114
    d4. cis4. b4. | % bar 115
    ais4.\trill~ ais4 fis8 b4. | % bar 116
    cis4( d8) ais4.\trill~ ais4 b8 | % bar 117
    b4. b4. b4. | % bar 118
    a?4.~\trill a4 g8 fis4. | % bar 119
    g4.~ g8 \once \slurDashed g'8( fis8) \once \slurDashed e8( fis8 g8) | % bar 120
    b,8( d8 e8) fis8( gis8 ais8) b8( ais8 b8) | % bar 121
    g4 fis8 e8 fis8 g8 cis,8 fis8 e8 | % bar 122
    d4. d4. d4. | % bar 123
}
\mvtItimeLine
>>


mvtIvlnI = <<
\relative c''' {
    b4 fis8 \once \slurDashed d8( cis8 b8) g'4.~ | % bar 1
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 2
    fis8 b8 fis8 d8( cis8 b8) e4.~ | % bar 3
    e8 fis8 e8 d8( e8 cis8) d4.~ | % bar 4
    d8 g8 fis8 g8( e8 c8) ais8( cis8 fis8~) | % bar 5
    fis8 b8( ais8) b8 fis8 e8 d8( fis8 b8) | % bar 6
    e,4.~ e8( d8 cis8) ais'8( b8 cis8) | % bar 7
    fis,4 g8 fis8( e8 d8) cis8( b8 cis8) | % bar 8
    b4. r8 b,8( cis8) d8( cis8 b8) | % bar 9
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 10
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 11
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 12
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 13
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 14
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 15
    d4. d4. d4. | % bar 16
    cis4.~\trill cis4 b8 a4. | % bar 17
    e'4. e4. e4. | % bar 18
    d4.~\trill d4 cis8 b4.~ | % bar 19
    b4 cis8 d4.( cis8\trill) b8 cis8 | % bar 20
    b4.\fermata r8 \once \slurDashed d,8( e8) \once \slurDashed fis8( a8 gis8) | % bar 21
    a2.~ a8 g8 a8 | % bar 22
    b4. b'2.~ | % bar 23
    b4 e,8 a4 g8 fis8 g8 e8 | % bar 24
    d4. r8 r8 b8 e4.~ | % bar 25
    e4 d8 cis8 b8 a8 d4 a8 | % bar 26
    b4. g4. fis4 e8 | % bar 27
    e2.\trill d4.~ | % bar 28
    d4. d'4. d4. | % bar 29
    cis4.~\trill cis4 b8 a4. | % bar 30
    b4 fis'8 b4 fis8 d8 cis8 b8 | % bar 31
    cis4.~ cis4 e8 d8 e8 cis8 | % bar 32
    b4.~ b8 e8 g8 a8 e8 cis8 | % bar 33
    d8 fis8 e8 fis4 cis8 d4.~ | % bar 34
    d8( e8 fis8) e8( fis8 g8) e8( fis8 g8) | % bar 35
    fis8( e8 d8) a'4 a,8 g8( fis8 g8) | % bar 36
    fis4.~ fis8 a8 d8 fis4 a,8 | % bar 37
    e'4 b8 gis4 e'8 d8( e8 fis8) | % bar 38
    g4.~ g8( fis8 e8) e8( d8 cis8) | % bar 39
    cis8( b8 ais8) fis'2.~ | % bar 40
    fis8 b8 g8 e2.~ | % bar 41
    \once \slurDashed e4( cis8) e4( cis8) d4( b8) | % bar 42
    cis4( ais8) fis4( b8) ais4( e'8) | % bar 43
    \once \slurDashed d8( e8 fis8) \once \slurDashed d8( e8 fis8) fis8( e8 d8) | % bar 44
    e8( fis8 g8) e8( fis8 g8) g8( fis8 e8) | % bar 45
    b'4 fis8 \once \slurDashed d8( cis8 b8) g'4.~ | % bar 46
    g8 a8 g8 fis8 g8 e8 fis4.~ | % bar 47
    fis8 b8 fis8 \once \slurDashed d8( cis8 b8) e4.~ | % bar 48
    e8 fis8 e8 d8 e8 cis8 d4.~ | % bar 49
    d8 g8 fis8 g8 e8 c8 ais8 cis8 fis8~ | % bar 50
    fis8 b8 ais8 b8 fis8 e8 d8 fis8 b8 | % bar 51
    e,4.~ e8 d8 cis8 ais'8 b8 cis8 | % bar 52
    fis,4 g8 fis8 e8 d8 cis8 b8 cis8 | % bar 53
    b4. r8 b,8( cis8) d8( cis8 b8) | % bar 54
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 55
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 56
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 57
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 58
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 59
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 60
    d4. d4. d4. | % bar 61
    cis4.~\trill cis4 b8 a4. | % bar 62
    e'4. e4. e4. | % bar 63
    d4.~\trill d4 cis8 b4.~ | % bar 64
    b4 cis8 d4.( cis8)\trill b8 cis8 | % bar 65
    b4. r8 d,8( e8) fis8( a8 gis8) | % bar 66
    a2.~ a8 g8 a8 | % bar 67
    b4. b'2.~ | % bar 68
    b4 e,8 a4 g8 fis8 g8 e8 | % bar 69
    d4. r8 r8 b8 e4.~ | % bar 70
    e4 d8 cis8 b8 a8 d4 a8 | % bar 71
    b4. g4. fis4( e8) | % bar 72
    e2.\trill d4.~ | % bar 73
    d4. d'4. d4. | % bar 74
    cis4.~\trill cis4 b8 a4. | % bar 75
    b4 fis'8 b4 fis8 d8 cis8 b8 | % bar 76
    cis4.~ cis4 e8 d8 e8 cis8 | % bar 77
    b4.~ b8 e8 g8 a8 e8 cis8 | % bar 78
    d8 fis8 e8 fis4 cis8 d4.~ | % bar 79
    d8 e8 fis8 e8 fis8 g8 e8 fis8 g8 | % bar 80
    fis8 e8 d8 a'4 a,8 g8 fis8 g8 | % bar 81
    fis4.~ fis8 a8 d8 fis4 a,8 | % bar 82
    e'4 b8 gis4 e'8 d8 e8 fis8 | % bar 83
    g4.~ g8 fis8 e8 e8( d8 cis8) | % bar 84
    cis8( b8 ais8) fis'2.~ | % bar 85
    fis8 b8 g8 e2.~ | % bar 86
    e4( cis8) e4( cis8) d4( b8) | % bar 87
    cis4( ais8) fis4( b8) ais4( e'8) | % bar 88
    d8( e8 fis8) d8( e8 fis8) fis8( e8 d8) | % bar 89
    e8( fis8 g8) e8( fis8 g8) g8( fis8 e8) | % bar 90
    d4. d4. d4. | % bar 91
    cis4.~\trill cis4 b8 a4. | % bar 92
    e'4. e4. e4. | % bar 93
    d4.~\trill d4 cis8 b4.~ | % bar 94
    b4 cis8 d4.( cis8\trill) b8 cis8 | % bar 95
    b4. r4. r8 r8 d,8 | % bar 96
    fis4 d8 r4. r4. | % bar 97
    R8*9 | % bar 98
    a'8( g8 fis8) a8( g8 fis8) c'8( b8 a8) | % bar 99
    g8( a8 b8) b8( cis8 dis8) e8( fis8 g8) | % bar 100
    fis8( g8 a8) a8( b8 c8) dis,8( e8 fis8) | % bar 101
    b,4( e8) g4( e8) b4( e8) | % bar 102
    dis4( fis8) a4.~ a8 b8 c8 | % bar 103
    b4. r4. r4. | % bar 104
    fis,8( gis8 ais8) fis8( gis8 ais8) ais8( b8 cis8) | % bar 105
    cis8( d8 e8) cis8( d8 e8) e8( fis8 g8) | % bar 106
    fis8( ais8 b8) fis8( ais8 b8) fis8( ais8 b8) | % bar 107
    e,8( fis8 g8) e8( fis8 g8) g8( fis8 e8) | % bar 108
    d8( fis8 e8) d8( fis8 e8) d8( e8 fis8) | % bar 109
    fis2.~ fis4. | % bar 110
    e4. e,4. e4. | % bar 111
    d4.\trill~ d4 cis8 b4. | % bar 112
    cis4 d8 e8( cis8 d8) e8( d8 cis8) | % bar 113
    b4 e8 e'4 d8 cis8( b8 cis8) | % bar 114
    d8( b8 cis8) d8( e8 cis8) b8( cis8 d8) | % bar 115
    e8( cis8 d8) e4.~ e8 cis8 d8 | % bar 116
    b4 e8~ e8 cis8 d8 e8( d8 cis8) | % bar 117
    d8( cis8 d8) b'8( cis,8 d8) b'8( cis, d) | % bar 118
    g8( fis8 e8) e8( d8 cis8) b4.~ | % bar 119
    b8 e8 fis8 g8( b8 a8) b8( a8 g8) | % bar 120
    fis4. fis4. fis4. | % bar 121
    e4.\trill~ e4 d8 cis4 fis,8 | % bar 122
    fis'8 b8 fis8 d8( cis8 b8) g'4.\laissezVibrer | % bar 123
}
\mvtItimeLine
>>


mvtIvlnII = <<
\relative c'' {
    fis4 d8 b4 fis8 \once \slurDashed b8( a8 g8) | % bar 1
    cis4.~ cis8 b8 cis8 d8 e8 cis8 | % bar 2
    b4.~ b8 cis8 d8 \once \slurDashed cis8( d8 b8) | % bar 3
    fis'4 cis8 ais4.\trill b8( cis8 a8) | % bar 4
    g4.~ g4 g8 fis4 cis'8 | % bar 5
    d4 e8 fis4 ais,8 b4.~ | % bar 6
    b8 ais8 b8 cis4.~ cis8 b8 ais8 | % bar 7
    b4.~ b8 cis8 b8 \once \slurDashed ais8( gis8 ais8) | % bar 8
    fis4. r8 b,8( cis8) d8( cis8 b8) | % bar 9
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 10
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 11
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 12
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 13
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 14
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 15
    d4. d4. d4. | % bar 16
    cis4.~\trill cis4 b8 a4. | % bar 17
    g4. b4. b4. | % bar 18
    fis2.~ fis4 b8 | % bar 19
    g4. fis4. fis4. | % bar 20
    fis4.\fermata r8 \once \slurDashed d8( e8) \once \slurDashed fis8( a8 gis8) | % bar 21
    a2.~ a4 e8 | % bar 22
    fis4. fis4. e4. | % bar 23
    e4.~ e4 e8 fis4.~ | % bar 24
    fis8 b8 a8 g4 fis8 e4. | % bar 25
    fis4.~ fis4 g8 a4 fis8 | % bar 26
    d4 g8 e4.~ e8 cis8 d8 | % bar 27
    d4. cis4.\trill a4.~ | % bar 28
    a4. d'4. d4. | % bar 29
    cis4.~\trill cis4 b8 a4. | % bar 30
    b4 d8 fis4 b,8~ b8 a8 g8 | % bar 31
    a4.~ a4 e8 a4. | % bar 32
    R8*9 | % bar 33
    r4. r4. r8 r8 a8 | % bar 34
    \once \slurDashed b8( cis8 d8) a4.~ a4.~ | % bar 35
    a4 d8 fis4 d,8 e4 cis8 | % bar 36
    a8 d8 fis8 a4.~ a8 g8 fis8 | % bar 37
    gis4.~ gis4 ais8 b4.~ | % bar 38
    b4. g4.~ g8 fis8 e8 | % bar 39
    \once \slurDashed fis8( gis8 ais8) cis,4. ais'4. | % bar 40
    fis4. b,4. e4. | % bar 41
    cis4( ais'8) cis4( ais8) b4( gis8) | % bar 42
    ais4( fis8) cis4( b8) fis'4( cis'8) | % bar 43
    b8( cis8 d8) b8( cis8 d8) d8( cis8 b8) | % bar 44
    cis8( d8 e8) cis8( d8 e8) e8( d8 cis8) | % bar 45
    fis4 d8 b4 fis8 \once \slurDashed b8( a8 g8) | % bar 46
    cis4.~ cis8 b8 cis8 d8 e8 cis8 | % bar 47
    b4.~ b8 cis8 d8 \once \slurDashed cis8( d8 b8) | % bar 48
    fis'4 cis8 ais4.\trill \once \slurDashed b8( cis8 a8) | % bar 49
    g4.~ g4 g8 fis4 cis'8 | % bar 50
    d4 e8 fis4 ais,8 b4.~ | % bar 51
    b8 ais8 b8 cis4.~ cis8 b8 ais8 | % bar 52
    b4.~ b8 cis8 b8 ais8 gis8 ais8 | % bar 53
    fis4. r8 b,8( cis8) d8( cis8 b8) | % bar 54
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 55
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 56
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 57
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 58
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 59
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 60
    d4. d4. d4. | % bar 61
    cis4.~\trill cis4 b8 a4. | % bar 62
    g4. b4. b4. | % bar 63
    fis2.~ fis4 b8 | % bar 64
    g4. fis4. fis4. | % bar 65
    fis4. r8 d8( e8) fis8( a8 gis8) | % bar 66
    a2.~ a4 e8 | % bar 67
    fis4. fis4. e4. | % bar 68
    e4.~ e4 e8 fis4.~ | % bar 69
    fis8 b8 a8 g4 fis8 e4. | % bar 70
    fis4.~ fis4 g8 a4 fis8 | % bar 71
    d4 g8 e4.~ e8 cis8 d8 | % bar 72
    d4. cis4.\trill a4.~ | % bar 73
    a4. d'4. d4. | % bar 74
    cis4.~\trill cis4 b8 a4. | % bar 75
    b4 d8 fis4 b,8~ b8 a8 g8 | % bar 76
    a4.~ a4 e8 a4. | % bar 77
    R8*9 | % bar 78
    r4. r4. r8 r8 a8 | % bar 79
    b8 cis8 d8 a2.~ | % bar 80
    a4 d8 fis4 d,8 e4 cis8 | % bar 81
    a8 d8 fis8 a4.~ a8 g8 fis8 | % bar 82
    gis4.~ gis4 ais8 b4.~ | % bar 83
    b4. g4.~ g8 fis8 e8 | % bar 84
    \once \slurDashed fis8( gis8 ais8) cis,4. ais'4. | % bar 85
    fis4. b,4. e4. | % bar 86
    cis4( ais'8) cis4( ais8) b4( gis8) | % bar 87
    ais4( fis8) cis4( b8) fis'4( cis'8) | % bar 88
    b8( cis8 d8) b8( cis8 d8) d8( cis8 b8) | % bar 89
    cis8( d8 e8) cis8( d8 e8) e8( d8 cis8) | % bar 90
    b4. d4. d4. | % bar 91
    cis4.~\trill cis4 b8 a4. | % bar 92
    g4. b4.~ b4 e,8 | % bar 93
    fis2.~ fis4 b8 | % bar 94
    g4. fis4. fis4. | % bar 95
    fis4. r4. r8 r8 b,8 | % bar 96
    d4 b8 r4. r4. | % bar 97
    R8*9 | % bar 98
    fis'8( e8 dis8) fis8( e8 dis8) a'8( g8 fis8) | % bar 99
    e8( fis8 g8) g8( a8 b8) b8( a8 b8) | % bar 100
    dis8( e8 fis8) fis8( g8 a8) b,8( cis8 dis8) | % bar 101
    g,4( b8) e4( b8) g4( b8) | % bar 102
    b4( dis8) fis4.~ fis8 g8 a8 | % bar 103
    g4. r4. r4. | % bar 104
    cis,,8( d8 e8) cis8( d8 e8) fis8( gis8 ais8) | % bar 105
    ais8( b8 cis8) ais8( b8 cis8) cis8( d8 e8) | % bar 106
    d8( e8 fis8) d8( e8 fis8) d8( e8 fis8) | % bar 107
    ais,4 b8 cis8( d8 e8) e8( d8 cis8) | % bar 108
    b8( d8 cis8) b8( d8 cis8) b8( cis8 d8) | % bar 109
    fis,4. cis'4. dis4. | % bar 110
    b4. e,4. e4. | % bar 111
    d4.\trill~ d4 cis8 b4. | % bar 112
    cis4 d8 e8( cis8 d8) e8( d8 cis8) | % bar 113
    b4 e8 e'4 d8 cis8( b8 cis8) | % bar 114
    d4 cis8 b4 e,8 fis4. | % bar 115
    fis4.~ fis4 e8 \once \slurDashed d8( e8 fis8) | % bar 116
    e4 d8 cis4. fis4. | % bar 117
    fis4.~ fis8 \once \slurDashed e8( fis8) \once \slurDashed d8( e fis) | % bar 118
    e8( d8 cis8) g'8( fis8 e8) \once \slurDashed dis8( e8 fis8) | % bar 119
    b,4 b'8 e4. e,4 b'8 | % bar 120
    d4. d4. d4. | % bar 121
    cis4.\trill~ cis4 b8 ais4. | % bar 122
    b8 fis'8 d8 b4 fis8 b8 a8 g8 | % bar 123
}
\mvtItimeLine
>>


mvtIvla = <<
\relative c'' {
    \clef C
    d4 b8 fis8( e8 d8) d8( cis8 b8) | % bar 1
    e4. fis4 g8 a4. | % bar 2
    d,4.~ d8 e8 fis8 g8( fis8 g8) | % bar 3
    cis,4. fis4.~ fis8 e8 fis8 | % bar 4
    b,4.~ b4 e8 cis4 ais'8 | % bar 5
    b4 cis8 fis,4.~ fis4 d8 | % bar 6
    e8( fis8 g8) fis4.~ fis4 e8 | % bar 7
    d4 cis8 d8( g8 fis8) e8( d8 e8) | % bar 8
    d4. r8 b8( cis8) d8( cis8 b8) | % bar 9
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 10
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 11
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 12
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 13
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 14
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 15
    d4. d4. d4. | % bar 16
    cis4.~\trill cis4 b8 a4. | % bar 17
    b,4. e4. e4. | % bar 18
    ais4.~ ais4 fis8 b,4. | % bar 19
    \once \slurDashed e8( d8 cis8) fis8( e8 d8) e8( d8 cis8) | % bar 20
    d4.\fermata r8 \once \slurDashed d8( e8) fis8( a8 gis8) | % bar 21
    a2.~ a4.~ | % bar 22
    a4. a,4. gis4. | % bar 23
    a4.~ a4 e8 a4. | % bar 24
    b8( d8 c8) b4.~ b8 a8 g8 | % bar 25
    a2.~ a4 d8 | % bar 26
    d,4. a'4. a4. | % bar 27
    g8( a8 b8) a8( b8 g8) fis4.~ | % bar 28
    fis4. d''4. d4. | % bar 29
    cis4.~\trill cis4 b8 a4. | % bar 30
    b4 b8 d4 fis,8 g4 d8 | % bar 31
    e4. fis4 g8 d4. | % bar 32
    R8*9 | % bar 33
    r4. r4. r8 r8 fis8 | % bar 34
    fis4 b8 cis4.~ cis8( d8 e8) | % bar 35
    d8( cis8 b8) d4 fis,,8 a4 a8 | % bar 36
    a4.~ a8 d8( fis8) a8( cis8 d8) | % bar 37
    b4.~ b4 e,8 fis4. | % bar 38
    e4. e4.~ e8 fis8 g8 | % bar 39
    cis,4 fis8 fis4. fis4. | % bar 40
    d4. g4. g4. | % bar 41
    ais,4. r4. r4. | % bar 42
    fis'4. r4. r4. | % bar 43
    fis4. r4. r4. | % bar 44
    ais4. r4. r4. | % bar 45
    d4 b8 fis8( e8 d8) \once \slurDashed d8( cis8 b8) | % bar 46
    e4. fis4 g8 a4. | % bar 47
    d,4.~ d8 e8 fis8 g8( fis8 g8) | % bar 48
    cis,4. fis4.~ fis8 e8 fis8 | % bar 49
    b,4.~ b4 e8 cis4 ais'8 | % bar 50
    b4 cis8 fis,4.~ fis4 d8 | % bar 51
    e8( fis8 g8) fis4.~ fis4 e8 | % bar 52
    d4 cis8 d8( g8 fis8) e8( d8 e8) | % bar 53
    d4. r8 b8( cis8) d8( cis8 b8) | % bar 54
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 55
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 56
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 57
    gis,8( a8 b8) gis8( a8 b8) cis8( dis8 eis8) | % bar 58
    fis8( gis8 a8) fis8( g8 a8) b8( cis8 d8) | % bar 59
    e,8( fis8 g8) e8( fis8 g8) a8( b8 cis8) | % bar 60
    d4. d4. d4. | % bar 61
    cis4.~\trill cis4 b8 a4. | % bar 62
    b,4. e4. e4. | % bar 63
    ais4.~ ais4 fis8 b,4. | % bar 64
    e8( d8 cis8) fis8( e8 d8) e8( d8 cis8) | % bar 65
    d4. r8 d8( e8) fis8( a8 gis8) | % bar 66
    a2.~ a4.~ | % bar 67
    a4. a,4. gis4. | % bar 68
    a4.~ a4 e8 a4. | % bar 69
    b8 d8 c8 b4.~ b8 a8 g8 | % bar 70
    a2.~ a4 d8 | % bar 71
    d,4. a'4. a4. | % bar 72
    g8 a8 b8 a8 b8 g8 fis4.~ | % bar 73
    fis4. d''4. d4. | % bar 74
    cis4.~\trill cis4 b8 a4. | % bar 75
    b4 b8 d4 fis,8 g4 d8 | % bar 76
    e4. fis4 g8 d4. | % bar 77
    R8*9 | % bar 78
    r4. r4. r8 r8 fis8 | % bar 79
    fis4 b8 cis4.~ cis8 d8 e8 | % bar 80
    d8( cis8 b8) d4 fis,,8 a4 a8 | % bar 81
    a4.~ a8 d8 fis8 a8( cis8 d8) | % bar 82
    b4.~ b4 e,8 fis4. | % bar 83
    e4. e4.~ e8 fis8 g8 | % bar 84
    cis,4 fis8 fis4. fis4. | % bar 85
    d4. g4. g4. | % bar 86
    ais,4. r4. r4. | % bar 87
    fis'4. r4. r4. | % bar 88
    fis4. r4. r4. | % bar 89
    ais4. r4. r4. | % bar 90
    fis4. d'4. d4. | % bar 91
    cis4.~\trill cis4 b8 a4. | % bar 92
    b,4. e4. e4. | % bar 93
    ais4.~ ais4 fis8 b,4. | % bar 94
    e8( d8 cis8) fis8( e8 d8) e8( d8 cis8) | % bar 95
    d4. r4. r8 r8 fis,8 | % bar 96
    b4 fis8 r4. r4. | % bar 97
    R8*9 | % bar 98
    dis'8( e8 fis8) dis8( e8 fis8) dis8( e8 fis8) | % bar 99
    b,4( e8) e4( fis8) g4~ g8 | % bar 100
    a4( fis8) dis4( e8) fis4( b,8) | % bar 101
    b'4( g8) b4( g8) e4( g8) | % bar 102
    b4( fis8) dis4.~ dis4 dis8 | % bar 103
    b'4. r4. r4. | % bar 104
    ais,8( b8 cis8) ais8( b8 cis8) cis8( d8 e8) | % bar 105
    fis4( cis8) fis4( cis8) ais'4( cis,8) | % bar 106
    b'8( cis8 d8) b8( cis8 d8) b8( cis8 d8) | % bar 107
    e4 e,8 ais4 b8 cis4 fis,8 | % bar 108
    fis8( b8 g8) fis8( b8 g8) fis4 b8 | % bar 109
    cis4 cis8 a8 b8 cis8 fis,4 b8 | % bar 110
    g4. e4. e4. | % bar 111
    d4.\trill~ d4 cis8 b4. | % bar 112
    cis4 d8 \once \slurDashed e8( cis8 d8) \once \slurDashed e8( d8 cis) | % bar 113
    b4 e8 e'4 d8 cis8( b8 cis8) | % bar 114
    d4 fis,8 b,4( ais8) d4( b8) | % bar 115
    cis4.~ cis4 ais8 fis4( b8) | % bar 116
    b4. fis'4.~ fis4 cis8 | % bar 117
    b4.~ b8 g'8( fis8) b,8( g' fis) | % bar 118
    a4.~ a4 g8 fis8( g8 a8) | % bar 119
    g4. a4. b4. | % bar 120
    b2.~ b4. | % bar 121
    ais4.~ ais4 b8 e,8( d8 cis8) | % bar 122
    d8 d'8 b8 fis4 d8 d8 cis8 b8 | % bar 123
}
\mvtItimeLine
>>


mvtIsop = <<
\relative c'' {
    \autoBeamOff
    R8*9*22 | % bar 22
    d4. d4. d4. | % bar 23
    cis4.~ cis4 b8 a4. | % bar 24
    R8*9*2 | % bar 25
    b4. g4. fis4( e8) | % bar 27
    e2. d4. | % bar 28
    R8*9*8 | %36
    a'4. a4. fis4. | % bar 37
    b4.~ b4 cis8 d4. | % bar 38
    R8*9*2 | % bar 39
    d,4( e8) e4.~\trill e4 fis8 | % bar 41
    fis2.~ fis4.~ | % bar 42
    fis2.~ fis4.~ | % bar 43
    fis2.~ fis4.~ | % bar 44
    fis2.~ fis4. | % bar 45
    R8*9*22 | % bar 67
    d'4. d4. d4. | % bar 68
    cis4.~ cis4 b8 a4. | % bar 69
    R8*9*2 | % bar 70
    b4. g4. fis4( e8) | % bar 72
    e2.\trill d4. | % bar 73
    R8*9*8 | % bar 74
    a'4. a4. fis4. | % bar 82
    b4.~ b4 cis8 d4. | % bar 83
    R8*9*2 | % bar 84
    d,4( e8) e4.~\trill e4 fis8 | % bar 86
    fis2.~ fis4.~ | % bar 87
    fis2.~ fis4.~ | % bar 88
    fis2.~ fis4.~ | % bar 89
    fis2.~ fis4. | % bar 90
    R8*9*7 | % bar 91
    fis4. fis4. fis4. | % bar 98
    a4. fis2. | % bar 99
    R8*9*4 | % bar 100
    b4. ais4. b4. | % bar 104
    cis4. fis,2.~ | % bar 105
    fis2.~ fis4.~ | % bar 106
    fis2.~ fis4.~ | % bar 107
    fis2.~ fis4. | % bar 108
    R8*9*6 | % bar 114
    d'4. cis4. b4. | % bar 115
    ais4.~ ais4 fis8 b4. | % bar 116
    cis4( d8) ais4.\trill~ ais4 b8 | % bar 117
    b2.~ b4.~ | % bar 118
    b2.~ b4.~ | % bar 119
    b2.~ b4.~ | % bar 120
    b2.~ b4. | % bar 121
    R8*9*2 | %123
}
\mvtItimeLine
>>


mvtIsopLyrics = \lyricmode {
    Lieb -- ster Im -- ma -- nu -- el,
    Her -- zog der __ From -- men,
    du, mei -- ner See -- len Heil,
    komm, komm __ nur bald! __

    Du hast mir, höch -- ster Schatz,
    mein Herz ge -- nom -- men,
    so ganz vor Lie -- be brennt
    und nach __ dir wallt. __

    Nichts kann auf Er -- den
    mir Lieb -- res wer -- den, __
    als wenn ich mei -- nen Je -- sum __ stets __ be -- halt. __
}


mvtIalto = <<
\relative c'' {
    \autoBeamOff
    R8*9*20 | % bar 20
    b4. b4. b4. | % bar 21
    a4.~\trill a4 g8 fis4. | % bar 22
    fis4. fis4. e4. | % bar 23
    e4.~ e4 e8 fis4. | % bar 24
    R8*9*2 | % bar 25
    g4. e4.~ e8[ cis8] d8 | % bar 27
    d4.( cis4.) a4. | % bar 28
    R8*9*8 | % bar 29
    fis'4. fis4.~ fis8[ g8] a8 | % bar 37
    gis4.~ gis4 ais8 b4. | % bar 38
    R8*9*2 | % bar 39
    b,4. b4. e4. | % bar 41
    cis4. r4. d4 b'8 | % bar 42
    ais4. r4. cis4 e,8 | % bar 43
    d4. r4. d4 b'8 | % bar 44
    ais4. r4. cis4 e,8 | % bar 45
    d4. r4. r4. | % bar 46
    R8*9*19 | % bar 65
    b'4. b4. b4. | % bar 66
    a4.~\trill a4 g8 fis4. | % bar 67
    fis4. fis4. e4. | % bar 68
    e4.~ e4 e8 fis4. | % bar 69
    R8*9*2 | % bar 70
    g4 e4.~\trill e8[ cis8] d4 | % bar 72
    d4.( cis4.) a4. | % bar 73
    R8*9*8 | % bar 81
    fis'4. fis4.~ fis8[ g8] a8 | % bar 82
    gis4.~\trill gis4 ais8 b4. | % bar 83
    R8*9*2 | % bar 84
    b,4. b4. e4. | % bar 86
    cis4. r8 r8 fis8 d4 b'8 | % bar 87
    ais4. r4. cis4 e,8 | % bar 88
    d4. r4. d4 b'8 | % bar 89
    ais4. r4. cis4 e,8 | % bar 90
    d4. r4. r4. | % bar 91
    R8*9*4 | % bar 95
    d4. d4. d4. | % bar 96
    fis4. d2. | % bar 97
    d4. d4. d4. | % bar 98
    dis4. dis2. | % bar 99
    R8*9*4 | % bar 103
    g4. g8[( fis8 e8]) fis4( gis8) | % bar 104
    ais4( fis8) cis4. cis4. | % bar 105
    cis2. cis4. | % bar 106
    fis4. b4. b4. | % bar 107
    ais4( b8) cis4. r4. | % bar 108
    R8*9*6 | % bar 114
    fis,4. fis4. fis4. | % bar 115
    fis4.~ fis4 e8 d8[ e8] fis8 | % bar 116
    e4( d8 cis4.) fis4. | % bar 117
    fis4 b,8 b'4. b4. | % bar 118
    a4.\trill(~ a4 g8) fis4. | % bar 119
    \autoBeamOn g2.~ \melisma g8 fis8 e8 | % bar 120
    d4.~ d4 e8 \autoBeamOff \melismaEnd fis4. | % bar 121
    g4.( fis4) gis8 ais8[ b8] cis8 | % bar 122
    d4. r4. r4. | % bar 123
}
\mvtItimeLine
>>


mvtIaltoLyrics = \lyricmode {
    Lieb -- ster Im -- ma -- nu -- el, |
    lieb -- ster Im -- ma -- nu -- el,
    Her -- zog __ der From -- men,
    du, mei -- ner See -- len Heil,
    komm, komm nur bald,
    komm nur bald,
    komm nur bald,
    komm nur bald,
    komm nur bald!

    Du hast mir, höch -- ster Schatz,
    du hast mir, höch -- ster Schatz,
    mein Herz __ ge -- nom -- men,
    so ganz __ vor Lie -- be brennt
    und nach dir wallt,
    und nach dir wallt,
    nach dir wallt,
    nach dir wallt,
    nach dir wallt.

    Nichts kann auf Er -- den,
    nichts kann auf Er -- den
    mir Lieb -- res wer -- den,
    auf Er -- den
    mir Lieb -- res wer -- den,
    als wenn ich mei -- nen Je -- sum stets __ be -- halt,
    als wenn ich mei -- nen Je -- sum, Je -- sum stets be -- halt.
}


mvtItenor = <<
\relative c' {
    \autoBeamOff
    R8*9*20 | % bar 19
    d4. d4. d4. | % bar 21
    cis4.~\trill cis4 b8 a4. | % bar 22
    a4. a4. gis4. | % bar 23
    a4.~ a4 e8 a4. | % bar 24
    R8*9*2 | % bar 25
    d,4. a'4. a4. | % bar 27
    g8[( a8 b8] a8[ b8 g8]) fis4. | % bar 28
    R8*9*8 | % bar 29
    d'4. d4.~ d8[ e8] fis8 | % bar 37
    e4.~ e4 e8 fis4. | % bar 38
    R8*9*2 | % bar 39
    fis,4. g4.~ g4 b8 | % bar 41
    ais4. r4. fis'4 d8 | % bar 42
    e4 r4. e4 cis4 | % bar 43
    fis4. r4. b,4 d8 | % bar 44
    fis4. r4. fis4 cis8 | % bar 45
    b4. r4. r4. | % bar 46
    R8*9*19 | % bar 65
    d4. d4. d4. | % bar 66
    cis4.~\trill cis4 b8 a4. | % bar 67
    a4. a4. gis4. | % bar 68
    a4.~ a4 e8 a4. | % bar 69
    R8*9*2 | % bar 71
    d,4. a'4. a4. | % bar 72
    g8[( a8 b8] a8[ b8 g8]) fis4. | % bar 73
    R8*9*8 | % bar 81
    d'4. d4.~ d8[ e8] fis8 | % bar 82
    e4.~ e4 e8 fis4. | % bar 83
    R8*9*2 | % bar 85
    fis,4. g4.~ g4 b8 | % bar 86
    ais4. r8 r8 cis8 fis4 d8 | % bar 87
    e4. r4. e4 cis8 | % bar 88
    fis4. r4. b,4 d8 | % bar 89
    fis4. r4. fis4 cis8 | % bar 90
    b4. r4. r4. | % bar 91
    R8*9*5 | % bar 96
    b4. b4. b4. | % bar 97
    d4. b2.~ | % bar 98
    b4.~ b2. | % bar 99
    R8*9*4 | % bar 103
    e4. e8[( fis8 g8]) fis8[( e8 d8]) | % bar 104
    cis4. ais4. ais4. | % bar 105
    ais2. ais4. | % bar 106
    b4. fis'4. fis4. | % bar 107
    e4( cis8) ais4. r4. | % bar 108
    R8*9*6 | % bar 114
    b4. b4( ais8) b4. | % bar 115
    cis4.~ cis4 ais8 fis4 b8 | % bar 116
    b4. fis'4.~ fis4 cis8 | % bar 117
    b4 r8 r4. r4. | % bar 118
    R8*9 | % bar 119
    e4. e4. e4. | % bar 120
    d4.~ d4 cis8 b4. | % bar 121
    cis4. cis4.~ cis4 fis8 | % bar 122
    fis4. r4. r4. | % bar 123
}
\mvtItimeLine
>>


mvtItenorLyrics = \lyricmode {
    Lieb -- ster Im -- ma -- nu -- el,
    lieb -- ster Im -- ma -- nu -- el,
    Her -- zog der From -- men,
    du, mei -- ner See -- len Heil,
    komm, komm nur bald,
    komm nur bald,
    komm nur bald,
    komm nur bald,
    komm nur bald!

    Du hast mir, höch -- ster Schatz,
    du hast mir, höch -- ster Schatz,
    mein Herz ge -- nom -- men,
    so ganz vor Lie -- be brennt
    und nach __ dir wallt,
    und nach dir wallt,
    nach dir wallt,
    nach dir wallt,
    nach dir wallt.

    Nichts kann auf Er -- den __
    mir Lieb -- res wer -- den,
    auf Er -- den
    mir Lieb -- res wer -- den,
    als wenn ich mei -- nen Je -- sum stets, stets __ be -- halt,
    als wenn ich mei -- nen Je -- sum stets __ be -- halt.
}


mvtIbasso = <<
\relative c' {
    \clef F
    \autoBeamOff
    R8*9*22 | % bar 19
    b4. b,4. e4. | % bar 23
    a4.~ a8[ b8] cis8 d4. | % bar 24
    R8*9*2 | % bar 25
    b,4. cis4. d4. | % bar 27
    g4.( a4.) d,4. | % bar 28
    R8*9*8 | % bar 29
    d4. d'4. d4. | % bar 37
    d4.~ d4 cis8 b4. | % bar 38
    R8*9*2 | % bar 39
    b4( a8) g4( fis8) g4. | % bar 41
    fis4. r4. r4. | % bar 42
    fis4. r4. r4. | % bar 43
    fis4. r4. r4. | % bar 44
    fis4. r4. ais4 fis8 | % bar 45
    b4. r4. r4. | % bar 46
    R8*9*21 | % bar 67
    b4. b,4. e4. | % bar 68
    a4.~ a8[ b8] cis8 d4. | % bar 69
    R8*9*2 | % bar 70
    b,4. cis4. d4. | % bar 72
    g4.( a4.) d,4. | % bar 73
    R8*9*8 | % bar 74
    d4. d'4. d4. | % bar 82
    d4.~ d4 cis8 b4. | % bar 83
    R8*9*2 | % bar 84
    b4( a8) g4( fis8) g4. | % bar 86
    fis4. r4. r4. | % bar 87
    r8 r8 fis8 ais4 cis8 ais4 fis8 | % bar 88
    b4. r4. r4. | % bar 89
    r8 r8 fis8 ais8[( gis8 fis8] cis'4) fis,8 | % bar 90
    b4. r4. r4. | % bar 91
    R8*9*6 | % bar 92
    b4. b4. b4. | % bar 98
    b,4. b2. | % bar 99
    R8*9*4 | % bar 100
    e4. e8[( d8 cis8]) d8[( cis8 b8]) | % bar 104
    fis'4. fis4 fis8 fis4 fis8 | % bar 105
    e4.~\trill \melisma e4 d8 \melismaEnd cis4. | % bar 106
    d4. d'4. d4. | % bar 107
    cis8[( b8 cis8]) fis,2. | % bar 108
    R8*9*4 | % bar 112
    a4. a4. a4. | % bar 113
    g4.~\trill( g4 fis8) e4. | % bar 114
    \autoBeamOn fis2.~ \melisma fis4.~ | % bar 115
    fis8 e8 d8 cis8 b8 cis8 d8 cis8 b8 | % bar 116
    g'8 fis8 e8 fis4 \autoBeamOff \melismaEnd e8 fis4 fis,8 | % bar 117
    b4. r4. b4. | % bar 118
    cis4. r4. dis4. | % bar 119
    e4.~ \melisma e8[ g8 fis8] g8[ fis8] \melismaEnd e8 | % bar 120
    b'2.~ b4. | % bar 121
    b4. ais4. fis4. | % bar 122
    b,4. r4. r4. | % bar 123
}
\mvtItimeLine
>>


mvtIbassoLyrics = \lyricmode {
    Lieb -- ster Im -- ma -- nu -- el,
    Her -- zog der From -- men,
    du, mei -- ner See -- len Heil,
    komm, komm nur bald,
    bald,
    bald,
    bald,
    komm nur bald!

    Du hast mir, höch -- ster Schatz,
    mein Herz ge -- nom -- men,
    so ganz vor Lie -- be brennt
    und nach dir wallt,
    so ganz vor Lie -- be brennt
    und nach __ dir wallt.

    Nichts kann auf Er -- den
    mir Lieb -- res wer -- den,
    nichts kann auf Er -- den
    mir Lieb -- res wer -- den,
    als wenn ich mei -- nen Je -- sum stets be -- halt,
    als wenn ich mei -- nen Je -- sum stets be -- halt.
}


mvtIbc = <<
\relative c' {
    \clef F
    b4. b4. b4. | % bar 1
    a4.~\trill a4 g8 fis4. | % bar 2
    g4. g4. g4. | % bar 3
    fis4.~\trill fis4 e8 d4. | % bar 4
    e4. e4. e4. | % bar 5
    d4.~\trill d4 cis8 b4. | % bar 6
    g'8( fis8 e8) ais8( b8 cis8) e,8( d8 cis8) | % bar 7
    d8( fis8 e8) fis4. fis,4. | % bar 8
    b4. r4. r4. | % bar 9
    R8*9*6 | % bar 10
    b'4. b4. b4. | % bar 16
    a4.~\trill a4 g8 fis4. | % bar 17
    g4. g4. g4. | % bar 18
    fis4.~\trill fis4 e8 d4. | % bar 19
    e4. fis4. fis,4. | % bar 20
    b4.\fermata r8 \slurDashed b8( cis8) d8( cis8 b8) | % bar 21
    \slurSolid fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 22
    \slurDashed b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 23
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 24
    g4. g4. g4. | % bar 25
    fis4.~\trill fis4 e8 \slurSolid d8( e8 fis8) | % bar 26
    b,8( cis8 d8) cis8( d8 e8) d8( e8 fis8) | % bar 27
    g8( fis8 e8) a4 a,8 d8( a8 fis8) | % bar 28
    d4. r4. r4. | % bar 29
    R8*9 | % bar 30
    b''4. b4. b4. | % bar 31
    a4.~\trill a4 g8 fis4. | % bar 32
    R8*9 | % bar 33
    r4. r4. r8 d8 fis8 | % bar 34
    b8( a8 g8) cis8 d8 e8 g,8 fis8 e8 | % bar 35
    fis4 g8 a4. a,4. | % bar 36
    d,4.~ d8 fis8 a8 d4.~ | % bar 37
    d8 e8 fis8 \once \slurDashed e8( d8 cis8) b8( cis8 d8) | % bar 38
    e8( fis8 g8) e8( fis8 g8) cis,8( d8 e8) | % bar 39
    \slurSolid ais,8( b8 cis8) ais8( b8 cis8) fis,8( gis8 ais8) | % bar 40
    b4 a8 g4 fis8 g4.\trill | % bar 41
    fis4. r4. r4. | % bar 42
    fis4. r4. r4. | % bar 43
    fis4. r4. r4. | % bar 44
    fis4. r4. r4. | % bar 45
    b'4. b4. b4. | % bar 46
    a4.~\trill a4 g8 fis4. | % bar 47
    g4. g4. g4. | % bar 48
    fis4.~\trill fis4 e8 d4. | % bar 49
    e4. e4. e4. | % bar 50
    d4.~\trill d4 cis8 b4. | % bar 51
    g'8( fis8 e8) ais8( b8 cis8) e,8( d8 cis8) | % bar 52
    d8( fis8 e8) fis4. fis,4. | % bar 53
    b4. r4. r4. | % bar 54
    R8*9*6 | % bar 60
    b'4. b4. b4. | % bar 61
    a4.~\trill a4 g8 fis4. | % bar 62
    g4. g4. g4. | % bar 63
    fis4.~\trill fis4 e8 d4. | % bar 64
    e4. fis4. fis,4. | % bar 65
    b4. r8 b8( cis8) d8( cis8 b8) | % bar 66
    fis'8( e8 d8) cis8( b8 cis8) d8( e8 cis8) | % bar 67
    b8( cis8 d8) b8( cis8 d8) e8( fis8 gis8) | % bar 68
    a,8( b8 cis8) a8( b8 cis8) d8( e8 fis8) | % bar 69
    g4. g4. g4. | % bar 70
    fis4.~\trill fis4 e8 d8( e8 fis8) | % bar 71
    b,8( cis8 d8) cis8( d8 e8) d8( e8 fis8) | % bar 72
    \once \slurDashed g8( fis8 e8) a4 a,8 d8 a8 fis8 | % bar 73
    d4. r4. r4. | % bar 74
    R8*9 | % bar 75
    b''4. b4. b4. | % bar 76
    a4.~\trill a4 g8 fis4. | % bar 77
    R8*9 | % bar 78
    r4. r4. r8 d8 fis8 | % bar 79
    b8( a8 g8) cis8( d8 e8) g,8( fis8 e8) | % bar 80
    fis4 g8 a4. a,4. | % bar 81
    d,4.~ d8 fis8 a8 d4.~ | % bar 82
    d8 e8 fis8 e8( d8 cis8) b8( cis8 d8) | % bar 83
    \slurDashed e8( fis8 g8) e8( fis8 g8) cis,8( d8 e8) | % bar 84
    \slurSolid ais,8( b8 cis8) ais8( b8 cis8) fis,8( gis8 ais8) | % bar 85
    b4 a8 g4 fis8 g4.\trill | % bar 86
    fis4. r4. r4. | % bar 87
    fis4. r4. r4. | % bar 88
    fis4. r4. r4. | % bar 89
    fis4. r4. r4. | % bar 90
    b'4. b4. b4. | % bar 91
    a4.~\trill a4 g8 fis4. | % bar 92
    g4. g4. g4. | % bar 93
    fis4.~\trill fis4 e8 d4. | % bar 94
    e4. fis4. fis,4. | % bar 95
    b8( cis8 d8) b8( cis8 d8) b8( cis8 d8) | % bar 96
    b8( cis8 d8) b8( cis8 d8) b8( cis8 d8) | % bar 97
    b8( cis8 d8) b8( cis8 d8) b8( cis8 d8) | % bar 98
    b8( cis8 dis8) b8( cis8 dis8) b8( cis8 dis8) | % bar 99
    e4. r4. r4. | % bar 100
    e4. r4. r4. | % bar 101
    e,4. r4. r4. | % bar 102
    e4. r4. r4. | % bar 103
    e8 e'8( d8) cis8( d8 e8) d8( cis8 b8) | % bar 104
    fis'4. fis4. fis4. | % bar 105
    e4.\trill~ e4 d8 cis4. | % bar 106
    d4. d4. d4. | % bar 107
    cis4.\trill~ cis4 b8 ais4. | % bar 108
    b4. r8 b8( cis8) d8( cis8 b8) | % bar 109
    fis'8( g8 a8) fis8( g8 a8) b8( a8 b8) | % bar 110
    e,4. r8 \once \slurDashed e,8( fis8) g8( fis8 e8) | % bar 111
    b'8( cis8 d8) b8( cis8 d8) e8( d8 e8) | % bar 112
    a,4. r8 a8( b8) cis8( b8 a8) | % bar 113
    e'8( fis8 g8) e8( fis8 g8) a8( g8 a8) | % bar 114
    d,4. r8 b8( cis8) d8( cis8 b8) | % bar 115
    fis'8( e8 d8) cis8( b8 cis8) d8( cis8 b8) | % bar 116
    g'8( fis8 e8) fis4 e8 fis4 fis,8 | % bar 117
    b4. r4. b4. | % bar 118
    cis4. r4. dis4. | % bar 119
    e4. r8 \once \slurDashed e8( fis8) g8( fis8 e8) | % bar 120
    b'4. r8 \once \slurDashed b,8( cis8) d8( cis8 b8) | % bar 121
    b'4. r4. r4. | % bar 122
    b4. b4. b4. | % bar 123
}
\mvtItimeLine
>>


mvtIfigs = \figuremode {
    % p43
    s4. s <[6]> |
    <7> <6> <6> |
    <7> s <6> |
    <7 _+> s <6> |
    <7> <6\\> <6 4\+ 2> |

    <6> s4 <6\\>8 s4. |
    <6> <6 5> <6 4\+ 2> |
    <[6]>4 <6 5>8 <6 4>4. <5 _+> |
    s8*9*7 |

    % p44
    <5>4. s <6> |
    <7> s <6> |

    <6> s s |
    <6 _+> s <6> |
    <6 5> <_+> s |
    s s <6> |
    s <6>4 <7 5>8 s4. |
    <7 5> <7 5> <7 _+> |

    % p45
    s s4 <7 5>8 s4. |
    <7> s <6> |
    <7> s s |
    <6> <6 5> <9>4 <6>8 |
    <6 5>4. s s |
    s8*9*2 |

    <7>4. s <6> |
    <7> <6> <6> |
    s8*9*2 |
    <6>4. <6 5> <6 4 2> |

    % p46
    <6>4 <6 5>8 <6 4>4. <5 3> |
    s8*9 |
    <6 4\+ 2>4. <_+>4 <6\\>8 s4. |
    <7> <6> <5-> |
    <6 5> s <7 _+> |
    s <6> s |

    <_+> s s |
    <7 _+> s s |
    <6 4> s s |
    <7 _+> s s |
    <5> s <6> |
    <7> <6> <6> |

    % p47
    <7> s <6> |
    <7 _+> s <6> |
    <7> <6!> <6 4\+ 2> |
    <6> s4 <6\\>8 s4. |
    <6> <6 5> <6 4\+ 2> |
    <6>4 <6 5>8 <6 4>4. <5 _+> |

    s8*9*7 |

    % p48
    <5>4. s <6> |
    <7> s4 <6>8 <6>4. |
    <6> s s |
    <6 _+> s4 <6 4\+ 2>8 <6>4. |
    <6 5> <_+> s |

    s s <6> |
    s <6>4 <7 5>8 s4. |
    <7 5> <7 5> <7 _+> |
    s s4 <7 5>8 s4. |
    <7> s <6> |
    <7> <6>4 <6>8 s4. |

    % p49
    <6> <6 5> <9>4 <6>8 |
    <6 5>4. s s |
    s8*9*2 |
    <7>4. s <6> |
    <7> <6> <6> |

    s8*9*2 |
    <6>4. <6 5> <6 4 2> |
    <6>4 <6 5>8 <6 4>4. <5 3> |
    s8*9 |
    <6 4\+ 2>4. <_+>4 <6\\>8 s4. |

    % p50
    <7> <6> <5-> |
    <6 5> <6 5> <7 _+> |
    s <6> s |
    <_+> s s |
    <7 _+> s s |
    <6 4> s s |

    <7 _+> s s |
    s s <6> |
    <7> s4 <6>8 <6>4. |
    <6> s s |
    <6 _+> s4 <6 4\+ 2>8 <6>4. |
    <6 5> <_+> s |

    % p51
    s8*9*3 |
    <7 _+>4. s s |
    s8*9 |
    <7\\ 4 2> |

    <5 3> |
    <7\\ 4 2> |
    <5 3>4. <6\\ 5-> <6> |
    <_+> s s |
    <6 4\+ 2> s4 <6>8 <6\\>4. |
    <6> <6> <6> |

    % p52
    <6\\> s <6 5> |
    s s s |
    <5> s <7 _+> |
    s s s |
    s s <7 _+> |
    s s s |

    s s <7> |
    <[6]> s <6> |
    <_+> <6\\> <6> |
    <6> <_+> s |
    s s s |

    % p53
    <7> s <6 5> |
    s s <6> |
    s s <6> |
    <6 4 2> <[5 4 2]> <7\\ 4 2> |
    s s s |
}


mvtIbreaks = {
    <>^"Breaks left in" | %5
    \repeat unfold 5 { s8*9\noBreak } | %5
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %11
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %17
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %23
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %29
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %35
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %41
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %47
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %53
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %59
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %65
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %71
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %77
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %83
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %89
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %95
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %101
    \break\noPageBreak
    \repeat unfold 6 { s8*9\noBreak } | %107
    \pageBreak

    \repeat unfold 6 { s8*9\noBreak } | %113
    \break\noPageBreak
    \repeat unfold 5 { s8*9\noBreak } | %118
    \pageBreak

    \repeat unfold 5 { s8*9\noBreak } | %123
    \bar "|'"
}
