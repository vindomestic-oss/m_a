\version "2.19.7"

#(define TitleSize 24)

\header {
    % title = \markup\center-column{ "Liebster Immanuel," "Herzog der Frommen" }
    title = \markup{ "Liebster Immanuel, Herzog der Frommen" }
    opus = \markup{ BWV 123 }
    subtitle = \markup{ Festo Epiphanias Christi }
    composer = "J.S. Bach"
    source = \markup\center-column{
                \line{Quellen: PL-Kj Mus. ms. Bach P 875 \italic{Biblioteka Jagiellonska Kraków}}
                \line{D-B Mus. ms. Bach St 395 \italic{Stsb. Berlin – Preußischer Kulturbesitz}}
                \line{D-LEb Thomana 123 \italic{Bach-Archiv Leipzig}}
            }
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2015 Creative Commons Attribution ShareAlike 4.0}}
}

\layout {
}


mvtIpiece = \markup{I. (Coro)}
mvtIIpiece = \markup{II. Rezit}
mvtIIIpiece = \markup{III. Aria}
mvtIVpiece = \markup{IV. Rezit}
mvtVpiece = \markup{V. Aria}
mvtVIpiece = \markup{VI. Chorale}
