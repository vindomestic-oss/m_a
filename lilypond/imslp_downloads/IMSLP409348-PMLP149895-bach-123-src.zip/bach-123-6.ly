\version "2.19.7"

\include "common.ly"


mvtVItimeLine = {
    \time 3/2
    \key d \major

    \repeat volta 2 {
	s1.*5
	s1.\noBreak
	s1.\noBreak
	s1.
    }
    \repeat volta 2 {
	\once \override Score.RehearsalMark.self-alignment-X = #LEFT
	\mark \markup{la seconda volta piano}
	s1.*8
    }
}


mvtVIsop = <<
\relative c'' {
    d2 d2 d2 | % bar 1
    cis2. b4 a2\fermata | % bar 2
    b2 g2 fis4( e4) | % bar 3
    \tag SCORE {
	e1\trill^\markup\right-align{"Fl,Vln:"}
    }
    \tag FLVLN {
	e1\trill
    }
    \tag OB {
	e1
    }
	d2\fermata | % bar 4
    a'2 a2 fis2 | % bar 5
    b2. cis4 d2\fermata | % bar 6
    d,4( e4)
	\tag SCORE {
	    e2.\trill^\markup\right-align{"Ob:"}
	}
	\tag OB {
	    e2.\trill
	}
	\tag FLVLN {
	    e2.
	}
	fis4 | % bar 7
    fis1. | % bar 8

    fis2 fis2 g2 | % bar 9
    a2 fis1\fermata | % bar 10
    b2 ais2 b2 | % bar 11
    cis2 fis,1\fermata | % bar 12
    d'2 cis2 b2 | % bar 13
    ais2. fis4 b2 | % bar 14
    cis4( d4)
	\tag SCORE {
	    ais2.\trill^\markup\right-align{"Ob:"}
	}
	\tag OB {
	    ais2.\trill
	}
	\tag FLVLN {
	    ais2.
	}
        b4 | % bar 15
    b1.\fermata | % bar 16
}
\mvtVItimeLine
>>


mvtVIalto = <<
\relative c' {
    fis2 fis2 eis4( fis4) | % bar 1
    gis2 eis2 fis2\fermata | % bar 2
    g2 e2 d2 | % bar 3
    d2( cis2) a2\fermata | % bar 4
    d2 e2 d2 | % bar 5
    d2 g2 fis2\fermata | % bar 6
    fis2 e4( d4) cis4( b4) | % bar 7
    cis1. | % bar 8

    d2 d2 d2 | % bar 9
    e2 d1\fermata | % bar 10
    fis2 e2 fis2 | % bar 11
    fis2 ais1\fermata | % bar 12
    fis2 g2 e2 | % bar 13
    fis2. fis4 fis2 | % bar 14
    g2 fis2 fis2 | % bar 15
    fis1.\fermata | % bar 16
}
\mvtVItimeLine
>>


mvtVIten = <<
\relative c' {
    b2 b2 b4( a4) | % bar 1
    gis2 cis2 cis2\fermata | % bar 2
    d2 e4( a,4) a2 | % bar 3
    a2.( g4) fis2\fermata | % bar 4
    a2 a2 a2 | % bar 5
    g4( a4) b2 b2\fermata | % bar 6
    b2 b2 e2 | % bar 7
    ais,1. | % bar 8

    b2 b2 b2 | % bar 9
    a2 a1\fermata | % bar 10
    b2 cis2 d2 | % bar 11
    ais2 cis1\fermata | % bar 12
    b2 ais2 b2 | % bar 13
    cis2. cis4 b2 | % bar 14
    e4( d4) cis2 cis2 | % bar 15
    dis1.\fermata | % bar 16
}
\mvtVItimeLine
>>


mvtVIbasso = <<
\relative c {
    \clef F

    b2 b'4( a4) gis4( fis4) | % bar 1
    eis2 cis2 fis2\fermata | % bar 2
    b,2 cis2 d2 | % bar 3
    a'2( a,2) d2\fermata | % bar 4
    fis2 cis2 d2 | % bar 5
    g2 e2 b2\fermata | % bar 6
    a2 g2 g'2 | % bar 7
    fis1. | % bar 8

    b,2 d2 e2 | % bar 9
    cis2 d1\fermata | % bar 10
    d2 cis2 b2 | % bar 11
    fis'2 fis1\fermata | % bar 12
    b2 e,2 g2 | % bar 13
    fis2 e2 d2 | % bar 14
    e2 fis2 fis,2 | % bar 15
    b1.\fermata | % bar 16
}
\mvtVItimeLine
>>


mvtVIbc = <<
\relative c {
\clef F

    b2 b'4( a4) gis4( fis4) | % bar 1
    eis2 cis2 fis2\fermata | % bar 2
    b,2 cis2 d2 | % bar 3
    a'2( a,2) d2\fermata | % bar 4
    fis2 cis2 d2 | % bar 5
    g2 e2 b2\fermata | % bar 6
    a2 g2 g'2 | % bar 7
    fis1. | % bar 8

    b,2 d2 e2 | % bar 9
    cis2 d1\fermata | % bar 10
    d2 cis2 b2 | % bar 11
    fis'2 fis1\fermata | % bar 12
    b2 e,2 g2 | % bar 13
    fis2 e2 d2 | % bar 14
    e2 fis2 fis,2 | % bar 15
    b1.\fermata | % bar 16
}
\mvtVItimeLine
>>


mvtVIlyricsI = \lyricmode {
    Drum fahrt nur im -- mer -- hin,
    ihr Ei -- tel -- kei -- ten!
    Du, Je -- su, du bist mein
    und ich bin dein;

    Mein gan -- zes Le -- ben
    sei dir er -- ge -- ben,
    bis man mich ein -- stens legt
    ins Grab hin -- ein.
}


mvtVIlyricsII = \lyricmode {
    ich will mich von der Welt
    zu dir be -- rei -- ten;
    du sollt in mei -- nem Herz
    und Mun -- de sein!
}
