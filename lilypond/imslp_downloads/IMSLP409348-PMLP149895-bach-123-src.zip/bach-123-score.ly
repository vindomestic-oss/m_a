\version "2.19.7"

\include "baroque-clefs.ly"

\include "bach-123-score-common.ly"
