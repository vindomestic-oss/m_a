\version "2.19.7"

\include "bach-123-1.ly"
\include "bach-123-2.ly"
\include "bach-123-3.ly"
\include "bach-123-4.ly"
\include "bach-123-5.ly"
\include "bach-123-6.ly"


\include "common-grand-score.ly"
\include "bach-123-title.ly"
\include "bach-paged-title.ly"

\markup\null
\pageBreak


\paper {
    indent = 18
    short-indent = 8
    % ragged-last-bottom = ##t
    % system-system-spacing = #'((basic-distance . 8) (minimum-distance . 6) (padding . 1) (stretchability . 40))
}


#(set-global-staff-size 15)

% %{
\score {
    <<
        \new StaffGroup <<
            % \new Dynamics \mvtIbreaks

            %{
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup\center-column{"Flauto" "traverso"}
                \set GrandStaff.shortInstrumentName = \markup{"Fl"}

                \new Staff = staffA <<
                    \set Staff.instrumentName = "1"
                    \set Staff.shortInstrumentName = "1"

                   \mvtIflI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = "2"
                    \set Staff.shortInstrumentName = "2"

                   \mvtIflII
                >>
            >>
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup\center-column{"Oboe" "d’Amore"}
                \set GrandStaff.shortInstrumentName = \markup\center-column{"Ob." "d’A."}

                \new Staff = staffC <<
                    \set Staff.instrumentName = "1"
                    \set Staff.shortInstrumentName = "1"

                   \transpose \transpObDAm c \mvtIobI
                >>
                \new Staff = staffD <<
                    \set Staff.instrumentName = "2"
                    \set Staff.shortInstrumentName = "2"

                   \transpose \transpObDAm c \mvtIobII
                >>
            >>
            %}
            \new Staff <<
                \set Staff.instrumentName = \markup\center-column{"Flauto" "Traverso 1&2"}
                \set Staff.shortInstrumentName = "Fl."

                \partcombine
                    \mvtIflI
                    \mvtIflII
            >>
            \new Staff <<
                \set Staff.instrumentName = \markup\center-column{"Oboe" "d’Amore 1&2"}
                \set Staff.shortInstrumentName = \markup\center-column{"Ob." "d’A."}

                \partcombine
                   \transpose \transpObDAm c \mvtIobI
                   \transpose \transpObDAm c \mvtIobII
            >>
        >>

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Violino"}
                \set GrandStaff.shortInstrumentName = \markup{"Vln"}

                \new Staff = staffE <<
                    \set Staff.instrumentName = "I"
                    \set Staff.shortInstrumentName = "I"

                   \mvtIvlnI
                >>
                \new Staff = staffF <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                   \mvtIvlnII
                >>
            >>
            \new Staff = staffG <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla"

               \mvtIvla
            >>
        >>

	\new ChoirStaff <<
	    \new Staff = staffH <<
		\set Staff.instrumentName = \markup\bold{"Soprano"}
		\set Staff.shortInstrumentName = \markup\bold{"S"}

	        \new Voice = mvtIsop { \clefSoprano \mvtIsop }
	        \new Lyrics \lyricsto mvtIsop { \mvtIsopLyrics }
	    >>
	    \new Staff = staffI <<
		\set Staff.instrumentName = \markup\bold{"Alto"}
		\set Staff.shortInstrumentName = \markup\bold{"A"}

	        \new Voice = mvtIalto { \clefAlto \mvtIalto }
	        \new Lyrics \lyricsto mvtIalto { \mvtIaltoLyrics }
	    >>
	    \new Staff = staffJ <<
		\set Staff.instrumentName = \markup\bold{"Tenore"}
		\set Staff.shortInstrumentName = \markup\bold{"T"}

	        \new Voice = mvtItenor { \clefTenor \mvtItenor }
	        \new Lyrics \lyricsto mvtItenor { \mvtItenorLyrics }
	    >>
	    \new Staff = staffK <<
		\set Staff.instrumentName = \markup\bold{"Basso"}
		\set Staff.shortInstrumentName = \markup\bold{"B"}

	        \new Voice = mvtIbasso \mvtIbasso
	        \new Lyrics \lyricsto mvtIbasso { \mvtIbassoLyrics }
	    >>
	>>

        \new StaffGroup <<
            \new Staff = staffL <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                \mvtIbc
                \new FiguredBass \mvtIfigs
            >>
        >>
    >>

    \header {
	piece = \mvtIpiece
    }

    \layout {
        \context {
            \Staff {
                \override VerticalAxisGroup.staff-staff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2.5)
                       (padding . 1.0)
                       (stretchability . 70))
            }
        }
        \context {
            \Lyrics {
                \override VerticalAxisGroup.nonstaff-unrelatedstaff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2)
                       (padding . 0.8)
                       (stretchability . 70))
                \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
                    #'((basic-distance . 2)
                       (minimum-distance . 1)
                       (padding . 0.4)
                       (stretchability . 40))
            }
        }
    }

    \midi { }
}
% %}


% %{
\score {
    \new StaffGroup <<
        \new Staff = mvtIIalto <<
	    \set Staff.instrumentName = \markup\bold{Alto}
	    \set Staff.shortInstrumentName = \markup\bold{A}

            \new Voice = mvtIIalto { \clefAlto \mvtIIalto }
	    \new Lyrics \lyricsto mvtIIalto \mvtIIlyrics
        >>
        \new Staff = mvtIIbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
	    \set Staff.shortInstrumentName = \markup{B.C.}

            \mvtIIbc
	    \new FiguredBass \mvtIIfigs
        >>
       
    >>

    \header {
	piece = \mvtIIpiece
        breakbefore = ##t
    }

    \layout {
        indent = 15
    }

    \midi { }
}


\score {
    <<
        % \new Dynamics \mvtIIIbreaksBGA

        \new StaffGroup <<
	    \set StaffGroup.instrumentName = \markup\center-column{"Oboe" "d’Amore"}
	    \set StaffGroup.shortInstrumentName = \markup\center-column{"Ob." "d’A."}

	    \new Staff = mvtIIIobI <<

		\set Staff.instrumentName = "1"
		\set Staff.shortInstrumentName = "1"

		\transpose \transpObDAm c \mvtIIIobI
	    >>
	    \new Staff = mvtIIIobII <<
		\set Staff.instrumentName = "2"
		\set Staff.shortInstrumentName = "2"

		\transpose \transpObDAm c \mvtIIIobII
	    >>
	>>

        \new Staff = mvtIIIten <<
	    \set Staff.instrumentName = \markup\bold{Tenore}
	    \set Staff.shortInstrumentName = \markup\bold{T}

            \new Voice = mvtIIIten { \clefTenor \mvtIIIten }
	    \new Lyrics \lyricsto mvtIIIten \mvtIIIlyrics
        >>

        \new StaffGroup <<
            \new Staff = mvtIIIbc <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{B.C.}

                \mvtIIIbc
                \new FiguredBass \mvtIIIfigs
            >>
        >>
    >>

    \header {
	piece = \mvtIIIpiece
	% breakbefore = ##t
    }

    \layout {
        indent = 15
    }

    \midi { }
}


\score {
    \new StaffGroup <<
        \new Staff = mvtIVbasso <<
	    \set Staff.instrumentName = \markup\bold{Basso}
	    \set Staff.shortInstrumentName = \markup\bold{B}

            \new Voice = mvtIVbasso \mvtIVbasso
	    \new Lyrics \lyricsto mvtIVbasso \mvtIVlyrics
        >>
        \new Staff = mvtIVbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
	    \set Staff.shortInstrumentName = \markup{B.C.}

            \mvtIVbc
	    \new FiguredBass \mvtIVfigs
        >>
    >>

    \header {
	piece = \mvtIVpiece
	% breakbefore = ##t
    }

    \layout {
        indent = 15
    }

    \midi { }
}


\score {
    \new StaffGroup <<
        % \new Dynamics \mvtVbreaksBGA

        \new Staff = mvtVfl <<

	    \set Staff.instrumentName = \markup\center-column{"Flauto" "traverso"}
	    \set Staff.shortInstrumentName = \markup{Fl}

           \mvtVfl
        >>
        \new Staff = mvtVbasso <<
	    \set Staff.instrumentName = \markup\bold{Basso}
	    \set Staff.shortInstrumentName = \markup\bold{B}

            \new Voice = mvtVbasso \mvtVbasso
	    \new Lyrics \lyricsto mvtVbasso \mvtVlyrics
        >>
        \new Staff = mvtVbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
	    \set Staff.shortInstrumentName = \markup{B.C.}

            \mvtVbc
	    \new FiguredBass \mvtVfigs
        >>
       
    >>

    \header {
	piece = \mvtVpiece
	breakbefore = ##t
    }

    \layout { }
    \midi { }
}


\score {
    <<
        \new Dynamics {
            \set Score.tempoHideNote = ##t
            \tempo 2 = 60
        }

	\new ChoirStaff <<
	    \new Staff = mvtVIsop <<
		\set Staff.instrumentName = \markup\center-column{
						\line\bold{"Soprano"}
						"Flauto 1,2 in 8va"
						"Oboe d’amore 1,2"
						"Violino I"
					    }
		\set Staff.shortInstrumentName = \markup\bold{"S"}

	        \new Voice = mvtVIsop { \clefSoprano \keepWithTag SCORE \mvtVIsop }
		\new Lyrics \lyricsto mvtVIsop \mvtVIlyricsI
		\new Lyrics \lyricsto mvtVIsop \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIalto <<
		\set Staff.instrumentName = \markup\center-column{
						\line\bold{"Alto"}
						"Violino II"
					    }
		\set Staff.shortInstrumentName = \markup\bold{"A"}

	        \new Voice = mvtVIalto { \clefAlto \mvtVIalto }
		\new Lyrics \lyricsto mvtVIalto \mvtVIlyricsI
		\new Lyrics \lyricsto mvtVIalto \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIten <<
		\set Staff.instrumentName = \markup\center-column{
						\line\bold{"Tenore"}
						"Viola"
					    }
		\set Staff.shortInstrumentName = \markup\bold{"T"}

	        \new Voice = mvtVIten { \clefTenor \mvtVIten }
		\new Lyrics \lyricsto mvtVIten \mvtVIlyricsI
		\new Lyrics \lyricsto mvtVIten \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIbasso <<
		\set Staff.instrumentName = \markup\bold{"Basso"}
		\set Staff.shortInstrumentName = \markup\bold{"B"}

	        \new Voice = mvtVIbasso \mvtVIbasso
		\new Lyrics \lyricsto mvtVIbasso \mvtVIlyricsI
		\new Lyrics \lyricsto mvtVIbasso \mvtVIlyricsII
	    >>
	>>

        \new StaffGroup <<
            \new Staff = mvtVIbc <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{B.C.}

               \mvtVIbc
            >>
        >>
    >>

    \header {
	piece = \mvtVIpiece
	breakbefore = ##t
    }

    \layout {
        indent = 25
    }

    \midi { }
}
% %}
