\version "2.19.15"

\paper {
    oddFooterMarkup = \markup {
        \column {
            \mm-feed #4
            \fill-line {
                \on-the-fly #last-page \fromproperty #'header:copyright
            }
            \mm-feed #2
            \fill-line {
                \abs-fontsize #10 \on-the-fly #last-page \fromproperty #'header:tagline
            }
        }
    }
}
