\version "2.19.7"

\include "bach-123-1.ly"
\include "bach-123-2.ly"
\include "bach-123-3.ly"
\include "bach-123-4.ly"
\include "bach-123-5.ly"
\include "bach-123-6.ly"


\include "bach-123-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Basso Continuo"
}

\paper {
    ragged-bottom = ##f
    ragged-last-bottom = ##f
}


% %{
\score {
    \new Staff <<
           \mvtIbc
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}


\score {
    \new StaffGroup <<
        \new Staff = mvtIIalto \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize Alto}

            \new Voice = mvtIIalto \mvtIIalto
	    \new Lyrics \with {
		alignBelowContext = "mvtIIalto"
		\override LyricText #'font-size = #-1
	    } {
		\lyricsto mvtIIalto \mvtIIlyrics
	    }
        >>
        \new Staff = mvtIIbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \mvtIIbc
        >>
       
    >>

    \header {
	piece = \mvtIIpiece
	% breakbefore = ##t
    }

    \layout {
	indent = 18
    }
}


\score {
    \new Staff = mvtIIIbc <<
	\mvtIIIbc
    >>

    \header {
	piece = \mvtIIIpiece
	breakbefore = ##t
    }
}

\markup\null\pageBreak
\blankPage
\pageBreak


\score {
    \new StaffGroup <<
        \new Staff = mvtIVbasso \with { \staffSize #-3 } <<
	    \set Staff.instrumentName = \markup\bold{\normalsize Basso}

            \new Voice = mvtIVbasso \mvtIVbasso
	    \new Lyrics \with {
		alignBelowContext = "mvtIVbasso"
		\override LyricText #'font-size = #-1
	    } {
		\lyricsto mvtIVbasso \mvtIVlyrics
	    }
        >>
        \new Staff = mvtIVbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \mvtIVbc
        >>
    >>

    \header {
	piece = \mvtIVpiece
	% breakbefore = ##t
    }

    \layout {
	indent = 18
    }
}


\score {
    \new Staff = mvtVbc <<
	\mvtVbc
    >>

    \header {
	piece = \mvtVpiece
	% breakbefore = ##t
    }
}


\score {
    \new Staff = mvtVIbc <<
       \mvtVIbc
    >>

    \header {
	piece = \mvtVIpiece
    }
}
