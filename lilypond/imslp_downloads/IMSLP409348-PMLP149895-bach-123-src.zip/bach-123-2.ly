\version "2.19.7"

\include "common.ly"

mvtIItimeLine = {
    \time 4/4
    \key d \major

    s1*10 |
    \bar "|."
}


mvtIIalto = <<
\relative c' {
    \autoBeamOff

    \key d \major
    r4 r8 fis8 cis'8 cis8 d8 b8 | % bar 1
    gis8 r16 a16 b16 gis16 eis16 gis16 cis,4 r8 cis8 | % bar 2
    gis'8 b,8 b8 cis8 d8 b8 b'8 gis8 | % bar 3
    a4 r16 a16 gis16 fis16 bis8 bis8 bis8 cis8 | % bar 4
    dis8 gis,8 r16 fis16 fis16 dis16 bis8 bis8 a'8 gis8 | % bar 5
    e8 e8 r16 cis16 gis'16 a16 b4 r8 b8 | % bar 6
    d,8 d8 d'8 cis8 cis4 r16 fis,16 fis16 cis16 | % bar 7
    cis8 r16 cis16 g'16 g16 g16 e16 ais4 r8 fis8 | % bar 8
    b8. b16 b8 fis8 gis8 e8 cis'8 a8 | % bar 9
    a8[ e] r4 r2 | % bar 10
}
\mvtIItimeLine
>>


mvtIIlyrics = \lyricmode {
    Die Him -- mels- Süs -- sig -- keit,
    der Aus -- er -- wähl -- ten Lust,
    er füllt auf Er -- den schon mein Herz und Brust,
    wenn ich den Je -- sus- Na -- men nen -- ne
    und sein ver -- borg -- nes Man -- na ken -- ne:
    Gleich -- wie der Thau ein dür -- res Land er -- quickt,
    so ist mein Herz auch bei Ge -- fahr und Schmerz
    in Freu -- dig -- keit durch Je -- su Kraft ent -- zückt.
}


mvtIIbc = <<
\relative c {
    \key d \major
    \clef F
    fis1~ | % bar 1
    fis2 eis2~ | % bar 2
    eis1 | % bar 3
    fis1 | % bar 4
    bis,1 | % bar 5
    cis2 gis2~ | % bar 6
    gis2 ais2~ | % bar 7
    ais2 e'2 | % bar 8
    dis2 e2 | % bar 9
    r4 e,4 a2 | % bar 10
}
\mvtIItimeLine
>>


mvtIIfigs = \figuremode {
    <5>2. <6>4 |
    <6 4 2>2 <6> |
    <5-> <7-> |

    s <[6\\]> |
    <6 5>1 |
    s2 <6> |

    <5-> <6 5> |
    s <6> |
    <6 5> <_+> |
    s1
}
