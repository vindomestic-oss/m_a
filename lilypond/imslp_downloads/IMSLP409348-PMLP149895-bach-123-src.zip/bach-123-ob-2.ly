\version "2.19.0"

\include "bach-123-1.ly"
\include "bach-123-2.ly"
\include "bach-123-3.ly"
\include "bach-123-4.ly"
\include "bach-123-5.ly"
\include "bach-123-6.ly"

% #(set-global-staff-size 17)

\include "bach-123-title.ly"
\include "bach-paged-title.ly"

\paper {
    % page-breaking = #ly:page-turn-breaking
    % page-count = 3
    ragged-last-bottom = ##f
}

\header {
    instrument = "Oboe d’amore II"
}


\score {
    \transpose a c' \new Staff <<
	\mvtIobII
    >>

    \header {
	piece = \mvtIpiece
    }
}


\markup\null\pageBreak
\markup\Tacet{\mvtIIpiece }


\score {
    \transpose a c' \new Staff <<
	\mvtIIIobII
    >>

    \header {
	piece = \mvtIIIpiece
    }
}


\markup\Tacet{\mvtIVpiece - \mvtVpiece }


\score {
    \transpose a c' \new Staff <<
	\clef treble \keepWithTag OB \mvtVIsop
    >>

    \header {
	piece = \mvtVIpiece
    }

    \layout {
    }
}
