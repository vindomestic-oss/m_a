\version "2.19.7"

\include "common.ly"


mvtVtimeline = {
    \key d \major
    \time 4/4

    s1*37 |
    \tempo \markup\bold{"adagio"}
    s1 |
    \tempo \markup\bold{"(a tempo)"}
    s1*26 |
    \daCapo
    \bar "|."
}


mvtVfl = <<
\relative c'' {
    \key d \major
    d4.^"Solo" e16( fis16 g16 fis16 e16 d16) a'8 b8 | % bar 1
    c,4\trill b16( a16 b16 cis16) d16( cis16 b16 a16) e'8 fis8 | % bar 2
    g,4\trill fis8 gis16 a16 b8 a16 gis16 a8 b16 cis16 | % bar 3
    d8 cis16 b16 cis8 d8 fis16 gis16 a16 fis16 gis8.\trill a16 | % bar 4
    a16 e16 cis16 e16 g16 e16 cis16 e16 a,16 g'16 b,16 g'16 cis,16 g'16 fis16 e16 | % bar 5
    fis16 a16 fis16 a16 c16 a16 fis16 a16 d,16 c'16 e,16 c'16 fis,16 c'16 b16 a16 | % bar 6
    b16 g16 e16 g16 cis,16 e16 g16 b16 a16 fis16 d16 fis16 b,16 d16 fis16 a16 | % bar 7
    g16 e16 cis16 e16 a,16 cis16 e16 g16 fis8 e16 d16 a8 cis8 | % bar 8
    d4 r4 r2 | % bar 9
    R1*2 | % bar 10
    r2 r16 e16 cis16 e16 g16 e16 cis16 e16 | % bar 12
    a,16 g'16 b,16 g'16 cis,16 g'16 fis16 e16 fis16 a16 fis16 a16 c16 a16 fis16 a16 | % bar 13
    d,16 c'16 e,16 c'16 fis,16 c'16 b16 a16 b16 g16 e16 g16 cis,16 e16 g16 b16 | % bar 14
    a16 fis16 d16 fis16 b,16 d16 fis16 a16 g16 e16 cis16 e16 a,16 cis16 e16 g16 | % bar 15
    fis8 e16 d16 a8 cis8 d4 r4 | % bar 16
    r2 d4. e16( fis16 | % bar 17
    g16 fis16 e16 d16) a'8 b8 b,8( cis8) r4 | % bar 18
    R1 | % bar 19
    r2 a4. b16( cis16 | % bar 20
    d16 cis16 b16 a16) e'8 fis8 g,4\trill fis16 e16 fis16 gis16 | % bar 21
    a16 gis16 fis16 e16 b'8 cis8 fis16 d16 b16 d16 gis,16 b16 d16 fis16 | % bar 22
    e16 cis16 a16 cis16 fis,16 a16 cis16 e16 d16 b16 gis16 b16 e,16 gis16 b16 d16 | % bar 23
    c16 a fis a dis, fis a c fis c a c fis, a dis fis | % bar 24
    a4 r4 r2 | % bar 25
    a,4. b16( cis16 d16 cis16 b16 a16) e'8 fis8 | % bar 26
    g,4\trill fis8 gis16 a16 b8 a16 gis16 a8 b16 cis16 | % bar 27
    d8 cis16 b16 cis8 d16 e16 fis16 gis16 a16 fis16 gis8. a16 | % bar 28
    a4 r4 r2 | % bar 29
    d,4. e16( fis16 g16 fis16 e16 d16) a'8 r8 | % bar 30
    R1*2 | % bar 31
    d,4. \once \slurDashed e16( fis16 g16 fis16 e16 d16) a'8 b8 | % bar 33
    c,4\trill b16 a16 b16 cis16 d16 cis16 b16 a16 e'8 fis8 | % bar 34
    b16 g16 e16 g16 cis,16 e16 g16 b16 a16 fis16 d16 fis16 b,16 d16 fis16 a16 | % bar 35
    g16 e16 cis16 e16 a,16 cis16 e16 g16 f16 d16 b16 d16 gis,16 b16 d16 f16 | % bar 36
    b16 f16 d16 f16 b,16 d16 gis16 b16 d4 r4 | % bar 37
    R1 | % bar 38
    d,4. \once \slurDashed e16( fis16 g16 fis16 e16 d16) a'8 b8 | % bar 39
    c,4\trill b16 a16 b16 cis16 d16 cis16 b16 a16 e'8 fis8 | % bar 40
    g,4 fis8 gis16 a16 b8 a16 gis16 a8 b16 cis16 | % bar 41
    d8 cis16 b16 cis8 d16 e16 fis16 gis16 a16 fis16 gis8. a16 | % bar 42
    a16 e16 cis16 e16 g16 e16 cis16 e16 a,16 g'16 b,16 g'16 cis,16 g'16 fis16 e16 | % bar 43
    fis16 a16 fis16 a16 c16 a16 fis16 a16 d,16 c'16 e,16 c'16 fis,16 c'16 b16 a16 | % bar 44
    b16 g16 e16 g16 cis,16 b'16 a16 g16 a16 fis16 d16 fis16 b,16 a'16 g16 fis16 | % bar 45
    g16 e16 cis16 e16 a,16 cis16 e16 g16 fis8 e16 d16 a8 cis8 | % bar 46
    d4\fermata r4 r2 | % bar 47
    R1*3 | % bar 48
    r2 r4 r16 cis'16 b16 cis16 | % bar 51
    d16 b16 gis16 b16 e,16 gis16 b16 d16 cis16 a16 fis16 a16 d,16 fis16 a16 cis16 | % bar 52
    b16 gis16 eis16 gis16 cis,16 eis16 gis16 b16 a8 gis16 fis16 cis8 eis8 | % bar 53
    fis4 r4 r2 | % bar 54
    R1*3 | % bar 55
    b,4. cis16( d16 e16 d16 cis16 b16) fis'8 g8 | % bar 58
    a,4\trill gis16 fis16 gis16 ais16 b16 ais16 gis16 fis16 cis'8 d8 | % bar 59
    e,4\trill d16 fis'16 e16 fis16 g16 e16 cis16 e16 a,16 cis16 e16 g16 | % bar 60
    fis16 d16 b16 d16 g,16 b16 d16 fis16 e16 cis16 ais16 cis16 fis,16 ais16 cis16 e16 | % bar 61
    d16 cis16 b16 ais16 b16 cis16 d16 e16 fis2~ | % bar 62
    fis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 ais16 b16 cis16 fis,8 ais8 | % bar 63
    b4 r4 r2 | % bar 64
   
}
\mvtVtimeline
>>


mvtVbasso = <<
\relative c {
    \autoBeamOff

    \clef F
    R1*8 | % bar 1
    d4. e16[ fis16] g16[ fis16] e16[ d16] a'8 b8 | % bar 9
    c,4\trill b4 e4. fis16[ g16] | % bar 10
    a16[ g16] fis16[ e16] b'8 cis?8 d,4\trill cis8 b16 a16 | % bar 11
    gis'8 a8 cis,8 d8 a2~ | % bar 12
    a2 r2 | % bar 13
    R1*2 | % bar 14
    r2 d4. e16[ fis16] | % bar 16
    g16[ fis16] e16[ d16] a'8 b8 c,4 b4 | % bar 17
    cis4. b16[ cis16] d16[ cis16] b16[ a16] e'8 fis8 | % bar 18
    \appoggiatura fis8 g4 fis8 e16 d16 c'8 a8 dis,8. e16 | % bar 19
    e1~ | % bar 20
    e2~ e4 d16[ cis16] d8 | % bar 21
    d8[( b'8]) gis8[( a8]) d,2~ | % bar 22
    d8[ cis8]~ cis8 b16[( a16]) gis'4 b8 e,8 | % bar 23
    \autoBeamOn c'1~ \melisma | % bar 24
    c8.( b16 a16[ g16]) \melismaEnd \autoBeamOff f16 e16 d16[( b'16 gis16]) a16 cis,8 b16[ a16] | % bar 25
    a4 r4 r2 | % bar 26
    R1*2 | % bar 27
    cis'4. d16[ cis16] b16[ a16] b16[ cis16] d8 d,8 | % bar 29
    c'8[( b8]) b4 e,4. fis16[ e16] | % bar 30
    d16[ cis16] d16[ e16] fis8 b,8 a'8[( g8]) g8 fis16 e16 | % bar 31
    f8 d8 gis8. a16 a2~ | % bar 32
    a1~ | % bar 33
    a4 g16[ fis16] g8 g8[ cis,8]~ cis8 d8 | % bar 34
    g,2~ g8[ fis'8]~ fis8 e16[ d16] | % bar 35
    cis4 e8 cis16[ a16] \autoBeamOn f'2~ \melisma | % bar 36
    f2~ f8. e16 d16 cis16 d16 f16 | % bar 37
    bes8( a8) \autoBeamOff \melismaEnd gis8[( a8]) a,8( g'4) fis8 | % bar 38
    d4 r4 r2 | % bar 39
    R1*7 | % bar 40
    r2\fermata b'4. ais16[( b16]) | % bar 47
    cis16[ b16] ais16[ gis16] fis8 e8 e8[\trill( d8]) d4 | % bar 48
    gis4. fis16[ eis16] cis'8 d16[ cis16] b16[ a16] gis16[ fis16] | % bar 49
    eis8[ b'8~] b8 a16[ gis16] a8[ b16 cis16 d8] cis16[ b16] | % bar 50
    cis8 fis,8 a16[ gis16] fis16[ eis16] fis4 r4 | % bar 51
    R1*2 | % bar 52
    a4. g!16[ fis16] b8 c16[ b16] a16[ g16] fis16[ e16] | % bar 54
    dis16[ fis16 a8~] a8 g16[ fis16] g4. fis16[ e16] | % bar 55
    a8 b16[ a16] g16[ fis16] e16[ d16] cis16[ e16 b'8~] b8 ais16[ \once \set suggestAccidentals = ##t gis16] | % bar 56
    ais8[( b16 cis16] b16[ ais16]) gis16[ fis16] d'8 cis16[ b16] cis8 ais8 | % bar 57
    b4 \autoBeamOn fis2.~ \melisma | % bar 58
    fis8 e16 \once \set suggestAccidentals = ##t dis16 e2~ e16( dis16 e16 fis16 | % bar 59
    \autoBeamOff gis8) \melismaEnd ais8 b16[( cis16]) d8 \autoBeamOn d8 \melisma e16 d16 cis4~ | % bar 60
    cis8 d16 cis16 b4~ b16[ e,16] \autoBeamOff \melismaEnd fis16[ g16] d8 cis16[ b16] | % bar 61
    b4 r16 \autoBeamOn ais16 \melisma b16 cis16 d8 cis16 b16 cis8 d16 e16 | % bar 62
    fis8 e16 d16 e4~ \autoBeamOff e8 \melismaEnd d'16[ cis16] ais8. b16 | % bar 63
    b4 r4 r2 | % bar 64
}
\mvtVtimeline
>>



mvtVlyrics = \lyricmode {
    Laß, o Welt, mich aus Ver -- ach -- tung,
    laß, o Welt, mich aus Ver -- ach -- tung
    In be -- trüb -- ter Ein -- sam -- keit! __
    Laß, o Welt, mich aus Ver -- ach -- tung,
    laß, o Welt, mich aus Ver -- ach -- tung
    In be -- trüb -- ter Ein -- sam -- keit, __
    in be -- trüb -- ter Ein -- sam -- keit,
    in be -- trüb -- ter, be -- trüb -- ter Ein -- sam -- keit!

    Laß, o Welt, mich aus Ver -- ach -- tung,
    laß, o Welt, mich aus Ver -- ach -- tung
    In be -- trüb -- ter Ein -- sam -- keit, __
    in be -- trüb -- ter Ein -- sam -- keit,
    in be -- trüb -- ter Ein -- sam -- keit!

    Je -- sus, der ins Fleisch ge -- kom -- men
    Und mein O -- pfer an -- ge -- nom -- men,
    Blei -- bet bei mir al -- le -- zeit.

    Je -- sus, der ins Fleisch ge -- kom -- men
    Und mein O -- pfer an -- ge -- nom -- men,
    Blei -- bet bei mir al -- le -- zeit,
    Blei -- bet bei mir al -- le, al -- le zeit,
    al -- le, al -- le zeit.
}


mvtVbc = <<
\relative c {
    \key d \major
    \clef F
    d8^"staccato" e8 fis8 e8 d8 e8 fis8 g8 | % bar 1
    a8 fis8 g8 a8 b8 a8 g8 fis8 | % bar 2
    e8 a8 d,8 cis8 d8 e8 fis8 e8 | % bar 3
    fis gis8 a8 a,8 d8 b8 e8 e, | % bar 4
    a4 r8 a'8 cis,8 e8 a,8 cis8 | % bar 5
    d4 r8 d'8 fis,8 a8 d,8 fis8 | % bar 6
    g8 r8 e8 cis8 fis8 r8 d8 b8 | % bar 7
    e8 r8 cis8 a8 d8 g8 a8 a,8 | % bar 8
    d8 e8 fis8 e8 d8 e8 fis8 g8 | % bar 9
    a8 g16( fis16 g16 fis16 e16 dis16) e8 fis8 g8 fis8 | % bar 10
    e8 fis8 gis8 a8 b8 a16 gis16 a8 r8 | % bar 11
    r2 r4 r8 a8 | % bar 12
    cis,8 e8 a,8 cis8 d4 r8 d'8 | % bar 13
    fis,8 a8 d,8 fis8 g8 r8 e8 cis8 | % bar 14
    fis8 r8 d8 b8 e8 r8 cis8 a8 | % bar 15
    d8 g8 a8 a,8 d8 e8 fis8 e8 | % bar 16
    d8 e8 fis8 g8 a8 g16( fis16 g16 fis16 e16 d16) | % bar 17
    e8 d8 cis8 d8 e8 a8 g8 fis8 | % bar 18
    e8 d16 cis16 d8 a8 fis8 fis8 fis8 fis8 | % bar 19
    gis8 fis16( gis16 a16 gis16 fis16 e16) cis'8 d16 cis16 b8 a8 | % bar 20
    gis8 a16 b cis8 d8 e8 a,8 d8 b8 | % bar 21
    e,4 r4 r8 d''8 b8 gis8 | % bar 22
    r8 cis8 a8 fis8 r8 b8 gis8 e8 | % bar 23
    a8 g8 fis8 e8 dis8 e8 fis8 e8 | % bar 24
    dis4 r8 c'8 gis8 a8 e8 e,8 | % bar 25
    a8 b8 cis8 b8 a8 b8 cis8 d8 | % bar 26
    e8 a,8 d8 cis8 d8 e8 fis8 e8 | % bar 27
    fis8 gis8 a8 a,8 d8 b8 e8 e,8 | % bar 28
    a e' a g fis e fis d | % bar 29
    g b16 a g8 e cis b cis a | % bar 30
    b8 cis8 d8 b8 cis8 dis8 e8 cis8 | % bar 31
    d8 e16( f16 e16 d16 cis16 b16) cis8 b16( cis16 d16 cis16 b16 a16) | % bar 32
    fis'8 g16 fis16 e8 d8 cis8 d16 e16 fis8 g8 | % bar 33
    a8 d,8 g8 e8 a,4 r4 | % bar 34
    r8 g'8 e8 cis8 r8 fis8 d8 b8 | % bar 35
    r8 e8 cis8 a8 d8 c8 b8 a8 | % bar 36
    gis8 a8 b8 a8 gis4 r4 | % bar 37
    r2 a2 | % bar 38
    d8 e8 fis8 e8 d8 e8 fis8 g8 | % bar 39
    a8 fis8 g8 a8 b8 a8 g8 fis8 | % bar 40
    e8 a8 d,8 cis8 d8 e8 fis8 e8 | % bar 41
    fis8 gis8 a8 a,8 d8 b8 e8 e,8 | % bar 42
    a4 r8 a'8 cis,8 e8 a,8 cis8 | % bar 43
    d4 r8 d'8 fis,8 a8 d,8 fis8 | % bar 44
    g8 r8 e8 cis8 fis8 r8 d b | % bar 45
    e8 r8 cis8 a8 d8 g8 a8 a,8 | % bar 46
    d8\fermata e8 d8 cis8 b8 cis8 d8 e8 | % bar 47
    ais,8 cis16 b16 ais8 fis8 b8 cis16( d16 e16 d16 cis16 b16) | % bar 48
    b'8 d16 cis16 b8 gis8 a8 fis8 d8 b8 | % bar 49
    cis8 dis8 eis8 cis8 fis8 eis8 fis8 gis8 | % bar 50
    a8 d,8 b8 cis8 fis8 gis8 a8 fis8 | % bar 51
    b8 r8 gis8 e8 a8 r8 fis8 d8 | % bar 52
    gis8 r8 eis8 cis8 fis8 b8 cis8 cis,8 | % bar 53
    fis8 fis,8 fis'8 e dis e fis g16 a16 | % bar 54
    b8 b,16 cis16 dis8 b8 e8 e,8 e'8 d8 | % bar 55
    cis8 d8 e8 fis8 g8 fis8 e8 cis8 | % bar 56
    fis8 fis,8 gis8 ais8 b8 g'8 e8 fis8 | % bar 57
    b,8 cis8 d8 cis8 b8 cis8 dis8 e8 | % bar 58
    dis8 b8 e8 cis8 fis,2~ | % bar 59
    fis8 fis'8 b,8 b'8 e,8 r8 a8 a,8 | % bar 60
    d8 r8 g8 b,8 cis e fis8 fis,8 | % bar 61
    b8 cis8 d8 cis8 b8 ais16 \once \set suggestAccidentals = ##t gis16 ais8 b16 cis16 | % bar 62
    d8 b'8 ais8 b8 g8 e8 fis8 fis,8 | % bar 63
    b4 r4 r2 | % bar 64
}
\mvtVtimeline
>>


mvtVfigs = \figuremode {
}


mvtVbreaksBGA = {
    <>^"BGA breaks left in" |
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \pageBreak

    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \pageBreak

    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } |
    \pageBreak

    \repeat unfold 4 { s1\noBreak } |
    \bar "|."
}
