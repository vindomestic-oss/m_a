\version "2.19.0"

\include "bach-123-1.ly"
\include "bach-123-2.ly"
\include "bach-123-3.ly"
\include "bach-123-4.ly"
\include "bach-123-5.ly"
\include "bach-123-6.ly"

% #(set-global-staff-size 17)

\include "bach-123-title.ly"
\include "bach-paged-title.ly"

\paper {
    % page-breaking = #ly:page-turn-breaking
    % page-count = 3
    ragged-last-bottom = ##f
}

\header {
    instrument = "Violino I"
}


\score {
    \new Staff <<
	\mvtIvlnI
    >>

    \header {
	piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece - \mvtIIIpiece - \mvtIVpiece - \mvtVpiece}

\score {
    \new Staff <<
	\clef treble \keepWithTag FLVLN \mvtVIsop
    >>

    \header {
	piece = \mvtVIpiece
    }

    \layout {
    }
}
