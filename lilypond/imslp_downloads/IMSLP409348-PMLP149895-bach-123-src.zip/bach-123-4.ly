\version "2.19.7"

\include "common.ly"

mvtIVtimeLine = {
    \key d \major
    \time 4/4

    s1*10
    \bar "|."
}


mvtIVbasso = <<
\relative c {
    \autoBeamOff

    \key d \major
    \clef F

    r8 e8 b'8 gis8 d'8 b8 gis8 e8 | % bar 1
    cis8 cis8 r8 e8 c'16 c16 c16 b16 gis8 a8 | % bar 2
    a8[( e8]) r4 r4 r8 e8 | % bar 3
    a8. a16 a8 b8 cis8 cis8 ais8 fis8 | % bar 4
    b8 b8 r8 fis8 dis4 r8 b8 | % bar 5
    a'8 a8 cis8 b8 gis4 r8 gis8 | % bar 6
    e8 e8 gis8 cis,8 cis'8 gis8 eis8 cis8 | % bar 7
    fis4 r8 fis8 d8 fis8 b8 fis8 | % bar 8
    g?8 r16 e16 cis'8. d16 d8[( a8]) r4 | % bar 9
    R1\fermataMarkup | %10
}
\mvtIVtimeLine
>>


mvtIVlyrics = \lyricmode {
    Kein Höl -- len -- feind kan mich ver -- schlin -- gen,
    das schrei -- en -- de Ge -- wis -- sen schweigt.
    Was soll -- te ich der Fein -- de Zahl um -- rin -- gen?
    Der Tod hat selb -- sten kei -- ne Macht,
    mir a -- ber ist der Sieg schon zu -- ge -- dacht,
    weil sich mein Hel --fer mir, mein Je -- sus, zeigt.
}


mvtIVbc = <<
\relative c {
    \clef F
    gis1 | % bar 1
    g2 fis2 | % bar 2
    r4 e4 a2~ | % bar 3
    a2 e'2 | % bar 4
    dis2 a2 | % bar 5
    fis2 bis2 | % bar 6
    cis2 b2 | % bar 7
    ais2 b2 | % bar 8
    e2 fis4 a4 | % bar 9
    \onceCenterNoteColumn #0 d,1\fermata | % bar 10
}
\mvtIVtimeLine
>>


mvtIVfigs = \figuremode {
    <6>2 <5-> |
    <6 4 2> <6\\ 5!> |
    s4 <4>8 <_+> s2 |

    s2 <6 4\+ 2> |
    <6> <6 4\+ 2> |
    <6\\> <6> |

    s <6 4\+ 2> |
    <6>1 |
    <7 5> 4 <6> <6> <4>8 <3> |
    s1 |
}
