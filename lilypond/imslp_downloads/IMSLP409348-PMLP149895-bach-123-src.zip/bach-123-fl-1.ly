\version "2.19.0"

\include "bach-123-1.ly"
\include "bach-123-2.ly"
\include "bach-123-3.ly"
\include "bach-123-4.ly"
\include "bach-123-5.ly"
\include "bach-123-6.ly"

% #(set-global-staff-size 17)

\include "bach-123-title.ly"
\include "bach-paged-title.ly"

\paper {
    % page-breaking = #ly:page-turn-breaking
    % page-count = 3
    ragged-last-bottom = ##f
}

\header {
    instrument = "Flauto traverso I"
}


\score {
    \new Staff <<
	\mvtIflI
    >>

    \header {
	piece = \mvtIpiece
    }
}


\markup\Tacet{\mvtIIpiece - \mvtIIIpiece - \mvtIVpiece }


\score {
    \new Staff <<
	\mvtVfl
    >>

    \header {
	piece = \mvtVpiece
	breakbefore = ##t
    }
}


\score {
    \new Staff <<
	\clef treble \transpose c c' { \keepWithTag FLVLN \mvtVIsop }
    >>

    \header {
	piece = \mvtVIpiece
    }

    \layout {
    }
}
