\version "2.19.7"

\include "common.ly"


mvtIIItimeline = {
    \key a \major

    \set Score.tempoHideNote = ##t
    \tempo "Lento" 4 = 48
    s1*22 | %22
    s8 \tempo "Allegro" s2.. | %23
    s1*3 | %26
    s4 \tempo "Lento" s2. | %27
    s1*6 |
    \daCapo
    \bar "|."
}

mvtIIIobI = <<
\relative c'' {
    \transposition c

    r4 a8 gis16 fis16 bis16( cis16 dis16) fis16 a8 gis16 fis16 | % bar 1
    eis16( gis16 cis,16) e16 g8 fis16 e16 \once \slurDashed dis16( fis16 b,16) d16 fis8 e16 d16 | % bar 2
    cis16 a16 b8~ b8 gis'8~ gis16 gis,16 a8~ a8 fis'8~ | % bar 3
    fis16 fis,16 g8~ g8 e'8~ e16 cis16 d16 b16 a8 gis16\trill fis16 | % bar 4
    fis4 r4 dis'8(\Pia dis8 dis8 dis8) | % bar 5
    cis4 fis4~\For fis16 cis16 d16 b16 g16( fis16 eis16 fis16) | % bar 6
    eis16( fis16 gis16) b16 d8 cis16 b16 \once \slurDashed ais16( cis16 fis,16) a16 c8 b16 a | % bar 7
    \once \slurDashed gis16( b16 e,16) g16 b8 a16 g16 fis8[ fis'8]~ fis8 eis8 | % bar 8
    fis4.\Pia e8 dis2 | % bar 9
    cis2~ cis8 b16 cis16 d16( b16 fis'16 eis16) | % bar 10
    eis8 r8 r4 r2 | % bar 11
    R1*2 | % bar 12
    r4 d,8\f cis16 b eis16( fis16 gis16) b16 d8 cis16 b16 | % bar 14
    \once \slurDashed a16( eis16 fis16) a16 cis8\p a'8~ a8 fis8 dis4~ | % bar 15
    dis16 bis16 cis16 e16 g8 fis16 e16 dis16( fis16 b,16) d16 fis8 e16 d16 | % bar 16
    cis16 a16 b8~ b8 gis'8~ gis16 gis,16 a8~ a8 fis'8~ | % bar 17
    fis16 fis,16 g8~ g8 e'8~ e16 cis16 d8 r4 | % bar 18
    r4 fis4~\For fis16 e16 fis16 dis16 bis8. cis16 | % bar 19
    cis8 gis8 e'4~ e16 d16 e16 cis16 ais8. b16 | % bar 20
    b8 fis8 d'4~ d16 cis16 d16 b16 gis'4~ | % bar 21
    gis4~ gis8 eis8 fis8. gis16 eis8. fis16 | % bar 22
    fis4\fermata r4 r2 | % bar 23
    r8 cis16 d16 e16 cis16 a'16 a16 gis8 r8 r16 cis,16 cis16 cis16 | % bar 24
    cis8 a16 b16 cis16 a16 fis'16 fis16 e8 r8 r16 a,16 a16 a16 | % bar 25
    a8 fis16 g16 a16 fis16 fis'16 fis16 e8 a,16 b16 cis16 a16 a'16 a16 | % bar 26
    gis8 r8 r4 gis4\Pia~ gis8 fis8 | % bar 27
    fis4 r4 r2 | % bar 28
    r4 gis4~ gis8 fis16 dis16 bis8. cis16 | % bar 29
    cis2 fis2~ | % bar 30
    fis16 e16 dis16 cis16 dis4~ dis16 cis16 dis16 bis16 gis4~ | % bar 31
    gis4 r4 r2 | % bar 32
    R1 |
}
\mvtIIItimeline
>>


mvtIIIobII = <<
\relative c' {
    \transposition c

    R1 | % bar 1
    r2 r4 d8 cis16 b16 | % bar 2
    eis16( fis16 gis16) b16 d8 cis16 b16 ais16( cis16 fis,16) a16 c8 b16 a16 | % bar 3
    gis16( b16 e,16) g16 b8 a16 g16 fis4~ fis8 eis8 | % bar 4
    fis4 r4 gis8(\Pia gis8 fis8 fis8) | % bar 5
    gis8( eis8) cis8\For b16 a d16( e16 fis16) b16 d8 cis16 b16 | % bar 6
    cis16 a16 b8~ b8 gis'8~ gis16 gis,16 a8~ a8 fis'8~ | % bar 7
    fis16 fis,16 g8~ g8 e'8~ e16 cis16 d16 b16 a8( gis16\trill fis16) | % bar 8
    fis4 cis'4\Pia gis4 fis4 | % bar 9
    gis4 g16( fis16 b16) ais16 fis4 b8 a16( gis16) | % bar 10
    gis8 r8 r4 r2 | % bar 11
    r4 cis,8\For b16 a16 dis16( e16 fis16) a16 c8 b16 a16 | % bar 12
    g16( dis16 e16) g16 b8\Pia g'8~ g8 e8 cis4~ | % bar 13
    cis8 fis,8 b16 cis16 d8~ d16 cis16 b16 d16 gis4~ | % bar 14
    gis8 cis,8 fis4\p~ fis8 a,8 fis8[ bis8] | % bar 15
    gis8 eis8 cis'8\noBeam r8 r4 d,8 cis16 b16 | % bar 16
    eis16( fis16 gis16) b16 d8 cis16 b16 ais16( cis16 fis,16) a16 c8 b16 a16 | % bar 17
    gis16( b16 e,16) g16 b8 a16 g16 fis4 r4 | % bar 18
    r2 dis'2\For | % bar 19
    gis,4. cis,8 cis'2 | % bar 20
    fis,4. b,8 b'4. cis8 | % bar 21
    d16( cis16 b16 d16) eis,8 gis8 a8. b16 gis8. fis16 | % bar 22
    fis4\fermata r4 r8 gis16 a16 b16 gis16 cis16 cis16 | % bar 23
    cis8 r8 r16 e16 e16 e16 e8 e,16 fis16 gis16 e16 a16 a16 | % bar 24
    a8 r8 r16 cis16 cis16 cis16 cis8 cis,16 d16 e16 cis16 fis16 fis16 | % bar 25
    fis8 r8 r16 a16 a16 a16 a8 r8 r16 cis16 cis16 cis16 | % bar 26
    dis8 r8 r4 cis4\p~ cis16 dis16 bis16 cis16 | % bar 27
    dis4 r4 r2 | % bar 28
    r2 dis2 | % bar 29
    gis,2 cis2 | % bar 30
    fis,2 bis2 | % bar 31
    cis4 r4 r2 | % bar 32
    R1 |
}
\mvtIIItimeline
>>


mvtIIIten = <<
\relative c' {
    \autoBeamOff

    R1*4 | % bar 1
    r4 a8 gis16[ fis16] bis16[ cis16 dis16] \set melismaBusyProperties = #'() \schleifer fis16 a8
	\set melismaBusyProperties = #'( melismaBusy slurMelismaBusy tieMelismaBusy beamMelismaBusy )
	gis16[ fis16] | % bar 5
    eis16[ fis32 gis32] cis,8 r4 r2 | % bar 6
    R1*2 | % bar 7
    r4 a8 gis16[ fis16] bis16[ cis16 dis16] fis16 a8 gis16[ fis16] | % bar 9
    eis16[ fis32 gis32] cis,8 e8 e8 e16[ cis16] d8 g8 d8 | % bar 10
    d16[ b16] cis8 r8 gis'16 b,16 a16 b32[( cis32 d32 e32 fis16]) r16 a,16 gis16 e'16 | % bar 11
    cis8 r8 r4 r2 | % bar 12
    r4 g8 fis16[ e16] ais16[( b16 cis16]) e16 g8 fis16[ e16] | % bar 13
    d8 b8 r4 r2 | % bar 14
    r4 a8 gis16[ fis16] bis16[( cis16 dis16]) fis16 a8 gis16[ fis16] | % bar 15
    eis16[( fis32 gis32]) cis,8 r8 cis16 cis16 cis8 fis,8 b8 r8 | % bar 16
    r4 r8 gis'16 eis16 cis16 eis16 fis8 r8 fis16 dis16 | % bar 17
    b16 dis16 e8 r8 e16 cis16 a16 gis32[ \melisma fis32 gis32 a32 b32 cis32] d16 \melismaEnd cis16 a'16 eis16 | % bar 18
    fis8 r8 r4 r2 | % bar 19
    R1*3 | % bar 20
    r8\fermata a,16 b16 cis16 a16 e'16 e16 \autoBeamOn e16. \melisma b32 e8~ e32 a32 gis32 fis32 e32 fis32 e32 d32 | % bar 23
    cis32 b32 cis32 a32 e'8~ e32 fis32 e32 d32 cis32 e32 d32 cis32 b32 a32 b32 gis32 e'8~ e32 fis32 e32 d32 cis32 d32 cis32 b32 | % bar 24
    a32 gis32 a32 fis32 cis'8~ cis32 d32 cis32 b32 a32 cis32 b32 a32 gis32 fis32 gis32 e32 cis'8~ cis32 d32 cis32 b32 a32 b32 a32 gis32 | % bar 25
    fis32 e32 fis32 gis32 a32 b32 cis32 a32 d32 e32 d32 cis32 d32 cis32 b32 d32 cis32 b32 a32 b32 cis32 dis32 eis32 cis32 fis32 gis32 a32 gis32 fis32 e32 dis32 e32 | % bar 26
    \autoBeamOff fis8 \melismaEnd gis,8 r8 gis'16 fis16 e16[ dis16] cis16[ b16] a16[ gis16] a16[ fis16] | % bar 27
    a'8 gis8 r8 fis16 dis16 e8 cis8 gis8 bis8 | % bar 28
    cis4 r4 r2 | % bar 29
    r4 e4~ e16[ d16 e16 cis16] ais4 | % bar 30
    b4 fis'4~ fis16[ e16] fis16[ dis16] bis8 gis'16 fis16 | % bar 31
    e16[ dis16] cis16[ bis16] cis8 fis16[ eis16] fis8 a16[ gis16] e8 dis16[ cis16] | % bar 32
    cis4 r4 r2 | % bar 33
}
\mvtIIItimeline
>>


mvtIIIlyrics = \lyricmode {
    Auch die har -- te Kreu -- zes -- rei -- se,
    auch die har -- te Kreu -- zes -- rei -- se
    und der Trä -- nen bitt -- re Spei -- se
    schreckt mich nicht,
    schreckt mich nicht, mich nicht,
    auch die har -- te Kreu -- zes -- rei -- se
    und der Trä -- nen bitt -- re Spei -- se
    schreckt mich nicht, mich nicht,
    schreckt mich nicht, mich nicht,
    schreckt mich nicht, mich nicht,
    schreckt mich nicht,
    schreckt __ mich nicht, mich nicht!

    Wenn die Un -- ge -- wit -- ter to -- ben,
    sen -- det Je -- sus mir von o -- ben
    mir von o -- ben
    Heil und Licht,
    Heil __ und Licht,
    Heil __ und Licht,
    sen -- det Je -- sus mir von o -- ben
    Heil und Licht.
}


mvtIIIbc = <<
\relative c, {
    \clef F
    fis4 fis'2 bis,4 | % bar 1
    cis8 b'8 ais8 fis8 b8 b,8 b'4~ | % bar 2
    b8 gis8 eis8 cis8 fis8 e8 dis8 b8 | % bar 3
    e8 d8 cis8 a8 d8 b8 cis8 cis,8 | % bar 4
    fis4 fis'2 bis,4 | % bar 5
    b4 a8 fis8 b8 fis'8 b4~ | % bar 6
    b8 gis8 eis8 cis8 fis e dis b | % bar 7
    e8 d8 cis8 a8 d8 b8 cis8 cis,8 | % bar 8
    fis4 fis'2 bis,4 | % bar 9
    b8 b'8 ais8 e8 b' b, b'4~ | % bar 10
    b8 gis8 eis8 cis8 fis d e8 e,8 | % bar 11
    a4 a'2 dis,4 | % bar 12
    e8 g16 fis16 e8 d8 cis8 b8 ais8 fis8 | % bar 13
    b8 d16 cis16 b8 a8 gis8 fis8 eis8 cis'8 | % bar 14
    fis8 a16 gis16 fis8 e8 dis8 cis8 bis8 gis8 | % bar 15
    cis8 b'8 ais8 fis8 b8 b,8 b'4~ | % bar 16
    b8 gis8 eis8 cis8 fis8 e8 dis8 b8 | % bar 17
    e8 d8 cis8 a8 d8 b8 cis8 cis,8 | % bar 18
    fis4 a8 gis16 fis16 bis16( cis16 dis16) fis16 a8 gis16 fis16 | % bar 19
    eis16( fis16 gis16) e16 cis16( b16 ais16 gis16) ais16( b16 cis16) e16 g8 fis16 e16 | % bar 20
    dis16( e16 fis16) d16 b16( a16 gis16 fis16) gis16( a16 b16) d16 fis8 eis16 dis16 | % bar 21
    eis16( fis16 gis16) b16 d8 cis16 b16 a8 fis8 cis'8 cis,8 | % bar 22
    fis,4\fermata r4 r8 e'16 fis16 gis16 e16 a16 a16 | % bar 23
    a8 a,16 b16 cis16 a16 e'16 e16 e8 cis16 d16 e16 cis16 fis16 fis16 | % bar 24
    fis8 fis,16 gis16 a16 fis16 cis'16 cis16 cis8 a16 b16 cis16 a16 d16 d16 | % bar 25
    d8 d,16 e16 fis16 d16 a'16 a16 a8 fis16 gis16 a16 fis16 bis16 bis16 | % bar 26
    bis8 r8 r8 gis8 cis8 e8 fis8 dis8 | % bar 27
    bis8 bis'16 ais16 bis8 gis8 cis8 e,16 fis16 gis8 gis,8 | % bar 28
    cis4 e8 dis16 cis16 bis16( cis16 dis16) fis16 a8 gis16 fis16 | % bar 29
    eis16( fis16 gis16) eis?16 cis16( b16 ais16 gis16) ais16( b16 cis16) e16 g8 fis16 e16 | % bar 30
    dis16( e16 fis16) dis16 b16( a16 gis16 fis16) gis16( ais16 bis16) dis16 fis8 e16 dis16 | % bar 31
    cis16( dis16 e16) gis16 b8 a16 gis16 a8 fis8 gis8 gis,8 | % bar 32
    cis4 r4 r2 | % bar 33
}
\mvtIIItimeline
>>


mvtIIIfigs = \figuremode {
    s4 <5 3> <6\\ 4\+ 2> <7 5>8 <6> |
    <_+>4 <7 5> <_+> s |
    % Continued in autograph bc-2 (copyist W.F.Bach)
    <4\+ 2>4 <7 5> <9 -+>8 <4 2> <7! 5>4 |
    <9 _!>8 <4 2> <7 5!>4 s8 <6> <6 4> <5 _+> |
    s4 <5> <6 4\+ 2> <7 5>8 <6> |
    <4\+ 2>4 <6> s <6>8 <5!> |

    <4\+ 2>4 <7 5>8 <6> <9 _+> <4 2> <7! 5> <6> |
    <9 _+> <4! 2> <7 5> <7!> <9> <3> <6 4> <5 _> |
    s4 <5> <6 4\+ 2> <7 5>8 <6> |
    <4\+ 2>4 <6 5!> <9 4>8 <8 3> <6!>4 |
    <9 4>8 <6 4> <6>4 s8 <6> s4 |
    s4 <7> <6 4\+ 3> <7! 5>8 <6> |
    <_!> <6>

        s <4! 2> <6\\ 5!> s <7! 5> <8>16 <7> |
    <_!>8 <6> s <2> <6\\> s <7 5> <8>16 <7> |
    <9>8 <6> s <2> <6\\> s <7 5> <8>16 <7> |
    <_+>8 s <7! 5> <8>16 <7> <_+>8 s s4 |
    <4\+ 2> <7 5>8 <8>16 <7> <_+>8 <4! 2> <7! 5> s |
    <_+> <4! 2> <7 5> s s4 <_+> |

    s4 <6> <6 5> <2\+> |
    <6> <_!> <6 5> <2\+> |
    <6> <_!> <6 5> <4 2> |
    <6> <4 2\+> <6> <_+> |

    s4 s s <6> |
    s8 <6> s <6 4> <5 3> <6> s <5> |
    s4 s8 <6 4> <5 3>4 s8 <5> |
    s4 s8 <6 4> <5 3> s s <7 5> |

    <6>4 s s8 <6> <9> <6> |
    <7> <6> s4 s8 <6> <4> <_+> |
    s4 <6> <6> <4 2\+> |
    <6> <_!> <6 5> <4 2\+> |
    <6>

        <_!> <7 _+> <4\+ 2> |
    s <4\+ 2> <6> <6 4>8 <5 \+> |
    s1 |
}


mvtIIIbreaksBGA = {
    <>^"BGA breaks left in"
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 2 { s1\noBreak }
    \pageBreak

    \repeat unfold 2 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \bar "|."
}
