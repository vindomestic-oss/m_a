\version "2.19.7"

\include "bach-123-score-common.ly"
