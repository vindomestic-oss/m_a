\version "2.19.11"

\include "common.ly"

mvtIItimeLine = {
    \key g \minor

    \time 4/4
    s1*13
    \bar "|."
}


mvtIIalto = <<
\relative c'' {
    \autoBeamOff

    r4 r8 g8 d'8 r16 d16 f,8 g8 | % bar 129
    as4 r16 as16 as16 f16 d16 d16 d16 es16 f8 d8 | % bar 130
    b8 b r8 bes8 as' f8 b8. c16 | % bar 131
    c4 r8 c,8 g'4 r8 g8 | % bar 132
    des'8 des8 des8 bes8 e,8. f16 g8 c,8 | % bar 133
    as'4 r8 f8 as8. bes16 c16 c16 a16 c16 | % bar 134
    c8 fis,8 r16 d16 fis16 a16 bes8 g8 g16 d16 d8 | % bar 135
    r4 r8 d8 g8. g16 g8 a8 | % bar 136
    bes8 bes8 d8 g,8 c8 r16 g16 e8 f8 | % bar 137
    g8 c,8 bes'8 a8 f4 r8 f8 | % bar 138
    ges8 ges8 ges8 es8 a?8 a8 r8 c8 | % bar 139
    des8 g,8 r8 a16 bes16 bes8 f8 r4 | % bar 140
    R1\fermataMarkup |
}
\mvtIItimeLine
>>


mvtIIlyrics = \lyricmode {
    Mein Gott, ver -- wirf mich nicht,
    in -- dem ich mich in De -- mut vor dir beu -- ge,
    von dei -- nem An -- ge -- sicht.
    Ich weiß, wie groß dein Zorn und mein Ver -- bre -- chen ist,
    daß du zu -- gleich ein schnel -- ler Zeu -- ge
    und ein ge -- rech -- ter Rich -- ter bist.
    Ich le -- ge dir ein frei Be -- kennt -- nis dar
    und stür -- ze mich nicht in Ge -- fahr,
    die Feh -- ler mei -- ner See -- len
    zu leug -- nen, zu ver -- heh -- len. 
}


mvtIIbc = <<
\relative c {
    \clef F
    c1~ | % bar 129
    c1~ | % bar 130
    c1~ | % bar 131
    c2 bes2~ | % bar 132
    bes1 | % bar 133
    f2. es4 | % bar 134
    d2 cis'2 | % bar 135
    d4 g,4~ g2~ | % bar 136
    g2 e2~ | % bar 137
    e2 es2~ | % bar 138
    es1 | % bar 139
    e2 r4 f4 | % bar 140
    \onceCenterNoteColumn #0 bes1\fermata | % bar 141
}
\mvtIItimeLine
>>


mvtIIfigs = \figuremode {
    s2 <6- 4 2> |
    s1 |
    <5 4 2> |
    <8 5 3>2 <6 4\+> |
    s1 |
    <[_-]>2. <6>4 |
    <7 _+>2 <7- 5> |
    <_+>4 s2. |
    s2 <[6]> |
    s <6 4 2> |
    <[\FBx \FBx 3-]>1 |
    <[7- 5]> |
    s |
}
