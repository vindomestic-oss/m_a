\version "2.17.14"

\include "common.ly"

mvtIVtimeLine = {
    \time 4/4
    \key bes \major

    \tempo "a tempo"
    s1*19
    \bar "|."
}

mvtIVbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \bar "|."
}


mvtIVbreaksAuto = {
    <>^"Autograph repeats left in"
    \repeat unfold 2 { s1\noBreak } s2 \bar "" \pageBreak

    s2\noBreak \repeat unfold 3 { s1\noBreak } s2 \bar "" \break\noPageBreak
    s2\noBreak \repeat unfold 2 { s1\noBreak } s2. \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 3 { s1\noBreak } s2. \bar "" \break\noPageBreak
    s4 \repeat unfold 5 { s1\noBreak } \bar "|."
}


mvtIVvlnI = <<
\relative c'' {
    d16( bes16 a16 bes16) f8 r8 es'16( c16 bes16 c16) a8 r8 | % bar 1
    f'16( c16 bes16 c16) a8 r8 f'16( d16 c16 d16) bes8 r8 | % bar 2
    g'16( d16 c16 d16) b8 r8 g'16( es16 d16 es16) c8 r8 | % bar 3
    a'16( es16 d16 es16) c8 r8 a'16( es16 d16 es16) c8 r8 | % bar 4
    g'16( d16 c16 d16) bes8 r8 g'16( es16 d16 es16) c8 r8 | % bar 5
    g'16( d16 c16 d16) fis16( c16 bes16 c16) g'16( bes,16 a16 bes16) g8 r8 | % bar 6
    g'16( d16 c16 d16) bes8 r8 f'16( d16 c16 d16) bes8 r8 | % bar 7
    bes'16( g16 f16 g16) es8 r8 es16( bes16 as16 bes16) g8 r8 | % bar 8
    es'16( c16 bes16 c16) as8 r8 c16( a16 g16 a16) c16( a16 g16 a16) | % bar 9
    des16\Pia( bes16 a16 bes16) des16( bes16 a16 bes16) des16( bes16 a16 bes16) des16( bes16 a16 bes16) | % bar 10
    c16( f,16 e16 f16) c'16( f,16 e16 f16) bes16( f16 e16 f16) bes16( f16 e16 f16) | % bar 11
    as16( f16 e16 f16) g16( e16 d16 e16) f16( c16 bes16 c16) as8 r8 | % bar 12
    r2 es'16( c16 des16 bes16) es16( c16 des16 bes16) | % bar 13
    es16( c16 des16 bes16) es16( as,16 bes16 g16) es'16( bes16 c16 as16) es'16( bes16 c16 as16) | % bar 14
    es''16( bes16 c16 a?16) es16( bes16 c16 a16) f''16( c16 des16 bes16) f16( c16 des16 bes16) | % bar 15
    f''16( c16 des16 bes16) f16( c16 des16 bes16) bes''16( c,16 des16 bes16) g16( c,16 des16 bes16) | % bar 16
    bes''16( g16 as8) es16( c16 bes16 c16) f8 r8 f16( bes,16 as16 bes16) | % bar 17
    g'8 r8 r4 r16 d16( es16 c16) bes8( as16\trill g16) | % bar 18
    \onceCenterNoteColumn #0 g1\fermata | % bar 19
}
\mvtIVtimeLine
>>


mvtIVvlnII = <<
\relative c'' {
    bes16( f16 es16 f16) d8 r8 c'16( a16 g16 a16) es8 r8 | % bar 1
    c'16( a16 g16 a16) f8 r8 d'16( bes16 a16 bes16) f8 r8 | % bar 2
    d'16( b16 a16 b16) g8 r8 es'16( c16 b16 c16) g8 r8 | % bar 3
    es'16( c16 bes16 c16) a8 r8 es'16( c16 bes16 c16) fis,8 r8 | % bar 4
    d'16( bes16 a16 bes16) d,8 r8 es'16( c16 bes16 c16) a8 r8 | % bar 5
    d16( bes16 a bes16) c16( a g16 a16) bes16( g16 fis16 g16) d8 r8 | % bar 6
    d'16( bes16 a16 bes16 g8) r8 d'16( bes16 a16 bes16) f8 r8 | % bar 7
    g'16( es16 d16 es16) bes8 r8 bes16( g16 f16 g16) es8 r8 | % bar 8
    c'16( as16 g16 as16) es8 r8 a16( f16 e16 f16) a16( f16 e16 f16) | % bar 9
    bes16\Pia( f16 es16 f16) bes16( f16 es16 f16) bes16( g16 f16 g16) bes16( e,16 f16 e16) | % bar 10
    f16( c16 bes16 c16) f16( c16 bes16 c16) g'16( bes,16 c16 des16) g16( bes,16 c16 des16) | % bar 11
    f16( c16 bes16 c16) e16( bes16 as16 bes16) c16( as16 g16 as16) c8 r8 | % bar 12
    r2 bes2~ | % bar 13
    bes2 c2~ | % bar 14
    c2 des2~ | % bar 15
    des2~ des8 bes8 es4~ | % bar 16
    es4 c'16( as16 g16 as16) f8 r8 as16( d,16 c16 d16) | % bar 17
    bes'8 r8 r4 r16 g16( c16 as16) g8( f8) | % bar 18
    \onceCenterNoteColumn #0 es1\fermata | % bar 19
}
\mvtIVtimeLine
>>


mvtIVvla = <<
\relative c' {
    \clef C
    f16( d16 c16 d16) bes8 r8 a'16( es16 d16 es16) c8 r8 | % bar 1
    a'16( es16 d16 es16) c8 r8 bes'16( f16 es16 f16) d8 r8 | % bar 2
    b'16( f16 es16 f16) d8 r8 c'16( g16 f16 g16) es8 r8 | % bar 3
    c'16( fis,16 g16 fis16) d8 r8 c'16( fis,16 g16 fis16) a8 r8 | % bar 4
    bes16( g16 fis16 g16) g,8 r8 c'16( fis,16 g16 fis16) a8 r8 | % bar 5
    bes16( d,16 es16 d16) a'16( fis16 g16 fis16) d'16( d,16 c16 d16) bes8 r8 | % bar 6
    bes'16( g16 fis16 g16) d8 r8 bes'16( f16 es16 f16) d8 r8 | % bar 7
    g16( bes16 as16 bes16) g8 r8 g16( bes,16 c16 des16) bes8 r8 | % bar 8
    as'16( es16 des16 es16) c8 r8 f16( c16 bes16 c16) f16( c16 bes16 c16) | % bar 9
    f16\p( des16 c16 des16) f16( des16 es16 des16) bes16( e16 f16 e16) g,16( g'16 f16 g16) | % bar 10
    c,16( as16 g16 as16) c16( as16 g16 as16) des16( g,16 as16 g16) des'16( g,16 as16 g16) | % bar 11
    c16( as16 g16 as16) bes16( g16 f16 g16) as16( f16 e16 f16) c8 r8 | % bar 12
    r2 es2~ | % bar 13
    es1~ | % bar 14
    es2 bes'2~ | % bar 15
    bes1~ | % bar 16
    bes8 c8 \once \override Slur.outside-staff-priority = #50 as'16( es16 \once \set suggestAccidentals = ##t des16 es16) as8 r8 bes,16( f'16 es16 f16) | % bar 17
    es8 r8 r4 r8 es8 es8( d8) | % bar 18
    \onceCenterNoteColumn #0 bes1\fermata | % bar 19
}
\mvtIVtimeLine
>>


mvtIVbass = <<
\relative c {
    \clef F
    \autoBeamOff

    r8 f8 bes8. c16 a4 r8 f8 | % bar 1
    c'8 c8 es8 d8 bes4 r8 d8 | % bar 2
    b8 b8 c8 d8 es,8 es8 r16 es16 d16 c16 | % bar 3
    c'8 a8 bes8. c16 fis,4 r8 a8 | % bar 4
    d8[ bes8] g4 c8 a8 fis8. g16 | % bar 5
    g8 d8 r4 r4 r8 d8 | % bar 6
    g8 g8 g8 a8 bes8 bes8 c8 d8 | % bar 7
    es4 r8 bes8 g8 g8 bes8 es,8 | % bar 8
    as8 as8 r8 es'16 c16 a8 a8 r16 f16 bes16 a16 | % bar 9
    bes8 f8 des8 c16[ bes16] e4 r8 g8 | % bar 10
    c8 as8 f8 r16 f16 des'8 c8 bes8 as8 | % bar 11
    f8 f8 r4 r4 r8 c8 | % bar 12
    f8 f8 g8 as8 bes4 r8 es,8 | % bar 13
    des'8 bes16[( g16)] es8 des16\trill[ c32 des32] c4 r8 c8 | % bar 14
    ges'8 ges8 ges8 f8 des8 des8 r8 f8 | % bar 15
    bes8. bes16 c8 des8 es8 es,8 \autoBeamOn des'4~ \melisma | % bar 16
    des16 es32 des32 c16 des32 bes32 c4~ c16 as16 g16 as32 f32 bes4~ | % bar 17
    bes16 d16 \melismaEnd \autoBeamOff es16[ c16] bes8[ as16\trill g16] g4 r4 | % bar 18
    R1\fermataMarkup |
}
\mvtIVtimeLine
>>


mvtIVlyrics = \lyricmode {
    Wohl a -- ber dem, der sei -- nen Bür -- gen weiß,
    der al -- le Schuld er -- set -- zet,
    so wird die Hand -- schrift aus -- ge -- tan,
    wenn Je -- sus sie mit Blu -- te net -- zet.
    Er hef -- tet sie ans Kreu -- ze sel -- ber an,
    er wird von dei -- nen Gü -- tern, Leib und Le -- ben,
    wenn dei -- ne Ster -- be -- stun -- de schlägt,
    dem Va -- ter selbst die Rech -- nung ü -- ber -- ge -- ben.
    So mag man dei -- nen Leib, den man zum Gra -- be trägt,
    mit Sand und Staub be -- schüt -- ten,
    dein Hei -- land öff -- net dir die ew -- gen Hüt -- ten. 
}


mvtIVbc = <<
\relative c {
    \key bes \major
    \clef F
    bes8^\markup\upright{pizzicato} bes'8 bes,8 bes'8 c,8 c'8 c,8 c'8 | % bar 1
    es,8 es'8 es,8 es'8 d,8 d'8 d,8 d'8 | % bar 2
    g,,8 g'8 g,8 g'8 c,8 c'8 c,8 c'8 | % bar 3
    fis,,8 fis'8 fis,8 fis'8 d,8 d'8 d,8 d'8 | % bar 4
    bes bes' bes, bes' es,8 es'8 es,8 es'8 | % bar 5
    d,8 d'8 d,8 d'8 g,,8 g'8 g,8 g'8 | % bar 6
    bes,8 bes'8 bes,8 bes'8 as,8 as'8 as,8 as'8 | % bar 7
    g,8 g'8 g,8 g'8 des8 des'8 des,8 des'8 | % bar 8
    c,8 c'8 c,8 c'8 es,8 es'8 es,8 es'8 | % bar 9
    des,8 des'8 des,8 des'8 g,,8 g'8 g,8 g'8 | % bar 10
    as,8 as'8 as,8 as'8 bes,8 bes'8 bes,8 bes'8 | % bar 11
    c,8 c'8 c,8 c'8 f,,8 f'8 f,8 f'8 | % bar 12
    f,8 f'8 f,8 f'8 g,8 g'8 g,8 g'8 | % bar 13
    g,8 g'8 g,8 g'8 as,8 as'8 as,8 as'8 | % bar 14
    a,8 a'8 a,8 a'8 bes,8 bes'8 bes,8 bes'8 | % bar 15
    as,8 as'8 as,8 as'8 g,8 g'8 g,8 g'8 | % bar 16
    as,8 as'8 as,8 as'8 d,,8 d'8 d,8 d'8 | % bar 17
    es,8 g8 as8 bes8 c8 as8 bes8 bes8 | % bar 18
    \onceCenterNoteColumn #0 es,1\fermata | % bar 19
}
\mvtIVtimeLine
>>


mvtIVfigs = \figures {
    s2 <6> |
    <6 4 2> <6> |
    <7 _!> s |

    <7- 5> <7 _+> |
    <6> <6> |
    <6 4>4 <[5 _+]> s2 |
    <6> <6 4 2> |

    <6> <6 4 2> |
    <6-> <6 4\+ 2> |
    <6> <6\\ 5-> |

    <6> <_-> |
    <6- 4>4 <[7 _!]> s2 |
    s4 <6> <5->2 |

    <6 5-> s |
    <5-> <_-> |
    <4- 2> <6 5-> |

    <5 4->8 <[5 3]> s4 <6 5->2 |
    s8 <6> <9 7> <7- 5> <5> <7 5> <6 4> <5 3> |
    s1 |
}
