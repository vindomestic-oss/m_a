\version "2.19.7"

\header {
    title = \markup\smaller{ "Herr, gehe nicht ins Gericht" }
    subtitle = \markup{ Dominica 19 post F. Trinitatis }
    opus = "BWV 105"
    composer = "J.S. Bach"
    source = \markup\center-column{
                \line{"Quellen: D-B Mus. ms. Bach P 99"}
                \line\italic{ Staatsbibliothek zu Berlin – Preußischer Kulturbesitz }
                \line{"BGA: Bezifferung, manche Bogen, Dynamik"}
             }
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2015 Creative Commons Attribution ShareAlike 4.0}}
}

\layout {
}


mvtIpiece = \markup{I. (Coro)}
mvtIIpiece = \markup{II. Recit.}
mvtIIIpiece = \markup{III. Aria}
mvtIVpiece = \markup{IV. Recit.}
mvtVpiece = \markup{V. Aria}
mvtVIpiece = \markup{VI. Chorale}
