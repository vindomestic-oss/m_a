\version "2.19.15"

\include "bach-105-1.ly"
\include "bach-105-2.ly"
\include "bach-105-3.ly"
\include "bach-105-4.ly"
\include "bach-105-5.ly"
\include "bach-105-6.ly"

\include "bach-105-title.ly"
\include "bach-paged-title.ly"
\include "common-grand-score.ly"


\paper {
    indent = #14
    short-indent = #6
}


#(set-global-staff-size 15)


\markup\null\pageBreak


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics \mvtIbreaks
        % \new Dynamics \mvtIbreaksAuto

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup\center-column{"Oboi" "Violini"}
                \set GrandStaff.shortInstrumentName = \markup\center-column{"Ob./V."}

                \new Staff = staffA <<

                    \set Staff.instrumentName = "I + corno"
                    \set Staff.shortInstrumentName = "I+cor"

                    \mvtIobI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                    \mvtIobII
                >>
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla."

                \mvtIvla
            >>
        >>

        \new ChoirStaff <<
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup\bold{Soprano}
                \set Staff.shortInstrumentName = \markup\bold{S.}

               \new Voice = mvtIsoprano { \clefSoprano \mvtIsoprano }
               \new Lyrics \lyricsto mvtIsoprano \mvtIsopranoLyrics
            >>
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\bold{Alto}
                \set Staff.shortInstrumentName = \markup\bold{A.}

               \new Voice = mvtIalto { \clefAlto \mvtIalto }
               \new Lyrics \lyricsto mvtIalto \mvtIaltoLyrics
            >>
            \new Staff = staffF <<
                \set Staff.instrumentName = \markup\bold{Tenore}
                \set Staff.shortInstrumentName = \markup\bold{T.}

               \new Voice = mvtItenor { \clefTenor \mvtItenor }
               \new Lyrics \lyricsto mvtItenor \mvtItenorLyrics
            >>
            \new Staff = staffG <<
                \set Staff.instrumentName = \markup\bold{Basso}
                \set Staff.shortInstrumentName = \markup\bold{B.}

               \new Voice = mvtIbass { \mvtIbass }
               \new Lyrics \lyricsto mvtIbass \mvtIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffH <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

               \dynamicUp \mvtIbc
               \mvtIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtIpiece
    }

    \layout {
        short-indent = #8
    }

    \midi { }
}
% %}


% %{
\score {
    \keepWithTag SCORE \new StaffGroup <<
        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\bold{Alto}
            \set Staff.shortInstrumentName = \markup\bold{A.}

            \new Voice = mvtIIalto { \clefAlto \mvtIIalto }
            \new Lyrics \lyricsto mvtIIalto \mvtIIlyrics
        >>
        \new Staff = staffH <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = "B.C."

            \dynamicUp \mvtIIbc
            \mvtIIfigs
        >>
    >>

    \header {
        piece = \mvtIIpiece
        % breakbefore = ##t
    }

    \layout { }
    \midi { }
}
% %}


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics \mvtIIIbreaks
        % \new Dynamics \mvtIIIbreaksAuto

        \new StaffGroup <<
            \new Staff = staffA <<
                \set Staff.instrumentName = "Oboe"
                \set Staff.shortInstrumentName = "Ob."

                \mvtIIIob
            >>
        >>

        \new StaffGroup <<
            \set StaffGroup.instrumentName = "Violini"
            \set StaffGroup.shortInstrumentName = "V."

            \new Staff = staffB <<
                \set Staff.instrumentName = "I"
                \set Staff.shortInstrumentName = "I"

                \mvtIIIvlnI
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = "II"
                \set Staff.shortInstrumentName = "II"

                \mvtIIIvlnII
            >>
        >>

        \new Staff = mvtIIIsoprano <<
            \set Staff.instrumentName = \markup\bold{Soprano}
            \set Staff.shortInstrumentName = \markup\bold{S.}

            \new Voice = mvtIIIsoprano { \clefSoprano \mvtIIIsoprano }
            \new Lyrics \lyricsto mvtIIIsoprano \mvtIIIlyrics
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla."

                \mvtIIIvla
            >>
        >>
    >>

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }

    \layout { }
    \midi { }
}
% %}


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics \mvtIVbreaks
        % \new Dynamics \mvtIVbreaksAuto

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = "Violini"
                \set GrandStaff.shortInstrumentName = "V."

                \new Staff = staffA <<

                    \set Staff.instrumentName = "I"
                    \set Staff.shortInstrumentName = "I"

                    \mvtIVvlnI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                    \mvtIVvlnII
                >>
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla."

                \mvtIVvla
            >>
        >>

        \new Staff = staffD <<
            \set Staff.instrumentName = \markup\bold{Basso}
            \set Staff.shortInstrumentName = \markup\bold{B.}

            \new Voice = mvtIVbass \mvtIVbass
            \new Lyrics \lyricsto mvtIVbass \mvtIVlyrics
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                \dynamicUp \mvtIVbc
                \mvtIVfigs
            >>
        >>
    >>

    \header {
        piece = \mvtIVpiece
        breakbefore = ##t
    }

    \layout { }
    \midi { }
}
% %}


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics \mvtVbreaks
        % \new Dynamics \mvtVbreaksAuto

        \new StaffGroup <<
            \new Staff = staffA <<
                \set Staff.instrumentName = "Corno"
                \set Staff.shortInstrumentName = "Cor."

                \mvtVcorno
            >>
        >>

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = "Violini"
                \set GrandStaff.shortInstrumentName = "V."

                \new Staff = staffB <<
                    \set Staff.instrumentName = "I"
                    \set Staff.shortInstrumentName = "I"

                    \mvtVvlnI
                >>
                \new Staff = staffC <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                    \mvtVvlnII
                >>
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla."

                \mvtVvla
            >>
        >>

        \new Staff = staffE <<
            \set Staff.instrumentName = \markup\bold{Tenore}
            \set Staff.shortInstrumentName = \markup\bold{T.}

            \new Voice = mvtVtenor { \clefTenor \mvtVtenor }
            \new Lyrics \lyricsto mvtVtenor \mvtVlyrics
        >>

        \new StaffGroup <<
            \new Staff = staffF <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                { \dynamicUp \mvtVbc }
                \mvtVfigs
            >>
        >>
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }

    \layout { }
    \midi { }
}
% %}


% %{
\score {
    \keepWithTag SCORE <<
        % \new Dynamics \mvtVIbreaks
        % \new Dynamics \mvtVIbreaksAuto

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = \markup{"Violino"}
                \set GrandStaff.shortInstrumentName = \markup{"Vln."}

                \new Staff = staffA <<
                    \set Staff.instrumentName = "I"
                    \set Staff.shortInstrumentName = "I"

                    \mvtVIvlnI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                    \mvtVIvlnII
                >>
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = \markup{"Viola"}
                \set Staff.shortInstrumentName = \markup{"Vla."}

                \mvtVIvla
            >>
        >>

        \new ChoirStaff <<
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup\bold{Soprano}
                \set Staff.shortInstrumentName = \markup\bold{S.}

                \new Voice = mvtVIsoprano { \clefSoprano \mvtVIsoprano }
                \new Lyrics \lyricsto mvtVIsoprano \mvtVIsopranoLyrics
            >>
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\bold{Alto}
                \set Staff.shortInstrumentName = \markup\bold{A.}

                \new Voice = mvtVIalto { \clefAlto \mvtVIalto }
                \new Lyrics \lyricsto mvtVIalto \mvtVIaltoLyrics
            >>
            \new Staff = staffF <<
                \set Staff.instrumentName = \markup\bold{Tenore}
                \set Staff.shortInstrumentName = \markup\bold{T.}

                \new Voice = mvtVItenor { \clefTenor \mvtVItenor }
                \new Lyrics \lyricsto mvtVItenor \mvtVItenorLyrics
            >>
            \new Staff = staffG <<
                \set Staff.instrumentName = \markup\bold{Basso}
                \set Staff.shortInstrumentName = \markup\bold{B.}

                \new Voice = mvtVIbass { \mvtVIbass }
                \new Lyrics \lyricsto mvtVIbass \mvtVIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffH <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                \dynamicUp \mvtVIbc
                \mvtVIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }

    \layout { }
    \midi { }
}
% %}
