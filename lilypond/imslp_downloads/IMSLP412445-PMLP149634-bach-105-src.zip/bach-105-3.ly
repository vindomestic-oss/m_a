\version "2.19.11"

\include "common.ly"

mvtIIItimeLine = {
    \time 3/4
    \key es \major

    s2. |
    \segno
    s2.*93 |
    \dalSegno
    \bar "||"
}


mvtIIIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \pageBreak

    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak }
    \pageBreak

    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak }
    \pageBreak
}

mvtIIIbreaksAuto = {
    <>^"Autograph breaks left in"
    \repeat unfold 6 { s2.\noBreak } s2 \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 6 { s2.\noBreak } s2 \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 6 { s2.\noBreak } s2 \bar "" \pageBreak

    %p3
    s4\noBreak \repeat unfold 7 { s2.\noBreak } s2 \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 5 { s2.\noBreak } s2 \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \pageBreak

    %p4
    \repeat unfold 6 { s2.\noBreak } s2 \bar "" \break\noPageBreak
    s4\noBreak \repeat unfold 7 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak } \pageBreak

    %p5
    \repeat unfold 7 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 8 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 7 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 1 { s2.\noBreak }
    \bar "||"
}


mvtIIIob = <<
\relative c' {
    r4 r4 r8 es8 | % bar 1
    des'8( c8) des4 r8 es,8 | % bar 2
    c'8( bes8) c4 r8 as8 | % bar 3
    es'8( c8) d4 r8 f8 | % bar 4
    as,8( f8) g4 r8 bes8 | % bar 5
    g'8( f8) g4 r8 bes,8 | % bar 6
    des8( c8) a4\trill r8 f'8 | % bar 7
    a8 bes8~ bes8 a16( g16 f8 es16 des16) | % bar 8
    \grace c8 bes4 r4 r8 bes8 | % bar 9
    g'8( f8) g4 r8 e8 | % bar 10
    f8( g16 as16) as4 r8 f8 | % bar 11
    es8( d8) bes'4 r8 d,8 | % bar 12
    es8( g16 f16) as,4 r8 f8 | % bar 13
    d'8( es)~ es8 d16( c16 bes8 as16 g16) | % bar 14
    f'8 ges8~ ges8 f16( es16 d8 c16 bes16) | % bar 15
    a'8( bes16) f16 g16( es16 d16 es16) a,16( bes16 d,16 es16) | % bar 16
    es4\fermata r4 r4 | % bar 17
    r8 es8\noBeam des'8( c8) des4 | % bar 18
    r8 es,8\noBeam c'8( bes8) c4 | % bar 19
    r8 as8\noBeam d8( c8) d4 | % bar 20
    r8 bes8\For es8( d8) es8( as8) | % bar 21
    d,8( es8)~ es8 d16( c16 bes8 as16 g16) | % bar 22
    f'8 ges8~ ges8 f16( es16 d8 c16 bes16) | % bar 23
    a'8( bes16) f16 g16( es16 d16 es16) a,16( bes16) d,16( es16) | % bar 24
    es4 r4 r4 | % bar 25
    r8 es8\noBeam\Pia des'8( c8) des4 | % bar 26
    r8 es,8\noBeam c'8( bes8) c4 | % bar 27
    r8 as8\noBeam d?8( c8) d4 | % bar 28
    r8 bes8\noBeam es8( d8) es4 | % bar 29
    r4 r4 r8 c8 | % bar 30
    c8( bes16 a16) a8( g16 f16) f8( es16 d16) | % bar 31
    b'2.\trill | % bar 32
    c8 es16 c16 g'8. f16 es16 d16 c16 g16 | % bar 33
    es'8. d16 c16 bes16 a16 bes16 c16 a16 bes16 c16 | % bar 34
    f,8 r8 r4 r8 bes8 | % bar 35
    bes8 as16 g16 g8( f16 es16) es8( d16 c16) | % bar 36
    a'2.\trill | % bar 37
    bes8 d16 bes16 f'8. es16 d16 c16 bes16 f16 | % bar 38
    des'8. c16 bes16 as16 g16 as16 bes16 g16 as16 bes16 | % bar 39
    a16 c16 ges'8~ ges16 es16 f16 ges16 a,16 es'16 des16 c16 | % bar 40
    bes8 des16 c16 bes8 f16 a16 bes8 a16 bes16 | % bar 41
    g16( bes16 des8)~ des16 g,16 a16 bes16 c,16 des'16( c16 bes16) | % bar 42
    a8( c16 bes16) a8( f16 g16) a8( g16 a16) | % bar 43
    bes8 r8 r4 r4 | % bar 44
    r4 r4 r8 bes8\For | % bar 45
    as'?8( g8) as4 r8 bes,8 | % bar 46
    g'8( f8) g4 r8 bes,8 | % bar 47
    bes'8( g8) a4 r8 c8 | % bar 48
    es,8( c8) d4 r16 e16( f16 g16) | % bar 49
    a,8 bes8~ bes8 a16( g16 f8 es16 d16) | % bar 50
    c'8( des8~ des8) c16( bes16 a8 g16 f16) | % bar 51
    e'8( f16) c16 d16( bes16 a16 bes16) e,16( f16) bes16( a16) | % bar 52
    bes4 r4 r4 | % bar 53
    r8 f8\noBeam\Pia d'8( c8) d4 | % bar 54
    r8 f8\noBeam f8( d8) b4 | % bar 55
    r8 g8\noBeam des'8( bes8) c4 | % bar 56
    r8 c8 g'8( e8) f8( as8) | % bar 57
    as8( ges16 f16) f8( es16 des16) des8( c16 bes16) | % bar 58
    bes2.^~ | % bar 59
    bes16 as16 ges16 f16 es16 f16 ges16 es16 c32 d32 es32 f32 g32 a32 bes16 | % bar 60
    a2. | % bar 61
    bes8 des16 bes16 f'8. es16 des16( c16 bes16) f16 | % bar 62
    des'8. c16 bes16 as16 g16 as16 bes16 g16 es8 | % bar 63
    r8 es'8 es8( des16 c16) c8( bes16 as16) | % bar 64
    as8( g16 f16) f8( es16 d16) d'16( c16 b16 c16) | % bar 65
    b2.\trill | % bar 66
    c8 es16 c16 g'8. f16 es16 d16 c16 es16 | % bar 67
    as8. g16 f16 g16 as16 f16 d4~ | % bar 68
    d8 f16 es16 d8 b16 c16 d8 c16 d16 | % bar 69
    es16 c16 g'8~ g16 es16 f16 g16 c,16 es16 d16 c16 | % bar 70
    fis8 a16 g16 fis8 d16 e16 fis8 e16 fis16 | % bar 71
    g8 g,8 f'4~ f16 as16 g16 f16 | % bar 72
    es16( b16 c16 as'16) b,4.\trill c8 | % bar 73
    c8 g8\f es'8( b8) c8( as'8) | % bar 74
    fis8 g8~ g8 f16( es16 d8 c16 b16) | % bar 75
    g'8 as8~ as8 g16( f16 es8 d16 c16) | % bar 76
    b'8( c16) g16 as16( g16 f16 es16) d16( f16 b,16 c16) | % bar 77
    c4 r4 r4 | % bar 78
    r8 es8\Pia\noBeam es8( c8) a4 | % bar 79
    r8 c8\noBeam c8( a8) f4 | % bar 80
    r8 f'8\noBeam g8( e8) f4 | % bar 81
    r8 bes,8\noBeam c8( as8) des4 | % bar 82
    r8 g8\noBeam bes,8( g8) as4 | % bar 83
    r8 f'8\noBeam d8( b8) as'4 | % bar 84
    r8 as,8\noBeam f'8( d8) b4 | % bar 85
    r8 c8\noBeam b8( d8) f4 | % bar 86
    r8 g8 g8( es8 c8 f8) | % bar 87
    bes,8 bes'8 bes8( g8 es8 g8) | % bar 88
    c,8 f8 f8( as,8 g8 es'8) | % bar 89
    es8 c8 d8 bes8 es8( f16 d16) | % bar 90
    es8 c8 a8 c8 es4~ | % bar 91
    es2.~ | % bar 92
    es8.( d32 c32) bes8 r8 r4 | % bar 93
    r4 r4 r8 es,8 | % bar 94
}
\mvtIIItimeLine
>>


mvtIIIvlnI = <<
\relative c'' {
    \time 3/4 
    \key es \major
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 1
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 2
    as16( as16 as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 3
    as16( as16 as16 as16) as16( as16 as16 as16) d16( d16 d16 d16) | % bar 4
    es16( es16 es16 es16) es16( es16 es16 es16) es16( es16 es16 es16) | % bar 5
    des16( des16 des16 des16) des16( des16 des16 des16) des16( des16 des16 des16) | % bar 6
    des16( des16 des16 des16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 7
    c16( c16 c16 c16) des16( des16 des16 des16) a16( a16 a16 a16) | % bar 8
    bes16( bes16 bes16 bes16) f'16( f16 f16 f16) d16( d16 d16 d16) | % bar 9
    des16( des16 des16 des16) des16( des16 des16 des16) c16( c16 c16 c16) | % bar 10
    c16( c16 c16 c16) f16( f16 f16 f16) c16( c16 c16 c16) | % bar 11
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 12
    bes16( bes16 bes16 bes16) d16( d16 d16 d16) f16( f16 f16 f16) | % bar 13
    bes,16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) es16( es16 es16 es16) | % bar 14
    d16( d16 d16 d16) es16( es16 es16 es16) f16( f16 f16 f16) | % bar 15
    es16( es16 d16 d16) bes16( bes16 bes16 bes16) d16( d16 f16 f16) | % bar 16
    es16\fermata( es16 es16 es16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 17
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 18
    as16( as16 as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 19
    as16( as16 as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 20
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) as16( as16 as16 as16) | % bar 21
    as16( as16 as16 as16) bes16( bes16 bes16 bes16) es16( es16 es16 es16) | % bar 22
    d16( d16 d16 d16) es16( es16 es16 es16) f16( f16 f16 f16) | % bar 23
    ges16( ges16 f16 f16) es16( es16 g16 g16) f16( f16 as,16 as16) | % bar 24
    g16( g16 g16 g16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 25
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 26
    as16( as16 as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 27
    as16( as16 as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 28
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 29
    c8 r8 r4 r4 | % bar 30
    r16 c16( c16 c16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 31
    d8 r8 r4 r4 | % bar 32
    r16 es16( es16 es16) es8 r8 r16 es16( es16 es16) | % bar 33
    c8 r8 r16 c16( c16 c16) c16( c16 c16 c16) | % bar 34
    bes8 r8 r4 r4 | % bar 35
    r16 bes16( bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 36
    c8 r8 r4 r4 | % bar 37
    r16 d16( d16 d16) d8 r8 r16 d16( \once \set suggestAccidentals = ##t des16 des16) | % bar 38
    bes8 r8 r16 des16( des16 des16) c16( c16 c16 c16) | % bar 39
    c16( c16 a16 a16) a16( a16 c16 c16) es16( es16 a,16 a16) | % bar 40
    bes16( bes16 f16 f16) bes16( bes16 des16 des16) f16( f16 des16 des16) | % bar 41
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 42
    c16( c16 c16 c16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 43
    bes8 r8 r4 r4 | % bar 44
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 45
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 46
    es16( es16 es16 es16) es16( es16 es16 es16) es16( es16 es16 es16) | % bar 47
    es16( es16 es16 es16) es16( es16 es16 es16) a,16( a16 a16 a16) | % bar 48
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 49
    f'16( f16 es16 es16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 50
    a16( a16 a16 a16) bes16( bes16 bes16 bes16) c16( c16 c16 c16) | % bar 51
    bes16( bes16 a16 a16) bes16( bes16 d16 d16) c16( c16 es16 es16) | % bar 52
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 53
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 54
    b,16( b16 b16 b16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 55
    c16( c16 c16 c16) bes16( bes16 bes16 bes16) e16( e16 e16 e16) | % bar 56
    f16( f16 f16 f16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 57
    c16( c16 c16 c16) c16( c16 c16 c16) bes16( bes16 a16 a16) | % bar 58
    bes16( bes16 bes16 bes16) ges'16( ges16 ges16 ges16) f16( f16 f16 f16) | % bar 59
    es16( es16 es16 es16) c16( c16 c16 c16) es16( es16 es16 es16) | % bar 60
    c16( c16 c16 c16) es16( es16 es16 es16) a,16( a16 a16 a16) | % bar 61
    f16 des'16( des16 des16) des8 r8 r16 des16( des16 des16) | % bar 62
    bes8 r8 r16 bes16( bes16 bes16) bes16( bes16 bes16 bes16) | % bar 63
    as8 r8 r4 r4 | % bar 64
    r16 c16( c16 c16) c16( c16 c16 c16) f16( f16 f16 f16) | % bar 65
    d8 r8 r4 r4 | % bar 66
    r16 es16( es16 es16) es8 r8 r16 es16( es16 es16) | % bar 67
    c8 r8 r16 c16( c16 c16) d16( d16 d16 d16) | % bar 68
    d16( d16 b16 b16) b16( b16 d16 d16) f16( f16 b,16 b16) | % bar 69
    c16( c16 g16 g16) c16( c16 es16 es16) g16( g16 es16 es16) | % bar 70
    c16( c16 c16 c16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 71
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 72
    c8 r8 r4 r4 | % bar 73
    r16 g16( g16 g16) g16( g16 g16 g16) c16( c16 c16 c16) | % bar 74
    b16( b16 b16 b16) b16( b16 b16 b16) b16( b16 b16 b16) | % bar 75
    b16( b16 b16 b16) c16( c16 c16 c16) c16( c16 c16 c16) | % bar 76
    d16( d16 g,16 g16) b16( b16 c16 c16) d16( d16 g,16 g16) | % bar 77
    g16( g16 g16 g16) c16( c16 c16 c16) bes16( bes16 bes16 bes16) | % bar 78
    a16( a16 a16 a16) c16( c16 c16 c16) es16( es16 es16 es16) | % bar 79
    es16( es16 es16 es16) es16( es16 es16 es16) c16( c16 c16 c16) | % bar 80
    bes16( bes16 bes16 bes16) des16( des16 des16 des16) c16( c16 c16 c16) | % bar 81
    des16( des16 des16 des16) c16( c16 c16 c16) bes16( bes16 bes16 bes16) | % bar 82
    d16( d16 d16 d16) g16( g16 g16 g16) f16( f16 f16 f16) | % bar 83
    f16( f16 f16 f16) f16( f16 f16 f16) d16( d16 d16 d16) | % bar 84
    b16( b16 b16 b16) d16( d16 d16 d16) f16( f16 f16 f16) | % bar 85
    b,16( b16 a16 a16) b16( b16 b16 b16) b16( b16 b16 b16) | % bar 86
    c16( c16 c16 c16) es16( es16 es16 es16) f16( f16 f16 f16) | % bar 87
    f16( f16 f16 f16) bes,16( bes16 bes16 bes16) c16( c16 c16 c16) | % bar 88
    c16( c16 c16 c16) bes16( bes16 bes16 bes16) bes16( bes16 bes16) bes16 | % bar 89
    bes16( bes16 a16 a16) bes16( bes16 bes16 bes16) as16( as16 as16 as16) | % bar 90
    ges16( ges16 ges16 ges16) es16( es16 es16 es16) a16( a16 a16 a16) | % bar 91
    c16( c16 c16 c16) es16( es16 es16 es16) ges16( ges16 ges16 ges16) | % bar 92
    es8 r8 r4 r4 | % bar 93
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 94
}
\mvtIIItimeLine
>>


mvtIIIvlnII = <<
\relative c'' {
    \time 3/4 
    \key es \major
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 1
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 2
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 3
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 4
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 5
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 6
    bes16( bes16 bes16 bes16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 7
    es16( es16 es16 es16) g16( g16 g16 g16) c,16( c16 c16 c16) | % bar 8
    d16( d16 d16 d16) bes'16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 9
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) g16( g16 g16 g16) | % bar 10
    as16( as16 as16 as16) c16( c16 c16 c16) as16( as16 as16 as16) | % bar 11
    f16( f16 f16 f16) es16( es16 es16 es16) as16( as16 as16 as16) | % bar 12
    g16( g16 g16 g16) f16( f16 f16 f16) as16( as16 as16 as16) | % bar 13
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 14
    as16( as16 as16 as16) bes16( bes16 bes16 bes16) as16( as16 as16 as16) | % bar 15
    ges16( ges16 f16 f16) es16( es16 g16 g16) f16( f16 as16 as16) | % bar 16
    g16\fermata( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 17
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 18
    es16( es16 es16 es16) es16( es16 es16 es16) es16( es16 es16 es16) | % bar 19
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 20
    es16( es16 es16 es16) << { g16( g g g) } \\ { \tiny es16( es16 es16 es16) } >> es16( es16 es16 es16) | % bar 21
    f16( f16 f16 f16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 22
    as16( as16 as16 as16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 23
    c16( c16 d16 d16) bes16( bes16 bes16 bes16) d16( d16 f,16 f16) | % bar 24
    es16( es16 es16 es16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 25
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 26
    es16( es16 es16 es16) es16( es16 es16 es16) es16( es16 es16 es16) | % bar 27
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 28
    es16( es16 es16 es16) es16( es16 es16 es16) g16( g16 g16 g16) | % bar 29
    es8 r8 r4 r4 | % bar 30
    r16 a16( a16 a16) a16( a16 a16 a16) a16( a16 a16 a16) | % bar 31
    as8 r8 r4 r4 | % bar 32
    r16 c16( c16 c16) c8 r8 r16 g16( g16 g16) | % bar 33
    a8 r8 r16 f16( f16 f16) f16( f16 f16 f16) | % bar 34
    f8 r8 r4 r4 | % bar 35
    r16 g16( g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 36
    a8 r8 r4 r4 | % bar 37
    r16 bes16( bes16 bes16) bes8 r8 r16 f16( f16 f16) | % bar 38
    g8 r8 r16 g16( g16 g16) g16( g16 g16 g16) | % bar 39
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 40
    f16( f16 bes16 bes16) des16( des16 bes16 bes16) f16( f16 f16 f16) | % bar 41
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 42
    f16( f16 a16 a16) c16( c16 a16 a16) f16( f16 f16 f16) | % bar 43
    g8 r8 r4 r4 | % bar 44
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 45
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 46
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 47
    c16( c16 c16 c16) c16( c16 c16 c16) es,16( es16 es16 es16) | % bar 48
    f16( f16 f16 f16) f16( f16 f16 f16) g16( g16 g16 g16) | % bar 49
    c16( c16 c16 c16) f,16( f16 f16 f16) bes16( bes16 bes16 bes16) | % bar 50
    c16( c16 c16 c16) f,16( f16 f16 f16) es16( es16 es16 es16) | % bar 51
    des16( des16 c16 c16) f16( f16 f16 f16) a16( a16 f16 f16) | % bar 52
    f16( f16 f16 f16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 53
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 54
    d16( d16 d16 d16) g,16( g16 g16 g16) g16( g16 g16 g16) | % bar 55
    g16( g16 g16 g16) g16( g16 g16 g16) c16( c16 c16 c16) | % bar 56
    c16( c16 c16 c16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 57
    f16( f16 f16 f16) as16( as16 as16 as16) f16( f16 f16 f16) | % bar 58
    ges16( ges16 ges16 ges16) bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) | % bar 59
    c16( c16 c16 c16) bes16( bes16 bes16 bes16) g16( g16 g16 g16) | % bar 60
    f16( f16 f16 f16) c'16( c16 c16 c16) c16( c16 c16 c16) | % bar 61
    bes16 bes16( bes16 bes16) bes8 r8 r16 f16( f16 f16) | % bar 62
    g8 r8 r16 es16( es16 es16) es16( es16 es16 es16) | % bar 63
    es8 r8 r4 r4 | % bar 64
    r16 as16( as16 as16) as16( as16 as16 as16) as16( as16 as16 as16) | % bar 65
    g8 r8 r4 r4 | % bar 66
    r16 g16( g16 g16) c8 r8 r16 g16( g16 g16) | % bar 67
    f8 r8 r16 f16( f16 f16) as16( as16 as16 as16) | % bar 68
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 69
    g16( g16 c16 c16) es16( es16 c16 c16) g16( g16 g16 g16) | % bar 70
    a16( a16 a16 a16) a16( a16 a16 a16) a16( a16 a16 a16) | % bar 71
    g16( g16 b16 b16) d16( d16 b16 b16) g16( g16 g16 g16) | % bar 72
    c,8 r8 r4 r4 | % bar 73
    r16 es16( es16 es16) es16( es16 es16 es16) f16( f16 f16 f16) | % bar 74
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 75
    f16( f16 f16 f16) es16( es16 es16 es16) g16( g16 g16 g16) | % bar 76
    f16( f16 es16 es16) d16( d16 g16 g16) f16( f16 f16 f16) | % bar 77
    es16( es16 es16 es16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 78
    f16( f16 f16 f16) a16( a16 a16 a16) c16( c16 c16 c16) | % bar 79
    c16( c16 c16 c16) c16( c16 c16 c16) f,16( f16 f16 f16) | % bar 80
    f16( f16 f16 f16) bes16( bes16 bes16 bes16) f16( f16 f16 f16) | % bar 81
    bes16( bes16 bes16 bes16) as16( as16 as16 as16) bes16( bes16 bes16 bes16) | % bar 82
    g16( g16 g16 g16) g16( g16 g16 g16) c16( c16 c16 c16) | % bar 83
    d16( d16 d16 d16) d16( d16 d16 d16) f,16( f16 f16 f16) | % bar 84
    as16( as16 as16 as16) as16( as16 as16 as16) d,16( d16 d16 d16) | % bar 85
    d16( d16 d16 d16) d16( d16 d16 d16) g16( g16 g16 g16) | % bar 86
    g16( g16 g16 g16) g16( g16 g16 g16) as16( as16 as16 as16) | % bar 87
    bes16( bes16 bes16 bes16) es16( es16 es16 es16) g,16( g16 g16 g16) | % bar 88
    f16( f16 f16 f16) f16( f16 f16 f16) es16( es16 es16 es16) | % bar 89
    es16( es16 es16 es16) f16( f16 f16 f16) f16( f16 f16 f16) | % bar 90
    es16( es16 es16 es16) ges16( ges16 ges16 ges16) c,16( c16 c16 c16) | % bar 91
    es16( es16 es16 es16) ges16( ges16 ges16 ges16) c16( c16 c16 c16) | % bar 92
    bes8 r8 r4 r4 | % bar 93
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) | % bar 94
}
\mvtIIItimeLine
>>


mvtIIIsoprano = <<
\relative c' {
    \autoBeamOff

    R2.*16 | % bar 1
    r4\fermata r4 r8 es8 | % bar 17
    des'8[( c8)] des4 r8 es,8 | % bar 18
    c'8[( bes8)] c4 r8 as8 | % bar 19
    es'8[( c8)] d?4 r8 f8 | % bar 20
    as,8[( f8)] g4 r4 | % bar 21
    R2.*3 | % bar 22
    r4 r4 r8 es8 | % bar 25
    des'8[( c8)] des4 r8 es,8 | % bar 26
    c'8[( bes8)] c4 r8 as8 | % bar 27
    es'8[( c8)] d?4 r8 f8 | % bar 28
    as,8[ f8] g4 r8 g'8 | % bar 29
    g8 f16 es16 es8 d16 c16 c8 bes16 a16 | % bar 30
    \autoBeamOn f'2.~ \melisma | % bar 31
    f16 es16 d16 c16 b16 c16 d16 b16 g32 \once \set suggestAccidentals = ##t a32 b32 c32 d32 es32 f16 | % bar 32
    es16 c16 g'8~ g16 f16 es16 d16 c16 g16 es'8~ | % bar 33
    es16 d16 c16 bes16 a16 bes16 c16 a16 \melismaEnd \autoBeamOff f8 f'8 | % bar 34
    f8 es16 d16 d8 c16 bes16 bes8 as16 g16 | % bar 35
    \autoBeamOn es'2.~ \melisma | % bar 36
    es16 d16 c16 bes16 a16 bes16 c16 a16 f32 g32 a32 bes32 c32 d32 es16 | % bar 37
    d16 bes16 f'8~ f16 es16 d16 c16 bes16 f16 des'8~ | % bar 38
    des16 c16 bes16 as16 g16 as16 bes16 g16 \autoBeamOff e8 \melismaEnd d16 c16 | % bar 39
    c'8 es16 des16 c8 a16 bes16 c8 bes16 c16 | % bar 40
    \autoBeamOn des16 \melisma bes16 f'8~ f16 des16 es16 f16 bes,16 des16 c16 bes16 | % bar 41
    e8 \melismaEnd \autoBeamOff g16\noBeam f16 e8 c16 d16 e8 d16 e16 | % bar 42
    \autoBeamOn f8 \melisma f,8 es'4. des16 c16 | % bar 43
    \autoBeamOff des16 \melismaEnd c16 bes8 a4.( bes8) | % bar 44
    bes4 r4 r4 | % bar 45
    R2.*7 | % bar 46
    r4 r4 r8 f8 | % bar 53
    d'8[( c8)] d4 r8 f8 | % bar 54
    f8[( d8)] b4 r8 g8 | % bar 55
    f'8[( d8)] e4 r8 g8 | % bar 56
    bes,8[( g8)] as4 r4 | % bar 57
    r4 r4 r8 f'8 | % bar 58
    f8 es16 des16 des8 c16 bes16 bes8 as16 ges16 | % bar 59
    \autoBeamOn es'2.~ \melisma | % bar 60
    es16 des16 c16 bes16 a16 bes16 c16 a16 f32 g32 a32 bes32 c32 des32 es16 | % bar 61
    des16 bes16 f'8~ f16 es16 des16 c16 bes16 f16 des'8~ | % bar 62
    des16 c16 bes16 as16 g16 as16 bes16 g16 \melismaEnd \autoBeamOff es8 es' | % bar 63
    es8 des16 c16 c8 bes16 as?16 as8 g16 f16 | % bar 64
    \autoBeamOn f'2.~ \melisma | % bar 65
    f16 es16 d16 c16 b16 c16 d16 b16 g32 a32 b32 c32 d32 es32 f16 | % bar 66
    es16 c16 g'8~ g16 f16 es16 d16 c16 g16 es'8~ | % bar 67
    es16 d16 c16 bes16 as16 bes16 c16 as16 f16 es'16 d16 es32 c32 | % bar 68
    \autoBeamOff b8 \melismaEnd g8 r4 r8 b8 | % bar 69
    c8 es16 d16 c8 g16 b16 c8 b16 c16 | % bar 70
    \autoBeamOn a16 \melisma c16 es8~ es16 a,16 b16 c16 d,16 es'16 d16 c16 | % bar 71
    \autoBeamOff b8 \melismaEnd d16 c16 b8 g16 a16 b8 a16 b16 | % bar 72
    c8 f16 d16 d4.( c8) | % bar 73
    c4 r4 r4 | % bar 74
    R2.*3 | % bar 75
    r4 r4 r8 es8 | % bar 78
    es8[ c8] a4 r8 f8 | % bar 79
    ges'4 ges4 f4 | % bar 80
    des4 c8[ bes8] c4 | % bar 81
    e4( f4.) es16 des16 | % bar 82
    c8[( b8)] c4. f,8 | % bar 83
    as8[( g8)] g4 r8 f'8 | % bar 84
    f8[( d8)] b4 r8 g8 | % bar 85
    as8[( fis8)] g8[( b8)] d8[( f8)] | % bar 86
    es4 d8[( c8)] f4 | % bar 87
    d4( es4.) d16 c16 | % bar 88
    bes8[ a8] bes4. es,8 | % bar 89
    g8[ f8] f4 r4 | % bar 90
    r4 r8 a8 ges'8 as16 f16 | % bar 91
    ges2.~ | % bar 92
    ges8 f16 es16 d4.( es8) | % bar 93
    es4 r4 r4 | % bar 94
}
\mvtIIItimeLine
>>


mvtIIIlyrics = \lyricmode {
    Wie zit -- tern und wan -- ken
    der Sün -- der Ge -- dan -- ken,
    wie zit -- tern und wan -- ken
    der Sün -- der Ge -- dan -- ken,
    in -- dem sie sich un -- ter -- ein -- an -- der ver -- kla -- gen
    und wie -- der -- um sich zu ent -- schul -- di -- gen wa -- gen,
    in -- dem sie sich un -- ter -- ein -- an -- der ver -- kla -- gen
    und wie -- der -- um sich zu ent -- schul -- di -- gen wa -- gen.

    Wie zit -- tern und wan -- ken
    der Sün -- der Ge -- dan -- ken,
    in -- dem sie sich un -- ter -- ein -- an -- der ver -- kla -- gen
    und wie -- der -- um sich zu ent -- schul -- di -- gen wa -- gen,
    in -- dem sie sich un -- ter -- ein -- an -- der ver -- kla -- gen
    und wie -- der -- um sich zu ent -- schul -- di -- gen wa -- gen.

    So wird ein ge -- äng -- stigt Ge -- wis -- sen
    durch ei -- ge -- ne Fol -- ter zer -- ris -- sen,
    so wird ein ge -- äng -- stigt Ge -- wis -- sen
    durch ei -- ge -- ne Fol -- ter zer -- ris -- sen.,
    durch ei -- ge -- ne Fol -- ter zer -- ris -- sen. 
}

mvtIIIvla = <<
\relative c' {
    \clef C
    es8( es8 es8 es8 es8 es8) | % bar 1
    es8( es8 es8 es8 es8 es8) | % bar 2
    es8( es8 es8 es8 es8 es8) | % bar 3
    es8( es8 es8 es8 es8 es8) | % bar 4
    es8( es8 es8 es8 es8 es8) | % bar 5
    e8( e8 e8 e8 e8 e8) | % bar 6
    f8( f8 f8 f8 f8 f8) | % bar 7
    ges8( ges8) e8( e8) f8( f8) | % bar 8
    bes,8( bes8) d8( d8) f8( f8) | % bar 9
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 10
    as8( as8) f8( f8) as8( as8) | % bar 11
    as8( as8) g8( g8) f8( f8) | % bar 12
    es8( es8) bes8( bes8) bes8( bes8) | % bar 13
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 14
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 15
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 16
    es8\fermata( es8 es8 es8 es8 es8) | % bar 17
    es8( es8 es8 es8 es8 es8) | % bar 18
    es8( es8 es8 es8 es8 es8) | % bar 19
    es8( es8 es8 es8 es8 es8) | % bar 20
    es8( es8) d8( d8) c8( c8) | % bar 21
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 22
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 23
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 24
    es8( es8 es8 es8 es8 es8) | % bar 25
    es8( es8 es8 es8 es8 es8) | % bar 26
    es8( es8 es8 es8 es8 es8) | % bar 27
    es8( es8 es8 es8 es8 es8) | % bar 28
    es8( es8 es8 es8 es8 es8) | % bar 29
    es8( es8 es8 es8 es8 es8) | % bar 30
    es8( es8 es8 es8 es8 es8) | % bar 31
    d8( d8) g8( g8) g,8( g8) | % bar 32
    c8( c8 c8 c8 c8 c8) | % bar 33
    f8( f8) f8( f8) es8( es8) | % bar 34
    d8( d8 d8 d8 d8 d8) | % bar 35
    d8( d8 d8 d8 d8 d8) | % bar 36
    c8( c8) f8( f8) f,8( f8) | % bar 37
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 38
    e8( e8 e8 e8 e8 e8) | % bar 39
    f8( f8 f8 f8 f8 f8) | % bar 40
    f8( f8 f8 f8 f8 f8) | % bar 41
    f8( f8 f8 f8 f8 f8) | % bar 42
    f8( f8 f8 f8 f8 f8) | % bar 43
    e8( e8) f8( f8) f8( f8) | % bar 44
    bes,8( bes8 bes8 bes8 bes8 bes8) | % bar 45
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 46
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 47
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 48
    bes8( bes8) a8( a8) g8( g8) | % bar 49
    f8( f8 f8 f8 f8 f8) | % bar 50
    f8( f8 f8 f8 f8 f8) | % bar 51
    f8( f8 f8 f8 f8 f8) | % bar 52
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 53
    as8( as8 as8 as8 as8 as8) | % bar 54
    g8( g8 g8 g8 g8 g8) | % bar 55
    c8( c8 c8 c8 c8 c8) | % bar 56
    f8( f8 f8 f8 f8 f8) | % bar 57
    des8( des8 des8 des8 des8 des8) | % bar 58
    ges8( ges8 ges8 ges8 ges8 ges8) | % bar 59
    c,8( c8 c8 c8 c8 c8) | % bar 60
    f8( f8 f8 f8 f8 f8) | % bar 61
    bes,8( bes8 bes8 bes8 bes8 bes8) | % bar 62
    es8( es8 es8 es8 es8 es8) | % bar 63
    as,8( as8 as8 as8 as8 as8) | % bar 64
    d8( d8 d8 d8 d8 d8) | % bar 65
    g,8( g8 g8 g8 g8 g8) | % bar 66
    c8( c8 c8 c8 c8 c8) | % bar 67
    f,8( f8 f8 f8 f8 f8) | % bar 68
    g8( g8 g8 g8 g8 g8) | % bar 69
    g8( g8 g8 g8 g8 g8) | % bar 70
    g8( g8 g8 g8 g8 g8) | % bar 71
    g8( g8 g8 g8 g8 g8) | % bar 72
    as8 f8 g8( g8) g8( g8) | % bar 73
    c8( c8) bes8( bes8) as8( as8) | % bar 74
    g8( g8 g8 g8 g8 g8) | % bar 75
    g8( g8 g8 g8 g8 g8) | % bar 76
    g8( g8 g8 g8 g8 g8) | % bar 77
    c8( c8) es8( es8) c8( c8) | % bar 78
    f8( f8 f8 f8 f8 f8) | % bar 79
    a,8( a8 a8 a8 a8 a8) | % bar 80
    bes8( bes8) bes'8( bes8) as8( as8) | % bar 81
    g8( g8) as8( as8) g8( g8) | % bar 82
    f8( f8) e8( e8) f8( f8) | % bar 83
    b,8( b8 b8 b8 b8 b8) | % bar 84
    d8( d8 d8 d8 d8 d8) | % bar 85
    g,8( g8 g8 g8 g8 g8) | % bar 86
    c8( c8) bes8( bes8) as8( as8) | % bar 87
    as'8( as8) g8( g8) c,8( c8) | % bar 88
    es8( es8) d8( d8) es8( es8) | % bar 89
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 90
    c8( c8 c8 c8 c8 c8) | % bar 91
    a8( a8 a8 a8 a8 a8) | % bar 92
    bes8( bes8 bes8 bes8 bes8 bes8) | % bar 93
    es8( es8 es8 es8 es8 es8) | % bar 94
}
\mvtIIItimeLine
>>
