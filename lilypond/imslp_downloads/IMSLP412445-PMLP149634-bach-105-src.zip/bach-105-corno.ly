\version "2.19.15"

\include "bach-105-1.ly"
\include "bach-105-2.ly"
\include "bach-105-3.ly"
\include "bach-105-4.ly"
\include "bach-105-5.ly"
\include "bach-105-6.ly"

\include "bach-105-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Corno in C"
}


\addQuote mvtIobII { \mvtIobII }
\addQuote mvtIvla  { \mvtIvla }

\score {
    \new Staff <<
        \mvtIobI
        {
            % s1*47 | %47
            % \pageBreak
            % s1*24 | %71
            s1*71 | %71
            \cueDuringWithClef mvtIvla #DOWN #"alto" { s1*5^"Viola" }
            \cueDuring mvtIobII #DOWN { s1*5^"Oboe/Vln II" }
        }
    >>

    \header {
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}

\score {
    \new Staff <<
        \mvtVcorno
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}

\score {
    \new Staff <<
        \mvtVIsoprano
    >>

    \header {
        piece = \mvtVIpiece
    }
}
