\version "2.19.15"

\include "baroque-clefs.ly"
\include "bach-105-score-common.ly"
