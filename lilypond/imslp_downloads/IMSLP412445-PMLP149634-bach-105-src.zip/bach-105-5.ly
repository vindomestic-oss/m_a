\version "2.19.11"

\include "common.ly"


mvtVtimeLine = {
    \time 4/4
    \key g \minor

    \set Timing.beamExceptions = #'()
    \set Timing.baseMoment = #(ly:make-moment 1 4)
    \set Timing.beatStructure = #'(1 1 1 1)

    s1*54 |
    \daCapo
    \bar "||"
}

mvtVbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 2 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 2 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \bar "|."
}


mvtVbreaksAuto = {
    <>^"Autograph breaks left in"
    \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | } s4 \bar "" \break\noPageBreak
    s2.\noBreak | \repeat unfold 2 { s1\noBreak | } \pageBreak

    \repeat unfold 3 { s1\noBreak | } s1 \bar "" \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } s2 \bar "" \break\noPageBreak
    s2\noBreak | \repeat unfold 2 { s1\noBreak | } s2. \bar "" \break\noPageBreak
    s4\noBreak | \repeat unfold 3 { s1\noBreak | } s2 \bar "" \pageBreak

    s2\noBreak | \repeat unfold 2 { s1\noBreak | } s2 \bar "" \break\noPageBreak
    s2\noBreak | \repeat unfold 4 { s1\noBreak | } s4 \bar "" \break\noPageBreak
    s2.\noBreak | \repeat unfold 2 { s1\noBreak | } s2. \bar "" \break\noPageBreak
    s4\noBreak | \repeat unfold 3 { s1\noBreak | } s2 \bar "" \pageBreak

    s2\noBreak | \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } s2 \bar "" \break\noPageBreak
    s2\noBreak | \repeat unfold 2 { s1\noBreak | } s4. \bar "" \break\noPageBreak
    s8 s2 |
    s1 \bar "||"
}


mvtVcorno = <<
\relative c' {
    r4 f8 f8 f4 es'8 d16 c16 | % bar 1
    f8 bes,8 es8 d8 d8 c8 g8 g8 | % bar 2
    g4 f'8 es16 d16 g8 c,8 f8 es8 | % bar 3
    es8 d8 es8 es8 es4 d8 d8 | % bar 4
    d4 c8 bes'8 a8 g16 f16 e8. f16 | % bar 5
    f1 | % bar 6
    f4 f8 f8 f4 es8 es8 | % bar 7
    es4 d8 d8 d8 c16 bes16 a8. bes16 | % bar 8
    bes4 r4 r2 | % bar 9
    R1*2 | % bar 10
    r4 es8\p es8 es4 d8 d8 | % bar 12
    d4 c8 bes'8 a8 g16 f16 e8. f16 | % bar 13
    f1~ | % bar 14
    f4 r4 r2 | % bar 15
    R1*6 | % bar 16
    r4 c2.~ | % bar 22
    c4 c8 c8 c4 bes8 bes8 | % bar 23
    bes4 a8 a8 d8. d16 c8. c16 | % bar 24
    c4 r4 r2 | % bar 25
    r4 g8\p g8 g4 r4 | % bar 26
    r2 r4 f8 f8 | % bar 27
    f4 f'8 f8 f4 es8 es8 | % bar 28
    es4 d8 d8 d8 c16 bes16 a8. bes16 | % bar 29
    bes4 r8 bes8 bes8 r8 r8 c8 | % bar 30
    c8 r8 r4 r2 | % bar 31
    r4 f,8\For f8 f4 es'8 d16 c16 | % bar 32
    f8 bes,8 es8 d8 c4 g8 g8 | % bar 33
    g4 f'8 es16 d16 g8 c,8 f8 es8 | % bar 34
    es8 d8 es8 es8 es4 d8 d | % bar 35
    d4 c8 bes'8 a8 g16 f16 e8. f16 | % bar 36
    f1 | % bar 37
    f4 f8 f8 f4 es8 es8 | % bar 38
    es4 d8 d8 d8 c16 bes16 a8. bes16 | % bar 39
    bes4\fermata r4 r2 | % bar 40
    R1*10 | %54
    R1\fermataMarkup | %54
    R1*3 | %54
}
\mvtVtimeLine
>>


mvtVvlnI = <<
\relative c' {
    r4 f8 f8 f4 es'8 d16 c16 | % bar 1
    f8 bes,8 a16( bes16 a16 bes16) d16( bes16 c8) g8 g8 | % bar 2
    g4 f'8 es16 d16 g8 c,8 b16( c16 b16 c16) | % bar 3
    es16( c16 d8) es32( d32 c32 d32 es32 c32 d32 es32) f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) | % bar 4
    e,32( f32 g32 a32 bes32 c32 d32 bes32) c32( d32 e32 f32 g32 a32 bes32 g32) a32( g32 bes32 a32 g32 f32 e32 f32) e8. f16 | % bar 5
    f4 c32( d32 es32 c32 es32 d32 c32 bes32) a32( bes32 c32 a32 c32 bes32 a32 bes32) c32( d32 es32 c32 es32 d32 c32 bes32) | % bar 6
    f'4~ f32 es32( d32 es32 f32 d32 es32 f32) g,32( a32 bes32 c32 d32 es32 f32 d32) es32( d32 c32 d32 es32 c32 d32 es32) | % bar 7
    f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) g32( f32 es32 d32 c32 bes32 a32 bes32) a8. bes16 | % bar 8
    bes4 r4 r2 | % bar 9
    R1*2 | % bar 10
    r4 es32\p( d32 c32 d32 es32 c32 d32 es32) f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) | % bar 12
    e,32( f32 g32 a32 bes32 c32 d32 bes32) c32( d32 e32 f32 g32 a32 bes32 g32) a32( g32 bes32 a32 g32 f32 e32 f32) e8. f16 | % bar 13
    f4 c32( d32 es32 c32 es32 d32 c32 bes32) a32( bes32 c32 a32 c32 bes32 a32 bes32) c32( d32 es32 c32 es32 d32 c32 bes32) | % bar 14
    f'4 r4 r2 | % bar 15
    R1*3 | % bar 16
    r4 g32\For( a32 bes32 g32 bes32 a32 g32 f32) e32( f32 g32 e32 g32 f32 e32 f32) g32( a32 bes32 g32 bes32 a32 g32 f32) | % bar 19
    c'4 r4 r2 | % bar 20
    R1 | % bar 21
    r4 g,32\For( a32 bes32 g32 bes32 a32 g32 f32) e32( f32 g32 e32 g32 f32 e32 f32) g32( a32 bes32 g32 bes32 a32 g32 f32) | % bar 22
    c'4~ c32 bes32( a32 bes32 c32 a32 bes32 c32) d,32( e32 fis32 g32 a32 bes32 c32 a32) bes32( a32 g32 a32 bes32 g32 a32 bes32) | % bar 23
    c,32( d32 e32 f32 g32 a32 bes32 g32) a32( g32 f32 g32 a32 f32 g32 a32) d32( c32 bes32 a32 g32 f32 e32 f32) e8. f16 | % bar 24
    f4 r4 r2 | % bar 25
    R1*2 | % bar 26
    r4 f'32\p( es32 d32 es32 f32 d32 es32 f32) g,32( a32 bes32 c32 d32 es32 f32 d32) es32( d32 c32 d32 es32 c32 d32 es32) | % bar 28
    f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) g32( f32 es32 d32 c32 bes32 a32 bes32) a8. bes16 | % bar 29
    bes4 r8 bes8 bes8 r8 r8 c8 | % bar 30
    c8 r8 r4 r2 | % bar 31
    r4 f,8\For f8 f4 es'8 d16 c16 | % bar 32
    f8 bes,8 a16( bes16 a16 bes16) d16( bes16 c8) g8 g8 | % bar 33
    g4 f'8 es16 d16 g8 c,8 b16( c16 b16 c16) | % bar 34
    es16 c16 d8 es32( d32 c32 d32 es32 c32 d32 es32) f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) | % bar 35
    e,32( f32 g32 a32 bes32 c32 d32 bes32) c32( d32 e32 f32 g32 a32 bes32 g32) a32( g32 bes32 a32 g32 f32 e32 f32) e8. f16 | % bar 36
    f4 c32( d32 es32 c32 es32 d32 c32 bes32) a32( bes32 c32 a32 c32 bes32 a32 bes32) c32( d32 es32 c32 es32 d32 c32 bes32) | % bar 37
    f'4~ f32( es32 d32 es32 f32 d32 es32 f32) g,32( a32 bes32 c32 d32 es32 f32 d32) es32( d32 c32 d32 es32 c32 d32 es32) | % bar 38
    f,32( g32 a32 bes32 c32 d32 es32 c32) d32( c32 bes32 c32 d32 bes32 c32 d32) g32( f32 es32 d32 c32 bes32 a32 bes32) a8. bes16 | % bar 39
    bes4\fermata r4 r2 | % bar 40
    R1 | % bar 41
    r4 g8\Pia g8 g4 f'8 es16 d16 | % bar 42
    g8 c,8 b16( c16 b16 c16) es16( c16 d8) r8 c8(~ | % bar 43
    c32 b32 a32 b32 c32 a32 b32 c32) b8 r8 r4 r8 g'8(~ | % bar 44
    g32 f32 es32 f32 g32 es32 f32 g32) c,8 r8 r4 r8 f8(~ | % bar 45
    f32 es32 d32 es32 f32 d32 es32 f32) bes,8 r8 r2 | % bar 46
    r4 d,8\Pia d8 d4 c'8 bes16 a16 | % bar 47
    d8 g,8 fis16( g16 fis16 g16) bes16( g16 a8) r8 a8~ | % bar 48
    a32 g32( fis32 g32 a32 fis32 g32 a32) fis32( a32 bes32 c32 d32 bes32 c32 d32) es,32( fis32 g32 a32 bes32 c32 d32 bes32) c32( bes32 a32 bes32 c32 a32 bes32 c32) | % bar 49
    d,32( e32 fis32 g32 a32 bes32 c32 a32) bes32( a32 g32 a32 bes32 g32 a32 bes32) es32( d32 c32 bes32 a32 g32 fis32 g32) fis8. g16 | % bar 50
    g4\fermata e'32( f32 g32 e32 g32 f32 e32 d32) cis32( d32 e32 cis32 e32 d32 cis32 d32) e32( f32 g32 e32 g32 f32 e32 d32) | % bar 51
    a'4~ a32( g32 f32 g32 a32 f32 g32 a32) bes,32( \once \set suggestAccidentals = ##t cis32 d32 e32 f32 g32 a32 f32) g32( f32 e32 f32 g32 e32 f32 g32) | % bar 52
    a,32( b32 cis32 d32 e32 f32 g32 e32) f32( e32 d32 e32 f32 d32 e32 f32) bes32( a32 g32 f32 e32 d32 cis32 d32) cis8. d16 | % bar 53
    d4 r4 r2 | % bar 54
}
\mvtVtimeLine
>>


mvtVvlnII = <<
\relative c' {
    r4 d8 c8 d4 g8 f8 | % bar 1
    f8 g8 es8 f8 f16( g16 a8) d,8 f8 | % bar 2
    es4 f8 g8 g8 as8 f8 g8 | % bar 3
    g4 g8 g8 f4 f8 f8 | % bar 4
    e8 f8 g8 c8 c8 d8 c8 bes8 | % bar 5
    a16( bes16 a16 bes16) c8 bes8 c8 d8 c8 bes8 | % bar 6
    as4 as8 as8 g4 g8 g8 | % bar 7
    f4 f8 f8 g8. g16 f8. f16 | % bar 8
    f4 d8\Pia( c8) f8 es16 d16 g8 a8 | % bar 9
    bes16( a16 g16 f16) es16( c16 d16 es16) f4 d8( es16 f16) | % bar 10
    g8 c8~ c8 b8 c16( g16 as16 g16) f16( d16 es16 f16) | % bar 11
    g4 g8 g8 f4 f8 f8 | % bar 12
    e8 f8 g8 g8 f8 d'8 c8 bes8 | % bar 13
    a16( bes16 a16 bes16) c8 f,8 c'8 d8 c8 bes8 | % bar 14
    a4 r4 r4 bes4 | % bar 15
    bes8 c8 c8 b8 c8 g8 g16( f16 es16 d16) | % bar 16
    c16( d16 c16 d16) es8 es8 es8 d8 d16( c16 bes16 a16) | % bar 17
    bes4 r4 r2 | % bar 18
    r4 c'8\For c8 c8 c8 c8 c8 | % bar 19
    f,4 r4 r2 | % bar 20
    R1 | % bar 21
    r4 g8\For f8 g8 a8 g8 f16 g16 | % bar 22
    a4 a8 fis8 g8 d8 g8 g8 | % bar 23
    g8 e8 f8 f8 f8. bes,16 c8. c16 | % bar 24
    c4 f8\Pia e8 f8 c'8~ c8 b8 | % bar 25
    c16( bes16 as16 g16) f16( d16 es16 f16) g4 d8 es16 f16 | % bar 26
    es8 g8 c8 bes16 a16 bes16( a16 g16 f16) es16( c16 d16 es16) | % bar 27
    f4 f8 f8 g4 g8 g8 | % bar 28
    f4 f8 bes8 g8. g16 f8 f8 | % bar 29
    d4 r8 f8 g8 r8 r8 g8 | % bar 30
    a8 r8 r4 r2 | % bar 31
    r4 d,8\For c8 d4 g8 f8 | % bar 32
    f8 g8 es8 f8 f16( g16 a8) d,8 f8 | % bar 33
    es4 f8 g8 g8 as8 f8 g8 | % bar 34
    g4 g8 g8 f4 f8 f | % bar 35
    e8 f8 g8 c8 c8 d8 c8 bes8 | % bar 36
    a16( bes16 a16 bes16) c8 bes8 c8 d8 c8 bes8 | % bar 37
    as4 as8 as8 g4 g8 g8 | % bar 38
    f4 f8 f8 g8. g16 f8. f16 | % bar 39
    f4\fermata r4 r2 | % bar 40
    R1 | % bar 41
    r4 g8\Pia f8 es4 f8 g8 | % bar 42
    g as f8 g8 f4 r8 g8 | % bar 43
    a4 g8 r8 r4 r8 c8 | % bar 44
    a4 r4 r4 r8 bes8 | % bar 45
    g4 r4 r2 | % bar 46
    r4 a,8\Pia c8 bes4 c8 d8 | % bar 47
    d8 es8 c8 d8 c4 r8 es8 | % bar 48
    d8 e8 d8 bes'8 a4 r8 g8 | % bar 49
    fis4 r8 g8 g4 r8 d8 | % bar 50
    < a' cis,>1\fermata~  | % bar 51
    < a cis,>4  r4 r2 | % bar 52
    R1*2 |
}
\mvtVtimeLine
>>


mvtVvla = <<
\relative c' {
    \clef C
    r4 bes8 a8 bes4. a8 | % bar 1
    bes8 bes8 c8 d8 d16( e16 f8) b,8 b8 | % bar 2
    c4. b8 c8 c8 f,8 c'8 | % bar 3
    c8 b8 c8 c8 c4 bes8 bes8 | % bar 4
    bes4 g8 e'8 f8 d8 g,8 c8 | % bar 5
    c4 f8 f8 f8 f8 f8 f8 | % bar 6
    bes,4 bes8 bes8 bes4 c8 c8 | % bar 7
    c4 bes8 bes8 bes8. es16 c8. c16 | % bar 8
    d4 bes8\Pia( a8) bes4 g8 f8~ | % bar 9
    f8 es8~ es8 bes'8~ bes16 g16 a8 b8 b8 | % bar 10
    c8 es8 as,8 g8~ g8 f8~ f8 c'8~ | % bar 11
    c16 a16 b8 c8 c8 c4 bes8 bes8 | % bar 12
    bes4 g8 e'8 f8 d8 a8 c8 | % bar 13
    c4 f8 f8 f8 f8 es8 d16 es16 | % bar 14
    f4 r4 r4 f8 es16 d16 | % bar 15
    es8 es8 as,8 g8 g8 es'8 es16( d16 c16 bes16) | % bar 16
    a16( bes16 a16 bes16) c8 c8 c8 bes8 g8 f8 | % bar 17
    f4 r4 r2 | % bar 18
    r4 g'8\f f8 g8 a8 g8 f8 | % bar 19
    es4 r4 r2 | % bar 20
    R1 | % bar 21
    r4 c8\For c8 c8 c8 c8 f8 | % bar 22
    fis4 d8 d8 d4 d8 d8 | % bar 23
    c4 c8 c8 d8. d16 g,8. a16 | % bar 24
    a4 a8\Pia g8 a16( g16 f16 g16) as8 g8~ | % bar 25
    g8 f8~ f8 c'8~ c16 a16( b16 c16) d8 c16 b16 | % bar 26
    c4 f,8 f8~ f8 es8~ es8 bes'8~ | % bar 27
    bes16 g16 a8 bes8 bes8 bes4 c8 c8 | % bar 28
    c4 bes8 bes8 es8. es16 c8. bes16 | % bar 29
    bes4 r8 d8 es8 r8 r8 es8 | % bar 30
    f8 r8 r4 r2 | % bar 31
    r4 bes,8\For a8 bes4. a8 | % bar 32
    bes8 bes8 c8 d8 d16( e16 f8) b,8 b | % bar 33
    c4. b8 c8 c8 f,8 c'8 | % bar 34
    c8 b8 c8 c8 c4 bes8 bes8 | % bar 35
    bes4 g8 e'8 f8 d8 g,8 c8 | % bar 36
    c4 f8 f8 f8 f8 f8 f8 | % bar 37
    bes,4 bes8 bes bes4 c8 c8 | % bar 38
    c4 bes8 bes8 bes8. es16 c8. c16 | % bar 39
    d4\fermata r4 r2 | % bar 40
    R1 | % bar 41
    r4 c8\p d8 c4 as8 g8 | % bar 42
    g8 f8 f'8 es8 c8 as8 r8 c8 | % bar 43
    a8 fis8 d'8 r8 r4 r8 es8 | % bar 44
    c4 r4 r4 r8 d8 | % bar 45
    bes4 r4 r2 | % bar 46
    r4 fis8\Pia a8 g4 es8 d8 | % bar 47
    d c c'8 bes8 g8 c8 r8 c8 | % bar 48
    bes8 e,8 a8 g8 a4 r8 a8 | % bar 49
    a4 r8 e'8 d4 r8 d8 | % bar 50
    < e g,>1\fermata~  | % bar 51
    < e g,>4  r4 r2 | % bar 52
    R1*2 |
}
\mvtVtimeLine
>>


mvtVtenor = <<
\relative c {
    \autoBeamOff

    R1*8 | % bar 1
    r4 f8 f8 f4 es'8 d16[ c16] | % bar 9
    f8 bes,8 a8 bes8 d8 c8 g8 g8 | % bar 10
    g4 f'8 es16[ d16] g8 c,8 b8 c8 | % bar 11
    es8 d16 g,16 g'8 es8 c8 bes16[ a16] f'8 d8 | % bar 12
    bes8. a16 bes16[ d16] c8 c8. d16 a8 g16[ f16] | % bar 13
    f8 es'8 r16 c16 bes16 a16 f'8 bes,8 g'8 f16[ es16] | % bar 14
    c4 f8 f8 f4 as,8 g16[( f16)] | % bar 15
    g8 g'8 g16[ f16] es16[ d16] es8 c8 es8 es8 | % bar 16
    es4 bes8 a16[ g16] a8 f'8 f16[ es16] d16[ c16] | % bar 17
    d8 c16 bes16 a8 g8 e'8 f8 r8 a,16 f16 | % bar 18
    c'1~ | % bar 19
    c16 bes16 a16 bes16 c16 f,16 es'8 r16 d16 bes16 c16 d16 g,16 f'8 | % bar 20
    r16 f16 e16 d16 c16 bes16 g'8 r4 a,8 g16[ f16] | % bar 21
    f4 r4 r2 | % bar 22
    R1*2 | % bar 23
    r4 c'8 c8 c4 f8 es16[ d16] | % bar 25
    g8 c,8 b8 c16[ d16] es16[ c16] d8 g,8 g8 | % bar 26
    g4 es'8 d16[ c16] f8 bes,8 a8 bes16[ c16] | % bar 27
    d16[ bes16] c16 f,16 f'8 d8 bes8 a16[ g16] es'8 es8 | % bar 28
    es16 c16 f16 es16 d16[ c16] bes16[ a16] bes8 r8 f8 d'8 | % bar 29
    bes16 c16 d16 es16 f16 bes,16 as'8 r16 g16 f16 es16 d16 c16 es8 | % bar 30
    r16 f,16 g16 a16 bes16[ c16] d16[ bes16] g'8 r8 d8 c16[ bes16] | % bar 31
    bes4 r4 r2 | % bar 32
    R1*7 | % bar 33
    r8\fermata d8 es16[ d16] c16[ bes16] f'8. as16 g16[( f16)] es16([ d16)] | % bar 40
    es4 r8 c16 f16 d8 es16 b16 c16 es16 d16 c16 | % bar 41
    b16[ c16] d16[ b16] g8 b8 c16[( b16)] c16[( es16)] es16[( d16)] c16[( b16)] | % bar 42
    c4 r8 g'8 as,8[( f'8]~ f16[ g32 f32]) es16 d16 | % bar 43
    es8.[( d32 es32]) d8 c16[ b16] c16[( b16)] a16[ g16] c8[( d16)] es16 | % bar 44
    es8 d16[ c16] a8.\trill g16 bes16[( a16)] g16[( f16)] bes8[( c16)] d16 | % bar 45
    d8 c16[( bes16)] g8.\trill g'16 es8 d16[ c16] d16[( bes16)] a16[ g16] | % bar 46
    fis16[ g16] a16[ fis16] d8 fis8 g16[ fis16] g16[ bes16] bes16[ a16] g16[ fis16] | % bar 47
    g4 r8 d'8 es16([ d16 fis8]~ fis16[ g16]) es16 d16 | % bar 48
    bes8.[( a32 bes32)] a8 bes8 c8 d8 es8. f16 | % bar 49
    d8 fis,8 g4~ g16[ c16 d16] es16 a,8.[ g16] | % bar 50
    g8.\fermata f'16 e16 d16 cis16 d16 e16[ cis16] a16 f'16 e16 d16 cis16 d16 | % bar 51
    g,8. a16 b16 cis16 d16 e16 f16[ d16] bes8 r16 bes16 a16 g16 | % bar 52
    e'8 d16[ e32 cis32] d4~ d16 bes16 gis16 a16 f8[ e16 d16] | % bar 53
    d4 r4 r2 | % bar 54
}
\mvtVtimeLine
>>

mvtVlyrics = \lyricmode {
    Kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    so gilt der Mam -- mon nichts bei mir,
    so gilt der Mam -- mon nichts bei mir, nichts,
    so gilt der Mam -- mon nichts bei mir.

    Kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    so gilt der Mam -- mon nichts bei mir, __
    so gilt der Mam -- mon nichts,
    so gilt der Mam -- mon nichts,
    so gilt der Mam -- mon nichts, nichts bei mir.

    Kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    kann ich nur Je -- sum mir zum Freun -- de ma -- chen,
    so gilt der Mam -- mon nichts bei mir,
    so gilt der Mam -- mon nichts, nichts bei mir,
    so gilt der Mam -- mon nichts,
    so gilt der Mam -- mon nichts,
    so gilt der Mam -- mon nichts, nichts bei mir.

    Ich fin -- de kein Ver -- gnü -- gen hier,
    kein Ver -- gnü -- gen,
    ich fin -- de kein Ver -- gnü -- gen hier
    bei die -- ser eit -- len Welt und ir -- di -- schen Sa -- chen,
    ich fin -- de kein Ver -- gnü -- gen hier,
    ich fin -- de kein Ver -- gnü -- gen hier,
    ich fin -- de kein Ver -- gnü -- gen hier
    bei die -- ser eit -- len Welt und ir -- di -- schen Sa -- chen,
    bei die -- ser eit -- len Welt und ird -- schen Sa -- chen.,
    ich fin -- de kein Ver -- gnü -- gen
    bei die -- ser eit -- len Welt,
    ich fin -- de kein Ver -- gnü -- gen
    bei die -- ser eit -- len Welt __ und ird -- schen Sa -- chen.
}


mvtVbc = <<
\relative c {
    \clef F
    bes8 bes'16 a16 bes8 f8 d8 c16 bes16 c8 f8 | % bar 1
    d8 es8 c8 bes8 f8 f'16 es16 f8 d8 | % bar 2
    es8 d16 c16 d8 g8 es8 f8 d8 c8 | % bar 3
    g8 g'8 c8 bes8 a8 f8 bes8 a8 | % bar 4
    g8 f8 e8 c8 f8 bes,8 c8 c,8 | % bar 5
    f8 f'16 g16 a8 bes8 es,8 d8 a8 bes8 | % bar 6
    d,8 d'16 c16 d8 bes8 es8 d8 c8 bes8 | % bar 7
    a8 f8 bes8 bes'8 es,8. c16 f8 f,8 | % bar 8
    bes8 bes'16\Pia a16 bes8 f8 d8 c16 bes16 c8 f8 | % bar 9
    d8 es8 c8 bes8 f8 f'16 es16 f8 d8 | % bar 10
    es8 d16 c16 d8 g8 es8 f8 d8 c8 | % bar 11
    g8 g'8 c8 bes8 a8 f8 bes8 a8 | % bar 12
    g8 f8 e8 c8 f8 bes,8 c8 c,8 | % bar 13
    f8 f'16 g16 a8 bes8 es,8 d8 a8 bes8 | % bar 14
    f8 f'16\Pia es16 d8 c8 d8 bes16 c16 d8 bes8 | % bar 15
    es8 c8 f8 g8 c,8 c,8 r4 | % bar 16
    r4 c'16 d16 es16 c16 f8 d8 es8 f8 | % bar 17
    bes,8 d8 c8 bes8 bes'16 a16 g16 f16 e8 f8 | % bar 18
    e16 d16 c16 d16 e8 f8 bes,8 a8 e8 f16 g16 | % bar 19
    a8 g8 a8 f8 bes8 a8 bes8 g8 | % bar 20
    c8 d8 e8 c8 f8 bes,8 c8 c,8 | % bar 21
    f8 f'8\f e8 f8 bes,8 a8 e8 f8 | % bar 22
    d8 d'16 e16 fis8 d8 g8 g,8 g'8 f8 | % bar 23
    e8 c8 f8 f,8 bes8. g16 c8 c,8 | % bar 24
    f8 f'16 g16 a8\p c8 f,8 es8 d8 g8 | % bar 25
    es8 f8 d8 c8 g'8 g,16 a16 b8 g8 | % bar 26
    c8 c'16 bes16 a16 g16 f16 es16 d8 es8 c8 bes8 | % bar 27
    f'8 es8 d8 bes8 es8 d8 c8 bes8 | % bar 28
    a8 f8 bes8 g8 es8. c16 f8 d8 | % bar 29
    g8 g'8 d8 bes8 es8 d8 es8 c8 | % bar 30
    f8 es8 d8 bes8 es16 c16 d16 es16 f8 f,8 | % bar 31
    bes8 bes'16\f a16 bes8 f8 d8 c16 bes16 c8 f8 | % bar 32
    d8 es8 c8 bes8 f8 f'16 es16 f8 d8 | % bar 33
    es8 d16 c16 d8 g8 es8 f8 d8 c8 | % bar 34
    g8 g'8 c8 bes8 a8 f8 bes8 a8 | % bar 35
    g8 f8 e8 c8 f8 bes,8 c8 c,8 | % bar 36
    f8 f'16 g16 a8 bes8 es,8 d8 a8 bes8 | % bar 37
    d,8 d'16 c16 d8 bes8 es8 d8 c8 bes8 | % bar 38
    a8 f8 bes8 bes'8 es,8. c16 f8 f,8 | % bar 39
    bes4\fermata r8 a8\p g8 g'8 a8 b8 | % bar 40
    c8 d8 c8 bes8 as8 g8 as8 f8 | % bar 41
    g8 f8 es8 d8 es8 c8 d8 g8 | % bar 42
    es8 f8 d8 c8 f16 g16 as16 f16 b,8 c8 | % bar 43
    fis,4 g8 r8 r8 g'8 f16 es16 d16 c16 | % bar 44
    f8 f,8 es'8 d8 c8 f8 es16 d16 c16 bes16 | % bar 45
    es8 es,8 es'8 d8 c8 a8 bes c | % bar 46
    d8 d,8 d'16( c16 bes16 a16) bes8 g8 a8 d8 | % bar 47
    bes8 c8 a8 g8 c16 d16 es16 c16 bes16 a16 g16 fis16 | % bar 48
    g8 cis8 d8 g,8 fis4 r8 a8 | % bar 49
    c4 r8 cis8 d8 c8 d8 d,8 | % bar 50
    a'4\fermata r8 a'8 g4 r8 e8 | % bar 51
    cis8 g'8 f8 e8 d8 cis16 d16 e8 d8 | % bar 52
    cis8 a8 d8 bes8 g8 b a8 a8 | % bar 53
    d,4 r4 r2 | % bar 54
}
\mvtVtimeLine
>>


mvtVfigs = \figuremode {
    %138
    s2 <6>4 <7>8 <6>16 <5> |
    <6>4 <[6]> <6 4>8 <5 3> <6 4\+ 2> <6\\> |
    <6>4 <7>8 <7 _!> <6> <_-> <6\\>4 |
    <6 4>8 <5 _!> s4 <6 5> s |

    <6\\ 5> <6 5> s8 <6 5> <_!>4 |
    s <6 5> <6 4 2>8 <6> <6 5>4 |
    <6 5-> <6 5-> <9> s |

    <6 5> s <7>8 <6>16 <7> s4 |
    s s <6> <7> |
    <6> <6> <6 4>8 <5 3> <6 4\+ 2>4 |

    %139
    <6> <7>8 <7 _!> <6> <_-> <6\\>4 |
    <6 4>8 <5 _!> s4 <6 5> s |
    <6\\ 5> <5> s8 <6 5> <6 _!> <5 \FBx> |

    <8> <7> <6 5> s <6 4 2> <6> <7 5>4 |
    s4 <6>8 <6> <6>4 <5-> |
    s <6 5 _->8 <_!> s4 s |

    s <7> <7>8 <6> <9 7> <7 5> |
    s <6> <4\+ 3> <[6]> <6 4\+ 2> <7 4> <6 5>4 |
    <6> <6 5> <6 4\+ 2>8 <6> <6 5>4 |

    %140
    <6 5>4 s <9>16 <[8]> s8 <6>4 |
    <7> <6 5> <9>8 <7 5> <6 4> <5 _!> |
    s4 <6> <6 4\+ 2>8 <6> <6 5>4 |

    <7 _+>4 <6 5> <4>8 <3>16 <2> <3>4 |
    <6 5> s <7 5>8 <6> <_!>4 |
    s <6>8 <_!> s4 <7 5->8 <6 _!>16 <[5]> |

    <6>8 <_-> <6\\>4 <6 4>8 <5 _!> <6 5>4 |
    s s <6> <6> |
    <[6 4]>8 <[6 4 2]> <6>4 <9> s |

    %141
    <6 5> s <7 5>8 <6> s <7 5> |
    s4 <6>8 <7- 5> s4 <6> |

    s <6> <6 5>16 <6 4 3> <6>8 <6 4> <5 3> |
    s4 s <6> <7>8 <6>16 <5> |
    <6>4 <6> <6 4>8 <5 3> <6 4\+ 2> <6\\> |
    <6>4 <7>8 <7 _!> <6> <_-> <6\\>4 |

    <6 4>8 <5 _!> s4 <6 5> s |
    <6\\ 5> <6 5> s8 <6 5> <_!>4 |
    s <6 5> <6 4 2>8 <6> <6 5>4 |

    %142
    <6 5-> <6 5-> <9> s8 <4 2> |
    <6 5>4 s <7>8 <6>16 <7> s4 |
    s s8 <6 4 2> <7 _!> s <7> <6 5> |

    s4 s <6 4 3>8 <6 _!> <7> <6 5> |
    <_!>4 <6>8 <6\\> <6>4 <7>8 <6 4>16 <5 _!> |
    <6>8 <_-> <6\\>4 <7 _->8 <6 4 3> <6 5>4 |

    <7- 5> <_!> s8 <_!> <7 5 2>4 |
    <9>4 <6 4 2>8 <6> <7>4 <7 5 2> |
    <9 7> <5> s8 <6\\ 5> <6> <6 5> |

    %143
    <_+>4 <_+> <6> <9 7>8 <7 _+> |
    <6> <_-> <6\\>4 <7>8 <6 4 2\+> <4 2> <6 4 2> |
    <9> <7- 5> <_+>4 <7- 5> s8 <7 5> |

    <6 4\+ 2>4 s8 <7- 5> <6 4> <7 5> <_+>4 |
    <_+> s <6\\ 4\+ 2> s8 <6\\ 4 3> |

    <6 5> <6\\ 4\+ 2> <6 4\+ 3> <6\\> <6>4 <7 5> |
    <6 5> s <7>16 <6\\> <6\\ 4\+ 3>8 <6 _+> <5\+ \FBx> |
    s1 |
}
