\version "2.19.15"

\include "bach-105-1.ly"
\include "bach-105-2.ly"
\include "bach-105-3.ly"
\include "bach-105-4.ly"
\include "bach-105-5.ly"
\include "bach-105-6.ly"

\include "bach-105-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Viola"
}


\addQuote mvtIbc { \mvtIbc }
\addQuote mvtIvla  { \mvtIvla }

\score {
    \new Staff <<
        \mvtIvla
        {
            s1*46 | %46
            s2 s2^"Tenore" | %47
            s1*4 | %51
            s1*5^"Basso" | %56
            s1*5^"Soprano" | %61
            s1^"Alto" | %62
            \cueDuringWithClef mvtIbc #UP #"bass" { s1*9^"Continuo" }
            % \cueDuring mvtIobII #DOWN { s1*5^"Oboe/Vln II" }
        }
    >>

    \header {
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}

\score {
    \new Staff <<
        \mvtIIIvla
    >>

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff <<
        \mvtIVvla
    >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}


\score {
    \new Staff <<
        \mvtVvla
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff <<
        \mvtVIvla
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
