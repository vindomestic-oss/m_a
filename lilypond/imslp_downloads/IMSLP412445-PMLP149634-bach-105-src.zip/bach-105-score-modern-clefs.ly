\version "2.19.15"

\include "bach-105-score-common.ly"
