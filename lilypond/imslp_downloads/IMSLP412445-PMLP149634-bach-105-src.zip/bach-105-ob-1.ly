\version "2.19.15"

\include "bach-105-1.ly"
\include "bach-105-2.ly"
\include "bach-105-3.ly"
\include "bach-105-4.ly"
\include "bach-105-5.ly"
\include "bach-105-6.ly"

\include "bach-105-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Oboe I"
}

\paper {
    ragged-last-bottom = ##f
}


\addQuote mvtIobII { \mvtIobII }
\addQuote mvtIvla  { \mvtIvla }

\score {
    \new Staff <<
        \mvtIobI
        {
            s1*47 | %47
            \pageBreak
            s1*24 | %71
            \cueDuringWithClef mvtIvla #DOWN #"alto" { s1*5^"Viola" }
            \cueDuring mvtIobII #DOWN { s1*5^"Oboe/Vln II" }
        }
    >>

    \header {
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}

\score {
    \new Staff <<
        \mvtIIIob
    >>

    \header {
        piece = \mvtIIIpiece
    }

    \header {
        breakbefore = ##t
    }
}

\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}

\score {
    \new Staff <<
        \mvtVIsoprano
    >>

    \header {
        piece = \mvtVIpiece
    }
}
