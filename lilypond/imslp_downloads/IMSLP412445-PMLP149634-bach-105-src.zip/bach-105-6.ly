\version "2.19.11"

\include "common.ly"

mvtVItimeLine = {
    \key bes \major
    \time 4/4

    s1*24 |
    \bar "|."
}

mvtVIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 3 { s1\noBreak\noPageBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak\noPageBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak\noPageBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak\noPageBreak }
    \pageBreak

    \repeat unfold 5 { s1\noBreak\noPageBreak }
    \break\noPageBreak
    \repeat unfold 6 { s1\noBreak\noPageBreak }
    \bar "|."
}

mvtVIbreaksAuto = {
    <>^"Autograph breaks left in"
    \repeat unfold 7 { s1\noBreak } \break\noPageBreak
    \repeat unfold 7 { s1\noBreak } \pageBreak

    \repeat unfold 7 { s1\noBreak } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak } \bar "|."
}


mvtVIvlnI = <<
\relative c'' {
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) g16( g16 g16 g16) | % bar 1
    g16( g16 g16 g16) g16( g16 g16 g16) g16( g16 g16 g16) fis16( fis16 fis16 fis16) | % bar 2
    g16( g16 g16 g16) f16( f16 f16 f16) e16( e16 e16 e16) es16( es16 es16 es16) | % bar 3
    d16( d16 d16 d16) g16( g16 g16 g16) g16( g16 fis16 fis16) g16( g16 g16 g16) | % bar 4
    c,16( c16 c16 c16) bes16( bes16 bes16 bes16) a16( a16 a16 a16) d16( d16 d16 d16) | % bar 5
    cis16( cis16 cis16 cis16) c16( c16 c16 c16)
        % \time 12/8
        \set Staff.timeSignatureFraction = 12/8
        \scaleDurations 2/3 {
                bes8( bes8 bes8) bes8( bes8 bes8) | % bar 6
            a8( a8 a8) d8( d8 d8) c8( c8 c8) g'8( g8 g8) | % bar 7
            g8( g8 g8) fis8( fis8 fis8) g8( g8 g8) f8( f8 f8) | % bar 8
            e8( e8 e8) es8( es8 es8) d8( d8 d8) d8( d8 d8) | % bar 9
            c8( c8 c8) e8( e8 e8) a,8( a8 a8) g8( g8 g8) | % bar 10
            d'8( d8 d8) c8( c8 c8) b8( b8 b8) bes8( bes8 bes8) | % bar 11
    }
    \set Staff.timeSignatureFraction = 4/4
    a8( a8 g8 g8) g'8( g8 c,8 c8) | % bar 12
    f8( f8 f8 f8) f8( f8 \once \set suggestAccidentals = ##t e8 e8) | % bar 13
    f8( f8 f8 f8) e8( e8 es8 es8) | % bar 14
    d8( d8 f8 f8) f8( f8 g8 g8) | % bar 15
    g8( a8 bes8 bes8) bes8( bes8 a8 a8) | % bar 16
    bes8( bes8 as8 as8) g8( g8 ges8 ges8) | % bar 17
    \set Staff.timeSignatureFraction = 12/8
    \scaleDurations 2/3 {
        f4( f8) bes4( bes8) bes4( bes8) a4( a8) | % bar 18
        a4( a8) g4( g8) fis4( fis8) d'4( d8) | % bar 19
        cis4( cis8) c4( c8) c4( c8) bes4( bes8) | % bar 20
        bes4( a8) a4( g8) g4( g8) fis4( fis8) | % bar 21
    }
    \set Staff.timeSignatureFraction = 4/4
    g4 g4 fis4 f4 | % bar 22
    e4 es4 d2~ | % bar 23
    \onceCenterNoteColumn #0 d1\fermata | % bar 24
}
\mvtVItimeLine
>>


mvtVIvlnII = <<
\relative c'' {
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) c16( c16 c16 c16) b16( b16 b16 b16) | % bar 1
    g16( g16 g16 g16) bes16( bes16 bes16 bes16) es16( es16 es16 es16) d16( d16 d16 d16) | % bar 2
    d16( d16 d16 d16) d16( d16 d16 d16) d16( d16 d16 d16) c16( c16 c16 c16) | % bar 3
    bes16( bes16 bes16 bes16) bes16( bes16 bes16 bes16) es16( es16 d16 d16) c16( c16 bes16 bes16) | % bar 4
    a16( a16 a16 a16) d,16( d16 e16 e16) fis16( fis16 fis16 fis16) bes16( bes16 bes16 bes16) | % bar 5
    bes16( bes16 bes16 bes16) a16( a16 a16 a16)
        \set Staff.timeSignatureFraction = 12/8
        \scaleDurations 2/3 {
            g8( g8 g8) g8( g8 g8) | % bar 6
        f8( f8 f8) f8( f8 f8) g8( g8 g8) d'8( d8 d8) | % bar 7
        d8( d8 d8) d8( d8 d8) d8( d8 d8) d8( d8 d8) | % bar 8
        d8( d8 d8) c8( c8 c8) bes8( bes8 bes8) g8( g8 g8) | % bar 9
        g8( g8 fis8) g8( g8 g8) d'8( d8 d8) c8( c8 c8) | % bar 10
        fis,8( fis8 fis8) a8( a8 a8) a8( a8 a8) g8( g8 g8) | % bar 11
    }
    \set Staff.timeSignatureFraction = 4/4
    fis8( fis8 d'8 d8) c8( c8 f8 f8) | % bar 12
    bes,8( bes8 c8 d8) c8( c8 c8 c8) | % bar 13
    c8( c8 des8 des8) des8( des8 c8 c8) | % bar 14
    bes8( bes8 a8 a8) bes8( bes8 bes8 bes8) | % bar 15
    bes8( c8 d8 d8) g8( g8 f8 f8) | % bar 16
    f8( f8 f8 f8) f8( f8 es8 es8) | % bar 17
    \set Staff.timeSignatureFraction = 12/8
    \scaleDurations 2/3 {
        d4( d8) f4( f8) f4( f8) d4( d8) | % bar 18
        d4( d8) es4( es8) a,4( a8) bes'4( bes8) | % bar 19
        bes4( bes8) a4( a8) a4( a8) g4( g8) | % bar 20
        g4( d8) d4( d8) c4( c8) c4( c8) | % bar 21
    }
    \set Staff.timeSignatureFraction = 4/4
    b4 es2 d4~ | % bar 22
    d4 c4~ c4 b8 a8 | % bar 23
    \onceCenterNoteColumn #0 b1\fermata | % bar 24
}
\mvtVItimeLine
>>


mvtVIvla = <<
\relative c' {
    \clef C
    f16( f16 f16 f16) g16( g16 g16 g16) a16( a16 a16 a16) d,16( d16 d16 d16) | % bar 1
    e16( e16 e16 e16) g16( g16 g16 g16) a16( a16 a16 a16) a16( a16 a16 a16) | % bar 2
    bes16( bes16 bes16 bes16) b16( b16 b16 b16) c16( c16 c16 c16) fis,16( fis16 fis16) fis16 | % bar 3
    g16( g16 g16 g16) g16( g16 g16 g16) a16( a16 d,16 d16) g16( g16 bes,16 bes16) | % bar 4
    es16( es16 c16 c16) g'16( g16 cis,16 cis16) d16( d16 d16 d16) d16( d16 d16 d16) | % bar 5
    e16( e16 e16 e16) fis16( fis16 fis16 fis16)
        \set Staff.timeSignatureFraction = 12/8
        \scaleDurations 2/3 {
            g8( g8 g8) d8( d8 d8) | % bar 6
        d8( d8 d8) a8( a8 a8) e'8( e8 e8) bes'8( bes8 bes8) | % bar 7
        c8( c8 c8) c8( c8 c8) bes8( bes8 bes8) b8( b8 b8) | % bar 8
        c8( c8 c8) fis,8( fis8 fis8) g8( g8 g8) d8( d8 d8) | % bar 9
        es8( es8 es8) e8( e8 e8) fis8( fis8 fis) es'8( es8 es8) | % bar 10
        a,8( a8 a8) fis8( fis8 fis8) g8( g8 g8) cis,8( cis8 cis8) | % bar 11
    }
    \set Staff.timeSignatureFraction = 4/4
    d8( d8 bes8 bes8) g8( g8 a8 a8) | % bar 12
    d8( d8 a'8 bes8) bes8( bes8 bes8 bes8) | % bar 13
    a8( a8 f8 f8) g8( g8 a8 a8) | % bar 14
    bes8( bes8 f8 f8) f8( f8 d8 d8) | % bar 15
    bes8( bes8 f'8 f8) es8( es8 es8 es8) | % bar 16
    d8( d8 d8 d8) es8( es8 a,?8 a8) | % bar 17
    \set Staff.timeSignatureFraction = 12/8
    \scaleDurations 2/3 {
        bes4( bes8) f'4( f8) c'4( c8) a4( a8) | % bar 18
        bes4( bes8) g4( g8) d'4( d8) d,4( d8) | % bar 19
        e4( e8) fis4( fis8) g4( g8) d4( d8) | % bar 20
        g,4( d'8) d4( g8) es4( es8) d4( d8) | % bar 21
    }
    \set Staff.timeSignatureFraction = 4/4
    d4 g,4 a4 b4 | % bar 22
    c4 fis,4 g2~ | % bar 23
    \onceCenterNoteColumn #0 g1\fermata | % bar 24
}
\mvtVItimeLine
>>


mvtVIsoprano = <<
\relative c'' {
    \autoBeamOff

    d4 d4 a4 b4 | % bar 1
    c4 bes4 a2 | % bar 2
    g4\fermata r4 r2 | % bar 3
    bes4 bes4 a4 g4 | % bar 4
    fis4 g4 a4\fermata r4 | % bar 5
    r2 d4 d4 | % bar 6
    a4. bes8 c4 bes4 | % bar 7
    a2 g2\fermata | % bar 8
    r2 bes4 bes4 | % bar 9
    a4 g4 fis4 g4 | % bar 10
    a4\fermata r4 r2 | % bar 11
    a4 bes4 c4 a4 | % bar 12
    bes4 a4 g2 | % bar 13
    f4\fermata r4 r2 | % bar 14
    bes4 c4 d4 d4 | % bar 15
    es4 d4 c2 | % bar 16
    bes4\fermata r4 r2 | % bar 17
    d4 d4 c4 d4 | % bar 18
    bes4 c4 d4\fermata r4 | % bar 19
    r2 d4 d4 | % bar 20
    c4 bes4 a4 a4 | % bar 21
    g4 r4 r2 | % bar 22
    R1 |
    R1\fermataMarkup |
}
\mvtVItimeLine
>>

mvtVIsopranoLyrics = \lyricmode {
    Nun, ich weiß, du wirst mir stil -- len
    mein Ge -- wis -- sen, das mich plagt.
    Es wird dei -- ne Treu er -- fül -- len,
    was du sel -- ber hast ge -- sagt:
    daß auf die -- ser wei -- ten Er -- den
    kei -- ner soll ver -- lo -- ren wer -- den,
    son -- dern e -- wig le -- ben soll,
    wenn er nur ist Glau -- bens voll.
}


mvtVIalto = <<
\relative c' {
    \autoBeamOff

    f8[( bes16 a16)] bes8[ c8] d4 g,4 | % bar 1
    g4 g4 a4( d,4) | % bar 2
    d4\fermata r4 r2 | % bar 3
    d4 g4 g8[( d8)] g4 | % bar 4
    a4 bes8[( g8)] fis4\fermata r4 | % bar 5
    r2 bes8[ c8] d4 | % bar 6
    d,4 d4 g4 g4 | % bar 7
    g4( d4) d4\fermata r4 | % bar 8
    r2 g4 g4 | % bar 9
    es4 g4 d4 g4 | % bar 10
    fis4\fermata r4 r2 | % bar 11
    fis4 g4 g4 f4 | % bar 12
    f4 f4 f4( c4) | % bar 13
    c4\fermata r4 r2 | % bar 14
    g'4 a4 f4 bes4 | % bar 15
    bes4 bes4 g4( c,4) | % bar 16
    d4\fermata r4 r2 | % bar 17
    f4 f4 f4 a4 | % bar 18
    d,4 g4 a4\fermata r4 | % bar 19
    r2 g4 g8[ f8] | % bar 20
    e8[ d8] d4 es8[ c8] a4 | % bar 21
    b4 r4 r2 | % bar 22
    R1 |
    R1\fermataMarkup |
}
\mvtVItimeLine
>>

mvtVIaltoLyrics = \lyricmode {
    Nun, ich weiß, du wirst mir stil -- len
    mein Ge -- wis -- sen, das mich plagt.
    Es wird dei -- ne Treu er -- fül -- len,
    was du sel -- ber hast ge -- sagt:
    daß auf die -- ser wei -- ten Er -- den
    kei -- ner soll ver -- lo -- ren wer -- den,
    son -- dern e -- wig le -- ben soll,
    wenn er nur ist Glau -- bens voll.
}


mvtVItenor = <<
\relative c' {
    \autoBeamOff

    bes8[ c8] d4 d4 d4 | % bar 1
    c4 g'8[ a] es4( d8[ c8]) | % bar 2
    bes4\fermata r4 r2 | % bar 3
    g4 g4 a8[( bes8)] c4 | % bar 4
    c4 d8[( bes8)] d4\fermata r4 | % bar 5
    r2 d4 es,8[ f] | % bar 6
    f8[ g8] a4 g8[ a8] bes8[ c8] | % bar 7
    d4( a4) bes4\fermata r4 | % bar 8
    r2 d4 g,4 | % bar 9
    a4 bes4 a4 c4 | % bar 10
    a4\fermata r4 r2 | % bar 11
    d4 d4 e4 c4 | % bar 12
    d4 a8[( f8)] c'4( g4) | % bar 13
    a4\fermata r4 r2 | % bar 14
    d8[( g8)] c,4 bes8[ c8] d4 | % bar 15
    g4 f8[ bes,8] c4( f4) | % bar 16
    f4\fermata r4 r2 | % bar 17
    bes,4 f8[ g8] a8[ g8] a8[ fis8] | % bar 18
    g8[ bes8] es4 fis,4\fermata r4 | % bar 19
    r2 d'4. bes8 | % bar 20
    g8[ a8] bes8[ g8] c8[( es8)] fis,8[( d'8)] | % bar 21
    d4 r4 r2 | % bar 22
    R1 |
    R1\fermataMarkup |
}
\mvtVItimeLine
>>

mvtVItenorLyrics = \lyricmode {
    Nun, ich weiß, du wirst mir stil -- len
    mein Ge -- wis -- sen, das mich plagt.
    Es wird dei -- ne Treu er -- fül -- len,
    was du sel -- ber hast ge -- sagt:
    daß auf die -- ser wei -- ten Er -- den
    kei -- ner soll ver -- lo -- ren wer -- den,
    son -- dern e -- wig le -- ben soll,
    wenn er nur ist Glau -- bens voll.
}


mvtVIbass = <<
\relative c' {
    \autoBeamOff

    \clef F
    bes4 a8[ g8] fis4 f4 | % bar 1
    e4 es8[ d8] c4( d4) | % bar 2
    g,4\fermata r4 r2 | % bar 3
    g'8[ f8] es8[ d8] c8[ d8] es4 | % bar 4
    a,4 g4 d'4\fermata r4 | % bar 5
    r2 g,8[ a8] bes8[ c8] | % bar 6
    d8[ es8] f4 e8[ fis8] g4 | % bar 7
    d'4( d,4) g4\fermata r4 | % bar 8
    r2 g8[ g,8] a8[ bes8] | % bar 9
    c4 cis4 d4 es4 | % bar 10
    d4\fermata r4 r2 | % bar 11
    d4 g8[ f8] e4 f8[ e8] | % bar 12
    d4 c8[ bes8] c2 | % bar 13
    f4\fermata r4 r2 | % bar 14
    g4 f8[ es8] d8[ c'8] bes[ a] | % bar 15
    g8[ f8] es8[ d8] es4( f4) | % bar 16
    bes,4\fermata r4 r2 | % bar 17
    bes8[ c8] d8[ es8] f8[ e8] fis8[ d8] | % bar 18
    g4 f8[ es8] d4\fermata r4 | % bar 19
    r2 g8[ a8] bes8[ d,8] | % bar 20
    e8[ fis8] g8[ bes,8] c8[ a8] d4 | % bar 21
    g,4 r4 r2 | % bar 22
    R1 |
    R1\fermataMarkup |
}
\mvtVItimeLine
>>

mvtVIbassLyrics = \lyricmode {
    Nun, ich weiß, du wirst mir stil -- len
    mein Ge -- wis -- sen, das mich plagt.
    Es wird dei -- ne Treu er -- fül -- len,
    was du sel -- ber hast ge -- sagt:
    daß auf die -- ser wei -- ten Er -- den
    kei -- ner soll ver -- lo -- ren wer -- den,
    son -- dern e -- wig le -- ben soll,
    wenn er nur ist Glau -- bens voll.
}


mvtVIbc = <<
\relative c' {
    \clef F
    bes4 a8 g8 fis4 f4 | % bar 1
    e4 es8 d8 c4( d4) | % bar 2
    g,4\fermata r4 r2 | % bar 3
    g'8 f8 es8 d8 c8 d8 es4 | % bar 4
    a,4 g4 d'4\fermata r4 | % bar 5
    r2 g,8 a8 bes8 c8 | % bar 6
    d8 es8 f4 e8 fis8 g4 | % bar 7
    d'4( d,4) g,2\fermata | % bar 8
    r2 g'8 g,8 a8 bes8 | % bar 9
    c4 cis4 d4 es4 | % bar 10
    d4\fermata r4 r2 | % bar 11
    d4 g8 f8 e4 f8 e8 | % bar 12
    d4 c8 bes8 c4 c,4 | % bar 13
    f4\fermata r4 r2 | % bar 14
    g8 g'8 f8 es8 d8 c8 bes8 a8 | % bar 15
    g8 f8 es8 d8 es4 f4 | % bar 16
    bes4\fermata r4 r2 | % bar 17
    bes8 c8 d8 es8 f8 e8 fis8 d8 | % bar 18
    g4 f8 es8 d4\fermata r4 | % bar 19
    r2 g8 a8 bes8 d,8 | % bar 20
    e8 fis8 g8 bes,8 c8 a8 d8 d,8 | % bar 21
    g4 r4 r2 | % bar 22
    R1 |
    R1\fermataMarkup |
}
\mvtVItimeLine
>>


mvtVIfigs = \figuremode {
    <5>4 <7 4 2> <6> <6 4\+ 2> |
    <6> <5> <6 5> <_+> |
    s1 |

    s2 <6 5>8 <_+> <6>4 |
    <6\\> s <_+> s |
    s2 s4 <6> |

    <3> <6 3>8 <4> <6> <6 5> s4 |
    <4> <_+> s2 |
    s2 s4 <7 4 2> |

    <6> <7- 5> <_+> <6> |
    <_+> s s2 |
    <_+>4 s <6> s |
    <6> <6 4> <5 4> <\FBx _+> |

    s1 |
    s4 <7 5> <6> s |
    <6> <7 5 2> <6 5> s |
    s1 |
    s2 s4 <6> |

    s <7 5 2> <_+> s |
    s2 <5 4>4 <6> |
    <6 5>8 <6 5> <9> <6> <6 5>4 <_+> |
    <_!> s s2 |
    s1*2 |
}
