\version "2.19.15"

\include "bach-105-1.ly"
\include "bach-105-2.ly"
\include "bach-105-3.ly"
\include "bach-105-4.ly"
\include "bach-105-5.ly"
\include "bach-105-6.ly"

\include "bach-105-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Basso Continuo"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
    \new Staff = staffH <<
        \mvtIbc
    >>

    \header {
        piece = \mvtIpiece
    }
}


\score {
    \new StaffGroup <<
        \new Staff = mvtIIalto \with { \staffSize #-3 } <<
            \set Staff.instrumentName = \markup\bold{\normalsize "Alto"}

            \new Voice = mvtIIalto { \clefAlto \mvtIIalto }
            \new Lyrics \with {
                alignBelowContext = "mvtIValto"
                \override LyricText.font-size = #-1
            } {
                \lyricsto mvtIIalto \mvtIIlyrics
            }
        >>
        \new Staff = staffH <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \mvtIIbc
        >>
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }

    \layout {
        indent = 18
    }
}

\markup\Tacet{\mvtIIIpiece}


\score {
    \new Staff = staffE <<
        \mvtIVbc
    >>

    \header {
        piece = \mvtIVpiece
    }
}


\markup\null\pageBreak
\blankPage
% \pageBreak


\score {
    \new Staff = staffF <<
        \mvtVbc
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff = staffH <<
        \mvtVIbc
    >>

    \header {
        piece = \mvtVIpiece
        % breakbefore = ##t
    }
}
