\version "2.19.11"

\include "common.ly"

mvtItimeLine = {
    \key g \minor

    \time 4/4
    \tempo "Adagio"
    s1*46 |
    s2 \railroad \tempo "Allegro" s2 |
    \bar "||"
    \time 2/2
    s1*81
    \bar "|."
}

mvtIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 6 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | }
    \pageBreak

    \repeat unfold 3 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 6 { s1\noBreak | }
    \pageBreak

    \repeat unfold 5 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | }
    \pageBreak

    \repeat unfold 5 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | }
    \pageBreak

    \repeat unfold 3 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | }
    \pageBreak

    \repeat unfold 4 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 6 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak | }
    \pageBreak

    \repeat unfold 7 { s1\noBreak | }
    \bar "|."
}


mvtIbreaksAuto = {
    %p2
    <>^"Autograph breaks left in"
    \repeat unfold 6 { s1\noBreak } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak } s2 \bar "" \break\noPageBreak
    s2\noBreak \repeat unfold 3 { s1\noBreak } \pageBreak

    %p3
    \repeat unfold 7 { s1\noBreak } \break\noPageBreak
    \repeat unfold 5 { s1\noBreak } \pageBreak

    %p4
    \repeat unfold 4 { s1\noBreak } s2 \bar "" \break\noPageBreak
    s2\noBreak \repeat unfold 1 { s1\noBreak } s2 \bar "" \pageBreak

    %p5
    s2\noBreak \repeat unfold 5 { s1\noBreak } \break\noPageBreak
    \repeat unfold 5 { s1\noBreak } \break\noPageBreak
    \repeat unfold 5 { s1\noBreak } s2 \bar "" \pageBreak

    %p6
    s2\noBreak \repeat unfold 8 { s1\noBreak } \break\noPageBreak
    \repeat unfold 10 { s1\noBreak } \break\noPageBreak
    \repeat unfold 9 { s1\noBreak } \pageBreak

    %p7
    \repeat unfold 9 { s1\noBreak } \break\noPageBreak
    \repeat unfold 8 { s1\noBreak } \pageBreak

    %p8
    \repeat unfold 9 { s1\noBreak } \break\noPageBreak
    \repeat unfold 10 { s1\noBreak } \pageBreak

    %p9
    \repeat unfold 9 { s1\noBreak } \break\noPageBreak
    \repeat unfold 7 { s1\noBreak } \bar "|."
}


mvtIobI = <<
\relative c'' {
    r2 a4 bes4~ | % bar 1
    bes4 a4 b4 c4~ | % bar 2
    c4 b4 cis4 d4~ | % bar 3
    d4 c4~ c4 r8 bes8 | % bar 4
    bes8( a8) r8 b8 b8( c8) r8 d8 | % bar 5
    d8( es8) es8( d8) cis8( a'8) r8 c,8 | % bar 6
    b8( g'8) r8 bes,8 a8( f'8) r8 as,8 | % bar 7
    g8( as8) fis8( g8) fis4 g4~ | % bar 8
    g4 fis4\trill g4 r4 | % bar 9
    R1*5 | % bar 10
    a4 bes2 a4 | % bar 15
    b4 c2 b4 | % bar 16
    cis4 d2 c4 | % bar 17
    bes?2 a4 d4 | % bar 18
    d1~ | % bar 19
    d2. c4~ | % bar 20
    c4 bes2 a4~ | % bar 21
    a4 g4~ 8 g'8( f8 e8) | % bar 22
    f4( e4)\trill d8( e16 f16) g4~ | % bar 23
    g8 f16( e16) a4~ a8 g16( fis16) g4 | % bar 24
    r8 d8~ d8 c16( bes16) es4 d4~ | % bar 25
    d8 e16( fis16) g4~ g8 f16( e16) a8 d,8~ | % bar 26
    d8 c16( bes16) es8( d8) cis8( a8) r4 | % bar 27
    R1 | % bar 28
    e'8( g16 f16) g4~ g8 fis8 r8 a8 | % bar 29
    d,8( f16 e16) f4~ f8 e8 r8 g8 | % bar 30
    c,8( es16 d16) es4~ es8 d16( c16) d4~ | % bar 31
    d8 c8 bes8( c16 d16) es8. d16 c16( bes16 a16 g16) | % bar 32
    fis8 d'8~ d16 e16( fis16 g16) a8 r8 r4 | % bar 33
    r2 a,4 bes4~ | % bar 34
    bes4 a4 b4 c4~ | % bar 35
    c4 b4 cis4 d4~ | % bar 36
    d4 c2 r8 bes8 | % bar 37
    bes8( a8) r8 b8 b8( c8) r8 d8 | % bar 38
    d8( es8) es8( d8) cis8( a'8) r8 c,8 | % bar 39
    b8( g'8) r8 bes,8 a8( f'8) r8 as,8 | % bar 40
    g8( as8) fis8( g8) fis4 r8 fis8 | % bar 41
    g8( bes) a8( g8) fis4\Pia r8 a'8 | % bar 42
    d,?8( f16 es16) f4~ f8 es8( d8) g16( a32 bes) | % bar 43
    c,8( es16 d16) es4~ es8 d8( c8) fis16( g32 a32) | % bar 44
    bes,8( d16 c16) d4~ d8 c8( bes8) << { \tiny { g'16( fis32 g32) } } \\ { g8 } >>  | % bar 45
    a,8( c16 bes16) c4~ c8 bes8( a8)\For d8 | % bar 46
    bes16( c16) bes16( c16) c8.\trill d16 d4 r4 | % bar 47
    % R1*34 | % bar 81
    R1*24 | % bar 71
    \tag PARTS \voiceOne
    R1*10 | % bar 81
    \tag PARTS \oneVoice
    g,2 r4 g4 | % bar 82
    d'4 a4 d4 a4 | % bar 83
    bes4 a8 bes8 c4 g4 | % bar 84
    a4 g8 a8 bes4 f4 | % bar 85
    g4 a8 bes8 a4 g4 | % bar 86
    f4 d4 c'2~ | % bar 87
    c4 a4 d4 a4 | % bar 88
    bes4 a8 g8 es'2~ | % bar 89
    es4 d8 c8 f4 c4 | % bar 90
    d4 c8 bes8 g'2~ | % bar 91
    g4 e4 a4 e4 | % bar 92
    fis4 e8 d8 d'2~ | % bar 93
    d4 d,4 g4 d4 | % bar 94
    es4 d8 es8 f4 c4 | % bar 95
    d4 c8 d8 es4 bes4 | % bar 96
    c4 d8 es8 d4 c4 | % bar 97
    bes4 g4 g'2~ | % bar 98
    g2 f2~ | % bar 99
    f2 e2~ | % bar 100
    e2 d2~ | % bar 101
    d2 cis2 | % bar 102
    d4 a4\Pia f'2~ | % bar 103
    f2 es?2~ | % bar 104
    es2 d2~ | % bar 105
    d2 c2~ | % bar 106
    c2 b2 | % bar 107
    c4 g4 es'2\PPia~ | % bar 108
    es2 d2~ | % bar 109
    d2 c2~ | % bar 110
    c2 bes2~ | % bar 111
    bes2 a2 | % bar 112
    bes4 f4\For d'2~ | % bar 113
    d4 g,4 c2~ | % bar 114
    c4 d8 es8 d4 c4 | % bar 115
    bes8 a8 bes8 c8 d8 es8 f8 d8 | % bar 116
    g8 f8 es8 d8 c8 es8 d8 es8 | % bar 117
    f8 es8 d8 c8 bes8 d8 c8 d8 | % bar 118
    es8 d8 c8 bes8 c8 a8 d4 | % bar 119
    g,1~ | % bar 120
    g1~ | % bar 121
    g1~ | % bar 122
    g4 g4 es'2~ | % bar 123
    es2 d2~ | % bar 124
    d2 c2~ | % bar 125
    c4 d8 es8 d4 c4 | % bar 126
    bes2 a2\trill | % bar 127
    g1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIobII = <<
\relative c' {
    d4 es2 d4 | % bar 1
    e4 f2 e4 | % bar 2
    fis4 g2 f4 | % bar 3
    es2 d4 g4 | % bar 4
    g1~ | % bar 5
    g2. f4~ | % bar 6
    f4 es2 d4~ | % bar 7
    d4 c4~ 8 c'8( bes8 a8) | % bar 8
    bes4( a4\trill) g4 r4 | % bar 9
    R1*5 | % bar 10
    r2 e4 f4~ | % bar 15
    f4 e4 fis4 g4~ | % bar 16
    g4 fis4 gis4 a4~ | % bar 17
    a4 g2 r8 f8 | % bar 18
    f8( e8) r8 fis8 fis8( g8) r8 a8 | % bar 19
    a8( bes8) bes8( a8) gis8( e'8) r8 g,8 | % bar 20
    fis8( d'8) r8 f,8 e8( c'8) r8 es,8 | % bar 21
    d8 es'8( cis8 d8) cis4 d4~ | % bar 22
    d4 cis4\trill d8( c8) bes4~ | % bar 23
    bes4 a8( bes16 c16) d4 r8 c8~ | % bar 24
    c8 bes16( a16) bes4 r8 c8~ c8 bes16( a16) | % bar 25
    g8 bes8~ bes8 a16( g16) a4. g16( f16) | % bar 26
    bes4~ bes16( a16 g16 bes16) a8( e8) r4 | % bar 27
    R1 | % bar 28
    r2 a8( c16 bes16) c4~ | % bar 29
    c8 b8 r8 d8 g,8( bes16 a16) bes4~ | % bar 30
    bes8 a8 r8 c8 f,8( bes16 a16) bes4~ | % bar 31
    bes8 a8 g2~ g8 fis16( g) | % bar 32
    a8( bes16 c16) d4 r2 | % bar 33
    d,4 es2 d4 | % bar 34
    e4 f2 e4 | % bar 35
    fis4 g2 f4 | % bar 36
    es2 d4 g4 | % bar 37
    g1~ | % bar 38
    g2. f4~ | % bar 39
    f4 es2 d4~ | % bar 40
    d4 c4~ c8 c'8( bes8 a8) | % bar 41
    bes4 c4 d8( c16 bes16) c4\Pia~ | % bar 42
    c8 bes8( a8) d16( es32 f32) g,8( bes16 a16) bes4~ | % bar 43
    bes8 a8( g8) c16( d32 es32) fis,8( a16 g16) a4~ | % bar 44
    a8 g8( fis8) bes16( c32 d) e,8( g16 fis16) g4~ | % bar 45
    g8 fis8( e8) a16( bes32 c32) d,8( fis16 e16) fis4\For | % bar 46
    g16( a16) g16( a16) a8.\trill g16 fis4 r4 | % bar 47
    % R1*29 | % bar 76
    R1*24 | % bar 71
    \tag PARTS \voiceOne
    R1*5 | % bar 76
    \tag PARTS \oneVoice
    d2 r4 d4 | % bar 77
    g4 d4 g4 d4 | % bar 78
    es4 d8 es8 f4 c4 | % bar 79
    d4 c8 d8 es4 bes4 | % bar 80
    c4 d8 es8 d4 c4 | % bar 81
    bes4 g4 g'2~ | % bar 82
    g2 f2~ | % bar 83
    f2 e2~ | % bar 84
    e2 d2~ | % bar 85
    d2 cis2 | % bar 86
    d2 r4 bes'4 | % bar 87
    a4 g4 a4 fis4 | % bar 88
    g8 d8 e8 fis8 g8 a8 g8 a8 | % bar 89
    f4 a4 c4 a4 | % bar 90
    f8 fis8 g8 a8 bes8 c8 bes8 c8 | % bar 91
    a4 c4 es4 c4 | % bar 92
    a4 d,4 c'2~ | % bar 93
    c2 bes2~ | % bar 94
    bes2 a2~ | % bar 95
    a2 g2~ | % bar 96
    g2 fis2 | % bar 97
    g8 fis8 g8 a8 bes8 a8 bes8 g8 | % bar 98
    a8 g8 a8 bes8 a8 d8 c8 d8 | % bar 99
    g,2~ g8 c8 bes8 c8 | % bar 100
    f,2~ f8 bes8 a8 bes8 | % bar 101
    e,4 f8 g8 a4 a4 | % bar 102
    d,2 r2 | % bar 103
    r4 d4\Pia es4 c4 | % bar 104
    f4 c4 d4 c8 d8 | % bar 105
    es4 b4 c4 b8 c | % bar 106
    d2 d2 | % bar 107
    es2 r4 g4\PPia | % bar 108
    a4 f4 bes4 f4 | % bar 109
    g4 f8 g a4 es4 | % bar 110
    f4 es8 f8 g4 d4 | % bar 111
    es4 f8 g8 f4 es4 | % bar 112
    d8 f8\For g8 a8 bes8 c8 bes8 a8 | % bar 113
    g8 fis8 g8 a8 g8 bes8 a8 g8 | % bar 114
    fis8 e8 fis8 g8 a8 g8 a8 fis8 | % bar 115
    g8 fis8 g8 a8 bes2~ | % bar 116
    bes2 a2~ | % bar 117
    a2 g2~ | % bar 118
    g2 f?2~ | % bar 119
    f8 es8 f8 g8 f8 es8 d8 c8 | % bar 120
    b8 c8 d8 es8 f8 es8 f8 d8 | % bar 121
    g8 f8 g8 as8 g8 f8 es8 d8 | % bar 122
    es8 f8 es8 d8 c8 g'8 a8 bes8 | % bar 123
    c8 bes8 a8 g8 f8 a8 g8 a8 | % bar 124
    bes8 a8 g8 f8 e8 g8 fis8 g8 | % bar 125
    a4 bes8 c8 bes4 a4 | % bar 126
    g2 fis2\trill | % bar 127
    d1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIvla = <<
\relative c' {
    \clef alto
    bes4 c4~ c4 bes4 | % bar 1
    c2 d4 g,4 | % bar 2
    a4 d4 a'4 d,4 | % bar 3
    bes4 c4 a4 d4 | % bar 4
    es4 f4 es4 b4 | % bar 5
    c4 g4 a2 | % bar 6
    g2 f2 | % bar 7
    es4 r8 g8 a4 e'4 | % bar 8
    d4 c4 bes4 r4 | % bar 9
    R1*5 | % bar 10
    fis'4 g2 f4 | % bar 15
    g2 a4 d,4 | % bar 16
    e4 a,4 e'4 a4 | % bar 17
    f4 g4 e4 a,4 | % bar 18
    bes4 c4 bes4 fis'4 | % bar 19
    g4 d4 e2 | % bar 20
    d2 c2 | % bar 21
    bes4 r8 d8 e4 b'4 | % bar 22
    a4 g8( f16 e16) f4 bes8( c16 d16) | % bar 23
    e,4 f8( d8) bes8( c16 d16) g,4 | % bar 24
    d'4 r8 g8 es8( d16 c16) a'4 | % bar 25
    d,4. cis16( d16) e4 f8( g16 a16) | % bar 26
    d,8( es16 f16) g8( f8) e8( cis8) r4 | % bar 27
    R1 | % bar 28
    cis'4 e4 d4 a4 | % bar 29
    g4 d'4 c4 g4 | % bar 30
    f4 c'4 bes4 f4 | % bar 31
    g8( a16 bes16) bes,4~ bes8 c16( d16) es4~ | % bar 32
    es8 d16( c16) g'16( f16 es16 d16) c8( d16 es16) a,8 d8~ | % bar 33
    d8 es16( f16) g8( f16 g16) c,8 f8~ f8 g16( a16) | % bar 34
    g4 c,8( bes16 a16) d8( es16 f16) g8( a16 bes16) | % bar 35
    a8 fis8 d8( e16 f16) g8 e8 r8 d16( c16) | % bar 36
    bes4 a8( bes16 c16) d4. g16( f16) | % bar 37
    es8( d16 c16) f8( es16 d16) g8 g,16( a16) b8 g8 | % bar 38
    r8 c16( d16) es16( f16 g8) e4 d4~ | % bar 39
    d4 c4~ 8 bes16( a16) bes4~ | % bar 40
    bes4 a4~ a8 a'8( g8 fis8) | % bar 41
    d'8( bes,8) es8( c8) a4 fis'4\Pia | % bar 42
    g8 g,8 d'8( c8) bes8( c8) d8( bes8) | % bar 43
    es8( c8) bes8( a16 bes16) c8( d16 es16) fis,4 | % bar 44
    g8( bes8) a8( g16 fis16) g8( a8) bes8( c8) | % bar 45
    d8 a'8 g8( fis16 e16) fis8 d8 c8( bes16 a16) | % bar 46
    g8\For( d'8) c8( es8) a,4 r4 | % bar 47
    % R1*24 | % bar 71
    R1*15 | % bar 62
    \tag PARTS \voiceTwo
    R1*9 | % bar 71
    \tag PARTS \oneVoice
    g2 r4 g4 | % bar 72
    d'4 a4 d4 a4 | % bar 73
    bes4 a8 bes8 c4 g4 | % bar 74
    a4 g8 a8 bes4 f4 | % bar 75
    g4 a8 bes8 a4 g4 | % bar 76
    f4 d4 c'2~ | % bar 77
    c2 bes2~ | % bar 78
    bes2 a2~ | % bar 79
    a2 g2~ | % bar 80
    g2 fis2 | % bar 81
    g4 a4 b4 cis4 | % bar 82
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 83
    g2~ g8 c8 bes8 c8 | % bar 84
    f,2~ f8 bes8 a8 bes8 | % bar 85
    e,4 f8 g8 a4 a4 | % bar 86
    d,4 e4 fis4 g4 | % bar 87
    a8 bes8 c4~ c8 a8 d8 c8 | % bar 88
    bes8 a8 bes8 c8 bes8 es8 d8 es8 | % bar 89
    c4 a4 f4 f'4 | % bar 90
    d8 c8 d8 es8 d8 g8 f8 g8 | % bar 91
    es4 c4 a4 a4 | % bar 92
    d,4 d'4 e4 fis4 | % bar 93
    g4 g,4 bes4 g4 | % bar 94
    c4 g4 a4 g8 a8 | % bar 95
    bes4 fis4 g4 fis8 g8 | % bar 96
    a2 a2 | % bar 97
    g2 r2 | % bar 98
    r4 d'4 f4 d4 | % bar 99
    g4 d4 e4 d8 e8 | % bar 100
    f4 cis4 d4 cis8 d8 | % bar 101
    e2 e2 | % bar 102
    a,4 r4 r4 a4\Pia | % bar 103
    b4 g4 c4 g4 | % bar 104
    as4 g8 as8 bes4 f4 | % bar 105
    g4 f8 g8 as4 es4 | % bar 106
    f4 g8 as8 g4 f4 | % bar 107
    es8 g8\PPia a8 b8 c8 d8 es8 c8 | % bar 108
    f2~ f8 bes,8 a8 bes8 | % bar 109
    es2~ es8 a,8 g8 a8 | % bar 110
    d2~ d8 g,8 f8 g8 | % bar 111
    c4 d8 es8 f4 f,4 | % bar 112
    bes2 r8 bes8\For c8 d8 | % bar 113
    es8 d8 es8 f8 es8 d8 c8 es8 | % bar 114
    d8 bes8 a8 g8 fis8 e8 fis8 d8 | % bar 115
    d'2 d2 | % bar 116
    c1 | % bar 117
    bes1 | % bar 118
    a2~ a8 a8 b8 c8 | % bar 119
    d8 c8 d8 es8 d8 c8 b8 a8 | % bar 120
    g8 a8 b8 c8 d8 c8 d8 b8 | % bar 121
    c4 b4 es8 d8 c8 b8 | % bar 122
    c8 d8 es8 f8 g8 f8 es8 d8 | % bar 123
    c4 f2 f4 | % bar 124
    es4 bes4 c4 bes4 | % bar 125
    a4 fis4 g4 a4 | % bar 126
    bes4 c4 d4 a4 | % bar 127
    b1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIsoprano = <<
\relative c'' {
    \autoBeamOff
    R1*8 | % bar 1
    r2 r4 c4 | % bar 9
    r4 bes8 c16 d16 es8 es8 es4 | % bar 10
    r8 d8 c8 d16 es16 f8 f8 f4~ | % bar 11
    f8 es16 d16 es4 r8 d8 g,8 a16 bes | % bar 12
    c8 c8 c4~ c8 c8 b8 c16 d16 | % bar 13
    es8 es8 es8 d8 d8[( g16 es16)] cis4\trill | % bar 14
    d4 r4 r2 | % bar 15
    R1*7 | % bar 16
    r4 e4 r4 d8 e16 f16 | % bar 23
    g8 g8 f4 r8 d8 e8 f16 g16 | % bar 24
    a8 a8 d,8 d8 c8 d16 es16 a,8 a8 | % bar 25
    g8 g'8 d8 e16 f16 g8 g8 f4~ | % bar 26
    f8 es16 d16 es8 g8 cis,8 d16 e16 d8 fis8 | % bar 27
    g4 e8 e8 d8 f8 e8 d8 | % bar 28
    cis4 r4 r2 | % bar 29
    R1 | % bar 30
    r2 f4 r4 | % bar 31
    bes,8 c16 d16 es8 es8 es2~ | % bar 32
    es8 r8 g,8 a16 bes16 c8 c8 c4~ | % bar 33
    c4 bes4 a8 bes16 c16 d8 d8 | % bar 34
    bes4 c8 d16 e16 f8 d8 g4 | % bar 35
    c,4 b8 cis16 d16 e8 e8 f4 | % bar 36
    bes,8 c16 d16 es8 es8 a,4 bes8 c16 d16 | % bar 37
    es4 d4 d8[( c8)] f8 f8 | % bar 38
    f8[ es8] r8 d8 cis8 d16 e16 f8 f8 | % bar 39
    b,4 g'4 c,8 d16 es16 f8 f8 | % bar 40
    bes,8 c16 d16 es4~ 8 a,8 d8 c8 | % bar 41
    bes8. c16 c8.\trill d16 d4 r4 | % bar 42
    R1*4 | % bar 43
    r2 r2 | % bar 47
    R1*9 | % bar 48
    d2 r4 d4 | % bar 57
    g4 d4 g4 d4 | % bar 58
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 59
    d4 c8 d8 es4 bes4 | % bar 60
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 61
    bes4 g4 g'2~ | % bar 62
    g2 f2 | % bar 63
    f2 e2 | % bar 64
    e2 d2 | % bar 65
    d2 cis2 | % bar 66
    d4 d4 e4 fis4 | % bar 67
    \autoBeamOn g8 \melisma fis8 g8 a8 g8 f8 es8 d8 | % bar 68
    c2~ c8 f8 es8 f8 | % bar 69
    bes,2~ bes8 es8 d8 es8 | % bar 70
    a,4 \melismaEnd \autoBeamOff bes8[ c8] d4 d4 | % bar 71
    g,4 r4 r2 | % bar 72
    r4 d'4 f4 d4 | % bar 73
    g4 d4 \autoBeamOn e4 \melisma d8 e8 | % bar 74
    f4 cis4 d4 \melismaEnd \autoBeamOff cis8[ d8] | % bar 75
    e2 e2 | % bar 76
    d2 r2 | % bar 77
    r4 g,4 bes4 g4 | % bar 78
    c4 g4 \autoBeamOn a4 \melisma g8 a8 | % bar 79
    bes4 fis4 g4 \melismaEnd \autoBeamOff fis8[ g8] | % bar 80
    a2 a2 | % bar 81
    g2 r4 g4 | % bar 82
    d'4 a4 d4 a4 | % bar 83
    \autoBeamOn bes4 \melisma a8 bes8 c4 g4 | % bar 84
    a4 g8 a8 bes4 f4 | % bar 85
    g4 \melismaEnd \autoBeamOff a8[ bes8] a4 g4 | % bar 86
    f4 d4 c'2~ | % bar 87
    c4 a4 d4 a4 | % bar 88
    \autoBeamOn bes4 \melisma a8 g8 es'2~ | % bar 89
    es4 \melismaEnd \autoBeamOff d8[ c8] f4 c4 | % bar 90
    d4 r4 r2 | % bar 91
    R1 | % bar 92
    d2 r4 d4 | % bar 93
    g4 d4 g4 d4 | % bar 94
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 95
    d4 c8 d8 es4 bes4 | % bar 96
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 97
    bes4 g4 g'2~ | % bar 98
    g2 f2 | % bar 99
    f2 e2 | % bar 100
    e2 d2 | % bar 101
    d2 cis2 | % bar 102
    d4 a4\Pia f'2~ | % bar 103
    f2 es?2 | % bar 104
    es2 d2 | % bar 105
    d2 c2 | % bar 106
    c2 b2 | % bar 107
    c4 g4\PPia es'2~ | % bar 108
    es2 d2 | % bar 109
    d2 c2 | % bar 110
    c2 bes2 | % bar 111
    bes2 a2 | % bar 112
    bes4 f4\For d'2~ | % bar 113
    d4 g,4 c2~ | % bar 114
    c4 d8[ es8] d4 c4 | % bar 115
    \autoBeamOn bes8 \melisma a8 bes8 c8 d8 es8 f8 d8 | % bar 116
    g8 f8 es8 d8 c8 es8 d8 es8 | % bar 117
    f8 es8 d8 c8 bes8 d8 c8 d8 | % bar 118
    es8 d8 \melismaEnd \autoBeamOff c8[ bes8] c8[ a8] d4 | % bar 119
    g,1~ | % bar 120
    g1~ | % bar 121
    g1~ | % bar 122
    g4 g4 es'2~ | % bar 123
    es2 d2 | % bar 124
    d2 c2 | % bar 125
    c4( d8[ es8] d4) c4 | % bar 126
    bes2 a2\trill | % bar 127
    g1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIsopranoLyrics = \lyricmode {
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __ ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __ ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt, __
    ge -- he nicht ins Ge -- richt, __
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    nicht ins Ge -- richt mit dei -- nem Knecht.

    Denn vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    denn vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir, __ vor dir __ wird kein Le -- ben -- di -- ger ge -- recht, __
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht.
}


mvtIalto = <<
\relative c'' {
    \autoBeamOff
    R1*8 | % bar 1
    r4 a4 r4 g8 a16 bes16 | % bar 9
    c8 c8 bes4 r8 g8 a8 bes16 c16 | % bar 10
    d8 d8 g,8 g8 f8 g16 as16 d,8 d8 | % bar 11
    c8 c'8 g8 a16 bes16 c8 c8 bes4~ | % bar 12
    bes8 as16 g16 as8 c8 fis,8 g16 a16 g8 b8 | % bar 13
    c4 a8 a8 g8 bes8 a8 g8 | % bar 14
    fis4 r4 r2 | % bar 15
    R1*7 | % bar 16
    a4 r4 f8 g16 a16 bes8 bes8 | % bar 23
    bes4 r8 a8 g16 a16 bes8 c8 c8 | % bar 24
    c4 r8 bes8 a8 bes16 c16 d8 d8 | % bar 25
    d4 r8 bes8 e,8 f16 g16 a8 a8 | % bar 26
    d,4 bes'8 bes8 a8 a,8 a'8 bes16 c16 | % bar 27
    d8 d8 cis8 cis8 d4 d,4 | % bar 28
    a'4 r4 r2 | % bar 29
    R1 | % bar 30
    r2 r4 bes4 | % bar 31
    r4 g8 a16 bes16 c8 c8 c4 | % bar 32
    fis,8 g16 a16 bes8 bes8 a2 | % bar 33
    g4 g8 a16 bes16 c8 c8 bes4 | % bar 34
    e,8 f16 g16 a8 a8 b4 c4 | % bar 35
    a8 b16 c16 d8 d8 g,4 a4 | % bar 36
    g8 a16 bes16 c8 c8 c4 bes8 bes8 | % bar 37
    bes8[ a8] c8 b8 b8[( c8)] d8 d8 | % bar 38
    d8[ c8] r8 g8 a8 b16 cis16 d8 a8 | % bar 39
    g8 a16 b16 c8 g8 a8 bes16 c16 d8 d8 | % bar 40
    g,8 c16 bes16 c4~ 8 fis,8 g8 a8 | % bar 41
    bes8 bes8 a8 g8 fis4 r4 | % bar 42
    R1*4 | % bar 43
    r2 r2 | % bar 47
    R1*14 | % bar 48
    g2 r4 g4 | % bar 62
    d'4 a4 d4 a4 | % bar 63
    \autoBeamOn bes4 \melisma a8 bes8 c4 g4 | % bar 64
    a4 g8 a8 bes4 f4 | % bar 65
    g4 \melismaEnd \autoBeamOff a8[ bes8] a4 g4 | % bar 66
    f4 d4 c'2~ | % bar 67
    c2 bes2 | % bar 68
    bes2 a2 | % bar 69
    a2 g2 | % bar 70
    g2 fis2 | % bar 71
    g4 a4 b4 cis4 | % bar 72
    \autoBeamOn d8 \melisma c8 d8 es8 d8 c8 bes8 a8 | % bar 73
    g2~ g8 c8 bes8 c8 | % bar 74
    f,2~ f8 bes8 a8 bes8 | % bar 75
    e,4 \melismaEnd \autoBeamOff f8[ g8] a4 a4 | % bar 76
    d,2 r4 d4 | % bar 77
    g4 d4 g4 d4 | % bar 78
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 79
    d4 c8 d8 es4 bes4 | % bar 80
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 81
    bes4 g4 g'2~ | % bar 82
    g2 f2 | % bar 83
    f2 e2 | % bar 84
    e2 d2 | % bar 85
    d2 cis2 | % bar 86
    d2 r4 bes'4 | % bar 87
    a4 g4 a4 fis4 | % bar 88
    \autoBeamOn g8 \melisma d8 e8 fis8 g8 a8 g8 a8 | % bar 89
    f4 a4 c4 a4 | % bar 90
    f8 fis8 g8 a8 bes8 c8 bes8 c8 | % bar 91
    a4 \melismaEnd \autoBeamOff c4 es4 c4 | % bar 92
    a4 d,4 c'2~ | % bar 93
    c2 bes2 | % bar 94
    bes2 a2 | % bar 95
    a2 g2 | % bar 96
    g2 fis2 | % bar 97
    g4 g8 a8 \autoBeamOn bes8 \melisma a8 bes8 g8 | % bar 98
    a8 g8 a8 bes8 a8 d8 c8 d8 | % bar 99
    g,2~ g8 c8 bes8 c8 | % bar 100
    f,2~ f8 bes8 a8 bes8 | % bar 101
    e,4 \melismaEnd \autoBeamOff f8[ g8] a4 a4 | % bar 102
    d,4 r4 r2 | % bar 103
    r4 d4\Pia es4 c4 | % bar 104
    f4 c4 \autoBeamOn d4 \melisma c8 d8 | % bar 105
    es4 b4 c4 \melismaEnd \autoBeamOff b8[ c8] | % bar 106
    d2 d2 | % bar 107
    c4 r4 r4 g'4\PPia | % bar 108
    a4 f4 bes4 f4 | % bar 109
    \autoBeamOn g4 \melisma f8 g8 a4 es4 | % bar 110
    f4 es8 f8 g4 d4 | % bar 111
    es4 \melismaEnd \autoBeamOff f8[ g8] f4 es4 | % bar 112
    d4 f4\For bes4 a4 | % bar 113
    \autoBeamOn g8 \melisma fis8 g8 a8 g8 bes8 a8 g8 | % bar 114
    fis8 e8 \melismaEnd \autoBeamOff fis8[ g8] a4 fis4 | % bar 115
    g4 bes8[ a8] bes2~ | % bar 116
    bes2 a2 | % bar 117
    a2 g2 | % bar 118
    \autoBeamOn g2 \melisma f?2~ | % bar 119
    f8 es8 f8 g8 f8 es8 d8 c8 | % bar 120
    b8 c8 d8 es8 f8 es8 f8 d8 | % bar 121
    g8 f8 g8 as8 g8 f8 es8 d8 | % bar 122
    es8 f8 es8 d8 c8 g'8 a8 bes8 | % bar 123
    c8 bes8 a8 g8 f8 a8 g8 a8 | % bar 124
    bes8 a8 g8 f8 e8 g8 fis8 g8 | % bar 125
    a4 bes8 c8 bes4 \melismaEnd \autoBeamOff a4 | % bar 126
    g2 fis2\trill | % bar 127
    es1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIaltoLyrics = \lyricmode {
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __ ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __ ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    nicht ins Ge -- richt mit dei -- nem Knecht.

    Denn vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht.
}

mvtItenor = <<
\relative c' {
    \autoBeamOff
    R1*8 | % bar 1
    d4 r4 bes8 c16 d16 es8 es8 | % bar 9
    es4 r8 d8 c8 d16 es16 f8 f8 | % bar 10
    f4 r8 es8 d8 es16 f16 g8 g8 | % bar 11
    g4 r8 es8 a,8 bes16 c16 d8 d8 | % bar 12
    g,4 es'8 es8 d8 d,8 d'8 es16 f16 | % bar 13
    g8 g8 fis8 fis8 g4 g,4 | % bar 14
    a4 r4 r2 | % bar 15
    R1*7 | % bar 16
    r2 r4 g4 | % bar 23
    r4 f8 g16 a16 bes8 bes8 bes4 | % bar 24
    r8 a8 g8 a16 bes16 c8 c8 c4~ | % bar 25
    c8 bes16 a16 bes4 r8 a'8 d,8 e16 f16 | % bar 26
    g8 g8 g4~ g8 g,8 fis8 g16 a16 | % bar 27
    bes8 bes8 a8 a8 a8[( d16 bes16)] gis4\trill | % bar 28
    a4 r4 r2 | % bar 29
    R1*2 | % bar 30
    r4 bes4 r4 g8 a16 bes16 | % bar 32
    c8 c8 bes8 c16 d16 es8 es16 es16 fis,4 | % bar 33
    r4 es'4 c8 d16 es16 f8 f8 | % bar 34
    bes,4 a8 bes16 c16 d8 d8 g,4 | % bar 35
    fis8 g16 a16 d,8 d'8 cis4 a8 g16 a16 | % bar 36
    bes8[( a16 g16 fis8)] g8 a4 d4 | % bar 37
    c8 d16 es16 f8 f8 f8[( es8)] b8 c16[( d16)] | % bar 38
    g,8 a16 bes16 c8 d8 e8 f16 g16 f8 d8 | % bar 39
    d8 d8 es4~ 8 d16 c16 bes8 bes8 | % bar 40
    bes8 es4 d16 es16 a,4 r8 d8 | % bar 41
    d8[( es16 d16] c16[ bes16]) a16[( g16)] a4 r4 | % bar 42
    R1*4 | % bar 43
    r2 d4 r8 d8 | % bar 47
    g4 d4 g4 d4 | % bar 48
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 49
    d4 c8 d8 es4 bes4 | % bar 50
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 51
    bes4 g4 g'2~ | % bar 52
    g2 f2 | % bar 53
    f2 e2 | % bar 54
    e2 d2 | % bar 55
    d2 cis2 | % bar 56
    d4 d4 e4 fis4 | % bar 57
    \autoBeamOn g8 \melisma fis8 g8 a8 g8 f8 es8 d8 | % bar 58
    c2~ c8 f8 es8 f8 | % bar 59
    bes,2~ bes8 es8 d8 es8 | % bar 60
    a,4 \melismaEnd \autoBeamOff bes8[ c8] d4 d4 | % bar 61
    g,4 r4 r2 | % bar 62
    r4 d'4 f4 d4 | % bar 63
    g4 d4 \autoBeamOn e4 \melisma d8 e8 | % bar 64
    f4 cis4 d4 \melismaEnd \autoBeamOff cis8[ d8] | % bar 65
    e2 e2 | % bar 66
    d4 r4 r2 | % bar 67
    r4 g,4 bes4 g4 | % bar 68
    c4 g4 \autoBeamOn a4 \melisma g8 a8 | % bar 69
    bes4 fis4 g4 \melismaEnd \autoBeamOff fis8[ g8] | % bar 70
    a2 a2 | % bar 71
    g2 r4 g4 | % bar 72
    d'4 a4 d4 a4 | % bar 73
    \autoBeamOn bes4 \melisma a8 bes8 c4 g4 | % bar 74
    a4 g8 a8 bes4 f4 | % bar 75
    g4 \melismaEnd \autoBeamOff a8[ bes8] a4 g4 | % bar 76
    f4 d4 c'2~ | % bar 77
    c2 bes2 | % bar 78
    bes2 a2 | % bar 79
    a2 g2 | % bar 80
    g2 fis2 | % bar 81
    g4 a4 b4 cis4 | % bar 82
    \autoBeamOn d8 \melisma c8 d8 es8 d8 c8 bes8 a8 | % bar 83
    g2~ g8 c8 bes8 c8 | % bar 84
    f,2~ f8 bes8 a8 bes8 | % bar 85
    e,4 \melismaEnd \autoBeamOff f8[ g] a4 a4 | % bar 86
    d,4 e4 fis4 g4 | % bar 87
    \autoBeamOn a8 \melisma bes8 c4~ c8 a8 d8 c8 | % bar 88
    bes8 a8 bes8 c8 bes8 es8 d8 es8 | % bar 89
    c4 a4 f4 f'4 | % bar 90
    d8 c8 d8 es8 d8 g8 f8 g8 | % bar 91
    es4 \melismaEnd \autoBeamOff c4 a4 a4 | % bar 92
    d,4 d'4 e4 fis4 | % bar 93
    g4 g,4 \autoBeamOn bes4 \melisma g4 | % bar 94
    c4 g4 a4 g8 a8 | % bar 95
    bes4 fis4 g4 \melismaEnd \autoBeamOff fis8[ g8] | % bar 96
    a2 a2 | % bar 97
    g2 r2 | % bar 98
    r4 d'4 f4 d4 | % bar 99
    g4 d4 \autoBeamOn e4 \melisma d8 e8 | % bar 100
    f4 cis4 d4 \melismaEnd \autoBeamOff cis8[ d8] | % bar 101
    e2 e2 | % bar 102
    a,4 r4 r4 a4\Pia | % bar 103
    b4 g4 c4 g4 | % bar 104
    \autoBeamOn as4 \melisma g8 as8 bes4 f4 | % bar 105
    g4 f8 g8 as4 es4 | % bar 106
    f4 \melismaEnd \autoBeamOff g8[ as] g4 f4 | % bar 107
    es4 g4\PPia c8[ d8] es8[ c8] | % bar 108
    \autoBeamOn f8 \melisma es8 d8 c8 bes8 d8 c8 d8 | % bar 109
    es8 d8 c8 bes8 a8 c8 bes8 c8 | % bar 110
    d8 c8 bes8 a8 g8 bes8 a8 bes8 | % bar 111
    c4 \melismaEnd \autoBeamOff d8[ es8] f4 f,4 | % bar 112
    bes2 r4 bes4\For | % bar 113
    es4 d4 es4 c4 | % bar 114
    d4 a4 fis4 d4 | % bar 115
    d'2 d2 | % bar 116
    c2 c2 | % bar 117
    bes2 bes2 | % bar 118
    \autoBeamOn a2~ \melisma a8 a8 b8 c8 | % bar 119
    d8 c8 d8 es8 d8 c8 b8 a8 | % bar 120
    g8 a8 b8 c8 d8 c8 d8 b8 | % bar 121
    c4 \melismaEnd \autoBeamOff b4 es8[( d8)] c8[( b8)] | % bar 122
    c2 r4 bes4 | % bar 123
    f'2 f2 | % bar 124
    es4 bes4 c4 bes4 | % bar 125
    a4 fis4 g4 a4 | % bar 126
    bes4 c4 d4 a4 | % bar 127
    b1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtItenorLyrics = \lyricmode {
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __ ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, __
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins __ Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    nicht ins Ge -- richt mit dei -- nem Knecht.

    Denn vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger,
    wird kein Le -- ben -- di -- ger ge -- recht.
}

mvtIbass = <<
\relative c' {
    \clef F
    \autoBeamOff
    R1*8 | % bar 1
    r2 g4 r4 | % bar 9
    fis8 g16 a16 bes8 bes8 bes4 r8 a8 | % bar 10
    g8 a16 b16 c8 c8 c4 b8 b8 | % bar 11
    c4 r8 c8 fis,8 g16 a16 bes8 g8 | % bar 12
    es'4 r8 es8 a,8 bes16 c16 d8 d8 | % bar 13
    c4 r8 c8 bes8[ g8] e4 | % bar 14
    d4 r4 r2 | % bar 15
    R1*7 | % bar 16
    r2 d4 r4 | % bar 23
    cis8 d16 e16 f8 f8 f4 r8 e8 | % bar 24
    d8 e16 fis16 g8 g8 g4 fis8 fis8 | % bar 25
    g4 r8 g8 cis,8 d16 e16 f8 d8 | % bar 26
    bes'4 r8 bes8 e,8 f16 g16 a8 a8 | % bar 27
    g4 r8 g8 f8[ d8] b4 | % bar 28
    a4 r4 r2 | % bar 29
    R1*2 | % bar 30
    g'4 r4 g8 a16 bes16 c8 c8 | % bar 32
    c4 r4 a8 bes16 c16 d8 d8 | % bar 33
    g,4 r4 f4 d8 e16 f16 | % bar 34
    g8 g8 f4 d4 e8 fis16 g16 | % bar 35
    a8 a8 g4 e4 d8 e16 f16 | % bar 36
    g4 a4 fis4 g8 a16 bes16 | % bar 37
    c8 c8 d4 es4 g,8 a16 b16 | % bar 38
    c8 c8 bes4 a4 d,8 \once \set suggestAccidentals = ##t e16 f16 | % bar 39
    g8 g8 c,8 d16 es16 f8 f8 bes,8 c16 d16 | % bar 40
    es8 g,8 a8 bes16 c16 d4 r8 d8 | % bar 41
    g8[ f8] es4 d4 r4 | % bar 42
    R1*4 | % bar 43
    r2 r2 | % bar 47
    R1*4 | % bar 48
    g2 r4 g4 | % bar 52
    d'4 a4 d4 a4 | % bar 53
    \autoBeamOn bes4 \melisma a8 bes8 c4 g4 | % bar 54
    a4 g8 a8 bes4 f4 | % bar 55
    g4 \melismaEnd \autoBeamOff a8[ bes8] a4 g4 | % bar 56
    f4 d4 c'2~ | % bar 57
    c2 bes2 | % bar 58
    bes2 a2 | % bar 59
    a2 g2 | % bar 60
    g2 fis2 | % bar 61
    g4 a4 b4 cis4 | % bar 62
    \autoBeamOn d8 \melisma c8 d8 es8 d8 c8 bes8 a8 | % bar 63
    g2~ g8 c8 bes8 c8 | % bar 64
    f,2~ f8 bes8 a8 bes8 | % bar 65
    e,4 \melismaEnd \autoBeamOff f8[ g8] a4 a4 | % bar 66
    d,2 r4 d4 | % bar 67
    g4 d4 g4 d4 | % bar 68
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 69
    d4 c8 d8 es4 bes4 | % bar 70
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 71
    bes4 g4 g'2~ | % bar 72
    g2 f2 | % bar 73
    f2 e2 | % bar 74
    e2 d2 | % bar 75
    d2 cis2 | % bar 76
    d4 d4 e4 fis4 | % bar 77
    \autoBeamOn g8 \melisma fis8 g8 a8 g8 f8 es8 d8 | % bar 78
    c2~ c8 f8 es8 f8 | % bar 79
    bes,2~ bes8 es8 d8 es8 | % bar 80
    a,4 \melismaEnd \autoBeamOff bes8[ c8] d4 d4 | % bar 81
    g,4 r4 r2 | % bar 82
    r4 d'4 f4 d4 | % bar 83
    g4 d4 \autoBeamOn e4 \melisma d8 e8 | % bar 84
    f4 cis4 d4 \melismaEnd \autoBeamOff cis8[ d8] | % bar 85
    e2 e2 | % bar 86
    d2 r4 e4 | % bar 87
    fis4 e4 fis4 d4 | % bar 88
    \autoBeamOn g8 \melisma fis8 g8 a8 g8 c8 bes8 c8 | % bar 89
    a8 g8 a8 bes8 a8 bes8 g8 a8 | % bar 90
    bes8 a8 bes8 c8 bes8 es8 d8 es8 | % bar 91
    c8 bes8 c8 d8 c8 d8 bes8 c8 | % bar 92
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 93
    g8 \once \set suggestAccidentals = ##t fis8 g8 a8 g8 \once \set suggestAccidentals = ##t f8 es8 d8 | % bar 94
    c2~ c8 f8 es8 f8 | % bar 95
    bes,2~ bes8 es8 d8 es8 | % bar 96
    a,4 \melismaEnd \autoBeamOff bes8[ c8] d4 d4 | % bar 97
    g,2 r4 g'4 | % bar 98
    d'4 a4 d4 a4 | % bar 99
    \autoBeamOn bes4 \melisma a8 bes8 c4 g4 | % bar 100
    a4 g8 a8 bes4 f4 | % bar 101
    g4 \melismaEnd \autoBeamOff a8[ bes8] a4 g4 | % bar 102
    f4 r4 r4 d'4\Pia | % bar 103
    g,2~ g8 c8[( bes8 c8)] | % bar 104
    \autoBeamOn f,2~ \melisma f8 bes8 as8 bes8 | % bar 105
    es,2~ es8 as8 g8 as8 | % bar 106
    d,4 \melismaEnd \autoBeamOff es8[ f8] g4 g4 | % bar 107
    c,2 r2 | % bar 108
    R1*6 | % bar 109
    r2 r4 d4\f | % bar 115
    g4 d4 g4 d4 | % bar 116
    \autoBeamOn es4 \melisma d8 es8 f4 c4 | % bar 117
    d4 c8 d8 es4 bes4 | % bar 118
    c4 \melismaEnd \autoBeamOff d8[ es8] d4 c4 | % bar 119
    b2 r4 d4 | % bar 120
    g4 d4 g4 d4 | % bar 121
    es4 d8[ es8] c4 g'4 | % bar 122
    c4 g4 c4 g4 | % bar 123
    \autoBeamOn a4 \melisma g8 a8 bes4 f4 | % bar 124
    g4 f8 g8 a4 e4 | % bar 125
    fis4 d4 e4 \melismaEnd \autoBeamOff fis4 | % bar 126
    g2 d2 | % bar 127
    g,1\fermata | % bar 128
}
\mvtItimeLine
>>

mvtIbassLyrics = \lyricmode {
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt mit dei -- nem Knecht.

    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt, ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    Herr, ge -- he nicht ins Ge -- richt,
    ins Ge -- richt mit dei -- nem Knecht.

    Denn vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir __ wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    wird kein __ Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht,
    vor dir wird kein Le -- ben -- di -- ger,
    vor dir wird kein Le -- ben -- di -- ger ge -- recht.
}

mvtIbc = <<
\relative c {
    \clef F
    g8( g8) g8( g8) fis8( fis8) g8( g8) | % bar 1
    c8( c8) f8( f8) d8( d8) c8( c8) | % bar 2
    a8( a8) g8( g8) a8( a8) bes8( bes8) | % bar 3
    g8( g8) a8( a8) fis8( fis8) g8( g8) | % bar 4
    c8( c8) d8( d8) es8( es8) g8( g8) | % bar 5
    c8( c8) bes8( bes8) a8( a8) d,8( d8) | % bar 6
    g8( g8) c,8( c8) f8( f8) bes,8( bes8) | % bar 7
    es,8( es8) es'8( es8) d8( d8) cis8( cis8) | % bar 8
    d8( d8) d,8( d8) g8( g8) g8( g8) | % bar 9
    fis8( fis8) g8( g8) c8( c8) a8( a8) | % bar 10
    b8( b8) c8( c8) c8( c8) b8( b8) | % bar 11
    c8( c8) c'8( c8) fis,8( fis8) g8( g8) | % bar 12
    es8( es8) c8( c8) d8( d8) g,8( g8) | % bar 13
    c,8( c8) d8( d8) es8( es8) e8( e8) | % bar 14
    d8( d8) d'8( d8) cis8( cis8) d8( d8) | % bar 15
    g8( g8) c8( c8) a8( a8) g8( g8) | % bar 16
    e8( e8) d8( d8) e8( e8) f8( f8) | % bar 17
    d8( d8) e8( e8) cis8( cis8) d8( d8) | % bar 18
    g,8( g8) a8( a8) bes8( bes8) d8( d8) | % bar 19
    g8( g8) f8( f8) e8( e8) a,8( a8) | % bar 20
    d8( d8) g,8( g8) c8( c8) f,8( f8) | % bar 21
    bes8( bes8) bes'8( bes8) a8( a8) gis8( gis8) | % bar 22
    a8( a8) a,8( a8) d8( d8) d8( d8) | % bar 23
    cis8( cis8) d8( d8) g,8( g8) e8( e8) | % bar 24
    fis8( fis8) g8( g8) g8( g8) fis8( fis8) | % bar 25
    g8( g8) g'8( g8) cis,8( cis8) d8( d8) | % bar 26
    bes8( bes8) g'8( g8) a8( a8) d,8( d8) | % bar 27
    g,8( g8) a8( a8) bes8( bes8) b8( b8) | % bar 28
    a8( a8) cis8( cis8) d8( d8) fis8( fis8) | % bar 29
    g8( g8) b,8( b8) c8( c8) e8( e8) | % bar 30
    f8( f8) a,8( a8) bes8( bes8) d8( d8) | % bar 31
    es8( es8) d8( d8) c8( c8) bes8( bes8) | % bar 32
    a8( a8) g8( g8) fis8( fis8) d8( d8) | % bar 33
    g8( g8) g'8( g8) f8( f8) bes,8( bes8) | % bar 34
    g'8( g8) f8( f8) d8( d8) c8( c8) | % bar 35
    a'8( a8) g8( g8) e8( e8) d8( d8) | % bar 36
    g8( g8) a8( a8) fis8( fis8) g8( g8) | % bar 37
    c,8( c8) d8( d8) es8( es8) g8( g8) | % bar 38
    c8( c8) bes8( bes8) a8( a8) d,8( d8) | % bar 39
    g8( g8) c,8( c8) f8( f8) bes,8( bes8) | % bar 40
    es8( es8) a,8( a8) d4 r8 d8 | % bar 41
    g,8 f8 es4 d2~ | % bar 42
    d1~_"tasto solo" | % bar 43
    d1~ | % bar 44
    d1~ | % bar 45
    d2~ d4 r8 d'8\f | % bar 46
    g8 f8 es4 d16 c16 d16 es16 d16 c16 bes16 a16 | % bar 47
    bes4 g'4 bes4 g4 | % bar 48
    c4 g4 a4 g8 a8 | % bar 49
    bes4 fis4 g4 fis8 g8 | % bar 50
    a4 g4 fis4 e8 fis8 | % bar 51
    g8 fis8 g8 a8 bes8 a8 bes8 g8 | % bar 52
    d'2 d,2 | % bar 53
    g2 c,2 | % bar 54
    f2 bes,4 bes'4 | % bar 55
    g4 e4 a4 a,4 | % bar 56
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 57
    g4 g'4 bes4 g4 | % bar 58
    c4 f,4 a4 f4 | % bar 59
    bes4 es,4 g4 es4 | % bar 60
    a4 d,4 fis4 d4 | % bar 61
    g4 f4 e2 | % bar 62
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 63
    g2 c2 | % bar 64
    f,2 bes4 bes'4 | % bar 65
    g4 e4 a4 a,4 | % bar 66
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 67
    g4 d'4 g4 d4 | % bar 68
    es4 d8 es8 f4 c4 | % bar 69
    d4 c8 d8 es4 bes4 | % bar 70
    c4 d8 es8 d4 c4 | % bar 71
    bes4 g4 g'2~ | % bar 72
    g2 f2~ | % bar 73
    f2 e2~ | % bar 74
    e2 d2~ | % bar 75
    d2 cis2 | % bar 76
    d8 c8 d8 es?8 d8 c8 bes8 a8 | % bar 77
    g8 fis8 g8 a8 g8 f8 es8 d8 | % bar 78
    c2 f2 | % bar 79
    bes2 es,4 es'4 | % bar 80
    c4 a4 d4 d,4 | % bar 81
    g4 g'4 f4 e4 | % bar 82
    d4 d,4 f4 d4 | % bar 83
    g2 c2 | % bar 84
    f,2 bes4 bes'4 | % bar 85
    g4 e4 a4 a,4 | % bar 86
    d2 r4 e4 | % bar 87
    fis4 e4 fis4 d4 | % bar 88
    g8 fis8 g8 a8 g8 c8 bes8 c8 | % bar 89
    a8 g8 a8 bes8 a8 bes8 g8 a8 | % bar 90
    bes8 a8 bes8 c8 bes8 es8 d8 es8 | % bar 91
    c8 bes8 c8 d8 c8 d8 bes8 c8 | % bar 92
    d8 c8 d8 es8 d8 c8 bes8 a8 | % bar 93
    g8 \once \set suggestAccidentals = ##t fis8 g8 a8 g8 \once \set suggestAccidentals = ##t f8 es8 d8 | % bar 94
    c4 f4 es4 f4 | % bar 95
    bes,4 es4 d4 es4 | % bar 96
    a,4 bes8 c8 d4 d,4 | % bar 97
    g2 r4 g'4 | % bar 98
    d'4 a4 d4 a4 | % bar 99
    bes4 a8 bes8 c4 g4 | % bar 100
    a4 g8 a8 bes4 f4 | % bar 101
    g4 a8 bes8 a4 g4 | % bar 102
    f8 g8\Pia f8 e8 d8 c8 b8 a8 | % bar 103
    g8 f8 \once \set suggestAccidentals = ##t es8 d8 c4 c'4 | % bar 104
    << as \\ f4 >> f'4 bes,4 d4 | % bar 105
    es,4 es'4 as,4 c4 | % bar 106
    d,4 es8 f8 g4 g4 | % bar 107
    c,8 g''8\PPia a8 b8 c8 d8 es8 c8 | % bar 108
    f8 es8 d8 c8 bes8 d8 c8 d8 | % bar 109
    es8 d8 c8 bes8 a8 c8 bes8 c8 | % bar 110
    d8 c8 bes8 a8 g8 bes8 a8 bes8 | % bar 111
    c4 d8 es8 f4 f,4 | % bar 112
    bes2 r8 bes8\For c8 d8 | % bar 113
    es8 d8 es8 f8 es8 d8 c8 es8 | % bar 114
    d4 a4 fis4 d4 | % bar 115
    g4 d4 g4 d4 | % bar 116
    es4 d8 es8 f4 c4 | % bar 117
    d4 c8 d8 es4 bes4 | % bar 118
    c4 d8 es8 d4 c4 | % bar 119
    b2 r4 d4 | % bar 120
    g4 d4 g4 d4 | % bar 121
    es4 d8 es8 c4 g'4 | % bar 122
    c4 g4 c4 g4 | % bar 123
    a4 g8 a8 bes4 f4 | % bar 124
    g4 f8 g8 a4 e4 | % bar 125
    fis4 d4 e4 fis4 | % bar 126
    g2 d2 | % bar 127
    g,1\fermata | % bar 128
}
\mvtItimeLine
>>


mvtIfigs = \figuremode {
    %119
    s4 <6 4> <7- 3> s |
    <7 _!> s <6\\> <_!> |
    <6\\> <_!> <7 _+> <5> |
    <6- 5> <5-> <6 5> s |
    <7>8 <6> <6\\ 4 3> s <5\+> <6> <_!>4 |
    s <6> <7 _+> <7! _!> |

    <7 _!> <7 _-> <7> <7-> |
    <7> <6> <7 _+> <7- 5> |
    <6 4> <5 _+> s <6 4> |
    <7- 5> s <7>8 <6>16 <5> <6 5>4 |

    %120
    <6 5> s <6- 4 2> <6 5> |
    <4> <3> <6 5> s |
    <6 5> <6-> <7 _+> <7 _!> |

    s <_+> <7> <6\\> |
    <_+> <6 4> <7- 5> <_!> |
    <[_!]> <[_!]> <6\\> <_!> |
    <6\\> <_+> <7 _+> <5> |
    <6 5> <5> <6 5> s |
    <7 5>8 <6\\> <6\\ 4 3> s <5\+> <6> <[_+]>4 |

    %121
    s <6> <7 _+> s |
    <7 _+> <7!> <7 _!> <7-> |
    <7> <6> <7 _+> <7- 5> |
    <6 4> <5\+ _+> s <6 4> |
    <7- 5> s <9 7>8 <8 6\\> <6 5>4 |

    <6 3> s <6 4 2> <6 5> |
    <4> <3> <6 5> s |
    <6 5> <6->8 <5> <7 _+>4 <7 _+> |

    %122
    s <_+> <7> <6\\> |
    <_+> <6 5> <4>8 <_+> <6 5>4 |
    <4>8 <_!> <6 5>4 <4>8 <_!> <6 5->4 |
    <4>8 <3> <6 5->4 <4->8 <3> <6>4 |
    <7>8 <6> <6 4 2>4 <7>8 <6> <6 4 2>4 |

    <6\\ 5->4 <3> <7- 5> <7 _+> |
    <4> <6> <7> s |
    <6\\> s <[6\\]> <[_!]> |

    %123
    <6\\> <_!> <6\\> s |
    <6 5> s <6 5> s |
    <7>8 <6> <7> <6\\> <7> <6> <7 _!>4 |

    s <6 4>8 <3> <7 _+>4 <8>8 <7> |
    <7 _!>4 <8>8 <7-> s s <8> <7-> |
    <7> s <6\\> <7> <_+>4 s8 <_+> |

    %124
    s4 <6 4>8 <3> <_+>2 |
    s1*3 |

    s2. s8 <_+> |
    s <5 4 2> <6>4 <_+>4 s |
    <[6]>2 <6> |
    s <6> |
    s4 <6> <6>2 |
    s <6> |

    %125
    s1 |
    <4>2 <3> |
    <7> <7 _!> |
    <7/> s |
    <6\\ 5> <_+> |
    s <4 2\+>4 <7 5\+> |
    <[5 4]>2 <[6]> |

    <7>4 <6 4> <6>2 |
    <7>4 <6 4> <6>2 |
    <7>4 <6 4> <6>2 |
    s <5\+>4 <6\\> |
    <4>2 <3> |
    <7> <7 _!> |
    <7/> s |

    %126
    <6\\ 5> <_+> |
    s s4 <7 5\+> |
    <4>2 <3>4 <6 4> |
    <6 5>2 s4 <6 4> |
    <6 5>2 s4 <6 4> |
    <6 5>2 <_+> |
    <[6]> <_!>4 <6\\ 4\+ 2> |

    <5 2>2 <6> |
    <6 4 2> <6> |
    <6 4 2>4 <6\\> <6 5>2 |
    <6 4 2\+> <6 5> |
    s <4 2\+>4 <7 5\+> |
    <4>2 <3> |
    <7> <7> |

    %127
    <7> s |
    <6 5> <_+> |
    s <6 4\+ 2>4 <6\\> |
    <4>2 <6> |
    <7> <_!> |
    <7/> s |
    <6\\ 5> <_+> |

    s s4 <6> |
    <6 4>2 <6>4 <_+> |
    s2 <6> |
    <6 5> <6> |
    <5> <6> |
    % <[6 5 _-]>4 \bassFigureExtendersOn <[6 5 _!]> \bassFigureExtendersOff <[6 _-]> \bassFigureExtendersOn <[6 _!]> \bassFigureExtendersOff |
    <[6 5 _-]>4 <[\FBx \FBx _!]> <[6 _-]> <[\FBx _!]>
    <_+>2 <4 2\+>4 <7 5\+> |

    %128
    <4>2 <3> |
    <7> <6 4 2> |
    <7> <6 4 2> |
    <7> <_+>4 <7> |
    s1 |
    <4>2 <3> |
    <6 5> <_!> |

    <6 5\+> s |
    <6\\ 5> <_+> |
    <6> s |
    <7 _!> s |
    <7 _-> <7-> |
    <7> <7> |
    <7> <_!> |

    %129
    s1 |
    <7>2 <7> |
    <7> <7> |
    <7> <7> |
    <7> s |
    s s |
    <7> <6> |

    <[_+]> <6>4 <7 _+> |
    s1 |
    <6 5> |
    <6 5> |
    <6 5> 2 <_!> |
    <6 5> s4 <6\\ 4> |
    <_!>1 |

    %130
    <6>4 <6\\> s <_!> |
    s1 |
    <6 5> |
    <6 5>2 <5\+> |
    <6 5>4 <7 _+> <7 5> <6 5> |
    s2 <_+> |
    <[_!]>1 |
}
