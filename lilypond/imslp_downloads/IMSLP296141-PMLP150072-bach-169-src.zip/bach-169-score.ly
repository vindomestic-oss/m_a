\version "2.18.0"

\include "baroque-clefs.ly"

transpChorton = d

\include "bach-169-score-common.ly"
