# Intended to be copied into the current directory by inserting at the end
# of your Makefile:
# #-------------- insert common makefile
# include lilypond.mk
#
# lilypond.mk: $(ROOT)/lilypond.mk
#	cp $^ $@
# #-------------- end of insert
#
# Common stuff for compiling a score and parts
# Include this file from the Makefile.
# The Makefile must define:
#	ROOT	a relative path from the working dir to this dir
#	WORK	a file base for score and part files
#	NOTES	a list of .ly files that contain the notes
#	INSTR	a list of instrument names for the part files (WORK is prepended)

.SUFFIXES:
.SUFFIXES:	.ly .pdf .midi .zip .flac

LILYROOT	?= /usr/share/lilypond/lilypond-2.19
LILYPOND	:= $(LILYROOT)/bin/lilypond
LILYFLAGS	:=


.PHONY: all
all:	score parts

SCORE	+= $(WORK)-score.ly

NOTES	+= common.ly
NOTES	+= common-defs.ly
NOTES	+= common-settings.ly
NOTES	+= common-grand-score.ly

PARTS	:= $(INSTR:%=$(WORK)-%.ly)

SCORE_PDF	:= $(SCORE:%.ly=%.pdf)
PARTS_PDF	:= $(PARTS:%.ly=%.pdf)

.PHONY:	score
score:	$(SCORE_PDF)

.PHONY:	parts
parts:	$(PARTS_PDF)

%.pdf:	%.ly common.ly
	$(LILYPOND) $(LILYFLAGS) $*.ly

ifeq ($(wildcard $(ROOT)/common.ly), $(ROOT)/common.ly)
common.ly: common-defs.ly common-settings.ly

common.ly: $(ROOT)/common.ly
	cp $< $@

common-defs.ly: $(ROOT)/common-defs.ly
	cp $< $@

common-settings.ly: $(ROOT)/common-settings.ly
	cp $< $@

baroque-clefs.ly: $(ROOT)/baroque-clefs.ly
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/common-grand-score.ly), $(ROOT)/common-grand-score.ly)
common-grand-score.ly: $(ROOT)/common-grand-score.ly
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/bach-paged-title.ly), $(ROOT)/bach-paged-title.ly)
bach-paged-title.ly: $(ROOT)/bach-paged-title.ly
	cp $< $@

bach-paged-title.ly: bach-monogram.eps

bach-monogram.eps: $(ROOT)/bach-monogram.eps
	cp $< $@
endif

.PHONY: convert
convert:
	$(LILYROOT)/bin/convert-ly -e $(wildcard *.ly)

ZIP_PDF	:= $(WORK)-pdf.zip
ZIP_SRC	:= $(WORK)-src.zip

$(WORK)-pdf.zip:	$(SCORE_PDF) $(PARTS_PDF)
	zip $@ $(SCORE_PDF) $(PARTS_PDF)

SRC	+= $(SCORE)
SRC	+= $(PARTS)
SRC	+= $(NOTES)
SRC	+= Makefile
SRC	+= lilypond.mk

$(WORK)-src.zip:	$(SCORE) $(PARTS) $(NOTES) Makefile
	zip $@ $(SRC)

.PHONY:	zip
zip:	$(ZIP_SRC) $(ZIP_PDF)

DEPLOY_HOST	:= fluit.few.vu.nl
DEPLOY_DIR	:= www/sheet-music/$(WORK)

DEPLOY_FILES	:=
DEPLOY_FILES	+= $(PARTS_PDF)
DEPLOY_FILES	+= $(SCORE_PDF)
DEPLOY_FILES	+= $(ZIP_SRC)
DEPLOY_FILES	+= $(ZIP_PDF)

.PHONY: deploy
deploy:
	-rm $(DEPLOY_FILES)
	$(MAKE) $(MFLAGS) -f $(firstword $(MAKEFILE_LIST)) LILYFLAGS=-dno-point-and-click parts score
	$(MAKE) -f $(firstword $(MAKEFILE_LIST)) $(MFLAGS) zip
	chmod a+rX $(DEPLOY_FILES)
	ssh $(DEPLOY_HOST) mkdir -p $(DEPLOY_DIR)
	scp $(DEPLOY_FILES) $(DEPLOY_HOST):$(DEPLOY_DIR)

.PHONY: flac
flac:
	for f in *.midi; do timidity -OF "$$f"; done

.PHONY:	clean
clean:
	rm -f $(SCORE_PDF) $(PARTS_PDF) $(ZIP_PDF) $(ZIP_SRC) *.ly~

# Dependencies.
# Don't try to specify individual dependencies: all PDFs depend on all notes.
$(SCORE_PDF):	$(NOTES)
$(PARTS_PDF):	$(NOTES)
