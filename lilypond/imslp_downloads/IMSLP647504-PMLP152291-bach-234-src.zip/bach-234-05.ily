\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"

mvtVtimeline = {
    \key d \major
    \time 6/8

    s2.*74 |
    \barNumberCheck # 75
    \bar "|."
}

mvtVbreaks = <<
\mvtVtimeline
{
    <>^"breaks left in"
    \repeat unfold 3 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 19
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 38
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 58
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 75
}
>>


mvtVvl = <<
\mvtVtimeline
\relative c' {
    % \clef alto
    fis8 e16( d16) e16-. cis16-. d16-. fis16-. a,16( cis16 d16) fis16-. | %1
    g8 fis16( e16) fis16-. d16-. e16-. g16-. a,16( cis16 e16) g16-. | %2
    a16-. c,16( b16 a16) b16-. fis'16-. a16( g16) g16( fis16) fis16-. g16-. | %3
    g16-. b,16( a16 g16) a16-. e'16-. g16( fis16) fis16( e16) e16-. fis16-. | %4
    fis16-. d16( cis16 b16) gis'16( a16) d,16-. b16( a16 gis16) fis'16( e16) | %5
    e8 d16( cis16) b16 cis16 a4 r8 | %6
    e'16-. g16( fis16 e16) a16-. d,16-. cis16-. e16-. a,16( b16 cis16) d16-. | %7
    e16 g16( fis16 e16) a16 d,16 cis16 e16 a,16( b16 cis16) d16 | %8
    e16 g16( fis16) b16( a16) d,16( cis16) e16( d16) g16( fis16) b,16( | %9
    a16) c16( b16) e16( d16) a16 g4.~ | %10
    g16 b16( a16 g16) cis16( d16) a16-. cis16( b16 a16) g'16( fis16) | %11
    fis8 d8 cis8 d4. | %12
    R2.*2 | %13
    fis8 e16( d16) e16-. cis16-. d16-. fis16-. a,16( cis16 d16) fis16-. | %15
    g8 fis16( e16) fis16-. d16-. e16-. cis16-. a16( gis16 a16) cis16-. | %16
    e4.~ e16 fis16 gis16( a16) gis16( a16) | %17
    e4.~ e16 d16 d16( cis16) cis16( b16) | %18
    cis4.~ cis16 fis16 eis16( fis16) eis16( fis16) | %19
    cis4.~ cis16 b16 b16( a16) a16 cis'16 | %20
    b16( a16) a16( gis16) gis16( fis16) e4 r8 | %21
    r4 r8 r16 e16( d16 cis16) g'16( fis16) | %22
    fis16-. d16( cis16 b16) gis'16( a16) d,16-. b16( a16 gis16) fis'16( e16) | %23
    e8 d16( cis16 b16 cis16) d4.~ | %24
    d8 r8 r8 r4 r8 | %25
    cis'8 b16( a16) b16-. gis16-. a16-. cis16-. e,16( gis16 a16) cis16-. | %26
    d8 cis16( b16) cis16-. a16-. b16-. d16-. e,16( fis16 gis16) a16-. | %27
    b16-. d16( cis16) fis16( e16) a,16( gis16) b16( a16) d16( cis16) fis,16( | %28
    e16) g16( fis16) b16( a16) e16 d4.~ | %29
    d16 fis16( e16 d16) gis16( a16) e16-. gis16( fis16 e16) d'16( cis16) | %30
    cis8 a8 gis8 a16 d,16( cis16 b16) cis16 e16 | %31
    a,16( cis16 e8) r8 a,16( cis16 e8) r8 | %32
    b'16( gis16 e8) a8 gis16( b16 e8) r8 | %33
    r16 d,16( cis16 b16) cis16 g'16 fis16 \once \slurDashed g16( fis16 e16) fis16 d16 | %34
    b8 e8 g8 r16 d16( cis16 b16) cis16 e16 | %35
    d16 fis16( e16 d16) e16 fis16 g,8 r8 r8 | %36
    r8 r8 g'8~ g16 e16( fis16 ais16) b16 d16 | %37
    g,16( e16 cis8) r8 r16 d16( cis16 b16) fis'16 g16 | %38
    a16 c,16( b16 a16) b16 fis'16 a16( g16) g16( fis16) fis16 g16 | %39
    g16 b,16( a16 g16) a16 e'16 g16( fis16) fis16( e16) e16 fis16 | %40
    fis16 b16( ais16 gis16) ais16 cis16 e16 g,16( fis16 e16) ais16 b16 | %41
    fis8 e16 d16 cis16 d16 b16 cis16 b16 ais16 b16 d16 | %42
    gis16 b16( a16 gis16) a16 b16 cis16 b,16 a16 gis16 a16 cis16 | %43
    fis16 a16 gis16 fis16 gis16 a16 b16 fis16 eis16 dis16 eis16 gis16 | %44
    a16 b16( a16 gis16) a16 cis16 d16 cis16( b16 ais16) b16 d16 | %45
    g,16 a16( g16 fis16) g16 b16 cis,4.~ | %46
    cis8 r8 fis8~ fis16 gis16( fis16 eis16) fis16 a16 | %47
    d16 fis,16( eis16 dis16) eis16 gis16 b,8( a8) r8 | %48
    R2. | %49
    r4 r8 r16 e'16( d16 cis16) d16 fis16 | %50
    e16 \once \slurDashed g16( fis16 e16) a16 d,16 cis16 e16 \once \slurDashed a,16( b16 cis16) d16 | %51
    e16 g16( fis16 e16) a16 d,16 cis16 e16 \once \slurDashed a,16( b16 cis16) d16 | %52
    e16 g16( fis16) b16( a16) d,16( cis16) e16( d16) g16( fis16) b,16( | %53
    a16) c16( b16) e16( d16) a16 g4.~ | %54
    g16 b16( a16 g16) \once \slurDashed cis16( d16) a16 \once \slurDashed cis16( b16 a16) \once \slurDashed g'16( fis16) | %55
    fis8 d8 cis8 d16 a16 d16 fis16 a16 g16 | %56
    a2.~ | %57
    a4.~ a16 cis,16( b16 a16) g'16( fis16) | %58
    fis8 e16( d16) e16 cis16 d16 fis16 a,16( cis16 d16) fis16 | %59
    g8 fis16( e16) fis16 d16 e16 cis16 a16( gis16 a16) cis16 | %60
    e16 g16( fis16 e16) a16 d,16 cis16 e16 a,16( b16 cis16) d16 | %61
    e16 g16( fis16 e16) a16 d,16 cis16 e16 a,16( b16 cis16) d16 | %62
    e16 g16( fis16) b16( a16) d,16( c16) e16( d16) g16( fis16) \once \slurDashed b,16( | %63
    a16) c16( b16) \once \slurDashed e16( d16) a16 g4.~ | %64
    g8 r8 r8 r4 r8 | %65
    R2.*2 | %66
    r16 a16( b16 cis16 d16 e16) fis16 cis16( d16 e16 fis16 g16) | %68
    a16 \once \slurDashed c,16( b16 a16) b16 fis'16 a16( g16) g16( fis16) fis16 g16 | %69
    g16 \once \slurDashed b,16( a16 g16) a16 e'16 \once \slurDashed g16( fis16) \once \slurDashed fis16( e16) e16 fis16 | %70
    fis16 \once \slurDashed a16( g16) \once \slurDashed b16( a16) d,16( cis16) e16( d16) g16( fis16) b,16( | %71
    a16) \once \slurDashed c16( b16) e16( d16) a16 g4.~ | %72
    g16 b16( a16 g16) cis16( d16) a16 cis16( b16 a16) g'16( fis16) | %73
    fis8 d8 cis8 d4.\fermata | %74
}
>>


mvtValto = <<
\mvtVtimeline
\relative c' {
    \autoBeamOff
    R2.*12 | %1
    fis8[ e16 d16] e8 d16 a16 cis16([ d16 e16 fis16] | %13
    g8[ fis16 e16)] fis16([ d16)] e8([ d16 cis16)] b16([ a16)] | %14
    a'8([ g16 fis16)] g8 fis8 e8([ d8)] | %15
    b'8([ a8)] d8 d8 cis4 | %16
    b8 cis8 d8 cis8[ b8] a8 | %17
    b8 e8 d8 cis8 b8 a8 | %18
    gis8 a8 b8 a8([ b16 a16)] gis16([ fis16)] | %19
    gis8 cis8 b8 a8 gis8 fis8 | %20
    b16[ cis16] d4~ d8[ cis16( b16)] a16[ gis16] | %21
    fis16([ e16)] cis'8 b8 a8 a4~ | %22
    a2.~ | %23
    a4.~ a8[ gis16 a16 b16 gis16] | %24
    e8 b'8.([ cis32 d32)] cis8([ a8)] gis8 | %25
    a4 r8 r4 r8 | %26
    R2.*5 | %27
    cis8[ b16 a16] b8 a16 e16 gis16[ \melisma a16 b16 cis16] | %32
    d8[ cis16 b16] \melismaEnd cis16[ a16] b8[ a16 gis16] fis16[ e16] | %33
    e'8 ais,4 b8[ cis8] d8 | %34
    g,16 e16([ fis16 g16)] a16([ b16)] cis16[ b16 a8] g8 | %35
    fis8 g16([ fis16)] e16([ d16)] b'8 g8 fis8 | %36
    e16([ g16)] fis16([ e16)] ais16([ b16)] cis8 ais16 fis16 d'8~ | %37
    d16 cis16 ais8.[ b16] b4 r8 | %38
    R2.*3 | %39
    r4 r8 r8 fis8 d'8~ | %42
    d8[ cis16 b16] a16[ gis16] e'8[ cis8] a8 | %43
    r8 d,8 b'8~ b8[ cis16 b16] a16[ gis16] | %44
    cis8 a8 fis8 r8 b,8 g'8~ | %45
    g8 b16([ a16)] g16([ fis16)] eis16([ fis16)] gis16([ a16)] b16([ cis16)] | %46
    fis,8([ d'8)] cis8 b8 a16[ gis16] a8~ | %47
    a16 b16 gis8.[ fis16] fis4 r8 | %48
    fis8([ e16 d16)] e8 d16 a16 cis16([ d16 e16 fis16] | %49
    g8[ fis16 e16)] fis16[ d16] e8 a,8 a'8 | %50
    a4.~ a8 cis8 e8 | %51
    a,4.~ a8[ g16 fis16] e8 | %52
    R2.*4 | %53
    fis8[ e16 d16] e8 d16 a16 cis16[ \melisma d16 e16 fis16] | %57
    g8[ fis16 e16] \melismaEnd fis16[ d16] e8[ d16 cis16] b16[ a16] | %58
    a'8[ g16 fis16] g8 fis8 e8([ d8)] | %59
    b'8([ a8)] d8 d8 cis4 | %60
    e,8 cis'8 d8 a8([ g8)] fis8 | %61
    e8 cis'8 d8 a8 g8 fis8 | %62
    e8 d16[ e16] fis16 g16 a8 c16[ b16] c8 | %63
    d,8[ d'8] c8 b16[ a16] b16[ g16] fis16[ e16] | %64
    cis'16[ b16] cis16[ a16] g16[ fis16] d'16[ cis16] d16[ b16] a16[ g16] | %65
    e'8 g,4 r8 fis8 g32([ a32 b16)] | %66
    a8 g16[ fis16] e16[ d16] g32([ fis32 e16)] e8.[ d16] | %67
    d4 r8 r4 r8 | %68
    R2.*5 |
    R2.\fermata |
    \barNumberCheck # 75
}
>>


mvtVlyrics = \lyricmode {
    Quo -- ni -- am tu so -- lus san -- ctus,
    quo -- ni -- am tu so -- lus san -- ctus,
    tu so -- lus san -- ctus,
    tu so -- lus Do -- mi -- nus,
    tu so -- lus san -- ctus,
    tu so -- lus Do -- mi -- nus,
    tu so -- lus al -- tis -- si -- mus,
    so -- lus al -- tis -- si -- mus;
    quo -- ni -- am tu so -- lus san -- ctus Je -- su Chri -- ste,
    tu so -- lus Do -- mi -- nus Je -- su Chri -- ste,
    tu so -- lus al -- tis -- si -- mus Je -- su Chri -- ste;
    tu so -- lus san -- ctus,
    tu so -- lus Do -- mi -- nus,
    tu so -- lus al -- tis -- si -- mus Je -- su Chri -- ste;
    Je -- su Chri -- ste;
    quo -- ni -- am tu so -- lus san -- ctus, tu san -- ctus, tu so -- lus,
    quo -- ni -- am tu so -- lus san -- ctus,
    quo -- ni -- am tu so -- lus san -- ctus,
    tu so -- lus san -- ctus,
    tu so -- lus Do -- mi -- nus,
    tu so -- lus al -- tis -- si -- mus,
    Je -- su __ Chri -- ste,
    tu so -- lus al -- tis -- si -- mus,
    Je -- su, Je -- su __ Chri -- ste, Je -- su __ Chri -- ste.
}


mvtVbc = <<
\mvtVtimeline
\relative c {
    \clef bass
    d8 a'8 g8 fis4 r8 | %1
    cis8 d8 d,8 a'4 r8 | %2
    fis'8 g8 a8 dis,8 b8 dis8 | %3
    e8 fis8 g8 cis,8 a8 cis8 | %4
    d8 d'8 cis8 b8 fis8 gis8 | %5
    a8 d,8 e8 a,8 cis8 e8 | %6
    a8 g8 fis8 e4 d8 | %7
    cis8 d8 fis8 a8 cis8 e8 | %8
    cis8 a8 fis8 a8 fis8 d8 | %9
    fis8 d8 b8 e8 b8 d8 | %10
    cis8 e8 fis8 g8 cis,8 a8 | %11
    d8 fis8 a8 d,8 fis,8 a8 | %12
    d8\P a'8 g8 fis8 e8 d8 | %13
    cis8 d8 d,8 a'8 a'8 g8 | %14
    fis8 cis8 a8 d4 r8 | %15
    cis8 d8 d,8 a'8 e'8 a8 | %16
    gis8 fis8 e8 a4 r8 | %17
    gis8 fis16( e16) fis16( gis16) a4 r8 | %18
    eis8 cis'8 cis,8 fis4 r8 | %19
    eis8 cis16( dis16) eis16( cis16) fis4 e8 | %20
    d8 cis8 b8 gis'8 a8 b8 | %21
    cis,8 d8 e8 a,8 b8 cis8 | %22
    d8 d'8 cis8 b8 cis8 d8 | %23
    cis8 a8 gis8 fis8 b8 a8 | %24
    gis8 fis8 e8 a8 cis,8 e8 | %25
    a,8\F e'8 d8 cis4 r8 | %26
    gis'8 a8 a,8 e'4 r8 | %27
    gis8 e8 cis8 e8 cis8 a8 | %28
    cis8 a8 fis8 b8 fis'8 a8 | %29
    gis8 b8 cis8 d8 gis,8 e8 | %30
    a8 cis,8 e8 a,8 cis8 e8 | %31
    a8\P gis16( fis16) e16( d16) cis8 b8 a8 | %32
    gis8 a8 a'8 e4 d8 | %33
    cis8 fis8 e8 d8 cis8 b8 | %34
    e4 r8 a,8 e'8 a8 | %35
    d,4 r8 g,8 b8 d8 | %36
    g8 cis,8 b8 ais8 fis8 b8 | %37
    e8 fis8 fis,8 b4 r8 | %38
    fis'8\F g8 a8 dis,8 b8 dis8 | %39
    e8 fis8 g8 cis,8 a8 cis8 | %40
    d8 cis8 e8 ais,8 b8 cis8 | %41
    d8 e8 fis8 b,8\P d8 b8 | %42
    e8 e,8 r8 a8 a'8 cis,8 | %43
    d8 b8 d8 gis,8 cis8 b8 | %44
    a8 fis'16( e16 d16 cis16) b4 r8 | %45
    r4 r8 r16 a'16( gis16 fis16) gis16 b16 | %46
    ais16 cis16( b16 a16) gis16 fis16 gis8 cis,8 fis8 | %47
    b,8 cis8 cis,8 fis8 fis'8 e8 | %48
    d8 a'8 g8 fis8 e8 d8 | %49
    cis8 d8 d,8 a'4 b8 | %50
    cis8 d8 fis8 a8 e8 g8 | %51
    cis,8 d8 d,8 a'8 a'8 b8 | %52
    cis8\F a8 fis8 a8 fis8 d8 | %53
    fis8 d8 b8 e8 b8 d8 | %54
    cis8 e8 fis8 g8 cis,8 a8 | %55
    d8 fis8 a8 d,8 d,8 r8 | %56
    d'8\P a'8 g8 fis8 e8 d8 | %57
    cis8 d8 d,8 a'8 b8 cis8 | %58
    d8 a'8 a,8 d4 r8 | %59
    cis8 d8 d,8 a'8 cis8 e8 | %60
    a8 g8 fis8 r8 e8 d8 | %61
    cis8 a8 fis'8 r8 e8 d8 | %62
    cis8 d8 d,8 r8 fis'8 a8 | %63
    fis8 d8 d,8 g8 g8 g8 | %64
    a8 a8 a8 b8 b8 b8 | %65
    cis16( b16) d16( cis16) b16( a16) d4 e8 | %66
    fis8 a8 b8 g8 a8 a,8 | %67
    d4 r8 r16 a16\F( b16 cis16 d16 e16) | %68
    fis8 g8 a8 dis,8 b8 dis8 | %69
    e8 fis8 g8 cis,8 a8 cis8 | %70
    d8 e8 fis8 g8 fis8 d8 | %71
    fis8 d8 b8 e8 b8 d8 | %72
    cis8 e8 fis8 g8 cis,8 a8 | %73
    d8 fis,8 a8 d,4.-\fermata | %74
}
>>

mvtVfigs = <<
\mvtVtimeline
\figuremode {
    s4 <4 2>8 <6>4. |
    <6 5> s |
    <5!>8 <\FBx> <4\+ 2> <6 5>4. |
    s4 <4 2>8 <6 5>4. |
    s8 <4\+ 2> <6> s <6> <6 5> |
    s <7 5> <_+> s <\FBnull> \once \bassFigureExtendersOn 8 |
    s4 <6>8 <6>4. |
    <6 5>4 <6>8 s4. |
    <6>8 <6> <6> s <6> s |
    <6> <6> s s <\FBx> <4 2> |
    <6 5> <\FBx> s <4 2> <\FBnull> \once \bassFigureExtendersOn 8 |
    s8 <6> s s4. |
    s <6> |
    <6 5> s |
    <6>8 <6 5> s s4. |
    <6 5>4. s |
    <6>4 <7 _+>8 s4. |
    <6> s |
    \barNumberCheck # 19
    <6>8 <6 4> <5\+ _+> s4. |
    <6>8 s <6 5> s4 <4 2>8 |
    <6> <\FBnull> \once \bassFigureExtendersOn 8 <6 5>4. |
    <6>8 <7 5> <_+> s4 <6>8 |
    s4. <6\\>8 s <4\+ 2> |
    <6>4 <6>8 <6>4. |
    <6 5> s8 <6> <_+> |
    s <_+> <\FBx> <6>4. |
    <6 5>4. <_+> |
    <6>8 <6> s <_+> <6> s |
    <6> <6> s s <6 4> <4 2> |
    <6 5> <6\\> s <4\+ 2> <6 5> s |
    s <6> <_+> s <\FBnull> \once \bassFigureExtendersOn 8 |
    s <6> s <6> <6\\> s |
    <6 5>4. <_+>4 <4\+ 2>8 |
    <7 5!> <_+> s <6>4. |
    s <7> |
    s <7> |
    <6>8 <6\\ 5> <6 4> <6 5>4. |
    \barNumberCheck # 38
    <7 5>8 <7 _+> s s4. |
    <5!>8 s <4\+ 2> <6 5>4. |
    s4 <6>8 <6 5>4. |
    s8 <6\\> s <6 5>4 <6\\>8 |
    <6> <\FBx> <_+> s <6> s |
    <7 _+>4. s4 <6>8 |
    <6> s <6> <7> <_+> s |
    <6>4. <7>4 <6!>8 |
    s4. <4\+2>8 <6\\> s |
    <6>4. <7>8 <7 _+> s |
    <7 5> <_+> s s4 <\FBx>8 |
    s4 <4 2>8 <6>4. |
    <6 5> s |
    <6 5>4 <6>8 s <6 4> <4 2> |
    <6 5>4. s |
    <6>8 8 s s <6> s |
    <6> <6> s s <6 4> <4 2> |
    <6 5> <6> <6> <4 2> <6 5> s |
    s <6> s s4. |
    s <6> |
    \barNumberCheck # 58
    <6 5>4. s4 <6 5>8 |
    s <7> s s4. |
    <7 5> <4>8 <6> <\FBx> |
    s <4 2> <6> s <6> s |
    <6 5> <7> <6> s <6> s |
    <6 5>4. s8 <6> <\FBx> |
    <6 5!>4 <7!>8 <5> s <6> |
    <5> s <6> <5> s <6> |
    <6 5>4. s4 <6>8 |
    <6>4. <6 5> |
    s2. |
    <6>8 <\FBx> <6 4\+> <6 5>4. |
    s4 <6 4>8 <6 5>4. |
    s4 <6>8 <4 2> <6> s |
    <6> <6> s s <6 4> <4 2> |
    <6 5> <6> <6> <6 4 2> <6 5> s |
    s <6> s s4. |
    \barNumberCheck # 75
}
>>
