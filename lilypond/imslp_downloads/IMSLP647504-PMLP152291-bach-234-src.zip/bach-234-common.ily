\version "2.21.0"

\include "include-once.ily"
\includeOnce "common.ily"

% #(define clefTaille   (if (defined? 'clefTaille)   clefTaille  #{ \clef G #}))
% #(define transpTaille (if (defined? 'transpTaille) transpTaille  #{ f, #}))
% #(define clefObDaC    (if (defined? 'clefObDaC)    clefObDaC  #{ \clef G #}))
% #(define transpObDaC  (if (defined? 'transpObDaC)  transpObDaC  #{ f, #}))

