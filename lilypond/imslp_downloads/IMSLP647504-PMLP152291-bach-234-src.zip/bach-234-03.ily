\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"

mvtIIItimeline = {
    \key a \major
    \time 4/4

    \tempo \markup\smaller{Andante}
    s1*100 |
    \barNumberCheck # 101
    \bar "|."
}


mvtIIIbreaks = <<
\mvtIIItimeline
{
    <>^"breaks left in"
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 16
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 31
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 46
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 61
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 76
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 91
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
    \barNumberCheck # 101
}
>>


mvtIIIvln = <<
\mvtIIItimeline
\relative c'' {
    cis16( b16 a16 gis16 fis8) a'8 gis16( fis16 eis16 dis16) cis4 | %1
    a'16( gis16 fis16 e16 d8) fis,8 e8 gis'8 cis,4 | %2
    fis16( e16 d16 cis16 b8) d,8 cis8 e'8 a,4 | %3
    d16( cis16 b16 a16 gis8) b,8 a8 cis'8 fis,8 fis'8~ | %4
    fis16( e16 fis16) dis16-. bis16( ais16 bis16) gis16-. eis16( gis16 b16 d16) gis8 b8 | %5
    bis,8( cis4) eis,8 fis4 r4 | %6
    cis'16( b16 a16 gis16 fis8) a'8 gis16( fis16 eis16 dis16) cis4 | %7
    R1 | %8
    cis16( b16 a16 gis16 fis8) a'8 gis16( fis16 eis16 dis16) cis4 | %9
    r2 gis16( fis16 eis16 dis16 cis8) a''8 | %10
    gis16( fis16 eis16 d16) cis16 b16 a16 gis16 fis16 e16 dis16 cis16 b8 gis''8 | %11
    fis16( e16 dis16 cis16) b16( a16 gis16 fis16) e16( d16 cis16 b16 a8) fis''8 | %12
    gis,8( a4) dis,8 e4 r4 | %13
    R1*2 | %14
    \barNumberCheck # 16
    r2 e'16( d16 cis16 b16 a8) cis'8 | %16
    b16( a16 gis16 fis16) e4 cis'16( b16 a16 gis16 fis8) a,8 | %17
    gis8 b'8 e,4 a16( gis16 fis16 e16 d8) fis,8 | %18
    e8 gis'8 cis,4 fis16( e16 d16 cis16 b8) d,8 | %19
    cis8 e'8 a,8 a'8~ a16( gis16 a16) fis16-. dis16( cis16 dis16) b16-. | %20
    gis16 b16 d16 f16 b8 d8 dis,8( e4) gis,8 | %21
    a4 r4 cis16( b16 ais16 gis16 fis8) g'8 | %22
    fis16( e16 d16 cis16) b16 a16 gis16 fis16 eis4 r4 | %23
    r4 r8 b''8~ b16 a16( gis16 fis16 eis8) d'8 | %24
    cis16( b16 ais16 gis16 fis16 e16 d16 cis16) \once \slurDashed b16( a16 gis16 fis16) e8 cis''8 | %25
    b16( a16 gis16 fis16 e16 d16 cis16 b16) a16( gis16 fis16 e16) d8 b''8 | %26
    a16( gis16 fis16 e16 d16 cis16 b16 a16) gis16( fis16 eis16 dis16) cis4 | %27
    R1*2 | %28
    r2 fis'16( e16 d16 cis16 b8) d'8 | %30
    \barNumberCheck # 31
    cis16( b16 ais16 gis16) fis4~ fis16 e16( d16 cis16 b16 a16 gis16 fis16) | %31
    eis4 r4 r2 | %32
    cis'16( b16 a16 gis16 fis8) a'8 gis16( fis16 eis16 dis16) cis4 | %33
    a'16( gis16 fis16 e16 d8) fis,8 e8 gis'8 cis,4 | %34
    fis16( e16 d16 cis16 b8) d,8 cis8 e'8 a,4 | %35
    d16( cis16 b16 a16 gis8) b,8 a8 cis'8 fis,8 fis'8 | %36
    fis16( e16 fis16) dis16-. bis16( ais16 bis16) gis16-. eis16 gis16 b16 d16 gis8 b8 | %37
    bis,8( cis4) eis,8 fis4 r4 | %38
    R1 | %39
    e16( d16 cis16 b16 a8) cis'8 b16( a16 gis16 fis16) e4 | %40
    R1 | %41
    fis16( e16 d16 cis16 b8) d'8 cis16( b16 ais16 gis16) fis4 | %42
    fis'16( e16 d16 cis16) e16( d16 cis16 b16) fis'16( e16 dis16 cis16) e16( dis16 cis16 b16) | %43
    b'16( a16 g16 fis16 e16 d16 cis16 b16) ais16 cis16 e16 g16 ais8 cis8 | %44
    d16( cis16 b16 a16 gis8) b,8 a8 c'8 fis,4 | %45
    \barNumberCheck # 46
    b16( a16 g16 fis16 e8) g,8 fis8 a'8 d,4 | %46
    g16( fis16 e16 d16 cis8) e,8 d8 fis'8 b,4 | %47
    R1 | %48
    fis'16( e16 d16 cis16 b8) d'8 cis16( b16 ais16 gis16 fis16 e16 d16 cis16) | %49
    d16 cis16 b16 a16 g8 b,8 a8 cis'8 fis,4 | %50
    b16( ais16 b16) g16-. eis16( dis16 eis16) cis16-. ais16 cis16 e16 g16 cis8 e8 | %51
    eis,8( fis4) ais,8 b4 r4 | %52
    b'16( a16 gis16 fis16 e8) cis''8 b16( a16 gis16 fis16) e4 | %53
    R1 | %54
    gis,16( fis16 e16 dis16 cis8) e'8 dis16( cis16 bis16 ais16) gis4~ | %55
    gis16( fis16 e16 dis16) fis16( e16 dis16 cis16) gis'16( fis16 eis16 dis16) fis16( eis16 dis16 cis16) | %56
    cis'16( b16 a16 gis16 fis16 e16 dis16 cis16) bis16( dis16 fis16 a16) bis8 dis8 | %57
    e16( dis16 cis16 b16 a8) cis,8 b8 a'8 gis8 d'8 | %58
    cis16 b16 a16 gis16 fis8 a,8 gis8 fis'8 e8 b'8 | %59
    a16 gis16 fis16 e16 dis8 fis8 e8 cis'8 a'4 | %60
    R1*3 | %61
    cis,16( b16 a16 gis16 fis8) a'8 gis16( fis16 eis16 dis16) cis4 | %64
    a'16( gis16 fis16 e16 d8) fis,8 e8 gis'8 cis,4 | %65
    fis16( e16 d16 cis16 b8) d,8 cis8 e'8 a,4 | %66
    d16 cis16 b16 a16 gis8 b,8 a8 cis'8 fis, fis'~ | %67
    fis16( e16 fis16) dis16-. bis16( ais16 bis16) gis16-. eis16 gis16 b16 d16 gis8 b8 | %68
    bis,8( cis4) eis,8 fis4 r4 | %69
    r2 cis'16 b16 a16 gis16 fis8 a'8 | %70
    gis16( fis16 eis16 dis16) cis4 r2 | %71
    gis16( fis16 eis16 dis16 cis8) a''8 gis16( fis16 eis16 dis16 cis16 b16 a16 gis16) | %72
    fis16 e16 dis16 cis16 b8 gis''8 fis16( e16 dis16 cis16 b16 a16 gis16 fis16) | %73
    e16( d16 cis16 b16 a8) fis''8 gis,8( a4) dis,8 | %74
    e4 r4 r2 | %75
    R1*2 | %76
    e'16( d16 cis16 b16 a8) cis'8 b16( a16 gis16 fis16) e4 | %78
    cis'16( b16 a16 gis16 fis8) a,8 gis8 b'8 e,4 | %79
    a16( gis16 fis16 e16 d8) fis, e8 gis'8 cis,4 | %80
    fis16( e16 d16 cis16 b8) d,8 cis8 e'8 a,8 a'8~ | %81
    a16( gis16 a16) fis16-. dis16( cis16 dis16) b16-. gis16( b16 d16 f16) b8 d8 | %82
    dis,8( e4) gis,8 a4 r4 | %83
    cis16( b16 ais16 gis16 fis8) g'8 fis16( e16 d16 cis16 b16 a16 gis16 fis16) | %84
    eis4 r4 r4 r8 b''8~ | %85
    b16 a16 gis16 fis16 eis8 d'8 cis16( b16 ais16 gis16 fis16 e16 d16 cis16) | %86
    b16 a16 gis16 fis16 e8 cis''8 b16( a16 gis16 fis16 e16 d16 cis16 b16) | %87
    a16 gis16 fis16 e16 d8 b''8 a16( gis16 fis16 e16 d16 cis16 b16 a16) | %88
    gis16( fis16 eis16 dis16) cis4 r2 | %89
    R1*2 | %90
    \barNumberCheck # 92
    fis'16( e16 d16 cis16 b8) d'8 cis16( b16 ais16 gis16) fis4~ | %92
    fis16 e16( d16 cis16 b16 a16 gis16 fis16) eis4 r4 | %93
    \barNumberCheck # 94
    r2 cis'16( b16 a16 gis16 fis8) a'8 | %94
    gis16( fis16 eis16 dis16) cis4 a'16( gis16 fis16 e16 d8) fis,8 | %95
    e8 gis'8 cis,4 fis16( e16 d16 cis16 b8) d,8 | %96
    cis8 e'8 a,4 d16( cis16 b16 a16 gis8) b,8 | %97
    a8 cis'8 fis,8 fis'8~ \once \slurDashed fis16( e16 fis16) dis16-. bis16( ais16 bis16) gis16-. | %98
    eis16( gis16 b16 d16) gis8 b8 bis,8( cis4) eis,8 | %99
    fis4 r4 r2 | %100
    \barNumberCheck # 101
}
>>

mvtIIIbass = <<
\mvtIIItimeline
\relative c' {
    \autoBeamOff
    \clef F
    R1*5 | %1
    r2 cis8 a8 fis4 | %6
    R1 | %7
    cis'16([ b16)] a16([ gis16)] fis4 gis8 a8 b8 a16[ gis16] | %8
    a8 fis16([ gis16)] a16([ b16)] cis8 d8 cis16([ b16 cis8)] fis,8 | %9
    eis8([ b'8. gis16)] a8 gis4 r4 | %10
    b16([ a16)] gis16([ fis16)] eis4 r2 | %11
    a8([ fis8)] dis4 r2 | %12
    e'16[ d16] cis16[ b16] a4 b8 cis8 d8 cis16[ b16] | %13
    cis8 a8 cis4(~ cis16[ b16 a16 gis16] a8) fis8 | %14
    dis8 \melisma c'4 b8 dis8 \melismaEnd e4 gis,8 | %15
    a8.[ b16] b8.[ a16] a4 r4 | %16
    R1*5 | %17
    cis16([ d16 e8. d16)] cis16 b16 ais8 ais8 b8 cis8 | %22
    d16[ cis16] b8 d4~ \melisma d16[ cis16 b16 a16] gis8 \melismaEnd fis8 | %23
    eis8 fis16 cis'16 b16([ a16)] gis16([ fis16)] gis4 r4 | %24
    e'16[ d16] cis16[ b16] ais4 r2 | %25
    d8([ b8)] gis4 r2 | %26
    cis16[ b16] a16[ gis16] fis4 gis8 a8 b8 a16[ gis16] | %27
    a8 fis8 a4~ \melisma a16[ gis16 fis16 eis16] fis8 \melismaEnd d8 | %28
    bis8 \melisma a'4 gis8 bis8 \melismaEnd cis4 eis,8 | %29
    fis8.[ gis16] gis8.[ fis16] fis4 g4~ | %30
    g8[ fis8] fis4 r8 d'8([ cis8)] bis8 | %31
    cis8([ d16 cis16)] b16([ a16)] gis16([ fis16)] cis4 eis4 | %32
    fis4 r4 r2 | %33
    R1*5 | %34
    a4~ a16[ b32 cis32] b16 a16 gis16[ a16 b16 gis16] e4 | %39
    R1 | %40
    b'4~ b16[ cis32 d32] cis16[ b16] ais16[ b16] cis16[ ais16] fis4 | %41
    R1 | %42
    d'8([ b8)] ais8[ b8] dis8([ b8)] ais8([ b8)] | %43
    e8.([ d16] cis16) b16[ ais16 b16] cis8[ ais8] fis4 | %44
    r4 b8 c16 d16 d8[ c8] c4 | %45
    r4 a8[ b16] c16 c16[ b16] c8 b4 | %46
    r4 ais8 b16([ cis16)] b8 cis16([ d16)] cis8 d16 e16 | %47
    fis,16([ gis16 ais16 b16] cis8) e,8 d16([ fis16)] b16([ cis16)] d8[ cis8] | %48
    b4 r4 r2 | %49
    R1*2 | %50
    r2 d16[ cis16 b8~] b16 a16 gis16([ fis16)] | %52
    gis16([ fis16 e8)] e4 r2 | %53
    cis'4. dis8 cis16[ bis16] cis16[ dis16] gis,4 | %54
    R1 | %55
    e8([ cis'8)] bis8([ cis8)] eis,8([ cis'8)] bis8([ cis8)] | %56
    fis,8.[ \melisma e'16] dis16[ cis16] \melismaEnd bis16[ cis16] dis8[ bis8] gis4 | %57
    r4 cis,8 d16 e16 e8[ d8] d4 | %58
    r4 b8[ cis16] d16 d16[ cis16] d8 cis4 | %59
    r4 bis8 cis16[ dis16] cis8 dis16[ e16] dis8 fis16 e16 | %60
    fis4~ fis16[ a16] gis16[ fis16] e16[ dis16] e16[ cis16] bis4 | %61
    cis8 cis'8.[ b16] a16[ gis16] fis8[ d'8] bis8[ cis8] | %62
    e,4( dis8.[ cis16)] cis4 r4 | %63
    r2 r4 cis'4~ | %64
    cis8 a8 fis4 r2 | %65
    d'8[ b8] gis4 r2 | %66
    r4 e'8 gis,8 a4 a,4 | %67
    r4 gis'4~ gis8 fis16 eis16 b'8([ a16 gis16] | %68
    a8) fis8 r4 cis'16[ b16] a16[ gis16] fis4 | %69
    gis8 a8 b8 a16[ gis16] a8 fis16[ gis16] a16[ b16] cis8 | %70
    d8 cis16[ b16] cis8 fis,8 eis8 b'8.([ gis16 a8)] | %71
    gis4 r4 b16[ a16] gis16[ fis16] eis4 | %72
    r2 a8([ fis8)] dis4 | %73
    r2 e'16[ d16] cis16[ b16] a4 | %74
    b8 cis8 d8 cis16[ b16] cis8 a8 cis4~ | %75
    \melisma cis16[ b16 a16 gis16] a8 \melismaEnd fis8 dis8( c'4) b8 | %76
    dis8( e4) a,16 gis16 a8.([ \melisma b16)] b4\trill | %77
    \melismaEnd a4 r4 r2 | %78
    R1*4 | %79
    r2 cis16[ d16 e8~] e16 d16 cis16[ b16] | %83
    ais8 ais8 b8 cis8 d16[ cis16] b8 d4~ | %84
    d16[ cis16] b16[ a16] gis8 fis8 eis8 dis16 cis16 fis8.([ gis32 a32)] | %85
    gis4 r4 e'16[ d16] cis16[ b16] ais4 | %86
    r2 d8[ b8] gis4 | %87
    r2 cis16([ b16 a16 gis16] fis8) fis8 | %88
    gis8 a8 b8 a16 gis16 a8 fis8 a4~ | %89
    \melisma a16[ gis16 fis16 eis16] fis8 \melismaEnd d8 bis8( a'4) gis8 | %90
    bis8( cis4) fis,16 eis16 fis8.[ \melisma gis16] gis4\trill \melismaEnd | %91
    fis4 g4~ g8[ fis8] fis4 | %92
    r8 d'8[ cis8] bis8 cis8 d16[ cis16] b16[ a16] gis16 fis16 | %93
    cis4( eis4) fis4 r4 | %94
    R1*6 |
    \barNumberCheck # 101
}
>>

mvtIIIlyrics = \lyricmode {
    Do -- mi -- ne, Do -- mi -- ne De -- us,
    Rex coe -- le -- stis,
    De -- us Pa -- ter __ o -- mni -- po -- tens,
    Do -- mi -- ne De -- us,
    Do -- mi -- ne De -- us,
    Rex coe -- le -- stis,
    De -- us Pa -- ter o -- mni -- po -- tens,
    Do -- mi -- ne De -- us,
    Rex coe -- le -- stis,
    De -- us Pa -- ter o -- mni -- po -- tens,
    Do -- mi -- ne De -- us,
    Do -- mi -- ne De -- us,
    Rex coe -- le -- stis,
    De -- us Pa -- ter o -- mni -- po -- tens,
    Pa -- ter,
    De -- us Pa -- ter o -- mni -- po -- tens,
    Do -- mi -- ne Fi -- li u -- ni -- ge -- ni -- te
    Je -- su Chri -- ste, Je -- su __ Chri -- ste, 
    Do -- mi -- ne Fi -- li u -- ni -- ge -- ni -- te,
    Fi -- li u -- ni -- ge -- ni -- te
    Je -- su, Je -- su Chri -- ste, 
    Do -- mi -- ne Fi -- li u -- ni -- ge -- ni -- te,
    Je -- su Chri -- ste, Je -- su Chri -- ste, 
    Do -- mi -- ne Fi -- li u -- ni -- ge -- ni -- te,
    Fi -- li u -- ni -- ge -- ni -- te,
    Je -- su, Je -- su Chri -- ste, 
    Je -- su, Je -- su Chri -- ste, 
    Do -- mi -- ne De -- us,
    A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    Do -- mi -- ne De -- us,
    A -- gnus De -- i, A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    Do -- mi -- ne De -- us, Do -- mi -- ne De -- us,
    A -- gnus De -- i, A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    Do -- mi -- ne De -- us,
    A -- gnus De -- i, A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    Do -- mi -- ne De -- us,
    A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    A -- gnus De -- i, Fi -- li -- us Pa -- tris,
    A -- gnus, A -- gnus De -- i, Fi -- li -- us Pa -- tris.
}


mvtIIIbc = <<
\mvtIIItimeline
\relative c {
    \clef F
    fis8-. gis8-. a8-. fis8-. cis'4~ cis16 b16( a16 gis16) | %1
    fis4 r8 b8-. gis8-. e8-. a16-. gis16( fis16 e16) | %2
    d4 r8 gis8-. e8-. cis8-. fis16-. e16 d16 cis16 | %3
    b4 r8 e8-. cis8-. a8-. d16-. cis16( b16 a16) | %4
    gis4 r8 gis'8-. b8-. gis8-. eis16-. dis16( cis16 b16) | %5
    a16 gis16 a16 b16 cis8 cis,8 fis4 r4 | %6
    fis'8\pocop gis8 a8 fis8 cis'4~ cis16 b16( a16 gis16) | %7
    fis4~ fis16 e16( d16 cis16) b4 cis4 | %8
    fis,8 fis'8~ fis16 e16( d16 cis16) b4~ b16 a16( gis16 fis16) | %9
    gis8 eis'8 fis8 fis,8 cis'8 b'8~ b16 a16( gis16 fis16) | %10
    eis4 r8 cis8 a'4~ a16 gis16( fis16 e16) | %11
    dis4 r8 b8 gis'4~ gis16 fis16( e16 d16) | %12
    cis16-. b16( a16 gis16) fis8 fis'8 gis8 fis16 e16 fis8 gis8 | %13
    a4~ a16 gis16( fis16 e16) d8 e8 fis4~ | %14
    fis16 e16( dis16 e16) fis16-. e16( dis16 e16) fis16-. a16( gis16 fis16) e16-. d16( cis16 b16) | %15
    cis8 d8 e8 e,8 a8\F b8 cis8 a8 | %16
    e'4~ e16 d16( cis16 b16) a4 r8 d'8-. | %17
    b8-. gis8-. cis16-. b16( a16 gis16) fis4 r8 b8-. | %18
    gis8-. e8-. a16-. gis16( fis16 e16) d4 r8 gis8-. | %19
    e8-. cis8-. fis16-. e16( dis16 cis16) b4 r8 b'8-. | %20
    d8-. b8-. gis16-. fis16( e16 d16) cis16-. b16( cis16 d16) e8 e,8 | %21
    a8 a'8\P g8 e8 fis8. e16 d16-. cis16( b16 ais16) | %22
    b4 r8 b'8-. gis8-. cis8-. r8 d8~ | %23
    d16 cis16( b16 a16) gis16-. fis16( eis16 dis16) cis8 cis'8~ cis16 b16( ais16 gis16) | %24
    ais4 r8 fis8 d'4~ d16 cis16( b16 a16) | %25
    gis4 r8 e8 cis'4~ cis16 b16( a16 gis16) | %26
    fis4~ fis16 e16( d16 cis16) b4 cis4 | %27
    fis,8 fis'8~ fis16 e16( d16 cis16) b8 cis8 d16( e16) fis16( e16) | %28
    dis16-. cis16( bis16 cis16) dis16-. cis16( bis16 cis16) dis16-. fis16( eis16 dis16) cis16-. b16( a16 gis16) | %29
    a8 b8 cis8 cis,8 d4 r8 b'8 | %30
    ais8 fis'8~ fis16 e16( d16 cis16) b4 r8 d8 | %31
    cis8 eis8 fis8 a8 cis8 b8 cis8 cis,8 | %32
    fis8\F gis8 a8 fis8 cis'4~ cis16 b16( a16 gis16) | %33
    fis4 r8 b8-. gis8-. e8-. a16-. gis16( fis16 e16) | %34
    d4 r8 gis8-. e8-. cis8-. fis16-. e16( d16 cis16) | %35
    b4 r8 e8-. cis8-. a8-. d16-. cis16( b16 a16) | %36
    gis4 r8 gis'8-. b8-. gis8-. eis16-. dis16( cis16 b16) | %37
    a16( gis16) a16( b16) cis8 cis,8 fis8 fis'8 e8 d8 | %38
    cis8\P b8 cis8 d8 e4~ e16 d16( cis16 b16) | %39
    a8 b8 cis8 a8 e8 e'8 d8 cis8 | %40
    d8 cis8 d8 e8 fis4~ fis16 e16( d16 cis16) | %41
    b8 cis8 d8 b8 fis'4~ fis16 e16( d16 cis16) | %42
    b4 r4 a4 r4 | %43
    g4 r4 fis8 fis'8~ fis16 e16( d16 cis16) | %44
    b8 r8 e8 r8 a,8 r8 d16 c16( b16 a16) | %45
    g8 r8 c8 r8 d8 r8 g16-. fis16( e16 d16) | %46
    cis8 r8 fis8 r8 b16-. a16( g16 fis16) e16-. d16( cis16 b16) | %47
    ais4~ ais16 fis16( gis16 ais16) b16( cis16) d16( e16) fis8 fis,8 | %48
    b8\F cis8 d8 b8 fis'8 gis8 ais8 fis8 | %49
    b4 r8 e8-. cis8-. a8-. d16-. cis16( b16 a16) | %50
    g4 r8 cis,8-. e8-. cis8-. ais16-. gis16( fis16 e16) | %51
    d8 d'16 e16 fis8 fis,8 b8\P cis8 d8 b8 | %52
    e8 d'8~ d16 cis16( b16 a16) gis8 e'8~ e16 d16( cis16 b16) | %53
    a8 gis8 a8 fis8 gis4~ gis16 fis16( e16 dis16) | %54
    cis8 dis8 e8 cis8 gis'4~ gis16 fis16( e16 dis16) | %55
    cis4 r4 b4 r4 | %56
    a4 r4 gis8 gis'8~ gis16 fis16( e16 dis16) | %57
    cis8 r8 fis8 r8 b,8 r8 e16-. d16( cis16 b16) | %58
    a8 r8 d8 r8 e8 r8 a16-. gis16( fis16 e16) | %59
    dis8 r8 gis8 r8 cis16-. b16( a16 gis16) fis16-. e16( dis16 cis16) | %60
    dis16-. cis16( bis16 ais16) gis8 bis8 cis8 fis8 gis8 gis,8 | %61
    a16-. a'16( gis16 fis16) eis8 cis8 fis8 gis8 a8 fis8 | %62
    gis8 fis8 gis8 gis,8 cis,4 r4 | %63
    fis'8\F gis8 a8 fis8 cis'4~ cis16 b16( a16 gis16) | %64
    fis4 r8 b8-. gis8-. e8-. a16-. gis16( fis16 e16) | %65
    d4 r8 gis8-. e8-. cis8-. fis16-. e16( d16 cis16) | %66
    b4 r8 e8-. cis8-. a8-. d16-. cis16( b16 a16) | %67
    gis4 r8 gis'8-. b8-. gis8-. eis16-. dis16( cis16 b16) | %68
    a16( gis16) a16( b16) cis8 cis,8 fis'4\P~ fis16 e16( d16 cis16) | %69
    b4 cis4 fis,8 fis'8~ fis16 e16( d16 cis16) | %70
    b4~ b16 a16( gis16 fis16) gis8 eis'8 fis8 fis,8 | %71
    cis'8 b'8~ b16 a16( gis16 fis16) eis4 r8 cis8 | %72
    a'4~ a16 gis16( fis16 e16) dis4 r8 b8 | %73
    gis'4~ gis16 fis16( e16 d16) cis16-. b16( a16 gis16) fis8 fis'8 | %74
    gis8 fis16 e16 fis8 gis8 a4~ a16 gis16( fis16 e16) | %75
    d8 e8 fis4~ fis16 e16( dis16 e16) fis16-. e16( dis16 e16) | %76
    fis16-. a16( gis16 fis16) e16\Pd d16( cis16 b16) cis8 d8 e8 e,8 | %77
    a8\F b8 cis8 a8 e'4~ e16 d16( cis16 b16) | %78
    a4 r8 d'8-. b8-. gis8-. cis16-. b16( a16 gis16) | %79
    fis4 r8 b8-. gis8-. e8-. a16-. gis16( fis16 e16) | %80
    d4 r8 gis8-. e8-. cis8-. fis16-. e16( dis16 cis16) | %81
    b4 r8 b'8-. d8-. b8-. gis16-. fis16( e16 d16) | %82
    cis16( b16) cis16( d16) e8 e,8 a8 a'8\P g8 e8 | %83
    fis8. e16 d16 cis16( b16 ais16) b4 r8 b'8 | %84
    gis8 cis8 b8 d8 cis16-. b16( a16 gis16) b16-. a16( gis16 fis16) | %85
    eis8 cis'8~ cis16 b16( ais16 gis16) ais4 r8 fis8 | %86
    d'4~ d16 cis16( b16 a16) gis4 r8 e8 | %87
    cis'4~ cis16 b16( a16 gis16) fis4~ fis16 e16( d16 cis16) | %88
    b4 cis4 fis,8 fis'8~ fis16 e16( d16 cis16) | %89
    b8 cis8 d16( e16) fis16( e16) dis16 cis16( bis16 cis16) dis16-. cis16( bis16 cis16) | %90
    dis16-. fis16( eis16 dis16) cis16-. b16( a16 gis16) a8 b8 cis8 cis,8 | %91
    d4 r8 b'8 ais8 fis'8~ fis16 e16( d16 cis16) | %92
    b4 r8 d8 cis8 eis8 fis8 a8 | %93
    cis8 b8 cis8 cis,8 fis8\F gis8 a8 fis8 | %94
    cis'4~ cis16 b16( a16 gis16) fis4 r8 b8-. | %95
    gis8-. e8-. a16-. gis16( fis16 e16) d4 r8 gis8-. | %96
    e8-. cis8-. fis16-. e16( d16 cis16) b4 r8 e8-. | %97
    cis8-. a8-. d16-. cis16( b16 a16) gis4 r8 gis'8-. | %98
    b8-. gis8-. eis16-. dis16( cis16 b16) a16( gis16) a16( b16) cis8 cis,8 | %99
    fis4 r4 r2 | %100
    \barNumberCheck # 101
}
>>

mvtIIIfigs = <<
\mvtIIItimeline
\figuremode {
    s4 <6> <_+>2 |
    s <6 5> |
    <7>4. <5>8 <6 5>2 |
    <7> <6 5> |
    <7 _+>4. <7 _+>8 <6 4\+ 2>4 <6 5> |
    <9\\ 7>8 <6> <6 4> <5 _+> s2 |
    s4 <6> <_+> <\FBnull>8 \once \bassFigureExtendersOn <\FBnull>16 s |
    s2 <6 5>4 <7 _+> |
    s2. <4\+>8 <7 4 2> |
    <6\\> <6 5> <4> <3> <5 _+>4 s8 <7 4 2> |
    <6 5>4. <7 _+>8 <6>4 <4\+ 2>8 <7 4 2> |
    <6>4. <7 _+>8 <6>4 <4 2>8 <7 4 2> |
    <6>4 s <6>8 <5 2> <6> <6 5> |
    s2 <7 5>4 <7> |
    <6\\>8 <7! 5> <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6 5>8 <6\\> <6> s <7 5> |
    \barNumberCheck # 16
    <6>8 <6 5> <4> <3> s4 <6> |
    s1 |
    <6 5>2 <7> |
    <6 5> <7>4. <5>8 |
    <6 5>2 <7 _+>4. <7 _+>8 |
    <4 2>8 <\FBx> <6 5>8 s s <6> <4> <3> |
    s4 <6>8 <6 5 _!> <_+>4 <6>8 <5 2> |
    s2 <6\\ 5>8 <_+> s <6> |
    <6 4 2\+> <5 2> <6\\> <6 5> <7 _+> s <\FBnull>8. \once \bassFigureExtendersOn 16 % <\FBnull>16 |
    <6 5>4. <7 _+>8 <6>4 <4 2>8 <5 2> |
    <6 5>4. <7>8 <6>4 <4 2>8 <5 2> |
    s2 <6 5>4 <7 _+> |
    s2 <7 5>8 <_+> <7>4 |
    <6\\ 5> <6\\ 5>8 <6 4\+ 2> <6\\> <6> <_+>4 |
    <6>8 <6 5> <4> <_+> s4. <6!>8 |
    \barNumberCheck # 31
    <7!>8 <_+> <7 _+>4 s s8 <6\\> |
    <_+> <6 5> s <6> <6 4>4 <5 _+> |
    s4 <6> <_+> <\FBnull>16 \once \bassFigureExtendersOn 16 s8 |
    s2 <6 5>8 <7> s4 |
    <7>4. <5>8 <6 5>2 |
    <7> <6 5> |
    <7 _+>4. <7 _+>8 <6 4\+ 2>4 <6 5> |
    <9\\ 7>8 <6> <5 4> <_+> s <\FBnull>4 \once \bassFigureExtendersOn 8 |
    <6> <\FBnull> \once \bassFigureExtendersOn 8 <6> s2 |
    s4 <6> s <4 2>8 <6\\> |
    <6> <\FBnull> \once \bassFigureExtendersOn 8 <6 5 _!> <_+>2 |
    s4 <6> <_+>2 |
    s <4\+ 2> 2 |
    <6> <7 _+>4 <\FBnull>16 \once \bassFigureExtendersOn 16 s8 |
    s4 <7> <7! 4>8 <_!> <7!>4 |
    \barNumberCheck # 46
    <5 3>4 <6 5!> <7!> <7> |
    <7 5!> <7 _+> s <_!> |
    <6 5> <\FBnull>8 \once \bassFigureExtendersOn 16 s <9>8 <6> <6 4> <5 _+> |
    s4 <6> <_+> <6> |
    s4. <_!>8 <6 5!>2 |
    <7>4. <7 _+>8 <6 4\+ 2>4 <6 5> |
    <9\\ 7>8 <8 6> <6 4> <5 _+> s4 <6> |
    <7> <4 2> <6 5> <7> |
    <7> <6>8 <6\\ 5> <_+>4 <\FBnull>8 \once \bassFigureExtendersOn 16 s |
    s4 <6> <_+> <\FBnull>16 \once \bassFigureExtendersOn 16 s8 |
    s2 <4\+ 2> |
    <6> <7 _+>4 <\FBnull>8. \once \bassFigureExtendersOn 16 |
    s4 <7> <7> <7> |
    s <6 5> <7> s |
    <7> <7 _+> s <5 3> |
    \barNumberCheck # 61
    <6\\ 5>4 <7 _+>8 <6 5> s <7 5> <_+>4 |
    <5>8 <7 4 2\+> <6> <7 _+> s <7 5!> <6 4\+ 2\+> <7 5> |
    <6 4>4 <5\+ _+> <_+> s |
    s <6> <_+> s |
    s2 <6 5> |
    <7>4. <5>8 <6 5>2 |
    <7>4 <6> <6 5> s |
    <7 _+>4. <\FBx>8 <4\+ 2>4 <6 5> |
    <9\\ 7>8 <6> <6 4> <5 _+> s2 |
    <6 5>4 <_+> s2 |
    <7>4 s16 <6>8. <6\\>8 <6 5> s4 |
    <_+>8 <4\+ 2> s4 <6 5>4. <_+>8 |
    <6>4 <4\+ 2> <6 5>4. <7 _+>8 |
    <6>4 <4 2> <6> <7>8 <6\\> |
    <6 5>4 <6>8 <6 5> s2 |
    \barNumberCheck # 76
    <7 5>4 <7> <6\\ 5!> s |
    <6\\ 4 3> s <6>8 <7 5> <4> <3> |
    s4 <6> s2 |
    s <6 5> |
    <7> <6 5> |
    <7>4. <5>8 <6 5>2 |
    <7 _+>4. <7 _+>8 <6 4 2>4 <6 5> |
    <9\\ 7>8 <8 6> <4> <3> s4 <6>8 <6 5 _!> |
    <_+>4 <6>8 <5 2> s2 |
    <6\\>8 <_+> <6 5> <6> <_+>4 <5 2> |
    <6 5>8 <7 _+> s4 <6 5>4. <7 _+>8 |
    <6>4 <4 2> <6 5>4. <7>8 |
    <6>4 <4 2> s2 |
    <6 5>4 <7 _+> s2 |
    <7 5>8 <_+> <7>4 <6\\ 5> <\FBx> |
    \barNumberCheck # 91
    <6\\ 4 3>4 <_+> <6>8 <6 5> <4> <_+> |
    <7> <6> s <6!> <7!> <_+> <\FBnull>8 \once \bassFigureExtendersOn 16 s |
    s4. <6\\>8 <_+> <6 5> s <6> |
    <6 4>4 <5 _+> s <6> |
    <_+> <\FBnull>8 \once \bassFigureExtendersOn 16 s s2 |
    <6 5> <7>4. <5>8 |
    <6 5>2 <7> |
    <6 5> <7 _+>4. <\FBx>8 |
    <4\+ 2>4 <6> <9\\ 7>8 <8 6> <4> <_+> |
    s1 |
    \barNumberCheck # 101
}
>>
