\version "2.21.0"

\header {
    title = \markup{ "Missa A-Dur" }
    subtitle = \markup{ Kyrie e Gloria }
    opus = "BWV 234"
    composer = "J.S. Bach"
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2020 Creative Commons Attribution ShareAlike 4.0}}
}

\layout {
}


mvtIpiece = \markup{I. Coro: Kyrie}
mvtIIpiece = \markup{II. Coro: Gloria}
mvtIIIpiece = \markup{III. Aria \medium(Basso): Domine Deus}
mvtIVpiece = \markup{IV. Aria \medium(Soprano): Qui tollis peccata mundi}
mvtVpiece = \markup{V. Aria \medium(Alto): Quoniam tu solus}
mvtVIpiece = \markup{VI. Coro: Cum Sancto Spiritu}
