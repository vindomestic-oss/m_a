\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"

mvtIVtimeline = {
    \time 3/4
    \key d \major

    s2.*113 |
    \bar "|."
    \barNumberCheck # 114
}


mvtIVbreaks = <<
\mvtIVtimeline
{
    <>^"Breaks left in"
    \repeat unfold 5 { s2.\noBreak } \pageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \pageBreak
    \barNumberCheck # 26
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \pageBreak
    \barNumberCheck # 46
    \repeat unfold 6 { s2.\noBreak } \break\noPageBreak
    \grace s8 \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak } \pageBreak
    \barNumberCheck # 69
    \repeat unfold 6 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \pageBreak
    \barNumberCheck # 92
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak } \break\noPageBreak
    \repeat unfold 7 { s2.\noBreak } \pageBreak
    \barNumberCheck # 114
}
>>


mvtIVflI = <<
\mvtIVtimeline
\relative c''' {
    r8 d8( cis8 b8 ais8 b8) | %1
    e2.~ | %2
    e8 d8( cis8 b8 ais8 b8) | %3
    g2.~ | %4
    g8 fis8( e8 d8 cis8 e8) | %5
    \barNumberCheck # 6
    d8[ fis16( e16 fis8) a8 c8( b8]) | %6
    r8 e,16[( d16 e8) g8 b8( a8]) | %7
    r8 d,16[( cis16 d8) fis8 a8( g8]) | %8
    r8 c,16[( b16 c8) e8 g8( fis8]) | %9
    b8( ais8) d8( cis8) e8( g,8) | %10
    g4. fis16 e16 fis8 b16( ais16) | %11
    b16( cis16 ais16 b16) d,4 cis8 b8 | %12
    b8 \once \slurDashed d'8( cis8 b8 ais8 b8) | %13
    e2.~ | %14
    e8 d8( cis8 b8 ais8 b8) | %15
    g2.~ | %16
    g8 \once \slurDashed fis8( e8 d8 cis8) e8~ | %17
    e8 d8( cis8 b8 ais8 b8) | %18
    e2.~ | %19
    e8 d8( cis8 b8 ais8 b8) | %20
    c8[ b8( a?8 g8 fis8 g16 a16]) | %21
    g4 r4 r4 | %22
    r8 g'8( fis8 e8 dis8 e8) | %23
    b'2.~ | %24
    b8[ b8( a8 g8 fis8 g16 a16]) | %25
    \barNumberCheck # 26
    dis,2.\trill | %26
    e8 g16 fis16 g2~ | %27
    g8 fis16 e16 fis2~ | %28
    fis8 e16 dis16 e2~ | %29
    e8[ a16( gis16 a8) f8 e8( dis8]) | %30
    g8( fis8) b8( a8) e'8( a,8) | %31
    a2~ a8 g16 fis16 | %32
    g8 fis16 e16 \appoggiatura e8 dis4.-\parenthesize\trill e8 | %33
    e8 g8( fis8 e8 dis8 e8) | %34
    a2.~ | %35
    a8 g8( fis8 e8 dis8 e8) | %36
    c'2.~ | %37
    c8[ \once \slurDashed b8( a8 g8 fis8 g16 a16]) | %38
    g4 r4 r4 | %39
    r8 c,8( b8 a8 gis8 a8) | %40
    d2.~ | %41
    d8[ f8( e8 d8 c8 d16 b16]) | %42
    c4 r4 r4 | %43
    r8 d8( c8 b8 ais8 b8) | %44
    e2.~ | %45
    \barNumberCheck # 46
    e8[ g8( fis8 e8 d8 e16 cis16]) | %46
    d4 r4 r4 | %47
    r8 e8( d8 cis8 bis8 cis8) | %48
    bis2.\trill | %49
    cis8[ d'8( cis8 b8 a8 b16 gis16)] | %50
    a8[ cis16( b16 cis8) e8 g,8( fis8)] | %51
    \barNumberCheck # 52
    r8 b16( a16 b8) d8 fis,8( e8) | %52
    r8 a16( gis16 a8) cis8 e,8( d8) | %53
    r8 g16( fis16 g8) b8 \once \slurDashed d,8( cis8) | %54
    fis8( eis8) a8( gis8) b8( d8) | %55
    d4. cis16 b16 cis4~ | %56
    \barNumberCheck # 57
    cis8 b16 a16 b8 d8 cis8 b8 | %57
    a4 r4 r4 | %58
    r8 a,8( gis8 fis8 eis8 gis8) | %59
    cis2.~ | %60
    cis8[ \once \slurDashed cis8( b8 a8 gis8 a16 b16)] | %61
    eis,2.\trill | %62
    \barNumberCheck # 63
    fis4 c'2~ | %63
    c4 b4 a4~ | %64
    a8 c8( b8 a8) e'8( dis8) | %65
    e4. dis8( e8 dis8) | %66
    e8 b8 g'2~ | %67
    g8 fis8( e8 d8 cis8 d8) | %68
    e2 a4~ | %69
    a8 \once \slurDashed b8( a8 g8 fis8 e8) | %70
    f16( e16 d8) b'2\trill | %71
    cis4. b8 cis8 d8 | %72
    d,8( cis8) d8( cis8) d8( cis8) | %73
    d4 e8 f8 g4~ | %74
    g8 bes8 a8 g8 f8 e8 | %75
    f8 a8 g8 f8 e8 d8 | %76
    e4 r4 cis'4 | %77
    d4 d,8 cis8 d4~ | %78
    d8 e,8 f8 e8 f4~ | %79
    f8 a'8 cis,4. d8 | %80
    d4 r4 r4 | %81
    r8 d'8( cis8 b8 ais8 b8) | %82
    e2.~ | %83
    e8 \once \slurDashed d8( cis8 b8 ais8 b8) | %84
    g2.~ | %85
    g8[ fis8( e8 d8 cis8 d16 e16]) | %86
    d8 d'8( cis8 b8 ais8 b8) | %87
    e,2.~ | %88
    e8 d'8( cis8 b8 ais8 b8) | %89
    g2.~ | %90
    g8[ \once \slurDashed fis8( e8 d8 cis8 d16 e16]) | %91
    d4 r4 r4 | %92
    r8 d8( cis8 b8 ais8 cis8) | %93
    fis2.~ | %94
    fis8[ \once \slurDashed g8( fis8 e8 dis8 e16 fis16]) | %95
    e8 \once \slurDashed g,8( fis8 e8 dis8 e8) | %96
    ais2. | %97
    b8 d8( cis8 b8 ais8 b8) | %98
    fis'2.~ | %99
    fis8[ \once \slurDashed fis16( e16] fis8) a8 c8( b8) | %100
    r8 e,16[( d16 e8) g8 b8( a8]) | %101
    r8 d,16[( cis16 d8) fis8 \once \slurDashed a8( g8]) | %102
    r8 c,16[( b16 c8) e8 g8( fis8]) | %103
    b8( ais8) d8( cis8) e8( g,8) | %104
    g4. fis16 e16 fis4~ | %105
    fis8 e16 d16 e8 g8 fis8 e8 | %106
    d8 d'8( cis8 b8 ais8 b8) | %107
    e2.~ | %108
    e8 \once \slurDashed d8( cis8 b8 ais8 b8) | %109
    g2.~ | %110
    g8[ fis8( e8 d8 cis8 d16 e16]) | %111
    d8 cis'8 ais4. b8 | %112
    \onceCenterNoteColumn #0 b2.-\fermata | %113
}
>>


mvtIVflII = <<
\mvtIVtimeline
\relative c''' {
    R2. | %1
    r8 d8( cis8 b8 ais8 cis8) | %2
    fis,2.~ | %3
    fis8 fis8( e8 d8 cis8 e8) | %4
    ais,2.\trill | %5
    b8 d16 cis16 d2~ | %6
    d8 cis16 b16 cis2~ | %7
    cis8 b16 ais16 b2~ | %8
    b8[ e16( dis16 e8) c8 b8( ais8]) | %9
    g'8( fis8) b8( ais8) \once \slurDashed b8( e,8) | %10
    e2~ e8 d16 cis16 | %11
    d8 cis16 b16 ais4. b8 | %12
    b4 r4 r4 | %13
    r8 \once \slurDashed d'8( cis8 b8 ais8 cis8) | %14
    fis,2.~ | %15
    fis8 \once \slurDashed fis8( e8 d8 cis8 e8) | %16
    ais,2. | %17
    b4 r4 r4 | %18
    r8 d8( cis8 b8 ais8 cis8) | %19
    fis,2.~ | %20
    fis8[ \once \slurDashed g8( fis8 e8 dis8 e16 fis16]) | %21
    e8 g'8( fis8 e8 dis8 e8) | %22
    a2.~ | %23
    a8 \once \slurDashed g8( fis8 e8 dis8 e8) | %24
    c'2.~ | %25
    c8[ \slurDashed b8( a8 g8 fis8 g16 a16)] | %26
    g8[ b16( a16 b8) d8 f,8( e8)] \undo \slurDashed | %27
    r8 a16[( g16 a8) c8 e,8( d8]) | %28
    r8 \once \slurDashed g16[( fis16 g8) b8 d,8( c8]) | %29
    r8 \once \slurDashed f16[( e16 f8) a8 \once \slurDashed c,8( b8)] | %30
    e8( dis8) g8( fis8) a8( c,8) | %31
    c4. b16 a16 b4~ | %32
    b8 a16 g16 a8[ c8 b8 a8] | %33
    g4 r4 r4 | %34
    r8 g'8( fis8 e8 dis8 e8) | %35
    b'2.~ | %36
    b8[ \once \slurDashed b8( a8 g8 fis8 g16 a16]) | %37
    dis,2. | %38
    e4 r4 r4 | %39
    R2. | %40
    r8 c8( b8 a8 gis8 a8) | %41
    b2.~ | %42
    b8[ \once \slurDashed f'8( e8 d8 c8 d16 b16)] | %43
    c4 r4 r4 | %44
    r8 d8( cis8 b8 ais8 b8) | %45
    cis2.~ | %46
    cis8[ \once \slurDashed g'8( fis8 e8 d8 e16 cis16)] | %47
    b4 r4 r4 | %48
    r8 gis'8( fis8 e8 dis8 e8) | %49
    cis4. dis8 eis4 | %50
    fis8 a16 gis16 a2~ | %51
    a8 gis16 fis16 gis2~ | %52
    gis8 fis16 eis16 fis2~ | %53
    fis8[ \slurDashed b16( ais16 b8) g8 fis8( eis8)] | %54
    a8( gis8) cis8( b8) fis8( b8) \undo \slurDashed | %55
    b2~ b8 a16 gis16 | %56
    a8 gis16 fis16 eis4. fis8 | %57
    fis8 a,8( gis8 fis8 eis8 fis8) | %58
    b2.~ | %59
    b8 a8( gis8 fis8 eis8 fis8) | %60
    d'2.~ | %61
    d8[ \once \slurDashed cis8( b8 a8 gis8 a16 b16)] | %62
    a4 a2~ | %63
    a8 \slurDashed g8( fis8 e8 dis8 e8) | %64
    fis2 b4~ | %65
    b8 a8( g8 fis8 e8 fis8) | %66
    g4 bes2~ | %67
    bes4 a4 g4~ | %68
    g8 bes8( a8 g8) d'8( cis8) | %69
    d4. \once \undo \slurDashed cis8( d8 cis8) | %70
    d4 e2~ | %71
    e8 f8( e8 d8 e8 f8) | %72
    b,2 bes4~ | %73
    bes8 a8 g8 a8 bes4~ | %74
    bes8 g8 e4 cis'4\trill | %75
    d2.~ | %76
    d4 c8 bes8 a8 g8 | %77
    f2 r4 | %78
    b2 r4 | %79
    r4 a4 g4 | %80
    fis4 r4 r4 | %81
    R2. | %82
    r8 d''8( cis8 b8 ais8 cis8) | %83
    fis,2.~ | %84
    fis8[ fis8( e8 d8 cis8 d16 e16]) | %85
    ais,2. | %86
    b4 r4 r4 | %87
    r8 d'8( cis8 b8 ais8 cis8) | %88
    fis,2.~ | %89
    fis8[ fis8( e8 d8 cis8 d16 e16]) | %90
    ais,2. | %91
    b8 d8( cis8 b8 ais8 b8) | %92
    e2.~ | %93
    e8 \slurDashed d8( cis8 b8 ais8 b8) | %94
    c8[ b8( a8 g8 fis8 g16 a16)] | %95
    g4 r4 r4 | %96
    r8 fis'8( e8 d8 cis8 d8) | %97
    d2. | %98
    cis2. | %99
    b8 d16 cis16 d2~ | %100
    d8 cis16 b16 cis2~ | %101
    cis8 b16 ais16 b2~ | %102
    b8[ e16( dis16 e8) c8 b8( ais8)] | %103
    \undo \slurDashed d8( cis8) fis8( e8) b'8( e,8) | %104
    e2~ e8 d16 cis16 | %105
    d8 cis16 b16 ais4. b8 | %106
    b4 r4 r4 | %107
    r8 \once \slurDashed d'8( cis8 b8 ais8 cis8) | %108
    fis,2.~ | %109
    fis8[ \once \slurDashed fis8( e8 d8 cis8 d16 e16)] | %110
    ais,2. | %111
    b8 g'8 cis,4. b8 | %112
    \onceCenterNoteColumn #0 b2.-\fermata | %113
}
>>


mvtIVsoprano = <<
\mvtIVtimeline
\relative c'' {
    \autoBeamOff
    R2.*12 | %1
    r8 fis8 e8[ d8] cis8 b8 | %13
    b4 ais4 r4 | %14
    r8 b8 ais8[ b8] fis8 d'8 | %15
    d8([ b8)] cis8 d8 e8 e8 | %16
    e8([ cis8)] fis,4 r4 | %17
    r4 fis4~ fis8 d'32([ cis32 b16)] | %18
    b8([ ais8)] ais4 r4 | %19
    r4 fis'32([ e32 d8.)] cis8\trill[ b8] | %20
    a8.([ b32 c32)] c4 c4~ | %21
    c8 b8 a8([ g8)] fis8([ e8)] | %22
    e8([ dis8)] dis4 r4 | %23
    r8 e'8 dis8[ e8] b8 g'8 | %24
    g32([ fis32 e8.)] fis8 dis8 e16([ dis16)] e8 | %25
    g,4\trill fis4 r4 | %26
    r4 g4. b16[ a16] | %27
    b8([ a8)] a4 c8 b8 | %28
    dis8([ e8)] e,4 r4 | %29
    f4 a4 c4~ | %30
    \melisma c4 b8[ dis8 e8 fis8] | %31
    dis8[ fis16 e16] fis4. e16[ dis16] | %32
    e8 \melismaEnd a8 fis2\trill | %33
    e4 r4 r4 | %34
    R2.*4 | %35
    r8 b8 c8[ b8] a8 g8 | %39
    f'2 f4 | %40
    r8 e8 d8[ c8] b8([ c16 d16)] | %41
    e,2 e4 | %42
    r8 d'8 c8[( b8]) c8 a8 | %43
    g'2 g4 | %44
    r8 fis8 e8[ d8] cis8([ d16 e16)] | %45
    fis,2 fis4 | %46
    r8 e'8 d8[ cis8] b8 ais8 | %47
    b4 fis8 gis8 a4~ | %48
    \melisma a8[ e'8] dis4 \melismaEnd fis,4 | %49
    fis4\trill eis4 r4 | %50
    r4 cis'4. fis16([ d16)] | %51
    \appoggiatura cis8 b4 b4. e16[ cis16] | %52
    \appoggiatura b8 a4. fis8 cis'8 d16([ e16)] | %53
    d8[ cis8] b4 r4 | %54
    r4 fis'8([ d8)] b8[ gis8] | %55
    eis8 gis16[ fis16] gis4.( fis16[ eis16] | %56
    fis8) b8 gis2 | %57
    fis4 r4 r4 | %58
    R2.*4 | %59
    r4 fis4. e'8 | %63
    dis4 dis8 e8 fis4~ | %64
    fis8 a,8 a4 g8[ fis8] | %65
    g8[ fis8] e4 r4 | %66
    r4 e4. d'8 | %67
    cis4 cis8 d8 e4~ | %68
    e8 g,8 g4 fis8([ e8)] | %69
    fis8[ g8] a4 r4 | %70
    r8 f'8([ e8)] d8 cis8([ d8)] | %71
    bes8 a8 g8[ f8] e8[ d8] | %72
    gis2 \melisma g4~ | %73
    g8[ f8 e8 d8] \melismaEnd cis8[ d8] | %74
    d'4 cis4 r4 | %75
    r4 e4. g16 f16 | %76
    g8 bes,8 a8([ g'8)] f8([ e8)] | %77
    d8[ c8 bes8 a8] g8[ f8] | %78
    e8 cis'8 d4. c16([ bes16)] | %79
    a8 d,8 f4( e8[ d8)] | %80
    d4 r4 r4 | %81
    R2.*5 | %82
    r8 fis'8 e8[ d8 cis8 b8~] | %87
    b8[ gis8] ais4 r4 | %88
    r8 b8 ais8([ b8)] fis8 d'8 | %89
    d8([ b8)] cis8 d8 e8 e8 | %90
    e8([ cis8)] fis,4 r4 | %91
    r4 fis4~ fis8 d'32([ cis32 b16)] | %92
    b8([ ais8)] ais4 r4 | %93
    r4 fis'32([ e32 d8.)] cis8[ b8] | %94
    a8.([ b32 c32)] c4 c4~ | %95
    c8 b8 dis8[ e8] g,4 | %96
    g8([ fis8)] fis4 fis'4 | %97
    fis8[ \melisma b,8] e2~ | %98
    e8[ g8] \melismaEnd fis8 e8 d8 cis8 | %99
    d8([ cis8)] b4 r4 | %100
    r4 cis8([ e8)] g8([ fis8)] | %101
    ais,8[ b8] b4 r4 | %102
    g4( c4) e4 | %103
    g8[ \melisma fis16 e16] d8 e4 cis8 | %104
    ais8[ cis16 b16] cis4. b16[ ais16] | %105
    b8 \melismaEnd e8 cis4.\trill( b8) | %106
    b4 r4 r4 | %107
    R2.*5 |
    R2.\fermata |
}
>>


mvtIVlyrics = \lyricmode {
    Qui tol -- lis pec -- ca -- ta,
    qui tol -- lis pec -- ca -- ta, pec -- ca -- ta mun -- di,
    mi -- se -- re -- re, mi -- se -- re -- re,
    mi -- se -- re -- re no -- bis,
    qui tol -- lis pec -- ca -- ta, pec -- ca -- ta mun -- di,
    mi -- se -- re -- re, mi -- se -- re -- re,
    mi -- se -- re -- re no -- bis.
    Qui tol -- lis pec -- ca -- ta, pec -- ca -- ta __ mun -- di,
    qui tol -- lis pec -- ca -- ta, pec -- ca -- ta __ mun -- di,
    qui tol -- lis pec -- ca -- ta, pec -- ca -- ta mun -- di,
    sus -- ci -- pe de -- pre -- ca -- ti -- o -- nem no -- stram,
    de -- pre -- ca -- ti -- o -- nem no -- stram,
    sus -- ci -- pe de -- pre -- ca -- ti -- o -- nem no -- stram,
    sus -- ci -- pe de -- pre -- ca -- ti -- o -- nem no -- stram,
    sus -- ci -- pe de -- pre -- ca -- ti -- o -- nem no -- stram,
    sus -- ci -- pe de -- pre -- ca -- ti -- o -- nem,
    de -- pre -- ca -- ti -- o -- nem no -- stram.
    Qui se -- des, qui se -- des ad dex -- tram, ad dex -- tram Pa -- tris,
    mi -- se -- re -- re, mi -- se -- re -- re,
    mi -- se -- re -- re no -- bis,
    qui se -- des ad dex -- tram Pa -- tris,
    mi -- se -- re -- re, mi -- se -- re -- re no -- bis.
}


mvtIVvl = <<
\mvtIVtimeline
\relative c' {
    b4-. b4-. b4-. | %1
    cis4 cis4 cis4 | %2
    d4 d4 d4 | %3
    e4 e4 e4 | %4
    fis4 fis4 fis4 | %5
    b,4 r8 fis'16( e16 fis8) g8 | %6
    a,4 r8 e'16( d16 e8) fis8 | %7
    g,4 r8 d'16( cis16 dis8) e8 | %8
    e,4 r4 r4 | %9
    r4 r8 g'16( fis16 g8) e8 | %10
    ais8 cis16 b16 ais8 fis8 d8 fis8 | %11
    g,8 e'8 fis8 e8 fis8 fis,8 | %12
    b4 b4 b4 | %13
    cis4 cis4 cis4 | %14
    d4 d4 d4 | %15
    e4 e4 e4 | %16
    fis4 fis4 fis4 | %17
    b,4 b4 b4 | %18
    cis4 cis4 cis4 | %19
    d4 d4 d4 | %20
    dis4 dis4 dis4 | %21
    e4 e4 e4 | %22
    fis4 fis4 fis4 | %23
    g4 g4 g4 | %24
    a4 a4 a4 | %25
    b4 b4 b4 | %26
    e,4 r8 b16[( a16 b8) c8] | %27
    d4 r8 a16[ g16 a8 b8] | %28
    c4 r8 g16[ fis16 gis8 a8] | %29
    a4 r4 r4 | %30
    r4 r8 c16[ b16 c8 a8] | %31
    b8[ dis'16 cis16 dis8 b8 g8 b8] | %32
    c,8 a'8 b8 a8 b8 b,8 | %33
    e4 e4 e4 | %34
    fis4 fis4 fis4 | %35
    g4 g4 g4 | %36
    a4 a4 a4 | %37
    b4 b4 b4 | %38
    e,4 e4 e4 | %39
    d4 d4 d4 | %40
    b4 b4 b4 | %41
    gis4 gis4 gis4 | %42
    a4 a4 a4 | %43
    e'4 e4 e4 | %44
    cis4 cis4 cis4 | %45
    ais4 ais4 ais4 | %46
    b4 b4 b4 | %47
    d4 d4 d4 | %48
    gis,4 gis4 gis4 | %49
    cis4 cis4 cis4 | %50
    fis4 r8 \once \slurDashed cis16([ b16 cis8) d8] | %51
    e4 r8 \once \slurDashed b16[( a16 b8) cis8] | %52
    d4 r8 a16[( gis16 ais8) b8] | %53
    b4 r4 r4 | %54
    r4 r8 \once \slurDashed d16([ cis16 d8) b8] | %55
    gis8[ eis'16 dis16 eis8 cis8 a8 fis'8] | %56
    d8 b'8 cis8 b8 cis8 cis,8 | %57
    fis4 fis4 fis4 | %58
    gis4 gis4 gis4 | %59
    a4 a4 a4 | %60
    b4 b4 b4 | %61
    cis4 cis4 cis4 | %62
    \barNumberCheck # 63
    fis,8 \once \slurDashed g8( fis8 e8 dis8 fis8) | %63
    b,8 b'8( a8 g8 fis8 a8) | %64
    dis,8 e8( dis8 cis8 b8 dis8) | %65
    e,8 c''8( b8 a8 g8 b8) | %66
    e,8 f8( e8 d8 cis8 e8) | %67
    a,8 a'8( g8 fis8 e8 g8) | %68
    cis,8 d8( cis8 b8 a8 cis8) | %69
    d,8 \once \slurDashed g'8( fis8 e8 d8 fis8) | %70
    gis,4 gis4 gis4 | %71
    g4 g4 g4 | %72
    f4 f4 f4 | %73
    e4 e4 e4 | %74
    a4 a4 a4 | %75
    a4 a4 a4 | %76
    a4 a4 a4 | %77
    bes4 bes4 bes4 | %78
    gis4 gis4 gis4 | %79
    a4 a4 a4 | %80
    d4 r4 r4 | %81
    b4 b4 b4 | %82
    cis4 cis4 cis4 | %83
    d4 d4 d4 | %84
    e4 e4 e4 | %85
    fis4 fis4 fis4 | %86
    b,4 b4 b4 | %87
    cis4 cis4 cis4 | %88
    d4 d4 d4 | %89
    e4 e4 e4 | %90
    fis4 fis4 fis4 | %91
    b,4 b4 b4 | %92
    cis4 cis4 cis4 | %93
    d4 d4 d4 | %94
    dis4 dis4 dis4 | %95
    e4 e4 e4 | %96
    fis4 fis4 fis4 | %97
    gis4 gis4 gis4 | %98
    ais4 ais4 ais4 | %99
    b4 r8 fis16[ e16 fis8 g8] | %100
    a,4 r8 e'16[ d16 e8 fis8] | %101
    g,4 r8 d'16[ cis16 dis8 e8] | %102
    e,4 r4 r4 | %103
    r4 r8 g'16[ fis16 g8 e8] | %104
    cis8 ais'16 gis16 ais8 fis8 d8 fis8 | %105
    g,8 e'8 fis8 e8 fis8 fis,8 | %106
    b4 b4 b4 | %107
    cis4 cis4 cis4 | %108
    d4 d4 d4 | %109
    e4 e4 e4 | %110
    fis4 fis4 fis4 | %111
    g8 e8 fis4 fis,4 | %112
    \onceCenterNoteColumn #0 b2.-\fermata | %113
}
>>


\addQuote mvtIVflI      { \mvtIVflI }
\addQuote mvtIVflII     { \mvtIVflII }
