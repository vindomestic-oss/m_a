\version "2.21.0"

\include "include-once.ily"
\includeOnce "baroque-clefs.ily"

\includeOnce "bach-234-score-common.ily"
