\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"

% \include "last-page-copyright.ily"

\header {
    instrument = "Flauto Traverso 1"
}

\paper {
    ragged-last-bottom = ##f
    page-count = 9      % finalize
}

\layout {
    \context {
        \StaffGroup {
            \revert StaffGroup.SystemStartBracket.collapse-height
        }
    }
    \context {
        \GrandStaff {
            \revert PianoStaff.SystemStartBrace.collapse-height
        }
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtIflI
        \mvtIflCues
    >>

    \header {
        piece = \mvtIpiece
    }
}


cuesII = {
    <>^\markup{Vln.I}
    \cueDuring mvtIIvlnI #UP {
        s1*8 |
    }
    \cueDuring mvtIIvlnI #DOWN {
        s2.
    } <>^\markup\halign #-0.5 {(Fl.)} s4 |
    \barNumberCheck # 10
    s2.*16 |
    \barNumberCheck # 26
    s1*4 |
    <>^\markup{Vln.I}
    \cueDuring mvtIIvlnI #UP {
        s1*6
    }
    s2. <>^\markup\halign #-0.5 {(Fl.)} s4 |
    \barNumberCheck # 37
    s2.*16 |
    s1 |
    \barNumberCheck # 54
    s1*7 |
    <>^\markup{Vln.I}
    \cueDuring mvtIIvlnI #DOWN {
        s1*4 |
    }
    s2. <>^\markup\halign #-0.5 {(Fl.)} s4 |
    \barNumberCheck # 66
    s2.*16 | 
    \barNumberCheck # 82
    s1*8 |
    <>^\markup{Vln.I}
    \cueDuring mvtIIvlnI #UP {
        s1*4 |
    }
    s2. <>^\markup\halign #-0.5 {(Fl.)} s4 |
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \with {
    } \context Bottom <<
        \mvtIIflI
        \cuesII
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}

\markup\Tacet{\mvtIIIpiece}

\markup\null\pageBreak
%{ % BEGIN OF DUPLEX-ONLY SECTION
\markup\wordwrap{\bold{Note:} Movement \mvtIVpiece is spread over three pages.
The page order in this document is adapted to allow double-sided printing with
pages 8 and 9 on a fold-out sheet.}
\markup{\vspace #1.0 }
%} % END OF DUPLEX-ONLY SECTION

\score {
    \new StaffGroup <<
        \new Staff \with {
        } \context Bottom <<
            \mvtIVflI
            % { s8 | s2.*37 | \pageTurn }
        >>
        %{
	\new Staff = mvtIVsoprano \with {
            \RemoveAllEmptyStaves
            \staffSize #-1.5
        } <<
            \new Voice = mvtIVsoprano { \clefSoprano \mvtIVsoprano }
            {
                s2.*12 |
                s8 <>^\markup\normalsize{Soprano}
            }
	    \new Lyrics \with {
		\override LyricText.font-size = #-1.5
	    } {
                \lyricsto mvtIVsoprano \mvtIVlyrics
            }
        >>
        %}
    >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}

%{ % BEGIN OF DUPLEX-ONLY SECTION
\markup\null
\middleBackPage
%} % END OF DUPLEX-ONLY SECTION

\markup\Tacet{\mvtVpiece}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVIflI
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
