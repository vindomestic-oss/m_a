\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"


mvtVItimeline = {
    \key a \major

    \time 4/4
    \tempo \markup\smaller{Grave}
    s1*3 |
    \bar "||"
    \barNumberCheck # 4
    \time 12/8
    \tempo \markup\smaller{Vivace}
    s1.*51 |
    \barNumberCheck # 55
    \bar "|."
}

mvtVIbreaks = <<
\mvtVItimeline
{
    <>^"breaks left in"
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \barNumberCheck # 14
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \barNumberCheck # 26
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \barNumberCheck # 38
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1.\noBreak | } \pageBreak
    \barNumberCheck # 50
    \repeat unfold 2 { s1.\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1.\noBreak | }
    \barNumberCheck # 55
}
>>

mvtVIflI = <<
\mvtVItimeline
\relative c'' {
    \key a \major
    r4 fis4 gis4. a16 b16 | %1
    a4. gis16 fis16 gis4 a4 | %2
    b4. a16 gis16 a8 b16 cis fis,4 | %3
    gis4.~ gis4 r8 r2. | %9
    r2. r8 gis16 fis16 gis16 a16 b16 a16 b16 cis16 a16 b16 | %15
    \barNumberCheck # 6
    gis16 fis16 gis16 a16 gis16 a16 b16 a16 b16 cis16 a16 b16 cis8 d16 cis16 b16 a16 e8 a8 gis8 | %21
    a8 gis16 fis16 e16 d16 cis16 fis16 e16 d16 cis16 b16 a16 e'16 d16 cis16 b16 a16 b16 d16 cis16 b16 a16 gis16 | %27
    a16 e'16 fis16 gis16 a16 b16 a16 gis16 a16 b16 cis16 d16 e8 r8 r8 r4. | %33
    r8 e,,16 fis16 gis16 a16 b16 cis16 d16 e16 fis16 gis16 a16 gis16 b16 a16 gis16 fis16 e16 fis16 e16 d16 cis16 b16 | %39
    a8 r8 r8 r4. r16 e16 fis16 gis16 a16 b16 a16 gis16 a16 b16 cis16 dis16 | %45
    e16 dis16 e16 fis16 gis16 a16 b16 cis16 d16 cis16 d16 e16 cis16 e16 d16 cis16 b16 a16 e'16 d16 cis16 b16 a16 gis16 | %51
    a8 r8 r8 r4. r16 e16 fis16 gis16 a16 b16 cis16 b16 a16 b16 cis16 d16 | %57
    e8 r8 r8 r4. r16 g,16 fis16 e16 d16 cis16 d16 e16 d16 cis16 b16 ais16 | %63
    \barNumberCheck # 14
    b8 r8 r8 r4. r16 fis'16 g16 a16 b16 cis16 d16 b16 cis16 d16 e16 fis16 | %69
    b,16 e16 d16 cis16 b16 a16 b16 cis16 b16 a16 g16 fis16 e8 r8 r8 r4. | %75
    r16 d16 e16 fis16 gis16 a16 b16 gis16 a16 b16 cis16 d16 gis,16 cis16 b16 a16 gis16 fis16 gis16 a16 gis16 fis16 e16 d16 | %81
    cis8 r8 r8 r4. r2. | %87
    \barNumberCheck # 18
    r2. cis16 gis16 a16 b16 cis16 dis16 eis16 dis16 cis16 dis16 eis16 fis16 | %93
    gis16 a16 b16 a16 gis16 fis16 eis16 fis16 gis16 fis16 gis16 eis16 fis16 cis'16 b16 a16 gis16 fis16 eis16 fis16 eis16 dis16 cis16 b16 | %99
    cis8 r8 r8 r4. r2. | %105
    R1. | %111
    gis'16 fis16 eis16 fis16 gis16 a16 b16 a16 gis16 fis16 eis16 dis16 cis8 r8 r8 r4. | %117
    R1. | %123
    \barNumberCheck # 24
    r4. r8 r8 cis'8 cis2.~ | %129
    cis2.~ cis8 cis8 b8 a8 b8 cis8 | %135
    d8 b8 a8 g8 a8 b8 eis,4 d'8 cis4.~ | %141
    cis16 d16 cis16 b16 a16 b16 gis16 fis16 gis16 a16 fis16 gis16 a16 gis16 a16 b16 gis16 a16 b16 a16 b16 cis16 a16 b16 | %147
    cis16 fis16 e16 d16 cis16 b16 cis16 d16 cis16 b16 ais16 gis16 fis16 ais,16 b16 cis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 | %153
    b4 r8 r4. b'16 a16 b16 cis16 b16 cis16 d16 cis16 d16 e16 cis16 d16 | %159
    \barNumberCheck # 30
    e8 d16 cis16 b16 a16 b16 cis16 b16 a16 gis16 fis16 e16 gis,16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 | %165
    a4 r8 r4. r16 cis16 d16 e16 fis16 g16 a16 b16 a16 g16 fis16 e16 | %171
    fis16 a,16 b16 cis16 d16 e16 d16 cis16 d16 e16 fis16 gis16 a16 gis16 fis16 e16 d16 cis16 e4( dis8\trill) | %177
    e16 d16 e16 fis16 e16 d16 cis16 d16 cis16 b16 a16 gis16 a16 gis16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 | %183
    a16 gis16 a16 b16 cis16 d16 e16 d16 cis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 b16 a16 g'16 fis16 e16 d16 cis16 | %189
    fis16 fis,16 b16 cis16 d16 e16 fis16 e16 dis16 e16 fis16 gis16 a16 gis16 fis16 e16 dis16 cis16 b16 a'16 gis16 fis16 e16 dis16 | %195
    \barNumberCheck # 36
    gis16 gis,16 cis16 dis16 e16 fis16 gis16 fis16 eis16 fis16 gis16 a16 b16 a16 gis16 fis16 eis16 dis16 cis16 b'16 a16 gis16 fis16 eis16 | %201
    a16 cis,16 fis16 e16 d16 cis16 d16 fis16 b16 a16 gis16 fis16 e16 gis16 fis16 e16 d16 cis16 d16 fis16 e16 d16 cis16 b16 | %207
    \barNumberCheck # 38
    a4 r8 r4. e'16 a16 gis16 fis16 e16 d16 e16 fis16 e16 d16 cis16 b16 | %213
    a8 r8 r8 r4. r16 e16 a16 b16 cis16 d16 cis16 a16 b16 cis16 d16 e16 | %219
    \barNumberCheck # 40
    fis16 gis16 fis16 e16 d16 cis16 b16 cis16 b16 a16 gis16 fis16 gis4 r8 r4. | %225
    cis16 gis16 a16 b16 cis16 d16 e16 d16 e16 g16 fis16 e16 dis16 cis16 dis16 e16 fis16 gis16 a16 b16 a16 gis16 fis16 e16 | %231
    fis16 b16 a16 gis16 fis16 e16 fis16 gis16 fis16 e16 dis16 cis16 b16 dis16 e16 fis16 gis16 a16 b16 cis16 b16 a16 gis16 fis16 | %237
    e4 r8 r4. cis16 b16 cis16 d16 b16 cis16 d16 cis16 d16 e16 cis16 d16 | %243
    e16 a16 g16 fis16 e16 d16 e16 fis16 e16 d16 cis16 b16 a16 cis16 d16 e16 fis16 g16 fis16 g16 fis16 e16 d16 cis16 | %249
    b4.~ b16 e16 fis16 gis16 a16 b16 cis8 r8 r8 r4. | %255
    \barNumberCheck # 46
    e,2.~ e8 a16 b16 a16 b16 cis16 b16 cis16 d16 cis16 d16 | %261
    e8 r8 r8 r4. r8 d16 e16 d16 cis16 b16 a16 b16 cis16 b16 cis16 | %267
    d8 r8 r8 r4. r8 cis16 d16 cis16 b16 a16 gis16 a16 b16 a16 b16 | %273
    cis16 b16 cis16 d16 b16 cis16 d16 e16 d16 cis16 b16 a16 gis16 fis16 gis16 a16 fis16 gis16 a4.~ | %279
    \barNumberCheck # 50
    a16 gis16 a16 b16 gis16 a16 b16 cis16 d16 e16 cis16 d16 b16 cis16 b16 a16 gis16 fis16 e16 fis16 e16 d16 cis16 b16 | %285
    \once \slurDashed a4.\trill( b8) cis8 d8 cis8 a8 b8 cis8 b8 a8 | %291
    fis'8 cis'16 b16 a16 gis16 fis16 gis16 fis16 e16 dis16 cis16 b16 cis16 b16 a16 gis16 fis16 e4 r8 | %297
    r16 a16 b16 cis16 d16 e16 fis16 d16 e16 fis16 gis16 a16 b16 a16 b16 cis16 a8~ a8 gis16 fis16 gis8 | %303
    a4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>


mvtVIflII = <<
\mvtVItimeline
\relative c'' {
    \key a \major
    r4 a4 e'4. fis16 gis16 | %1
    fis4. gis16 a16 b4 a8 cis,8 | %2
    dis8 fis8 b,8 e8 cis8 dis16 e16 fis4 | %3
    b,4.~ b4 r8 r2. |
    \barNumberCheck # 5
    \quoteDuring mvtVIflI {
        s1.*50 |
    }
    \barNumberCheck # 55
}
>>


mvtVIvlnI = <<
\mvtVItimeline
\relative c'' {
    \key a \major
    r4 fis4 b,4 e4~ | %1
    e4 d2 cis8 fis8 | %2
    dis8 b8 e8 e,8 a4. gis8 | %3
    gis4.~ gis4 r8 r2. | %9
    r2. r8 b16 a16 b16 cis16 d16 cis16 d16 e16 cis16 d16 | %15
    b16 a16 b16 cis16 b16 cis16 d16 cis16 d16 e16 cis16 d16 e8 fis16 e16 d16 e16 cis8 d16 cis16 b16 cis16 | %21
    a8 a8 cis8 e8 cis8 e8 a8 e8 cis8 b8 cis8 d8 | %27
    cis8 a8 b8 cis8 b8 a8 e'2.~ | %33
    e8 d8 cis8 b8 cis8 d8 cis8 b8 cis8 d8 cis8 b8 | %39
    e8 cis8 d8 e8 d8 cis8 b8 a16( gis16 fis16 e16) r4. | %45
    r4. r8 r8 e'8 a,4.\trill( b8) cis8 d8 | %51
    cis8 a8 b8 cis8 b8 a8 e'2.~ | %57
    e2.~ e8 fis8 e8 d8 e8 fis8 | %63
    g8 e8 d8 cis8 d8 e8 fis2.~ | %69
    fis8 d8 cis8 b8 cis8 d8 e8 cis8 b8 ais8 b8 cis8 | %75
    d2.~ d8 b8 a8 gis8 a8 b8 | %81
    cis8 a8 gis8 fis8 gis8 a8 b8 cis8 d8~ d8 cis8 b8 | %87
    a8 fis'8 d8 b4.\trill cis2.~ | %93
    cis1.~ | %99
    cis4.~ cis4 cis8 \once \slurDashed fis,4.\trill( gis8) a8 b8 | %105
    a8 fis8 gis8 a8 gis8 fis8 d'8 b8 cis8 d8 cis8 b8 | %111
    gis'4. b,4.~ b8 a8 gis8 a8 cis8 b8 | %117
    cis8 fis8 e8 d8 cis8 b8 cis8 fis,8 b8 gis4. | %123
    fis16 cis16 dis16 eis16 fis16 gis16 a16 gis16 fis16 gis16 a16 b16 cis16 b16 cis16 d16 cis16 d16 b16 a16 b16 cis16 a16 b16 | %129
    gis16 fis16 gis16 a16 gis16 a16 b16 a16 b16 cis16 a16 b16 gis16 eis16 fis16 gis16 a16 b16 cis8 r8 r8 | %135
    r16 fis,16 gis16 a16 b16 cis16 d8 r8 r8 r16 gis,16 cis16 dis16 eis16 fis16 gis16 fis16 eis16 fis16 gis16 a16 | %141
    b8 a16 gis16 a16 fis16 eis4\trill fis8 fis4 r8 r4. | %147
    r2. r16 ais,,16 b16 cis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 | %153
    b4 r8 r4. r2. | %159
    r2. r16 gis16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 | %165
    a4 r8 r4. r2. | %171
    R1. | %177
    r4. r8 r8 e''8 \once \slurDashed a,4.\trill( b8) cis8 d8 | %183
    cis8 a8 b8 cis8 b8 a8 e'2.~ | %189
    e8 d8 cis8 dis8 cis8 b8 fis'2.~ | %195
    fis8 e8 dis8 eis8 dis8 cis8 gis'2.~ | %201
    gis8 fis8 e8 d4.~ d8 cis8 b8 e8 fis8 d8 | %207
    cis16 b16 cis16 d16 cis16 d16 d4.\trill e2.~ | %213
    e8 d8 cis8 d4.~ d8 cis8 b8 cis4.~ | %219
    cis8 b8 a8 b4.~ b8 a8 gis8 cis8 d8 b8 | %225
    a8 gis8 fis8 gis8 b8 ais8 b4 b8 a4.~ | %231
    a2.~ a8 gis16 a16 b8~ b8 cis8 a8 | %237
    gis8 fis8 e8 e8 fis8 gis8 a4 a8 r4. | %243
    e'2.~ e8 d8 cis8 b8 cis8 d8~ | %249
    d8 cis8 b8 e4 d8 cis16 a,16 b16 cis16 d16 e16 fis16 d16 e16 fis16 gis16 a16 | %255
    b16 gis16 a16 b16 cis16 d16 e16 a16 gis16 fis16 e16 d16 cis16 b16 cis16 d16 cis16 d16 e16 d16 e16 fis16 e16 fis16 | %261
    ais,16 g'16 fis16 e16 d16 cis16 d16 e16 d16 cis16 b16 ais16 b16 fis16 b16 cis16 b16 cis16 d16 cis16 d16 e16 d16 e16 | %267
    gis,16 fis'16 e16 d16 cis16 b16 cis16 d16 cis16 b16 a16 gis16 a16 e16 a16 b16 a16 b16 cis16 b16 cis16 d16 cis16 d16 | %273
    e16 d16 e16 fis16 d16 e16 fis8 e8 d8 e4.~ e16 d16 e16 fis16 d16 e16 | %279
    fis4.~ fis16 e16 fis16 gis16 e16 fis16 gis8 r8 r8 r4. | %285
    r16 a,,16 b16 cis16 d16 e16 fis16 e16 d16 e16 fis16 gis16 a4 b8 cis8 b8 a8 | %291
    fis'4 e8 dis4.~ dis8 e8 b8 cis8 gis8 a8 | %297
    b8 gis8 e8 d'4.~ d8 fis8 e8 cis8 b16 a16 b8 | %303
    a4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>


mvtVIvlnII = <<
\mvtVItimeline
\relative c'' {
    \key a \major
    r4 a4 gis8 fis8 gis8 e8 | %1
    a4. b16 a16 gis8 fis8 e8 a8 | %2
    fis4 e2 dis4 | %3
    e4.~ e4 r8 r2. | %9
    r2. r8 e'8 b8 gis8 e8 a8 | %15
    e8 e'8 e8 e8 e8 a,8 a4 fis'8 e8 fis8 d8 | %21
    cis8 e,8 a8 cis8 a8 cis8 e8 r8 r8 r4. | %27
    r4. r8 r8 a,8 e4.\trill( fis8) gis8 a8 | %33
    gis8 e8 fis8 gis8 fis8 e8 a2.~ | %39
    a8 cis8 b8 a8 gis8 a8 gis8 fis8 gis8 a8 gis8 fis8 | %45
    b8 gis8 fis8 e8 fis8 gis8 cis,4 r8 r8 r8 b'8 | %51
    e,8 fis8 gis8 fis8 gis8 a8 gis8 e8 gis8 a8 e8 a8 | %57
    cis2.~ cis8 b8 ais8 b4.~ | %63
    b8 a8 b8 a4.~ a4 g8 fis8 e8 d8 | %69
    b'4.~ b4 a8 g4.~ g8 fis8 ais8 | %75
    b8 d,8 e8 fis4.~ fis4 dis8 e4.~ | %81
    e4 eis8 fis4.~ fis8 a8 gis8 eis8 fis8 gis8~ | %87
    gis8 fis8 a8~ a8 b16 a16 gis16 fis16 gis8 eis8 gis8 cis8 gis8 cis8 | %93
    eis8 gis,8 a8 b8 a8 gis8 fis8 gis8 a8 b8 cis8 eis,8 | %99
    fis4 eis8 fis8 gis8 a8~ a8 b8 a8 gis8 fis8 eis8 | %105
    fis4.~ fis8 gis8 a8 gis4 a8 b4.~ | %111
    b4 a8 gis8 a8 b8 eis,4. fis4 eis8 | %117
    fis8 a8 gis8 fis8 eis8 fis8 eis8 cis8 fis8 fis4 eis8 | %123
    cis8 a8 cis8 fis8 cis8 fis8 a16 gis16 a16 b16 a16 b16 gis16 fis16 gis16 a16 fis16 gis16 | %129
    eis16 dis16 eis16 fis16 eis16 fis16 gis16 fis16 gis16 a16 fis16 gis16 eis8 r8 r8 r16 gis16 fis16 e16 d16 cis16 | %135
    b8 r8 r8 r16 a'16 g16 fis16 e16 d16 cis8 gis'8 b8~ b8 a8 gis8 | %141
    fis8 cis'8. d16 gis,4 gis8 fis4 r8 r4. | %147
    r2. r16 ais,16 b16 cis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 | %153
    b4 r8 r4. r2. | %159
    r2. r16 gis16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 | %165
    a4 r8 r4. r8 a'8 fis8 e8 cis8 a8 | %171
    d4. r8 r8 b'8 \once \slurDashed e,4.\trill( fis8) gis8 a8 | %177
    gis8 e8 fis8 gis8 fis8 e8 a4. r8 r8 gis8 | %183
    e4 r8 g4.~ g8 fis8 e8 a4.~ | %189
    a4 r8 a4.~ a8 gis8 fis8 b4.~ | %195
    b4 r8 b4.~ b8 a8 gis8 cis4 r8 | %201
    a4.~ a8 gis8 fis8 b4.~ b8 fis8 gis8 | %207
    a4.~ a8 gis8 fis8 e8 fis8 gis8 a8 b8 cis8~ | %213
    cis8 b8 a8~ a8 gis8 fis8 e2.~ | %219
    e8 d8 e8 fis8 gis8 a8 gis4 cis,8 r8 r8 eis8 | %225
    fis8 cis8 fis8 e8 b8 fis'8~ fis8 e8 dis8 cis8 b8 cis8 | %231
    fis2.~ fis8 e16 dis16 e8 b8 dis8 dis8 | %237
    e8 b8 b8 b4 e8 e4 r8 g4.~ | %243
    g2.~ g8 fis8 e8 fis4.~ | %249
    fis8 e8 d8 e4.~ e16 a,16 b16 cis16 d16 e16 fis16 d16 e16 fis16 gis16 a16 | %255
    b8 e,8 e8 e4 e8 e4 r8 r4. | %261
    r16 e'16 d16 cis16 b16 ais16 b16 g16 fis16 e16 d16 cis16 d4 r8 r4. | %267
    r16 d'16 cis16 b16 a16 gis16 a16 fis16 e16 d16 cis16 b16 cis4 r8 r4. | %273
    r8 r8 a'8 fis8 gis8 a8 b8 e,8 gis8 a4.~ | %279
    a8 cis8 a8 b4.~ b8 d16 cis16 b16 a16 b4 r8 | %285
    r16 a,16 b16 cis16 d16 e16 fis16 e16 d16 e16 fis16 gis16 a8 fis8 gis8 a8 gis8 a8 | %291
    a4.~ a8 gis8 fis8 b4 b8 a8 gis8 fis8 | %297
    gis4 a8 fis8 b4~ b8 d8 cis8 a8 b8 gis8 | %303
    e4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>


mvtVIvla = <<
\mvtVItimeline
\relative c' {
    \key a \major
    \clef C
    r4 d4 e4. d8 | %1
    cis8 fis8~ fis16 e16 d16 cis16 b4 cis8 fis,8 | %2
    b2 cis8 b8 a4 | %3
    b4.~ b4 r8 r2. | %9
    r2. r8 e'8 b8 gis8 e8 a8 | %15
    e8 b'8 b8 b8 b8 fis8 e4 a8 a4 e8 | %21
    e8 cis8 e8 a8 e8 a8 cis8 r8 r8 r4. | %27
    R1. | %33
    r4. r8 r8 e,8 a,4.\trill( b8) cis8 d8 | %39
    cis8 a8 b8 cis8 b8 a8 e'2.~ | %45
    e8 d8 cis8 b8 a8 b8 a8 b8 cis8 b4.~ | %51
    b8 cis8 b8 a8 b8 cis8 cis8 gis8 cis8 e8 cis8 e8 | %57
    ais,8 cis8 b8 ais8 gis8 fis8 fis'4.~ fis4 fis8 | %63
    e4.~ e8 d8 cis8 d4 d8 a8 g8 fis8 | %69
    d'4.~ d8 cis8 b8 ais8 e'8 d8 cis8 d8 e8 | %75
    d8 fis8 e8 d8 cis8 b8 b4.~ b8 a8 gis8 | %81
    a4.~ a8 gis8 fis8 d'8 cis8 b8~ b8 a8 gis8 | %87
    cis4 a8 fis'8 eis8 fis8 eis8 cis8 eis8 gis8 eis8 a8 | %93
    cis,8 eis,8 fis8 gis8 a8 b8 a8 b8 cis8 b8 a8 gis8 | %99
    a4 b8 cis8 b8 a8 b4 cis8 d8 cis8 b8 | %105
    cis4.~ cis8 b8 a8 b8 d8 cis8 b8 a8 gis8 | %111
    cis2.~ cis4 cis8 cis4.~ | %117
    cis8 a8 cis8 d4 d8 gis,8 a8 b8 cis4 b8 | %123
    a8 fis8 a8 cis8 a8 cis8 fis8 a8 fis8 eis8 cis8 fis8 | %129
    gis8 cis,8 cis8 cis8 gis8 a8 cis8 a'8 gis8 fis8 gis8 a8 | %135
    b8 d,8 cis8 b8 cis8 d8 gis,4 gis'8 cis,4 cis8 | %141
    cis8 fis8 fis8 cis'4 cis8 cis4 r8 r4. | %147
    r2. r16 ais,16 b16 cis16 d16 e16 fis16 g16 fis16 e16 d16 cis16 | %153
    b4 r8 r4. r2. | %159
    r2. r16 gis16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 | %165
    a4 r8 r4. r8 fis8 a8 cis8 a8 e'8 | %171
    \once \slurDashed a,4.\trill( b8) cis8 d8 cis8 a8 b8 cis8 b8 a8 | %177
    e'2.~ e8 d8 cis8 b4.~ | %183
    b8 cis8 b8 a8 b8 cis8~ cis8 d8 e8~ e8 a,8 g'8 | %189
    fis4 ais,8 b8 cis8 dis8~ dis8 e8 fis8~ fis8 b,8 a'8 | %195
    gis4 bis,8 cis8 dis8 eis8~ eis8 fis8 gis8~ gis8 cis,8 cis8 | %201
    cis4 r8 d8 e8 fis8 b,8 cis8 d8 e4.~ | %207
    e16 d16 cis8 fis8 b,4.~ b8 cis8 d8 cis8 d8 e8 | %213
    a,8 b8 cis8 fis,8 gis8 a8 a4.~ a8 e8 a8~ | %219
    a8 fis8 a8 d4.~ d8 cis8 b8 a8 b8 gis8 | %225
    fis4 a8 b8 d8 cis8 b8 cis8 dis8 e8 dis8 cis8 | %231
    b2.~ b16 cis16 b16 a16 gis8 fis4 b8 | %237
    b8 a8 gis8 gis8 a8 b8 cis4 r8 r4. | %243
    r4. a4.~ a8 b8 fis8 b4.~ | %249
    b8 gis8 a8 b8 a8 gis8 a8 b16 cis16 d16 e16 fis16 d16 e16 fis16 gis16 a16 | %255
    b8 e,8 cis8 b4 cis8 cis4 r8 r4. | %261
    r4. r8 fis8 fis8 fis4 r8 r4. | %267
    r4. r8 e8 e8 e4 r8 r4. | %273
    r8 r8 cis8 a8 b8 cis8 b4 b8 e4 cis8 | %279
    fis,8 a8 cis8 b8 fis8 d'8 d4.~ d8 a8 b8 | %285
    cis16 a16 b16 cis16 d16 e16 fis16 e16 d16 e16 fis16 gis16 a8 cis,8 e8 a,8 b8 cis8 | %291
    b2.~ b8 e8 e8 e4 dis8 | %297
    b4 cis8 d4.~ d8 b8 cis8 e8 d16 cis16 d8 | %303
    cis4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>


mvtVIsoprano = <<
\mvtVItimeline
\relative c'' {
    \autoBeamOff
    \key a \major
    r4 fis4 b,4 \melisma e4~ | %1
    e4 d2 cis8[ fis8] | %2
    dis8[ b8] \melismaEnd e8[ e,8] a4. gis8 | %3
    gis4.~ gis4 e8 a4.\trill( b8) cis8 d8 | %9
    cis8([ a8)] b8 cis8([ b8)] a8 e'2.~ | %15
    e4. e,4 r8 r2. | %21
    r4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" e'8 a,4.\trill( b8) cis8 d8 | %27
    cis8([ a8)] b8 cis8([ b8)] a8 e'2.~ | %33
    e8[ \melisma d8 cis8] b8[ cis8 d8] cis8[ b8 cis8] d8[ cis8 b8] | %39
    e8[ cis8 d8] e8[ d8 cis8] b4 \melismaEnd b8 r4. | %45
    r4. r8 r8 e8 a,4.\trill( b8) cis8 d8 | %51
    cis8([ a8)] b8 cis8[ b8] a8 e'2.~ | %57
    e2.~ e8 fis8 e8 d8 e8 fis8 | %63
    g8[ e8] d8 cis8[ d8] e8 fis2.~ | %69
    fis8 d8 cis8 b8 cis8 d8 e8([ cis8)] b8 ais8([ b8)] cis8 | %75
    d2.~ d8 b8 a8 gis8 a8 b8 | %81
    cis8[ a8] gis8 fis8[ gis8] a8 b8[ \melisma cis8 d8~] d8[ cis8 b8] | %87
    a8[ fis'8 d8] b4\trill \melismaEnd b8 cis2.~ | %93
    cis1.~ | %99
    cis4. cis,4 cis'8 fis,4.\trill( gis8) a8 b8 | %105
    a8[ fis8] gis8 a8[ gis8] fis8 d'8[ \melisma b8 cis8] d8[ cis8 b8] | %111
    gis'4. b,4.~ b8 \melismaEnd a8 gis8 a8([ cis8 b8] | %117
    cis8) fis8 e8 d8([ cis8)] b8 cis8[ fis,8] b8 gis4.\trill | %123
    fis4. r4. r2. | %129
    R1.*2 | %135
    r2. r4. <>-\offset X-offset #-2.0 ^"solo" e'4.~ | %147
    e2.~ e8[ d16 e16 fis8~] fis8 g8 <>-\offset X-offset #-2.0 ^"tutti" e8 | %153
    d8 cis8 b8 b8([ cis8)] dis8 e4 e,8 <>-\offset X-offset #-2.0 ^"solo" d'4.~ | %159
    d2.~ d8[ cis16 d16 e8~] e8 fis8 <>-\offset X-offset #-2.0 ^"tutti" d8 | %165
    cis8 b8 a8 a8[ b8] cis8 d4 d,8 r4. | %171
    R1. | %177
    r4. r8 r8 e'8 a,4.\trill( b8) cis8 d8 | %183
    cis8([ a8)] b8 cis8([ b8)] a8 e'2.~ | %189
    e8[ \melisma d8 cis8] dis8[ cis8] \melismaEnd b8 fis'2.~ | %195
    fis8[ \melisma e8 dis8] eis8[ dis8] \melismaEnd cis8 gis'2.~ | %201
    gis8[ \melisma fis8 e8] d4.~ d8[ cis8 b8] e8[ fis8 d8] | %207
    cis16[ b16 cis16 d16 cis16 d16] d4.\trill e2.~ | %213
    e8[ d8 cis8] d4.~ d8[ cis8 b8] cis4.~ | %219
    cis8[ b8 a8] b4.~ b8[ a8 gis8] cis8 \melismaEnd d8 b8 | %225
    a8 gis8 fis8 gis8[ b8] ais8 b4 b8 <>-\offset X-offset #-2.0 ^"solo" a4.~ | %231
    a2.~ a8[ gis16 a16 b8~] b8 cis8 <>-\offset X-offset #-2.0 ^"tutti" a8 | %237
    gis8 fis8 e8 e8[ fis8] gis8 a4 a8 r4. | %243
    <>-\offset X-offset #-2.0 ^"solo" e'2.(~ e8[ d8 cis8] b8) cis8 <>-\offset X-offset #-2.0 ^"tutti" d8 | %249
    d8 cis8 b8 e4 d8 cis8[ b8] a8 b4.~ | %255
    b8[ cis8] a8 gis4( a8) a4 r8 <>-\offset X-offset #-2.0 ^"solo" e'4.~ | %261
    e8[ \melisma fis16 e16 d16 cis16] d8 \melismaEnd b8 r8 r4. d4.~ | %267
    d8[ \melisma e16 d16 cis16 b16] cis8 \melismaEnd a8 r8 r4. <>-\offset X-offset #-2.0 ^"tutti" g'4.~ | %273
    g8 e8 fis8 fis8 e8 d8 e4.~ e8[ cis8] a8 | %279
    d4.~ d8[ fis8] a,8 gis8[ fis8] e8 r8 r8 e'8 | %285
    a,4.\trill( b8) cis8 d8 cis8[ a8] b8 cis8[ b8] a8 | %291
    fis'8 fis8 e8 dis4.~ dis8 e8 b8 cis8[ gis8] a8 | %297
    b8[ gis8] e8 d'4.~ d8[ fis8] e8 cis8[ b16 a16 b8] | %303
    a4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>

mvtVIsopranoLyrics = \lyricmode {
    Cum San -- cto Spi -- ri -- tu __
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    a -- men, in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men.
}


mvtVIalto = <<
\mvtVItimeline
\relative c'' {
    \autoBeamOff
    \key a \major
    r4 a4 gis8[ \melisma fis8 gis8 e8] | %1
    a4. b16[ a16] gis8[ fis8] e8[ a8] | %2
    fis4 \melismaEnd e4 e4 dis4 | %3
    e4.~ e4 r8 r2. | %9
    R1.*3 | %15
    r4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" a8 e4.\trill( fis8) gis8 a8 | %33
    gis8[ e8] fis8 gis8[ fis8] e8 a2.~ | %39
    a8[ \melisma cis8 b8] a8[ gis8 a8] gis8[ fis8 gis8] a8[ gis8 fis8] | %45
    b8[ gis8 fis8] e8[ fis8 gis8] cis,4 \melismaEnd cis8 r8 r8 b'8 | %51
    e,8([ fis8 gis8] fis8) gis8 a8 gis8[ e8] gis8 a8[ e8] a8 | %57
    cis2.~ cis8[ \melisma b8 ais8] b4.~ | %63
    b8[ a8 b8] a4.~ a4 g8 fis8[ e8 d8] | %69
    b'4.~ b4 \melismaEnd a8 g4.~ g8[ fis8] ais8 | %75
    b8[ \melisma d,8 e8] fis4.~ fis4 \melismaEnd dis8 e4.~ | %81
    e4 eis8 fis4.~ fis8[ a8] gis8 eis8[ \melisma fis8 gis8]~ | %87
    gis8[ fis8 a8]~ a8[ b16 a16 gis16 fis16] \melismaEnd gis4 cis8 gis4\trill( a8 | %93
    b8[ gis8 a8] b8) a8 gis8 fis8[ gis8] a8 b8[ cis8] eis,8 | %99
    fis4 eis8 fis8[ \melisma gis8 a8~] a8[ b8 a8] gis8[ fis8 eis8] | %105
    fis4.~ fis8[ gis8 a8] gis4 \melismaEnd a8 b4.~ | %111
    b4 \melisma a8 gis8[ a8 b8] eis,4. \melismaEnd fis4 eis8 | %117
    fis8 a8 gis8 fis8[ eis8] fis8 eis8[ cis8] fis8 fis4( eis8) | %123
    cis4. r4. r2. | %129
    R1.*3 | %135
    <>-\offset X-offset #-2.0 ^"solo" cis'2.~ cis8[ \melisma b16 ais16 b8] fis8 \melismaEnd ais8 <>-\offset X-offset #-2.0 ^"tutti" ais8 | %153
    b8 fis8 fis8 fis4 b8 b4 gis8 r4. | %159
    <>-\offset X-offset #-2.0 ^"solo" b2.~ b8[ \melisma a16 gis16 a8] e8 \melismaEnd gis8 <>-\offset X-offset #-2.0 ^"tutti" gis8 | %165
    a8 e8 e8 e4 a8 a4 fis8 r4. | %171
    r4. r8 r8 b8 e,4.\trill( fis8) gis8 a8 | %177
    gis8([ e8)] fis8 gis8([ fis8)] e8 a4 a8 r8 r8 gis8 | %183
    e4 r8 g4.~ g8[ \melisma fis8 e8] a4. | %189
    \melismaEnd a4 r8 a4.~ a8[ \melisma gis8 fis8] b4. | %195
    \melismaEnd b4 r8 b4.~ \melisma b8[ a8 gis8] cis4 \melismaEnd gis8 | %201
    a4.~ a8[ \melisma gis8 fis8] b4.~ b8[ fis8 gis8] | %207
    a4.~ a8[ gis8 fis8] e8[ fis8 gis8] a8[ b8 cis8~] | %213
    cis8[ b8 a8~] a8[ gis8] \melismaEnd fis8 e2.~ | %219
    e8[ \melisma d8 e8] fis8[ gis8 a8] gis4 \melismaEnd cis,8 r8 r8 eis8 | %225
    fis8 cis8 fis8 e8[ b8 fis'8~] fis8[ e8] dis8 cis8[ b8] cis8 | %231
    <>-\offset X-offset #-2.0 ^"[solo]" fis2.~ fis8[ \melisma e16 dis16 e8] b8 \melismaEnd dis8 <>-\offset X-offset #-2.0 ^"[tutti]" dis8 | %237
    e8 b8 b8 b4 e8 e4 e8 <>-\offset X-offset #-2.0 ^"[solo]" g4.~ | %243
    g2.~ g8 fis8 <>-\offset X-offset #-2.0 ^"[tutti]" e8 fis4.~ | %249
    fis8 e8 d8 e4.~ e8[ d8] cis8 d4.~ | %255
    d8[ e8] cis8 b4( cis8) cis4 r8 <>-\offset X-offset #-2.0 ^"[solo]" cis'4.~ | %261
    cis8[ \melisma d16 cis16 b16 ais16] b8 \melismaEnd fis8 r8 r4. b4.~ | %267
    b8[ \melisma cis16 b16 a16 gis16] a8 \melismaEnd e8 r8 r4. <>-\offset X-offset #-2.0 ^"[tutti]" a4.~ | %273
    a8 g8 fis8 fis8 gis8 a8 b8[ e,8] gis8 a4.~ | %279
    a8[ cis8] a8 b4.~ b8[ d8] b8 gis4 e8 | %285
    r8 r8 a8 a8 a8 gis8 e8[ fis8] gis8 a8[ gis8] a8 | %291
    a4.~ a8[ \melisma gis8 fis8] b4 \melismaEnd b8 a8[ gis8] fis8 | %297
    gis4 a8 fis8 \melisma b4~ b8[ d8] \melismaEnd cis8 a8[ b8 gis8] | %303
    e4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>

mvtVIaltoLyrics = \lyricmode {
    Cum San -- cto Spi -- ri -- tu __
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    a -- men, in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    De -- i Pa -- tris, a -- men, a -- men.
}


mvtVItenor = <<
\mvtVItimeline
\relative c' {
    \autoBeamOff
    \key a \major
    r4 d4 e4. \melisma d8 | %1
    cis8[ fis8~] fis16[ e16 d16 cis16] b4 cis8[ fis,8] | %2
    b4 \melismaEnd b4 cis8[ b8] a4 | %3
    b4.~ b4 r8 r2. | %9
    R1.*4 | %15
    r4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" e8 a,4.\trill( b8) cis8 d8 | %39
    cis8([ a8)] b8 cis8([ b8)] a8 e'2.~ | %45
    e8[ \melisma d8 cis8] b8[ a8 b8] a8[ b8 cis8] b4.~ | %51
    b8[ cis8 b8] a8 \melismaEnd b8 cis8 cis8[ \melisma gis8 cis8] e8[ cis8] \melismaEnd e8 | %57
    ais,8 cis8 b8 ais8[ gis8] fis8 fis'4.~ fis4 fis8 | %63
    e4.~ e8[ \melisma d8 cis8] d4 \melismaEnd d8 a8[ \melisma g8 fis8] | %69
    d'4.~ d8[ cis8 b8] ais8[ e'8 d8] cis8[ d8 e8] | %75
    d8[ fis8 e8] d8[ cis8] \melismaEnd b8 b4.~ b8[ \melisma a8 gis8] | %81
    a4.~ a8[ gis8 fis8] d'8[ cis8 b8~] b8[ a8 gis8] | %87
    cis4 \melismaEnd a8 fis'8[ eis8 fis8] eis4 r8 r8 r8 cis8 | %93
    eis,4 \melisma fis8 gis8[ a8 b8] a8 \melismaEnd b8 cis8 b8[ a8] gis8 | %99
    a4 b8 cis8[ b8] a8 b4( \melisma cis8 d8[ cis8 b8]) | %105
    cis4.~ cis8[ b8 a8] b8[ d8 cis8] b8[ a8] \melismaEnd gis8 | %111
    cis4. cis4.~ cis4 cis8 cis4.~ | %117
    cis8 a8 cis8 d4 d8 gis,8[ a8] b8 cis4( b8) | %123
    a4. r4. r2. | %129
    R1.*3 | %135
    r4. <>-\offset X-offset #-2.0 ^"solo" fis'4.~ fis16[ g16 fis16 e16 d8] cis4 <>-\offset X-offset #-2.0 ^"tutti" fis8 | %153
    fis8 e8 d8 dis8[ e8] fis8 gis4 b,8 r4. | %159
    r4. <>-\offset X-offset #-2.0 ^"solo" e4.~ e16[ fis16 e16 d16 cis8] b4 <>-\offset X-offset #-2.0 ^"tutti" e8 | %165
    e8 d8 cis8 cis8[ d8] e8 fis4 a,8 r8 r8 e'8 | %171
    a,4.\trill( b8) cis8 d8 cis8[ a8] b8 cis8[ b8] a8 | %177
    e'2.~ e8[ d8] cis8 b4.~ | %183
    b8[ \melisma cis8 b8] a8[ b8 cis8~] cis8[ d8 e8~] e8[ a,8 g'8] | %189
    fis4 \melismaEnd ais,8 b8[ \melisma cis8 dis8~] dis8[ e8 fis8~] fis8[ b,8 a'8] | %195
    gis4 \melismaEnd bis,8 cis8[ \melisma dis8 eis8~] eis8[ fis8 gis8~] gis8 cis,4 | %201
    \melismaEnd cis4 r8 d8[ \melisma e8 fis8] b,8[ cis8 d8] e4.~ | %207
    e16[ d16 cis8 fis8] b,4.~ b8[ cis8 d8] cis8[ d8 e8] | %213
    a,8[ b8 cis8] fis,8[ gis8 a8] a4.~ a8[ e8 a8]~ | %219
    a8[ fis8 a8] d4.~ d8[ cis8 b8] a8[ b8 gis8] | %225
    \melismaEnd fis4 a8 b8 d8 cis8 b8[ cis8] dis8 e8[ dis8] cis8 | %231
    <>-\offset X-offset #-2.0 ^"[solo]" b2.~ b16[ cis16 b16 a16 gis8] fis4 <>-\offset X-offset #-2.0 ^"[tutti]" b8 | %237
    b8 a8 gis8 gis8[ a8] b8 cis4 cis8 r4. | %243
    r4. <>-\offset X-offset #-2.0 ^"[solo]" a4.~ a8[ \melisma b8 fis8] b4.~ | %249
    b8 \melismaEnd gis8 <>-\offset X-offset #-2.0 ^"[tutti]" a8 b8 a8 gis8 a8[ e'8] a8 fis4 fis8 | %255
    e2. e4 r8 <>-\offset X-offset #-2.0 ^"[solo]" g4.~ | %261
    g8[ ais,8] fis'8 fis8 d8 r8 r4. e4.~ | %267
    e8[ gis,8] e'8 e8 cis8 r8 r4. <>-\offset X-offset #-2.0 ^"[tutti]" e4.~ | %273
    e8 cis8 a8 a8 b8 cis8 b4 b8 e4 cis8 | %279
    fis,8[ \melisma a8 cis8] b8[ fis8] \melismaEnd d'8 d4.~ d8[ \melisma a8 b8] | %285
    cis8 \melismaEnd d8 cis8 b8 fis'8 e8 e8[ cis8] e8 a,8[ b8] cis8 | %291
    b2.~ b8[ e8] e8 e4 dis8 | %297
    b4 cis8 d4.~ d8[ b8] cis8 e8([ d16 cis16 d8)] | %303
    cis4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>

mvtVItenorLyrics = \lyricmode {
    Cum San -- cto Spi -- ri -- tu __
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, __
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    a -- men, in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    De -- i Pa -- tris, a -- men, a -- men.
}


mvtVIbass = <<
\mvtVItimeline
\relative c {
    \autoBeamOff
    \key a \major
    \clef F
    r4 d4 d'4 \melisma cis4 | %1
    fis,4 b4 e,4 a4~ | %2
    a4 \melismaEnd gis4 fis4. fis8 | %3
    e4.~ e4 r8 r2. | %9
    R1.*5 | %15
    r4. r8 r8 <>-\offset X-offset #-2.0 ^"[tutti]" a8 e4.\trill( fis8) gis8 a8 | %45
    gis8[ e8] fis8 gis8[ fis8] e8 fis8[ \melisma gis8 a8] gis8[ a8 b8] | %51
    a4 gis8 a8 \melismaEnd gis8 fis8 cis'4 \melisma b8 a8 \melismaEnd b8 g8 | %57
    fis8[ ais8] gis8 fis8[ gis8] ais8 b8[ \melisma d8 cis8] b8[ cis8 d8] | %63
    e,8[ fis8 g8] a4 \melismaEnd a,8 d4.~ d8[ \melisma e8 fis8] | %69
    g4.~ g8[ a8 b8] cis,8[ d8 e8] fis4 \melismaEnd fis8 | %75
    b,4.~ b8[ \melisma cis8 d8] e4.~ e8[ fis8 gis8] | %81
    a,8[ b8 cis8] d4 \melismaEnd d8 gis,8[ \melisma a8 b8] cis8[ dis8 eis8] | %87
    fis8[ a8] \melismaEnd fis8 d4. cis4. r4. | %93
    r4. r8 r8 cis'8 \once \slurDashed fis,4.\trill( gis8) a8 b8 | %99
    a8[ fis8] gis8 a8[ gis8] fis8 d'4 cis8 b8[ \melisma cis8 d8] | %105
    cis4 b8 a8[ b8 cis8] b4 a8 gis8[ a8 b8] | %111
    eis,8[ gis8 fis8] eis8[ fis8] \melismaEnd gis8 cis,4. fis4 gis8 | %117
    a8 fis8 ais8 b4 b8 b8[ a8] d8 cis4( cis,8) | %123
    fis4. r4. r2. | %129
    R1.*2 | %135
    r4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" cis'8 fis,4.\trill( gis8) ais8 b8 | %147
    ais8([ fis8)] gis8 ais8[ gis8] fis8 b2. | %153
    b4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" b8 e,4.\trill( fis8) gis8 a8 | %159
    gis8[ e8] fis8 gis8[ fis8] e8 a2. | %165
    a4. r8 r8 <>-\offset X-offset #-2.0 ^"tutti" a8 d,4.\trill( e8) fis8 g8 | %171
    fis8[ d8] e8 fis8[ e8] d8 a'8[ \melisma cis8 b8] a8[ gis8 fis8] | %177
    e8[ cis8 d8] e8[ d8 cis8] fis8[ gis8 a8] gis8[ fis8 e8] | %183
    \melismaEnd a4. r8 r8 a8 \melisma a,8[ b8 cis8~] cis8[ d8 e8] | %189
    d8[ e8 fis8] \melismaEnd b,4 b'8 \melisma b,8[ cis8 dis8]~ dis8[ e8 fis8] | %195
    e8[ fis8 gis8] \melismaEnd cis,4 cis'8 \melisma cis,8[ dis8 eis8~] eis8[ fis8 gis8] | %201
    fis8[ gis8 a8] b8[ cis8 d8] \melismaEnd gis,4. r8 r8 e8 | %207
    a,4.\trill( b8) cis8 d8 cis8[ a8] b8 cis8[ b8] a8 | %213
    fis'8[ \melisma d8 e8] fis8[ e8 d8] a'8[ fis8 gis8] a8[ gis8 fis8] | %219
    d'8[ b8 cis8] d8[ cis8 b8] eis,4 \melismaEnd eis8 r8 r8 cis8 | %225
    fis4. r8 r8 fis8 b,4.\trill( cis8) dis8 e8 | %231
    dis8[ b8] cis8 dis8[ cis8] b8 e2. | %237
    e4. r8 r8 e8 a,4.\trill( b8) cis8 d8 | %243
    cis8[ a8] b8 cis8[ b8] a8 d8[ \melisma b8 cis8] d8 \melismaEnd cis8 b8 | %249
    gis'8 e8 fis8 gis8[ fis8] e8 a4.~ a8[ gis8] fis8 | %255
    gis4 a8 e4. a,4 r8 <>-\offset X-offset #-2.0 ^"[solo]" ais'4.~ | %261
    ais8[ fis8] fis8 b8 b,8 r8 r4. gis'4.~ | %267
    gis8[ e8] e8 a8 a,8 r8 r4. <>-\offset X-offset #-2.0 ^"[tutti]" cis'4.~ | %273
    cis8 a8 a8 d4.~ d8 gis,8 e8 cis'4.~ | %279
    cis8[ a8] fis8 gis8[ a8] b8 e,8[ \melisma b8 e8] gis8[ fis8 gis8] | %285
    a8[ fis8 e8] d8[ b8 e8] \melismaEnd a,4 r8 r4. | %291
    r8 r8 fis'8 b4 \melisma a8 gis4 e8 a8[ cis,8] \melismaEnd fis8 | %297
    e8 d8 cis8 b8[ \melisma cis8 a8] gis4 \melismaEnd a8 e'4. | %303
    a,4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>

mvtVIbassLyrics = \lyricmode {
    Cum San -- cto Spi -- ri -- tu __
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men,
    in glo -- ri -- a De -- i Pa -- tris, a -- men.
}



mvtVIbc = <<
\mvtVItimeline
\relative c {
    \key a \major
    \clef F
    r4 d2 cis4 | %1
    fis,4 b4 e,4 a4~ | %2
    a4 gis4 fis2 | %3
    e8 gis8 b8 e8 e'8 d8 cis8 b8 a8 gis8 fis8 e8 | %9
    a8 cis,8 e8 a8 gis8 fis8 e8 r8 r8 r4. | %15
    r8 e'8 b8 gis8 e8 fis8 cis4 d8 e8 d8 e8 | %21
    a,4 r8 r4. r8 r8 a'8 gis4 e8 | %27
    a4 gis8 fis8 gis8 a8 gis8 cis8 b8 a8 gis8 fis8 | %33
    cis'4 a8 e4 e'8 a,4. b8 cis8 d8 | %39
    cis8 a8 b8 cis8 b8 a8 e4. fis8 gis8 a8 | %45
    gis8 e8 fis8 gis8 fis8 e8 fis8 gis8 a8 gis8 a8 b8 | %51
    a4 gis8 a8 gis8 fis8 cis'4 b8 a4 g8 | %57
    fis8 ais8 gis8 fis8 gis8 ais8 b8 d8 cis8 b8 cis8 d8 | %63
    e,8 fis8 g8 a4 a,8 d8 fis8 e8 d8 e8 fis8 | %69
    g8 b8 a8 g8 a8 b8 cis,8 d8 e8 fis4 fis,8 | %75
    b8 d8 cis8 b8 cis8 d8 e8 gis8 fis8 e8 fis8 gis8 | %81
    a,8 b8 cis8 d8 e8 fis8 gis,8 a8 b8 cis8 dis8 eis8 | %87
    fis8 a8 fis8 d8 cis8 d8 cis4 r8 r8 r8 cis'8 | %93
    eis,4 fis8 gis8 a8 cis,8 fis,4. gis8 a8 b8 | %99
    a8 fis8 gis8 a8 gis8 fis8 d'4 cis8 b8 cis8 d8 | %105
    cis4 b8 a8 b8 cis8 b4 a8 gis8 a8 b8 | %111
    eis,8 gis8 fis8 eis8 fis8 gis8 cis,4 cis'8 fis4 gis8 | %117
    a4 ais8 b4.~ b8 a8 d8 cis8 b8 cis8 | %123
    fis,4 r8 r4. r8 fis,8 a8 cis8 eis8 fis8 | %129
    cis8 cis'8 gis8 eis8 cis8 fis8 cis8 r8 r8 fis8 r8 r8 | %135
    b,8 r8 r8 b'8 r8 r8 r8 cis8 gis8 eis8 cis8 eis8 | %141
    fis8 a,8 b8 <<
        {
            cis4 cis,8 fis4
        } \\ {
            cis'8_\markup\center-align{Organo} b8 cis8 fis,4
        }
    >> r8 r4. | %147
    fis'8 r8 r8 fis,8 r8 r8 b4 r8 r4. | %153
    r16 d16 e16 fis16 gis16 ais16 b16 cis16 b16 a16 gis16 fis16 e4 r8 r4. | %159
    e8 r8 r8 e,8 r8 r8 a4 r8 r4. | %165
    r16 cis16 d16 e16 fis16 g16 a16 b16 a16 g16 fis16 e16 d8 r8 r8 cis8 r8 r8 | %171
    d4.~ d8 cis8 b8 a4.~ a8 gis8 fis8 | %177
    e8 cis'8 d8 e8 d8 cis8 fis8 gis8 a8 gis8 fis8 e8 | %183
    a4.~ a8 e8 cis8 a8 b8 cis8~ cis8 d8 e8 | %189
    d8 e8 fis8 b,4.~ b8 cis8 dis8~ dis8 e8 fis8 | %195
    e8 fis8 gis8 cis,4.~ cis8 dis8 eis8~ eis8 fis8 gis8 | %201
    fis8 gis8 a8 b,8 cis8 d8 gis,4.~ gis8 fis8 e8 | %207
    a4. b8 cis8 d8 cis8 a8 b8 cis8 b8 a8 | %213
    fis'8 d8 e8 fis8 e8 d8 a'8 fis8 gis8 a8 gis8 fis8 | %219
    d'8 b8 cis8 d8 cis8 b8 eis,4. r8 r8 cis8 | %225
    fis4. r8 r8 fis,8 b4. cis8 dis8 e8 | %231
    dis8 b8 cis8 dis8 cis8 b8 e8 r8 r8 r4. | %237
    r16 gis,16 a16 b16 cis16 d16 e16 fis16 e16 d16 cis16 b16 a4 r8 r4. | %243
    a'8 r8 r8 a,8 r8 r8 d8 b8 cis8 d8 cis8 b8 | %249
    gis'8 e8 fis8 gis8 fis8 e8 a4.~ a8 gis8 fis8 | %255
    gis4 a8 e4 e,8 a8 cis8 e8 ais,8 b8 cis8 | %261
    fis,8 r8 r8 r8 b'8 fis8 b,8 d8 fis8 gis,8 a8 b8 | %267
    e,8 r8 r8 r8 a'8 e8 cis8 d8 e8 a,8 cis8 e8 | %273
    a4 a,8 d4.~ d8 gis,8 e8 cis'4.~ | %279
    cis8 a8 fis8 gis8 a8 b8 e,4 b'8 e8 fis8 d8 | %285
    cis8 fis8 e8 d8 b8 e8 a,4 gis8 fis4 e8 | %291
    dis4 fis8 b4 a8 gis4 e8 a8 cis8 fis8 | %297
    e8 d8 cis8 b8 cis8 a8 gis4 a8 e'4 e,8 | %303
    a4.-\fermata r4. r2. | %309
    \barNumberCheck # 55
}
>>


mvtVIfigs = <<
\mvtVItimeline
\figuremode {
    s4 <5 3> <4 2> <6> |
    <7> <7> <7> <5>8 <6> |
    <4\+ 2>4 <6> <7> <6\\> |
    \barNumberCheck # 4
    s4. s4 <4 2>8 <6>4. <6>4 <7>8 |
    s <6> s s s <6\\> s2. |
    \barNumberCheck # 6
    s4 <\FBx>8 <6> s <5> <6>4 <6 5>8 <6 4> s <5 3> |
    s2. s4. <6>4 <7>8 |
    s4 <6>8 s4. <6>8 <5> <\FBx> <6 5> s <6\\> |
    s2. s4. <7>4 <4 2>8 |
    \barNumberCheck # 10
    <6>4 <6>8 <6>4. s <7>4 <4\+ 2>8 |
    <6> <\FBnull> \once \bassFigureExtendersOn <\FBnull> <6>4 <7>8 <5>4 <6>8 <6>4 <6 4 3>8 |
    s4 <6>8 s4 <5>8 <5>4 <\FBx>8 s4 <6 4 2>8 |
    <7 _+> <\FBnull> \once \bassFigureExtendersOn <\FBnull> <7 _+>4. s s4 <6>8 |
    \barNumberCheck # 14
    <7 _!>4. <7!> s8 <6> s s4. |
    <7> <\FBx> <7> <7 _+> |
    s2. <7>4. <7> |
    <7> <7> <7> <7 _+>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    \barNumberCheck # 18
    s8 <6> s <6>4. <_+> s |
    <6 5> <6\\>8 <6> <_+> s4. <6\\ 4 3>4 <4\+ 2>8 |
    <6>4. <6> <7>8 <6> <6> s4 <6 4 2\+>8 |
    <7> <6> <6> s4 <6>8 <7> <6> s <7>4. |
    \barNumberCheck # 22
    <6 5>8 <\FBx> s <6 5>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> <7 _+>4. s4 <6\\>8 |
    <6>4 <5>8 s4. <4\+ 2>8 <6> <6> <4>4 <_+>8 |
    s2. s4 <6>8 <_+> <6 5> s |
    <_+>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> <6 5>4. <_+> s |
    \barNumberCheck # 26
    <7>4. <6!> s8 <_+>8 s <6 5>4. |
    s8 <6> <6 5> <_+> <6 4\+> <5 _+> s2. |
    <7 _+>4. <\FBx> s2. |
    s16 <6> <\FBnull>8. \once \bassFigureExtendersOn <\FBnull>16 s4. <7> s |
    \barNumberCheck # 30
    <7>4. <7> s2. |
    s16 <6> s4 s4. s <6>4 <5!>8 |
    <8>4 <7>8 <6 5>4 <6>8 s4. <6 5>4 <6\\>8 |
    s4. <6> <7> <6 5> |
    \barNumberCheck # 34
    s2. s4. <6 5!> |
    <9 7>8 <7 5> <_+> s4. <7 _+> <6 5> |
    <9 7>8 <7 5> <5\+ _+> s4. <7 _+> <6 5> |
    s <7> <6 5> <6 5> |
    \barNumberCheck # 38
    s4. <7>4 <6 4 2>8 <6>4 <6>8 <6>4. |
    <6> <6> <5> <6> |
    <7> <6> <6 5> s4 <7 _+>8 |
    s4. s4 <7 _+>8 <_+>4. <6> |
    \barNumberCheck # 42
    <6 5>4. <6 5> s2. |
    s16 <6> s4 s4. s2. |
    <7!>4. <\FBx> s <6> |
    <6 5> <6 5> s <4 2> |
    \barNumberCheck # 46
    <6 5> <4>4 <3>8 s <\FBnull> \once \bassFigureExtendersOn <\FBnull> <7! 5>4. |
    <7 _+> s4 <\FBx>8 s <\FBnull> \once \bassFigureExtendersOn <\FBnull> <6 5>4. |
    <7>4. s <6> <7!> |
    <7!> s <4 2> <6> |
    \barNumberCheck # 50
    <4 2>4. <6 5> <7> s |
    <6> <6 5> s <6\\>4 <6 4 2>8 |
    <6 5>4. <7 _+>8 <6> <4\+ 2> <6>4 <7!>8 s4 <6\\>8 |
    s4 <6>8 <5>4 <4 2>8 <6 5>4. <6 4>8 <5 3> s |
    s1. |
    \barNumberCheck # 55
}
>>

\addQuote mvtVIflI      { \mvtVIflI }
