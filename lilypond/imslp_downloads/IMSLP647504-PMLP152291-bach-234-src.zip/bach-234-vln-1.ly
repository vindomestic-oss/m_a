\version "2.21.0"

ownInstr = "Vln."

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"

% \include "last-page-copyright.ily"

\header {
    instrument = "Violino I"
}

\paper {
    page-count = 17
    ragged-last-bottom = ##f
}

\layout {
    \context {
        \StaffGroup {
            \revert StaffGroup.SystemStartBracket.collapse-height
        }
    }
    \context {
        \GrandStaff {
            \revert PianoStaff.SystemStartBrace.collapse-height
        }
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtIvlnI
    >>

    \header {
        piece = \mvtIpiece
    }
}
\score {
    \keepWithTag #'( PARTS ) \new Staff \with {
    } \context Bottom <<
        \mvtIIvlnI
        \mvtIIcuesVl
        {
            s1*9 |
            s2.*16 |
            \barNumberCheck # 26
            s1*11 |
            \barNumberCheck # 37
            s2.*16 |
            \barNumberCheck # 53
            s1*13 |
            \barNumberCheck # 66
            s2.*11 |
            \pageTurn
        }
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}


\score {
    \new StaffGroup <<
        \new Staff \with {
            instrumentName = \markup\center-column{"Violino" "Solo"}
        } \context Bottom <<
            \mvtIIIvln
            {
                s1*5 |
                \barNumberCheck # 6
                % \break
                s1*24 |
                \barNumberCheck # 30
                \pageTurn
                s1*34 |
                \barNumberCheck # 64
                \pageTurn
            }
        >>
	\new Staff = mvtIIIbass \with {
            \RemoveAllEmptyStaves
            \staffSize #-1.5
        } \context Bottom <<
            \new Voice = mvtIIIbass { \clefSoprano \mvtIIIbass }
            {
                s2.*12 |
                <>^\markup\normalsize\halign #0.2 {Basso}
            }
	    \new Lyrics \with {
		alignBelowContext = "mvtIIIbass"
		\override LyricText.font-size = #-1.5
	    } {
                \lyricsto mvtIIIbass \mvtIIIlyrics
            }
        >>
    >>

    \header {
        piece = \mvtIIIpiece
        % breakbefore = ##t
    }
    \layout {
        indent = 18
    }
}


\score {
    \new StaffGroup <<
        \new Staff \with {
        } \context Bottom <<
            \clef treble \mvtIVvl
        >>
        \new Staff \with {
        } \context Bottom <<
            \clef alto \mvtIVvl
        >>
    >>

    \header {
        piece = \mvtIVpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVvl
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVIvlnI
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
