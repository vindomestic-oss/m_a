\version "2.21.0"

HairpinOffset = #0.8

\include "include-once.ily"
\includeOnce "common-grand-score.ily"

\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"

#(set-global-staff-size 15)

\paper {
    indent = 24
    short-indent = 12
}


% %{
\score {
   \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtIbreaks
        % \new Dynamics \mvtIbreaksNBA

        \new GrandStaff \with {
            instrumentName = \markup\center-column{"Flauto" "traverso"}
            shortInstrumentName = "Fl."
        } <<
            \new Staff \with {
                instrumentName = "1."
                shortInstrumentName = "1."
            } <<
                \mvtIflI
            >>
            \new Staff \with {
                instrumentName = "2."
                shortInstrumentName = "2."
            } <<
                \mvtIflII
            >>
        >>
        \new StaffGroup <<
            \new GrandStaff \with {
                instrumentName = "Violino"
                shortInstrumentName = "Vln."
            } <<
                \new Staff \with {
                    instrumentName = "I."
                    shortInstrumentName = "I."
                } <<
                    \mvtIvlnI
                >>
                \new Staff \with {
                    instrumentName = "II."
                    shortInstrumentName = "II."
                } <<
                    \mvtIvlnII
                >>
            >>
            \new Staff \with {
                instrumentName = "Viola"
                shortInstrumentName = "Vla."
            } <<
                \mvtIvla
            >>
        >>
        \new ChoirStaff <<
            \new Staff \with {
                instrumentName = \markup\bold{Soprano}
                shortInstrumentName = \markup\bold{S.}
            } <<
                \new Voice = mvtIsoprano { \clefSoprano \mvtIsoprano }
                \new Lyrics \lyricsto mvtIsoprano \mvtIsopranoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Alto}
                shortInstrumentName = \markup\bold{A.}
            } <<
                \new Voice = mvtIalto { \clefAlto \mvtIalto }
                \new Lyrics \lyricsto mvtIalto \mvtIaltoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Tenore}
                shortInstrumentName = \markup\bold{T.}
            } <<
                \new Voice = mvtItenor { \clefTenor \mvtItenor }
                \new Lyrics \lyricsto mvtItenor \mvtItenorLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Basso}
                shortInstrumentName = \markup\bold{B.}
            } <<
                \new Voice = mvtIbass \mvtIbass
                \new Lyrics \lyricsto mvtIbass \mvtIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff \with {
                instrumentName = \markup\center-column{"Basso" "Continuo"}
                shortInstrumentName = "B.C."
            } <<
                { \dynamicUp \mvtIbc }
                \mvtIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtIpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtIIbreaks
        % \new Dynamics \mvtIIbreaksNBA

        \new GrandStaff \with {
            instrumentName = \markup\center-column{"Flauto" "traverso"}
            shortInstrumentName = "Fl."
        } <<
            \new Staff \with {
                instrumentName = "1."
                shortInstrumentName = "1."
            } <<
                \mvtIIflI
            >>
            \new Staff \with {
                instrumentName = "2."
                shortInstrumentName = "2."
            } <<
                \mvtIIflII
            >>
        >>
        \new StaffGroup <<
            \new GrandStaff \with {
                instrumentName = "Violino"
                shortInstrumentName = "Vln."
            } <<
                \new Staff \with {
                    instrumentName = "I."
                    shortInstrumentName = "I."
                } <<
                    \mvtIIvlnI
                >>
                \new Staff \with {
                    instrumentName = "II."
                    shortInstrumentName = "II."
                } <<
                    \mvtIIvlnII
                >>
            >>
            \new Staff \with {
                instrumentName = "Viola"
                shortInstrumentName = "Vla."
            } <<
                \mvtIIvla
            >>
        >>
        \new ChoirStaff <<
            \new Staff \with {
                instrumentName = \markup\bold{Soprano}
                shortInstrumentName = \markup\bold{S.}
            } <<
                \new Voice = mvtIIsoprano { \clefSoprano \mvtIIsoprano }
                \new Lyrics \lyricsto mvtIIsoprano \mvtIIsopranoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Alto}
                shortInstrumentName = \markup\bold{A.}
            } <<
                \new Voice = mvtIIalto { \clefAlto \mvtIIalto }
                \new Lyrics \lyricsto mvtIIalto \mvtIIaltoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Tenore}
                shortInstrumentName = \markup\bold{T.}
            } <<
                \new Voice = mvtIItenor { \clefTenor \mvtIItenor }
                \new Lyrics \lyricsto mvtIItenor \mvtIItenorLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Basso}
                shortInstrumentName = \markup\bold{B.}
            } <<
                \new Voice = mvtIIbass \mvtIIbass
                \new Lyrics \lyricsto mvtIIbass \mvtIIbassLyrics
            >>
        >>
        \new StaffGroup <<
            \new Staff \with {
                instrumentName = \markup\center-column{"Basso" "Continuo"}
                shortInstrumentName = "B.C."
            } <<
                { \dynamicUp \mvtIIbc }
                \mvtIIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtIIpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtIIIbreaks
        % \new Dynamics \mvtIIIbreaksNBA

        \new StaffGroup <<
            \new Staff \with {
                instrumentName = \markup\center-column{"Violino" "solo"}
                shortInstrumentName = "Vln."
            } <<
                \mvtIIIvln
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Basso}
                shortInstrumentName = \markup\bold{B.}
            } <<
                \new Voice = mvtIIIbass \mvtIIIbass
                \new Lyrics \lyricsto mvtIIIbass \mvtIIIlyrics
            >>
            \new Staff \with {
                instrumentName = \markup\center-column{"Basso" "Continuo"}
                shortInstrumentName = "B.C."
            } <<
                { \dynamicUp \mvtIIIbc }
                \mvtIIIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtIIIpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtIVbreaks
        % \new Dynamics \mvtIVbreaksNBA

        \new GrandStaff \with {
            instrumentName = \markup\center-column{"Flauto" "traverso"}
            shortInstrumentName = "Fl."
        } <<
            \new Staff \with {
                instrumentName = "1."
                shortInstrumentName = "1."
            } <<
                \mvtIVflI
            >>
            \new Staff \with {
                instrumentName = "2."
                shortInstrumentName = "2."
            } <<
                \mvtIVflII
            >>
        >>
        \new Staff \with {
            instrumentName = \markup\bold{Soprano}
            shortInstrumentName = \markup\bold{S.}
        } <<
            \new Voice = mvtIVsoprano { \clefSoprano \mvtIVsoprano }
            \new Lyrics \lyricsto mvtIVsoprano \mvtIVlyrics
        >>
        \new StaffGroup <<
            \new Staff \with {
                instrumentName = \markup\center-column{"Violino I,II" "Viola"}
                shortInstrumentName = \markup\center-column{"Vln." "Vla."}
            } <<
                \clef alto \mvtIVvl
            >>
        >>
    >>

    \header {
        piece = \mvtIVpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtVbreaks
        % \new Dynamics \mvtVbreaksNBA

        \new Staff \with {
            instrumentName = \markup\center-column{"Violino I,II" "Viola"}
            shortInstrumentName = \markup\center-column{"Vln." "Vla."}
        } <<
            \clef alto \mvtVvl
        >>
        \new Staff \with {
            instrumentName = \markup\bold{Alto}
            shortInstrumentName = \markup\bold{A.}
        } <<
            \new Voice = mvtValto { \clefAlto \mvtValto }
            \new Lyrics \lyricsto mvtValto \mvtVlyrics
        >>
        \new Staff \with {
            instrumentName = \markup\center-column{"Basso" "Continuo"}
            shortInstrumentName = "B.C."
        } <<
            { \dynamicUp \mvtVbc }
            \mvtVfigs
        >>
    >>

    \header {
        piece = \mvtVpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE ) <<
        % \new Dynamics \mvtVIbreaks
        % \new Dynamics \mvtVIbreaksNBA

        \new GrandStaff \with {
            instrumentName = \markup\center-column{"Flauto" "traverso"}
            shortInstrumentName = "Fl."
        } <<
            \new Staff \with {
                instrumentName = "1."
                shortInstrumentName = "1."
            } <<
                \mvtVIflI
            >>
            \new Staff \with {
                instrumentName = "2."
                shortInstrumentName = "2."
            } <<
                \mvtVIflII
            >>
        >>
        \new StaffGroup <<
            \new GrandStaff \with {
                instrumentName = "Violino"
                shortInstrumentName = "Vln."
            } <<
                \new Staff \with {
                    instrumentName = "I."
                    shortInstrumentName = "I."
                } <<
                    \mvtVIvlnI
                >>
                \new Staff \with {
                    instrumentName = "II."
                    shortInstrumentName = "II."
                } <<
                    \mvtVIvlnII
                >>
            >>
            \new Staff \with {
                instrumentName = "Viola"
                shortInstrumentName = "Vla."
            } <<
                \mvtVIvla
            >>
        >>
        \new ChoirStaff <<
            \new Staff \with {
                instrumentName = \markup\bold{Soprano}
                shortInstrumentName = \markup\bold{S.}
            } <<
                \new Voice = mvtVIsoprano { \clefSoprano \mvtVIsoprano }
                \new Lyrics \lyricsto mvtVIsoprano \mvtVIsopranoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Alto}
                shortInstrumentName = \markup\bold{A.}
            } <<
                \new Voice = mvtVIalto { \clefAlto \mvtVIalto }
                \new Lyrics \lyricsto mvtVIalto \mvtVIaltoLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Tenore}
                shortInstrumentName = \markup\bold{TT.}
            } <<
                \new Voice = mvtVItenor { \clefTenor \mvtVItenor }
                \new Lyrics \lyricsto mvtVItenor \mvtVItenorLyrics
            >>
            \new Staff \with {
                instrumentName = \markup\bold{Basso}
                shortInstrumentName = \markup\bold{B.}
            } <<
                \new Voice = mvtVIbass \mvtVIbass
                \new Lyrics \lyricsto mvtVIbass \mvtVIbassLyrics
            >>
        >>
        \new StaffGroup <<
            \new Staff \with {
                instrumentName = \markup\center-column{"Basso" "Continuo"}
                shortInstrumentName = "B.C."
            } <<
                { \dynamicUp \mvtVIbc }
                \mvtVIfigs
            >>
        >>
    >>

    \header {
        piece = \mvtVIpiece
    }
}
% %}
