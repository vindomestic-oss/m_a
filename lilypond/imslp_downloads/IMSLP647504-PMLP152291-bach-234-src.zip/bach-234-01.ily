\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"

mvtItimeline = {
    \key a \major

    \time 3/4 
    \tempo \markup{Kyrie}
    s2.*72 |
    \barNumberCheck # 73
    \bar "||"
    \tempo \markup\column{\line{Christe} \line\smaller{Lente e piano}}
    \time 4/4
    s1*17 |
    \barNumberCheck # 90
    \bar "||"
    \tempo \markup\column{\line{Kyrie} \line\smaller{Vivace}}
    \time 3/8 
    s4.*54 |
    \barNumberCheck # 144
    s4 \tempo \markup\smaller{adagio e forte} s8 |
    s4.*4 |
    \barNumberCheck # 149
    \bar "|."
}

mvtIbreaks = <<
\mvtItimeline
{
    <>^"Breaks left in"
    \repeat unfold 5 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \pageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 20
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 40
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \grace s8
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 64
    \repeat unfold 4 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak | } \pageBreak
    % \time 4/4
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | } \pageBreak
    \barNumberCheck # 80
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \grace s16 \repeat unfold 3 { s1\noBreak | } \pageBreak
    \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
    % \time 3/8
    \repeat unfold 7 { s4.\noBreak | } \pageBreak
    \barNumberCheck # 97
    \repeat unfold 7 { s4.\noBreak | } \break\noPageBreak
    \repeat unfold 7 { s4.\noBreak | } \pageBreak
    \repeat unfold 6 { s4.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak | } \pageBreak
    \barNumberCheck # 123
    \repeat unfold 6 { s4.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak | } \pageBreak
    \repeat unfold 6 { s4.\noBreak | } \break\noPageBreak
    \repeat unfold 8 { s4.\noBreak | } \pageBreak
    \barNumberCheck # 149
}
>>

mvtIflI = <<
\mvtItimeline
\relative c'' {
    cis8.( d16) e8.( a16) fis8.( d16) | %1
    e8.( g16\P) fis8.( d16) e8.( cis16) | %2
    b8.\F( cis16) d8.( e16) cis8.( a16) | %3
    b8.( d16\P) cis8.( a16) b4 | %4
    e2.\f~ | %5
    e16( fis16 g8) g16( fis16 e8) e16( d16 cis8) | %6
    d2.~ | %7
    d16( e16 fis8) fis16( e16 d8) d16( cis16 b8) | %8
    cis16( a16) e'16( cis16) cis16( a16) fis'16( cis16) cis16( a16) gis'16( cis,16) | %9
    cis16( b16) d16( b16) b16( gis16) d'16( cis16) cis16( gis16) b16( a16) | %10
    a16( fis16) d'16( cis16) fis16( e16) a16( gis16) fis16( e16) dis16( e16) | %11
    b8.( d16) cis8.( a16) e8.( gis16) | %12
    a4 r4 r4 | %13
    r4 r8 r16 a'16 fis8.( d16) | %14
    e8.( g16\P) fis8.( d16) e4 | %15
    R2. | %16
    r4 r8 r16 e16\f d8.( b16) | %17
    cis8.( e16\p) d8.( b16) cis4 | %18
    R2.*2 | %19
    dis8.( e16) fis8.( b16) gis8.( e16) | %21
    fis8.( a16) gis8.( e16) fis4 | %22
    R2.*5 | %23
    gis,8.\f( a16) b8.( e16) cis8.( a16) | %28
    b4 r4 r4 | %29
    dis8.( e16) fis8.( b16) gis8.( e16) | %30
    fis4 r4 r4 | %31
    gis16( dis16) b'16( gis16) gis16( eis16) d'16( b16) b16( gis16) eis'16( b16) | %32
    b8( eis,8) r4 r4 | %33
    fis16( cis16) a'16( fis16) fis16( dis16) cis'16( a16) a16( fis16) dis'16( a16) | %34
    a8( dis,8) r4 r4 | %35
    gis8.( e16) cis'4 r4 | %36
    gis8.( dis16) dis'4 r4 | %37
    gis,8.( e16) ais4.\trill gis16 ais16 | %38
    b8.( fis16) gis8.( e16) b8.( dis16) | %39
    e4 r4 r4 | %40
    r4 r8 r16 e16 cis8.( a16) | %41
    b8.( d16\P) cis8.( a16) b4 | %42
    R2. | %43
    r4 r8 r16 b'16\F a8.( fis16) | %44
    gis8.( b16\P) a8.( fis16) gis4 | %45
    R2.*2 | %46
    d8.\f( e16) fis8.( b16) g8.( e16) | %48
    fis8.( d16\p) cis8.( e16) d4 | %49
    R2.*2 | %50
    d8.\f( e16) fis8.( a16) g8.( e16) | %52
    fis8.( a16\P) g8.( e16) fis4 | %53
    R2.*2 | %54
    e8.( fis16) gis8.( b16) a8.( fis16) | %56
    e8.( b'16) a8.( fis16) gis4 | %57
    R2.*5 | %58
    r4 e2~ | %63
    \once \slurDashed e16( fis16 g8) g16( fis16 e8) e16( d16 cis8) | %64
    d2.~ | %65
    \once \slurDashed d16( e16 fis8) fis16( e16 d8) d16( cis16 b8) | %66
    cis16( a16) e'16( cis16) cis16( a16) fis'16( cis16) cis16( a16) gis'16( cis,16) | %67
    cis16( b16) d16( b16) b16( gis16) d'16( cis16) cis16( gis16) b16( a16) | %68
    a16( fis16) d'16( cis16) fis16( e16) a16( gis16) fis16( e16) dis16( e16) | %69
    b8.( d16) cis8.( a16) e8.( gis16) | %70
    cis8.( d16) e8.( a16) fis8.( d16) | %71
    e8.( g16\P) fis8.( d16) e4-\fermata | %72
    % Christe
    <<
        \tag PARTS {
            R1*7 | %73
            \voiceTwo
            R1*3 | %73
            \oneVoice
        }
        \tag SCORE {
            R1*10 | %73
        }
    >>
    a4 a8 e8 cis8 a8 r8 a8 | %83
    e'8. f16 e16 f16 f16\trill e32 f32 g4 r8 a8 | %84
    bes8 bes8 bes8 a8 fis8 fis8(~ fis16 g16) fis16( g16) | %85
    a8( fis8) dis4 r8 fis8 \appoggiatura e16 dis8 \appoggiatura c16 b8 | %86
    g'1~ | %87
    g2~ g8 fis8 g4 | %88
    fis1\fermata | %89
    % Kyrie 2
    <<
        \tag PARTS {
            R4.*18 | %90
            \voiceTwo
            \temporary \override MultiMeasureRest.staff-position = #-8
            R4.*6 | %90
            \oneVoice
            \revert MultiMeasureRest.staff-position
        }
        \tag SCORE {
            R4.*24 | %90
        }
    >>
    r8 b,8. b16 | %114
    fis8. gis16 ais16 b16 | %115
    cis8 d8 e8~ | %116
    e16 dis16 gis16 fis16 eis16 dis16 | %117
    fis16 eis16 dis16 cis16 fis8~ | %118
    fis16[ gis16] gis8.-\parenthesize\trill fis32 gis32 | %119
    a4.~ | %120
    a4.~ | %121
    a8 gis16 fis16 e16 dis16 | %122
    e4.~ | %123
    e4 d16 cis16 | %124
    b4 ais8 | %125
    b16 cis16 d16 e16 fis16 gis16 | %126
    a16 gis16 fis16 e16 b'8~ | %127
    b8 e,4~ | %128
    e8 c'8 a8 | %129
    fis8\trill e16 dis16 e8 | %130
    a8 fis8 b16 a16 | %131
    g16 fis16 e16 d16 cis16 b16 | %132
    cis16 d16 cis16 b16 a16 b16 | %133
    cis8 d8 e8 | %134
    a,8 fis'8. fis16 | %135
    b,8 e4 | %136
    d8( f8) e8 | %137
    fis16 gis16 a8. a16 | %138
    dis,8. e16 fis16 gis16 | %139
    a8 b8 c8~ | %140
    c16 b16 e16 d16 cis16 b16 | %141
    d16 cis16 b16 a16 d8~ | %142
    d16 e16 e8.-\parenthesize\trill d32 e32 | %143
    f4\fermata r8 | %144
    r8 r8 fis,?8 | %145
    b,16 a16 b16 cis16 d16 cis16 | %146
    d16 fis16 e16 d16 cis16 b16 | %147
    cis4.-\fermata | %148
    <>^"Until HERE"
}
>>


mvtIflII = <<
\mvtItimeline
\relative c'' {
    a8.( b16) cis8.( e16) d8.( b16) | %1
    cis8.( e16\p) d8.( b16) cis8.( a16) | %2
    gis8.\f( a16) b8.( gis16) a8.( fis16) | %3
    gis8.( b16\p) a8.( fis16) gis4 | %4
    cis2.\f~ | %5
    cis16( d16 e8) e16( d16 cis8) cis16( b16 ais8) | %6
    b2.~ | %7
    b16( cis16 d8) d16( cis16 b8) b16( a16 gis8) | %8
    a4 r8 r16 fis'16 fis8 eis16.\trill fis32 | %9
    gis4 r8 r16 eis16 fis8. gis16 | %10
    a8. fis16 dis8. b16 a8.\trill( gis32 a32) | %11
    b8.( gis16) a8.( fis16) e8.( gis16) | %12
    a4 r4 r4 | %13
    r4 r8 r16 e'16 d8.( b16) | %14
    cis8.( e16\p) d8.( b16) cis4 | %15
    R2. | %16
    r4 r8 r16 a16\f fis8.( d16) | %17
    e8.( g16\p) fis8.( d16) e4 | %18
    R2.*2 | %19
    b'8.( cis16) dis8.( fis16) e8.( cis16) | %21
    b8.( fis'16) e8.( cis16) dis4 | %22
    R2.*5 | %23
    e,8.\f( fis16) gis8.( b16) a8.( fis16) | %28
    gis4 r4 r4 | %29
    b8.( cis16) dis8.( fis16) e8.( cis16) | %30
    dis4 r4 r4 | %31
    b4 r4 r4 | %32
    \once \slurDashed eis8( gis,8) r4 r4 | %33
    a4 r4 r4 | %34
    dis8( fis,8) r4 r4 | %35
    e'8.( b16) gis'4 r4 | %36
    dis8.( bis16) gis'4 r4 | %37
    \once \slurDashed e8.( gis16) cis,4. cis8 | %38
    b8.( dis16) e8.( cis16) b8.( dis16) | %39
    e4 r4 r4 | %40
    r4 r8 r16 b16 a8.( fis16) | %41
    gis8.( b16\p) a8.( fis16) gis4 | %42
    R2. | %43
    r4 r8 r16 e'16\f cis8.( a16) | %44
    b8.( d16\p) cis8.( a16) b4 | %45
    R2.*2 | %46
    b8.\f( cis16) d8.( fis16) e8.( cis16) | %48
    d8.( b16\p) ais8.( cis16) b4 | %49
    R2.*2 | %50
    fis8.\f( g16) a8.( d16) b8.( g16) | %52
    a8.( c16\p) b8.( g16) a4 | %53
    R2.*2 | %54
    gis8.( a16) b8.( e16) cis8.( a16) | %56
    b8.( d16) cis8.( a16) b4 | %57
    R2.*5 | %58
    r4 cis2~ | %63
    \slurDashed cis16( d16 e8) e16( d16 cis8) cis16( b16 ais8) | %64
    b2.~ | %65
    b16( cis16 d8) \undo \slurDashed d16( cis16 b8) b16( a16 gis8) | %66
    a4 r8 r16 fis'16 eis8. fis16 | %67
    gis4 r8 r16 eis16 fis8. gis16 | %68
    a8. fis16 dis8. b16 a8.\trill( gis32 a32) | %69
    b8.( gis16) a8.( d16) b8.( a16) | %70
    a8.( b16) cis8.( e16) d8.( b16) | %71
    cis8.( e16\p) d8.( b16) cis4-\fermata | %72
    % Christe
    % #(ly:expect-warning "conflict with event: `tempo-change-event'")
    % #(ly:expect-warning "discarding event: `tempo-change-event")
    \quoteDuring mvtIflI {
        s1*17 |
        \barNumberCheck # 90
        % #(ly:expect-warning-times 2 "conflict with event: `tempo-change-event'")
        % #(ly:expect-warning-times 2 "discarding event: `tempo-change-event")
        s4.*59 |
        \barNumberCheck # 149
    }
}
>>


mvtIflCues = <<
\mvtItimeline
\new Voice = mvtIflCues \relative c'' {
    % \time 3/4 
    s2.*72 |
    \barNumberCheck # 73
    % \time 4/4
    s1*7 |
    \barNumberCheck # 80
    \at 2 ^\markup\halign #-0.3 \normalsize{Soprano} \quoteDuring mvtIsoprano {
        \tiny \voiceOne \autoBeamOff
        s1*3 |
    }
    \barNumberCheck # 83
    <>^\markup\halign #-0.3 \normalsize{(Fl.)}
    s1*7
    \barNumberCheck # 90
    % \time 3/8 
    s4.*18 |
    \barNumberCheck # 108
    \at 8 ^\markup\halign #-0.3 \normalsize{Soprano} \quoteDuring mvtIsoprano {
        \tiny \voiceOne \autoBeamOff
        s4.*6 |
    }
    \barNumberCheck # 114
    \at 8 ^\markup\halign #-0.3 \normalsize{(Fl.)}
    s4.*30 |
    \barNumberCheck # 144
    s4.*5 |
    \barNumberCheck # 149
}
\new Lyrics \with {
    \override LyricText.font-size = #-1.5
} \lyricsto mvtIflCues {
    \lyricmode {
        Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son, Chri -- ste,

        Ky -- ri -- e e -- lei -- son, __ e
    }
}
>>

mvtIvlnI = <<
\mvtItimeline
\relative c'' {
    cis8.( d16) e8.( a16) fis8.( d16) | %1
    e4 r4 r4 | %2
    b8.( cis16) d8.( e16) cis8.( a16) | %3
    b4 r4 r4 | %4
    cis16( gis16) e'16( cis16) cis16( ais16) g'16( e16) e16( cis16) ais'16( e16) | %5
    e8( ais,8) r4 r4 | %6
    b16( fis16) d'16( b16) b16( gis16) fis'16( d16) d16( b16) gis'16( d16) | %7
    d8( gis,8) r4 r4 | %8
    cis8.( a16) fis'4 r4 | %9
    cis8.( gis16) gis'4 r4 | %10
    \once \slurDashed cis,8.( a16) dis4.\trill cis16 dis16 | %11
    e8.( b16) cis8.( a16) e8.( gis16) | %12
    a4 r4 r4 | %13
    r4 r8 r16 a'16 fis8.( d16) | %14
    e4 r4 r4 | %15
    R2. | %16
    r4 r8 r16 e16 d8.( b16) | %17
    cis4 r4 r4 | %18
    R2.*2 | %19
    dis8.( e16) fis8.( b16) gis8.( e16) | %21
    fis4 r4 r4 | %22
    R2.*5 | %23
    gis,8.( a16) b8.( e16) \once \slurDashed cis8.( a16) | %28
    b8.( d16\P) cis8.( a16) b8.( e16) | %29
    dis8.\F( e16) fis8.( b16) gis8.( e16) | %30
    fis8.( a16\p) gis8.( e16) fis4 | %31
    gis2.\f~ | %32
    gis16( a16 b8) b16( a16 gis8) gis16( fis16 eis8) | %33
    fis2.~ | %34
    fis16( gis16 a8) a16( gis16 fis8) fis16( e16 dis8) | %35
    e16( b16) b16( gis16) gis16( e16) cis'16( gis16) gis16( e16) dis'16( gis,16) | %36
    gis16( fis16) a16( fis16) fis16( dis16) a'16( gis16) gis16( dis16) fis16( e16) | %37
    e16( cis16) a'16( gis16) cis16( b16) e16( dis16) cis16( b16) ais16( b16) | %38
    fis8.( a'16) \once \slurDashed gis8.( e16) \once \slurDashed b8.( dis16) | %39
    e4 r4 r4 | %40
    r4 r8 r16 e16 cis8.( a16) | %41
    b4 r4 r4 | %42
    R2. | %43
    r4 r8 r16 b'16 \once \slurDashed a8.( fis16) | %44
    gis4 r4 r4 | %45
    R2.*2 | %46
    d8.\f( e16) fis8.( b16) g8.( e16) | %48
    \once \slurDashed fis8.( b16\p) g8.( e16) fis4 | %49
    R2.*2 | %50
    d8.\f( e16) fis8.( a16) g8.( e16) | %52
    fis8.( d16\p) e8.( cis16) d4 | %53
    R2.*2 | %54
    e8.( fis16) gis8.( b16) a8.( fis16) | %56
    e4 r4 r4 | %57
    R2.*5 | %58
    a,16( e16) e'16( cis16) cis16( a16) g'16( e16) e16( cis16) ais'16( e16) | %63
    e8( ais,8) r4 r4 | %64
    b16( fis16) d'16( b16) b16( gis16) fis'16( d16) d16( b16) gis'16( d16) | %65
    d8( gis,8) r4 r4 | %66
    cis8.( a16) fis'4 r4 | %67
    cis8.( gis16) gis'4 r4 | %68
    fis8.( cis16) dis4.-\parenthesize\trill cis16 dis16 | %69
    e8.( b16) cis8.( a16) e8.( gis16) | %70
    cis8.( d16) e8.( a16) fis8.( d16) | %71
    e4 r4 r4\fermata | %72
    % Christe
    gis1\P~ | %73
    gis1~ | %74
    gis2 fis2~ | %75
    fis1 | %76
    e1 | %77
    fis1~ | %78
    fis1~ | %79
    fis2 e2~ | %80
    e1 | %81
    d1 | %82
    e1~ | %83
    e1~ | %84
    e2 d2 | %85
    dis2 fis2~ | %86
    fis4 e8. dis16 e2~ | %87
    e2~ e4~ e16 fis16( dis16 e16) | %88
    e4~ e16 c16 ais16 b16 b2-\fermata | %89
    % Kyrie 2
    dis8 r8 fis8 | %90
    e8 r8 gis8 | %91
    fis8 r8 dis8 | %92
    e8 r8 gis8 | %93
    cis,8 r8 b8 | %94
    b8 r8 ais8 | %95
    b8 r8 fis'8 | %96
    e8 r8 b8 | %97
    gis8 r8 b8 | %98
    a8 r8 a'8 | %99
    fis8 r8 e8 | %100
    a8 r8 fis8 | %101
    e8 r8 g8 | %102
    a8 r8 e8 | %103
    cis8 r8 a8 | %104
    a'8 r8 d,8 | %105
    b8 r8 a8 | %106
    d8 r8 d8 | %107
    c8 r8 e8 | %108
    d8 r8 a'8 | %109
    fis8 r8 d8 | %110
    d8 r8 b'8 | %111
    a8 r8 a8 | %112
    g8 r8 g8 | %113
    fis8 r8 d8 | %114
    e8 r8 cis8 | %115
    ais8 r8 fis8 | %116
    fis'8 r8 b8 | %117
    gis8 r8 fis8 | %118
    fis,8 r8 eis8 | %119
    fis8 fis'16( e16) dis16( cis16) | %120
    dis8( e8) fis8 | %121
    b,4.~ | %122
    b8 gis8 cis8~ | %123
    cis8 b16 ais16 b16 cis16 | %124
    d8 g8 fis8~ | %125
    fis16 e16 d16 cis16 b8~ | %126
    b8 b8. b16 | %127
    e,8 r8 e'8~ | %128
    e8 dis16 e16 fis8~ | %129
    fis8 fis,8 e8 | %130
    c'4 b8 | %131
    b8 e8. d16 | %132
    cis16 b16 cis16 d16 e8 | %133
    a,4.~ | %134
    a8 d16 cis16 b16 a16 | %135
    e'8 gis,8 a8 | %136
    d8. c16 b16 c16 | %137
    a8 r8 a8 | %138
    \once \tieDashed a4.~ | %139
    a8 fis4\trill | %140
    e8 r8 e'8~ | %141
    e8 d16 cis16 d8 | %142
    g8 e8. d16 | %143
    d4-\fermata bes8 | %144
    gis?8( a4)~ | %145
    a8 gis8 fis8 | %146
    gis4. | %147
    a4.\fermata | %148
}
>>


mvtIvlnII = <<
\mvtItimeline
\relative c'' {
    a8.( b16) cis8.( e16) d8.( b16) | %1
    cis4 r4 r4 | %2
    gis8.( a16) b8.( gis16) a8.( fis16) | %3
    gis4 r4 r4 | %4
    gis8.( fis16) gis8.( cis16) cis8.( ais16) | %5
    ais8( cis,8) r4 r4 | %6
    fis8.( e16) fis8.( b16) b8.( gis16) | %7
    gis8( b,8) r4 r4 | %8
    a'8.( e16) cis'4 r4 | %9
    gis8.( eis16) eis'4 r4 | %10
    a,8.( cis16) fis,4. fis8 | %11
    e8.( gis16) a8.( fis16) e8.( e16) | %12
    e4 r4 r4 | %13
    r4 r8 r16 e'16 d8.( b16) | %14
    cis4 r4 r4 | %15
    R2. | %16
    r4 r8 r16 a16 fis8.( d16) | %17
    e4 r4 r4 | %18
    R2.*2 | %19
    b'8.( cis16) dis8.( fis16) \once \slurDashed e8.( cis16) | %21
    b4 r4 r4 | %22
    R2.*5 | %23
    e,8.( fis16) gis8.( b16) a8.( fis16) | %28
    gis8.( b16\p) a8.( fis16) gis8.( ais16) | %29
    b8.\f( cis16) dis8.( fis16) e8.( cis16) | %30
    dis8.( fis16\p) e8.( cis16) dis4 | %31
    b2.\f~ | %32
    b16( cis16 d8) d16( cis16 b8) b16( a16 gis8) | %33
    a2.~ | %34
    a16( b16 cis8) cis16( b16 a8) a16( gis16 fis8) | %35
    gis4 r8 r16 cis16 bis8.\trill cis16 | %36
    dis4 r8 r16 bis16 cis8. dis16 | %37
    e8.( cis16) ais8.( fis16) e8.-\parenthesize\trill dis32 e32 | %38
    \once \slurDashed fis8.( dis'16) \once \slurDashed e8.( cis16) \once \slurDashed b8.( b16) | %39
    b4 r4 r4 | %40
    r4 r8 r16 b16 a8.( fis16) | %41
    gis4 r4 r4 | %42
    R2. | %43
    r4 r8 r16 e'16 cis8.( a16) | %44
    b4 r4 r4 | %45
    R2.*2 | %46
    b8.\f( cis16) d8.( fis16) e8.( cis16) | %48
    d8.( fis16\p) e8.( cis16) d4 | %49
    R2.*2 | %50
    fis,8.\f( g16) a8.( d16) b8.( g16) | %52
    a8.( fis16\p) g8.( bes16) a4 | %53
    R2.*2 | %54
    gis8.( a16) b8.( e16) cis8.( a16) | %56
    b4 r4 r4 | %57
    R2.*5 | %58
    e,8.( gis16) a8.( cis16) cis8.( ais16) | %63
    ais8( cis,8) r4 r4 | %64
    \slurDashed fis8.( e16) fis8.( b16) b8.( gis16) \undo \slurDashed  | %65
    gis8( b,8) r4 r4 | %66
    a'8.( e16) cis'4 r4 | %67
    gis8.( eis16) eis'4 r4 | %68
    a,8.( cis16) fis,4. fis8 | %69
    e8.( gis16) a8.( d16) b8.( a16) | %70
    a8.( b16) cis8.( e16) d8.( b16) | %71
    cis4 r4 r4\fermata | %72
    % Christe
    cis1\p~ | %73
    cis2 d2~ | %74
    d2 cis2~ | %75
    cis1~ | %76
    cis1 | %77
    dis1~ | %78
    dis1~ | %79
    dis2 b2~ | %80
    b1~ | %81
    b1 | %82
    cis1~ | %83
    cis1~ | %84
    cis2 a2~ | %85
    a2. c8( b8) | %86
    b8 b8 \appoggiatura a16 g8 \appoggiatura fis16 e8 bes'2~ | %87
    ais2~ ais8 cis?16 b16 cis4~ | %88
    cis16 \once \slurDashed ais16( fis16 g16) e4\trill dis2\fermata | %89
    % Kyrie 2
    b'8 r8 b8 | %90
    b8 r8 b8 | %91
    b8 r8 b8 | %92
    b8 r8 gis8 | %93
    fis8 r8 d8 | %94
    g8 r8 fis8 | %95
    fis8 r8 b8 | %96
    b8 r8 gis8 | %97
    e8 r8 e8 | %98
    e'8 r8 fis8 | %99
    fis,8 r8 c'8 | %100
    a8 r8 a8 | %101
    g8 r8 b8 | %102
    a8 r8 a8 | %103
    a8 r8 a8 | %104
    a8 r8 b8 | %105
    gis8 r8 c8 | %106
    f,8 r8 b8 | %107
    a8 r8 c8 | %108
    c8 r8 c8 | %109
    c8 r8 d8 | %110
    d,8 r8 g8 | %111
    e8 r8 b'8 | %112
    b8 r8 cis8 | %113
    a8 r8 b8 | %114
    cis8 r8 cis,8 | %115
    fis8 r8 fis8 | %116
    fis8 r8 gis8 | %117
    gis8 r8 d8 | %118
    d8 r8 cis8 | %119
    cis8 fis8. fis16 | %120
    b,8. cis16 dis16 e16 | %121
    fis8 gis8 a8~ | %122
    a16 gis16 cis16 b16 ais16 gis16 | %123
    b16 ais16 gis16 fis16 b8~ | %124
    b16[ cis16] cis8.-\parenthesize\trill b32 cis32 | %125
    d4.~ | %126
    d4.~ | %127
    d8 cis16 b16 a16 gis16 | %128
    a4.~ | %129
    a4 g16 fis16 | %130
    e4 dis8 | %131
    e4.~ | %132
    e4.~ | %133
    e8 a16 g16 fis16 e16 | %134
    d4 fis8 | %135
    e4 e8 | %136
    f8 b,8 e8 | %137
    a,8 r8 fis'8 | %138
    fis4.~ | %139
    fis8 dis8 fis8 | %140
    b,8 r8 e8~ | %141
    e8 e8 d8~ | %142
    d8 bes'8 a8 | %143
    a4\fermata r8 | %144
    r8 r8 fis8 | %145
    e4.~ | %146
    e4. | %147
    e4.-\fermata | %148
}
>>


mvtIvla = <<
\mvtItimeline
\relative c' {
    \clef C
    e4 a4 d,4 | %1
    a8-. a'8-. a8-. a,8-. a4 | %2
    e'4 e4 a,4 | %3
    e8 e'8 e8 e,8 e4 | %4
    e'8.( d16) e8.( fis16) fis8.( g16) | %5
    g8( fis8) r4 r4 | %6
    d8.( cis16) d8.( fis16) e8.( b16) | %7
    b8( e,8) r4 r4 | %8
    e'8.( a16) fis4 r4 | %9
    gis8.( b16) cis,4 r4 | %10
    fis8.( cis16) b4. b8 | %11
    b8.( e16) e8.( d16) cis8.( b16) | %12
    cis4 r4 r4 | %13
    r4 a'4 d,4 | %14
    a8-. a'8-. a8-. a,8-. a4 | %15
    R2. | %16
    r4 a'4 d,4 | %17
    a8 a'8 a8 a,8 a4 | %18
    R2.*2 | %19
    fis'4 b4 e,4 | %21
    b8 b'8 b8 b,8 b4 | %22
    R2.*5 | %23
    b4 e4 a,4 | %28
    e8 e'8 e8 e,8 e8 cis'8 | %29
    b4 b'4 e,4 | %30
    b8 b'8 b8 b,8 b4 | %31
    dis4 r4 r4 | %32
    cis4 r4 r4 | %33
    cis4 r4 r4 | %34
    b4 r4 r4 | %35
    \once \slurDashed b8.( e16) cis4 r4 | %36
    \once \slurDashed dis8.( fis16) gis,4 r4 | %37
    \once \slurDashed cis8.( gis16) fis4. fis'8 | %38
    fis8.( b16) \once \slurDashed b8.( a16) gis8.( fis16) | %39
    gis4 r4 r4 | %40
    r4 e4 a,4 | %41
    e8 e'8 e8 e,8 e4 | %42
    R2. | %43
    r4 e'4 a,4 | %44
    e8 e'8 e8 e,8 e4 | %45
    R2.*2 | %46
    fis'4 b4 e,4 | %48
    b8 b'8 b8 b,8 b4 | %49
    R2.*2 | %50
    a4 d4 g,4 | %52
    d8 d'8 d8 d,8 d4 | %53
    R2.*2 | %54
    b''4 e,4 a4 | %56
    e8 e'8 e8 e,8 e4 | %57
    R2.*5 | %58
    cis8.( e16) e8.( fis16) fis8.( g16) | %63
    g8( fis8) r4 r4 | %64
    d8.( cis16) d8.( fis16) e8.( b16) | %65
    b8( e,8) r4 r4 | %66
    e'8.( a16) fis4 r4 | %67
    \once \slurDashed gis8.( b16) cis,4 r4 | %68
    \once \slurDashed fis8.( a16) b,4. b8 | %69
    \once \slurDashed b8.( e16) e8.( d16) d8.\trill( cis16) | %70
    cis4 a'4 d,4 | %71
    a8 a'8 a8 a,8 a4-\fermata | %72
    % Christe
    gis'1\p~ | %73
    gis1 | %74
    b2 fis2~ | %75
    fis2 ais2~ | %76
    ais1 | %77
    fis1 | %78
    b2 a2~ | %79
    a2 gis2~ | %80
    gis1~ | %81
    gis1 | %82
    e1 | %83
    a2 g2~ | %84
    g4 e4 fis2~ | %85
    fis2. a4 | %86
    g2~ g8 g8 \appoggiatura fis16 e8 \appoggiatura d16 c8 | %87
    cis!2~ cis8 e16 dis16 e4~ | %88
    e8 ais,8 b8 cis8 fis,2-\fermata | %89
    % Kyrie 2
    fis'8 r8 dis8 | %90
    e8 r8 b8 | %91
    b8 r8 fis'8 | %92
    e8 r8 b8 | %93
    fis'8 r8 g8 | %94
    cis,8 r8 cis8 | %95
    b8 r8 d8 | %96
    e8 r8 d8 | %97
    b8 r8 gis'8 | %98
    e8 r8 a,8 | %99
    b8 r8 e8 | %100
    c8 r8 b8 | %101
    b8 r8 e8 | %102
    e8 r8 cis8 | %103
    a8 r8 a8 | %104
    d8 r8 d8 | %105
    e8 r8 a,8 | %106
    a'8 r8 e8 | %107
    e8 r8 a8 | %108
    a8 r8 fis8 | %109
    d8 r8 fis8 | %110
    g8 r8 g,8 | %111
    a8 r8 fis'8 | %112
    d8 r8 a'8 | %113
    a,8 r8 fis'8 | %114
    fis8 r8 fis8 | %115
    cis8 r8 fis8 | %116
    b,8 r8 b8 | %117
    cis8 r8 fis8 | %118
    b,8 r8 b8 | %119
    a8 r8 r8 | %120
    R4.*5 | %121
    r8 b8. b16 | %126
    e,8. fis16 gis16 a16 | %127
    b8 cis8 d8~ | %128
    d16 cis16 fis16( e16) dis16( cis16) | %129
    e16 dis16 cis16 b16 e8~ | %130
    e16[ fis16] fis8.-\parenthesize\trill e32 fis32 | %131
    g4.~ | %132
    g4.~ | %133
    g8 fis16 e16 d16 cis16 | %134
    d4.~ | %135
    d4 c16 b16 | %136
    a4 gis8 | %137
    a4 fis8 | %138
    dis'4.~ | %139
    dis8 fis,8 a8 | %140
    gis8 b8. b16 | %141
    a4 d,8 | %142
    d'4 cis8 | %143
    d4-\fermata r8 | %144
    r8 r8 c8 | %145
    b4. | %146
    b8 cis?8 d8 | %147
    cis4.-\fermata | %148
}
>>


mvtIsoprano = <<
\mvtItimeline
\relative c'' {
    \autoBeamOff
    R2.*12 | %1
    cis8. d16 e8[ a,8] fis'4 | %13
    fis8([ e8)] e4 r4 | %14
    R2. | %15
    a,8. b16 cis8.([ d32 e32)] d4 | %16
    d8([ cis8)] cis4 r4 | %17
    R2. | %18
    b4. d8 cis4 | %19
    b4 cis8.([ \melisma dis16) e8.( fis16)] | %20
    dis8.([ e16)] fis4 e4~ | %21
    e8.([ dis16) e8.( gis16)] fis4~ | %22
    fis8.([ dis16) e8.( fis16)] gis4~ | %23
    gis4 fis8.[ e16 dis8. cis16] | %24
    dis8.[ b16] \melismaEnd e4. d8 | %25
    cis8.([ fis16) dis8.( cis16)] b4~ | %26
    b8 cis8 fis,4. e8 | %27
    e4 r4 r4 | %28
    R2.*11 | %29
    gis8. a16 b8([ e,8)] cis'4 | %40
    cis8([ b8)] b4 r4 | %41
    R2. | %42
    b8. dis16 e4 e4 | %43
    fis8([ dis8)] e4 r4 | %44
    R2. | %45
    b4. b8 e4~ | %46
    e8 d8 \once \slurDashed cis4( d16[ e16 fis8] | %47
    \appoggiatura e8 d4) \appoggiatura cis8 b4 r4 | %48
    R2. | %49
    fis'4. d8 b4~ | %50
    b8 d8 cis4. d8 | %51
    d2 r4 | %52
    R2. | %53
    cis4. e8 d8.[ fis16] | %54
    e4 e8.[ \melisma d16 cis8. d16] | %55
    b8.([ cis16) d8.( b16) cis8.( e16)] | %56
    d8.[ b16 cis8. e16] d4~ | %57
    d8.[ b16 cis8. d16] e4~ | %58
    e4 d8.[ cis16 b8. a16] | %59
    b4 \melismaEnd e,4 e'4~ | %60
    e8. fis16 d8.[ cis16] b8.[ d16] | %61
    cis8.[ \melisma a16] a4( gis4) | %62
    \melismaEnd a4 e'8. e16 e4 | %63
    r8 g8 g16([ \melisma fis16 e8)] e16([ d16 cis8)] | %64
    d2.~ | %65
    d16[ e16 fis8] fis16([ e16 d8)] d16([ cis16 b8)] | %66
    cis2.~ | %67
    cis2.~ | %68
    cis8.[ fis16] dis4.\trill cis16[ dis16] | %69
    e8.[ b16] \melismaEnd cis8. d16 b8.\trill[ a16] | %70
    a4 r4 r4 | %71
    R2.\fermata | %72
    % Christe
    R1*7 | %73
    r2 e'4 e8 b8 | %80
    gis8 e8 r8 e8 b'8.([ \melisma c16)] b16[ c16 c16\trill( b32 c32)] | %81
    \melismaEnd d4 r8 e8 f8 f8 f8 e8 | %82
    \appoggiatura d16 cis8 cis8.([ d16)] cis16([ d16)] e8[ cis8] a4 | %83
    r8 e'8 \appoggiatura d16 cis8 \appoggiatura b16 a8 bes4 bes4 | %84
    r8 g8 e8[ \melisma cis'8] d4 \melismaEnd d,4 | %85
    r8 fis'8 \appoggiatura e16 dis8 \appoggiatura c16 b8 c8[ a8] fis8 fis'8 | %86
    fis4 \melisma e8.[ dis16] e2~ | %87
    e2~ e4~ e16([ fis16) dis16( e16)] | %88
    e4~ e16[ c16 ais16 b16] \melismaEnd b2-\fermata | %89
    % Kyrie 2
    R4.*18 | %90
    r8 a8. a16 | %108
    d,8. e16[ fis16 g16] | %109
    a8[ b8 c8]~ | %110
    c16[ b16 e16 d16 cis16 b16] | %111
    \melisma d16([ cis16) b16( a16)] \melismaEnd d8(~ | %112
    d16[ e16)] e8.\trill[ d32 e32] | %113
    fis4.~ | %114
    fis4.~ | %115
    fis16([ e16)] d16([ cis16)] b16([ ais16)] | %116
    b4.~ | %117
    b4 a16[ gis16] | %118
    fis8 \once \slurDashed fis8( eis8) | %119
    fis8 fis'16([ e16)] dis16([ cis16)] | %120
    dis8[ e8] fis8 | %121
    b,4.~ | %122
    b8[ gis8 cis8~] | %123
    cis8 b16[ ais16] b16[ cis16] | %124
    d8[ g8 fis8~] | %125
    fis16[ e16 d16 cis16] b8~ | %126
    b8 b8. b16 | %127
    e,8 r8 e'8 | %128
    e8[ dis16 e16 fis8~] | %129
    fis8 fis,8 e8 | %130
    \once \slurDashed c'4( b8) | %131
    b8 e8. d16 | %132
    cis8 cis16[ d16 e8] | %133
    a,4.~ | %134
    a8[ \melisma d16 cis16 b16 a16] | %135
    e'8[ gis,8] \melismaEnd a8 | %136
    d8 d16[ c16 b16 c16] | %137
    a4 a8 | %138
    a4.~ | %139
    \melisma a8 fis4\trill | %140
    \melismaEnd e8 r8 e'8~ | %141
    e8 d16[ cis16] d8 | %142
    g8 \appoggiatura f8 e8.\trill \melisma d16 | %143
    \melismaEnd d4-\fermata bes8 | %144
    gis?8 \melisma a4~ | %145
    a8[ gis8 fis8] | %146
    gis4.\trill | %147
    \melismaEnd a4.\fermata | %148
}
>>


mvtIsopranoLyrics = \lyricmode {
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son, __ e -- le -- i -- son;
    %29->40
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- le -- i -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son.

    %73 ->80
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste, Chri -- ste __ e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son.

    %90 -> 108
    Ky -- ri -- e e -- lei -- son, __
    e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son, __
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son.
}


mvtIalto = <<
\mvtItimeline
\relative c' {
    \autoBeamOff
    R2.*12 | %1
    e8. gis16 a4 a4 | %13
    a4 a4 r4 | %14
    R2. | %15
    e8. gis16 a4 a4 | %16
    a4 a4 r4 | %17
    R2. | %18
    gis4. gis8 a4 | %19
    b4 b8.([ \melisma a16 gis8. a16)] | %20
    fis8.[ gis16 a8. fis16 gis8. b16] | %21
    a8.[ fis16 gis8. b16] a4~ | %22
    a8.[ fis16 gis8. a16] b4~ | %23
    b4 a8.[ gis16 fis8. e16] | %24
    b'8.[ fis16 gis8. a16] \melismaEnd b4~ | %25
    b8. cis16 a4. a8 | %26
    gis8. e16 e4( dis4) | %27
    b4 r4 r4 | %28
    R2.*11 | %29
    e8. fis16 gis8.([ a32 b32)] a4 | %40
    a8([ gis8)] gis4 r4 | %41
    R2. | %42
    gis8. a16 b8([ e,8)] cis'4 | %43
    cis8([ b8)] b4 r4 | %44
    R2. | %45
    gis4. gis8 ais4 | %46
    b4 b4( ais4 | %47
    b4) fis4 r4 | %48
    R2. | %49
    d4. d8 g4~ | %50
    g8 fis8 e4( fis16[ g16 a8] | %51
    \appoggiatura g8 fis4) \appoggiatura e8 d4 r4 | %52
    R2. | %53
    a'4. a8 a8([ gis8)] | %54
    a8.[ e16] fis8.([ \melisma gis16) a8.( b16)] | %55
    gis8.([ a16)] b4 a4~ | %56
    a8.[ gis16 a8. cis16] b4~ | %57
    b8.[ gis16 a8. b16] cis4~ | %58
    cis4 b8.[ a16 gis8. fis16] | %59
    gis8.[ e16] \melismaEnd a4. g8 | %60
    fis4 \melisma gis8.[ a16] \melismaEnd e4~ | %61
    e8 fis8 e4( d4) | %62
    cis4 a'8. cis16 cis4 | %63
    r8 ais8 \once \slurDashed ais16([ \melisma b cis8)] \once \slurDashed cis16([ b16 ais8)] | %64
    b2.~ | %65
    b16[ cis16 d8] \once \slurDashed d16([ cis16 b8)] \once \slurDashed b16([ a16 gis8)] | %66
    a2. | %67
    gis2. | %68
    fis8.[ a16] fis4.\trill( e16[ fis16] | %69
    gis8.[ b16)] \melismaEnd a8. b16 gis4 | %70
    e4 r4 r4 | %71
    R2.\fermata | %72
    % Christe
    R1*5 | %73
    b'4 b8 fis8 dis8 b8 r8 b8 | %78
    fis'8.[ g16] \melisma fis16[ g16 g16\trill fis32 g32] \melismaEnd a4 r8 b8 | %79
    c8 c8 c8 b8 gis8 gis8.([ a16)] gis16[ a16] | %80
    b8([ gis8)] e4 r8 b'8 \appoggiatura \parenthesize a16 gis8 \appoggiatura \parenthesize fis16 e8 | %81
    f4 f4 r8 d8\( b8[ \melisma gis'8] | %82
    a4\) \melismaEnd a,4 a'4 a8 e8 | %83
    cis8 a8 r8 a8 e'8.[ \melisma f16] e16[ f16 f16\trill e32 f32] | %84
    \melismaEnd g4 r8 a8 a2~ | %85
    a16[ gis16 a8] a4 r2 | %86
    r8 b8 \appoggiatura a16 g8 \appoggiatura fis16 e8 bes'2~ | %87
    \melisma ais2~ ais8[ cis?16 b16] cis4~ | %88
    cis16[ ais16 fis16 g16] e4\trill \melismaEnd dis2-\fermata | %89
    % Kyrie 2
    R4.*12 | %90
    r8 e8. e16 | %102
    a,8. b16[ cis16 d16] | %103
    e8[ \melisma fis8 g8~] | %104
    g16[ fis16 b16 a16 gis16 fis16] | %105
    a16[ gis16 fis16 e16] \melismaEnd a8(~ | %106
    a16[ b16)] b8.\trill([ a32 b32)] | %107
    c4.~ | %108
    c4.~ | %109
    c8 b16([ a16)] g16([ fis16)] | %110
    g4.~ | %111
    g4 fis16[ e16] | %112
    d8 d8( cis8) | %113
    d4 d8 | %114
    cis4.~ | %115
    cis8[ \melisma fis16 e16 d16 cis16] | %116
    b8 \melismaEnd dis8 gis8~ | %117
    gis8 eis8 fis8 | %118
    d4( cis8) | %119
    cis8 fis8. fis16 | %120
    b,8. cis16[ dis16 e16] | %121
    fis8[ \melisma gis8 a8]~ | %122
    a16[ gis16 cis16 b16 ais16 gis16] | %123
    b16[ ais16 gis16 fis16] \melismaEnd b8(~ | %124
    b16[ cis16)] cis8.\trill[ b32 cis32] | %125
    d4.~ | %126
    d4.~ | %127
    d8 cis16([ b16)] a16([ gis16)] | %128
    a4.(~ | %129
    a4 g16[ fis16)] | %130
    e4 dis8 | %131
    e4.~ | %132
    e4.~ | %133
    e8[ a16 g16 fis16 e16] | %134
    d4 fis8 | %135
    e4 e8 | %136
    f8 b,8([ e8)] | %137
    a,4 fis'8 | %138
    fis4.~ | %139
    fis8[ dis8 fis8] | %140
    b,8 r8 e8~ | %141
    e8 e8 d8 | %142
    d8 bes'8( a8) | %143
    a4-\fermata r8 | %144
    r8 r8 fis8 | %145
    e4.~ | %146
    e4. | %147
    e4.-\fermata | %148
}
>>


mvtIaltoLyrics = \lyricmode {
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, __ e -- lei -- son, e -- le -- i -- son;
    %29->40
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    e -- lei -- son, __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son.

    %73 ->80
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste, Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son.

    %90 -> 108
    Ky -- ri -- e e -- lei -- son, __
    e -- lei -- son, e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, __
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son.
}


mvtItenor = <<
\mvtItimeline
\relative c' {
    \autoBeamOff
    R2.*12 | %1
    a8. b16 cis8.([ d32 e32)] d4 | %13
    d8([ cis8)] cis4 r4 | %14
    R2. | %15
    cis8. d16 e8([ a,8)] fis'4 | %16
    fis8([ e8)] e4 r4 | %17
    R2. | %18
    e4. e8 e4 | %19
    e4 e8.[ \melisma a,16] b4~ | %20
    b4. dis8[ e8. gis16] | %21
    fis4 \melismaEnd b,4 dis8. fis16 | %22
    b,4. dis8 e8.[ \melisma b16] | %23
    cis4. b8[ a8. gis16] | %24
    \melismaEnd fis4 b4. gis8 | %25
    cis8. a16 fis'4. dis8 | %26
    e8. cis16 b4( a4) | %27
    gis4 r4 r4 | %28
    R2.*11 | %29
    b8. dis16 e4 e4 | %40
    e4 e4 r4 | %41
    R2. | %42
    e8. b16 b4 e,4 | %43
    a8([ b8)] e,4 r4 | %44
    R2. | %45
    e'4. e8 e8([ cis8)] | %46
    fis4 fis2~ | %47
    fis4 d4 r4 | %48
    R2. | %49
    fis4. a8 d,4 | %50
    e8[ a,8] a2~ | %51
    a8[ g8] fis4 r4 | %52
    R2. | %53
    fis'4. cis8 d4 | %54
    cis8.[ b16] a4 a4 | %55
    b4. gis8 a8. cis16 | %56
    b4 e,4 gis8.[ b16] | %57
    e4. \melisma gis,8[ a8. e'16] | %58
    fis4. e8[ d8. cis16] | %59
    \melismaEnd b4 e4. cis8 | %60
    fis8. d16 b8.[ cis16 d8. gis,16] | %61
    a8. a16 cis4( b4) | %62
    a4 cis8. fis16 fis4 | %63
    R2. | %64
    r8 d8 \once \slurDashed d16([ \melisma cis16 b8)] \once \slurDashed b16([ a16 gis8)] | %65
    gis4. \melismaEnd a8 b16([ cis16 d8)] | %66
    e,4 \melisma cis'2~ | %67
    cis2.~ | %68
    cis4 b2~ | %69
    b8.[ e16] \melismaEnd e8. d16 d8.([ cis16)] | %70
    cis4 r4 r4 | %71
    R2.\fermata | %72
    % Christe
    R1*2 | %73
    r2 fis4 fis8 cis8 | %75
    ais8 fis8 r8 fis8 cis'8.[ \melisma d16] cis16[ d16 d16\trill cis32 d32] | %76
    \melismaEnd e4 r8 fis8 g8 g8 g8 fis8 | %77
    dis8 dis8.([ e16)] dis16[ e16] fis8[ dis8] b4 | %78
    r8 fis'8 \appoggiatura e16 dis8 \appoggiatura cis16 b8 c4 c4 | %79
    r8 a8 fis8[ \melisma dis'8] e4 \melismaEnd e,4 | %80
    e'4 e8 b8 gis8 e8 r8 e8 | %81
    b'8.[ \melisma c8] b16[ c16 c16\trill b32 c32] \melismaEnd d4 r8 e16 | %82
    e2~ e4~ e16[ d16 cis16 b16] | %83
    a4 r4 r8 e'4 d8 | %84
    cis4 \appoggiatura d16 cis8 b16([ a16)] d8 d,8 d'4 | %85
    dis8 b8 fis8 dis8 s2*1 | %86
    r2 r8 g'8 \appoggiatura fis16 e8 \appoggiatura d16 c8 | %87
    cis!2~ \melisma cis8[ e16 dis16] e4~ | %88
    e8[ ais,8 b8 cis8] \melismaEnd fis,2-\fermata | %89
    % Kyrie 2
    R4.*6 | %90
    r8 b8. b16 | %96
    e,8. fis16[ gis16 a16] | %97
    b8[ \melisma cis8 d8~] | %98
    d16[ cis16 fis16 e16 dis16 cis16] | %99
    e16[ dis16 cis16 b16] \melismaEnd e8(~ | %100
    e16[ fis16)] fis8.\trill[ e32 fis32] | %101
    g4.~ | %102
    g4.~ | %103
    g8 fis16([ e16)] d16([ cis16)] | %104
    d4.~ | %105
    d4 c16[ b16] | %106
    a8 a8[ gis8] | %107
    a4 e8 | %108
    a4.~ | %109
    \melisma a8[ d16 c16 b16 a16] | %110
    g8 \melismaEnd b8 e8~ | %111
    e8 cis8 d8 | %112
    b4( a8) | %113
    a8 fis'8 fis8 | %114
    e8[ cis8] ais8~ | %115
    ais8 b8[ fis8] | %116
    fis8 gis8. gis16 | %117
    gis8 cis4 | %118
    b4 b8 | %119
    a8 r8 r8 | %120
    R4.*5 | %121
    r8 b8. b16 | %126
    e,8. fis16[ gis16 a16] | %127
    b8[ \melisma cis8 d8]~ | %128
    d16[ cis16 fis16 e16 dis16 cis16] | %129
    e16[ dis16 cis16 b16] \melismaEnd e8(~ | %130
    e16[ fis16)] fis8.\trill[ e32 fis32] | %131
    g4.~ | %132
    g4.~ | %133
    g8 fis16[ e16] d16[ cis16] | %134
    d4.~ | %135
    d4 c16[ b16] | %136
    a8 a8 gis8 | %137
    a4 fis8 | %138
    dis'4.~ | %139
    dis8[ fis,8 a8] | %140
    gis8 b8. b16 | %141
    a4 d,8 | %142
    d'4 cis8 | %143
    d4-\fermata r8 | %144
    r8 r8 c8 | %145
    b4.~ | %146
    b8[ cis?8 d8] | %147
    cis4.-\fermata | %148
}
>>


mvtItenorLyrics = \lyricmode {
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- le -- i -- son;
    %29->40
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    e -- lei -- son.

    %73 ->80
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste, Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste, Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son.

    %90 -> 108
    Ky -- ri -- e e -- lei -- son, __
    e -- lei -- son, e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- le -- i -- son,
    Ky -- ri -- e e -- lei -- son, __
    e -- lei -- son, e -- lei -- son, e -- le -- i -- son, e -- lei -- son,
    Ky -- ri -- e e -- le -- i -- son, e -- lei -- son.
}


mvtIbass = <<
\mvtItimeline
\relative c' {
    \autoBeamOff
    \clef F
    R2.*12 | %1
    a8. a,16 a'4 a4 | %13
    a4 a,4 r4 | %14
    R2. | %15
    a'8. a,16 a'4 a4 | %16
    a4 a,4 r4 | %17
    R2. | %18
    e'4. e8 a4 | %19
    gis4 a4 \melisma e4 | %20
    b'2.~ | %21
    b4 \melismaEnd b,4 b'8. a16 | %22
    gis4. fis8 e8.[ gis16] | %23
    a2.~ | %24
    a4 gis8.[ fis16] gis8.[ e16] | %25
    fis4. e8 dis8.[ b16] | %26
    e8. a16 b4( b,4) | %27
    e4 r4 r4 | %28
    R2.*11 | %29
    e8. e16 e4 e'4 | %40
    e4 e,4 r4 | %41
    R2. | %42
    e8. fis16 gis8.[ a32 b32] a4 | %43
    a8([ gis8)] gis4 r4 | %44
    R2. | %45
    e4. d8 cis4 | %46
    b4 \once \slurDashed fis'2( | %47
    b4) b,4 r4 | %48
    R2. | %49
    b'4. fis8 g8.[ fis16] | %50
    e8.[ d16] a'4 a,4 | %51
    d2 r4 | %52
    R2. | %53
    fis4. fis8 b,4 | %54
    cis4 d4 \melisma a4 | %55
    e'2.~ | %56
    e4 \melismaEnd e,4 e'8. d16 | %57
    cis4. b8 a8.[ cis16] | %58
    d2.~ | %59
    d8[ d'8] cis8.[ b16] cis8.[ a16] | %60
    b4. a8 gis8.[ e16] | %61
    a8. d,16 e2 | %62
    a,4 a'8. a16 fis4 | %63
    R2. | %64
    r8 b8 \slurDashed b16([ \melisma a16 gis8)] gis16([ fis16 e8)] | %65
    e4. \melismaEnd fis8 gis16([ a16 b8)] \undo \slurDashed | %66
    a4. \melisma b16[ a16] gis16[ a16 fis8] | %67
    eis4 \melismaEnd cis4 r4 | %68
    fis8. gis16 a8.([ fis16)] b8.([ 16)] | %69
    gis8.[ e16] a8 d,8 e4 | %70
    a,4 r4 r4 | %71
    R2.\fermata | %72
    % Christe
    cis'4 cis8 gis8 eis8 cis8 r8 cis8 | %73
    gis'8.[ \melisma a16] gis16[ a16 a16\trill gis32 a32] \melismaEnd b4 r8 cis8 | %74
    d8 d8 d8 cis8 ais8 ais8.[ b16] ais16[ b16] | %75
    cis8[ ais8] fis4 r8 cis'8 ais8 fis8 | %76
    g4 g4 r8 e8 cis8[ ais'8] | %77
    \melisma b4 \melismaEnd b,4 b'4 b8 fis8 | %78
    dis8 b8 r8 b8 fis'8.[ \melisma g16] fis16[ g16 g16\trill fis32 g32] | %79
    \melismaEnd a4 r8 b8 b2~ | %80
    b4~ b16[ a16 gis16 fis16] e4 r4 | %81
    r8 b'4 a8 gis4 \appoggiatura a16 gis8 fis16[ e16] | %82
    a8 a,8 a'4 a8 e8 cis8 a8 | %83
    r8 cis8[ e8 a8] cis4 cis4 | %84
    r4 r8 e,8 c2 | %85
    b2 s2*1 | %86
    R1 | %87
    r8 g'8 \appoggiatura fis16 e8 \appoggiatura d16 cis8 ais2 | %88
    b1\fermata | %89
    % Kyrie 2
    r8 fis'8. fis16 | %90
    b,8. cis16[ dis16 e16] | %91
    fis8[ \melisma gis8 a8~] | %92
    a16[ gis16 cis16 b16 ais16 gis16] | %93
    b16[ ais16 gis16 fis16] \melismaEnd b8(~ | %94
    b16[ cis16)] cis8.\trill[ b32 cis32] | %95
    d4.~ | %96
    d4.~ | %97
    d8 cis16([ b16)] a16([ gis16)] | %98
    a4.~ | %99
    a4 g16[ fis16] | %100
    e8 \once \slurDashed e8( dis8) | %101
    e4 b8 | %102
    e4.~ | %103
    \melisma e8[ a16 g16 fis16 e16] | %104
    d8 \melismaEnd fis8 b8~ | %105
    b8 gis?8 a8 | %106
    \once \slurDashed f4( e8) | %107
    e8 a8[ g8] | %108
    fis?8[ g8] a8 | %109
    d,4 d8 | %110
    \once \slurDashed g4( e8) | %111
    a4 b8~ | %112
    b8 g8 a8 | %113
    d,8[ \melisma e16 d16 cis16 b16] | %114
    ais8[ cis8 e8] | %115
    \melismaEnd fis,4 fis'8 | %116
    \once \slurDashed b4( gis8 | %117
    cis8) a8 d8 | %118
    d,8[ b8 cis8] | %119
    fis,8 r8 r8 | %120
    R4.*11 | %121
    r8 e'8. e16 | %132
    a,8. b16[ cis16 d16] | %133
    e8[ \melisma fis8 g8]~ | %134
    g16[ fis16 b16 a16 gis16 fis16] | %135
    a16[ gis16 fis16 e16] \melismaEnd a8~ | %136
    a16[ b16] b8.\trill[ a32 b32] | %137
    c4.~ | %138
    c4.~ | %139
    c8[ b16 a16 gis16 fis16] | %140
    gis8 g4 | %141
    g4 f8 | %142
    bes8 g8[ a8] | %143
    d,4-\fermata r8 | %144
    r8 r8 dis8 | %145
    e4.~ | %146
    e4. | %147
    a,4.-\fermata | %148
}
>>


mvtIbassLyrics = \lyricmode {
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, __
    Ky -- ri -- e e -- lei -- son, e -- lei -- son;
    %29->40
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e __ e -- le -- i -- son,
    Ky -- ri -- e e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, __
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e __ e -- lei -- son, e -- lei -- son.

    %73 ->80
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son, Chri -- ste,
    Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste, Chri -- ste e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son.

    %90 -> 108
    Ky -- ri -- e e -- lei -- son, __
    e -- lei -- son, e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Chris -- ste e -- lei -- son, e -- le -- i -- son, e -- lei -- son,
    Chri -- ste e -- lei -- son, e -- lei -- son, e -- lei -- son,
    Ky -- ri -- e e -- lei -- son, __ e -- lei -- son,
    e -- lei -- son, e -- lei -- son, e -- lei -- son.
}


mvtIbc = <<
\mvtItimeline
\relative c' {
    \clef F
    a8-. a,8-. a8-. a'8-. a8-. a,8-. | %1
    a4 r4 r4 | %2
    e'8-. e,8-. e8-. e'8-. e8-. e,8-. | %3
    e4 r4 r4 | %4
    cis'8-. cis'8-. cis8-. ais8-. ais8-. fis8-. | %5
    fis4 r4 r4 | %6
    b,8-. b'8-. b8-. gis8-. gis8-. e8-. | %7
    e4 r4 r4 | %8
    a8.( cis16) b8.( a16) gis8.( fis16) | %9
    eis8.( d'16) cis8.( b16) a8.( gis16) | %10
    fis8.( gis16) a8.( b,16) b'8.( a16) | %11
    gis8-. e8-. a8-. d,8-. e8-. e,8-. | %12
    a4 r4 r4 | %13
    a'8-. a,8-. a8-. a'8-. a8-. a,8-. | %14
    a4-. r4 r4 | %15
    a4 r4 r4 | %16
    a'8-. a,8-. a8-. a'8-. a8-. a,8-. | %17
    a4 r4 r4 | %18
    e'8.( fis16) gis8.( b16) a8.( fis16) | %19
    gis8.( b16) a8.( fis16) gis8.( e16) | %20
    b'8-. b,8-. b8-. b'8-. b8-. b,8-. | %21
    b4 r4 b'8. a16 | %22
    gis4. fis8 e8.( gis16) | %23
    a8-. a,8-. a8-. a'8-. a8-. a,8-. | %24
    a8.( a'16) gis8.( fis16) gis8.( e16) | %25
    fis4. e8 dis8.( b16) | %26
    e8.( a16) b8-. a8-. b8-. b,8-. | %27
    e8-. e,8-. e8-. e'8-. e8-. e,8-. | %28
    e4 r4 r4 | %29
    b''8-. b,8-. b8-. b'8-. b8-. b,8-. | %30
    b4 r4 r4 | %31
    gis8-. gis'8-. gis8-. eis8 eis8-. cis8-. | %32
    cis4 r4 r4 | %33
    fis,8-. fis'8-. fis8-. dis8-. dis8-. b8-. | %34
    b4 r4 r4 | %35
    e8.( gis16) fis8.( e16) dis8.( cis16) | %36
    bis8.( a'16) gis8.( fis16) e8.( dis16) | %37
    cis8.( dis16) e8.( fis,16) fis'8.( e16) | %38
    dis8-. b8-. e8-. a8-. b8-. b,8-. | %39
    e,4 r4 r4 | %40
    e'8-. e,8-. e8-. e'8-. e8-. e,8-. | %41
    e4 r4 r4 | %42
    e4 r4 r4 | %43
    e'8-. e,8-. e8-. e'8-. e8-. e,8-. | %44
    e4 r4 r4 | %45
    e'8.( fis16) e8.( d16) cis8.( fis16) | %46
    b,8.( e16) fis8.( e16) fis8 fis,8 | %47
    b'8-. b,8-. b8-. b'8-. b8-. b,8-. | %48
    b4 r4 r4 | %49
    b'8.( a16) g8.( fis16) g8.( fis16) | %50
    e8.( d16) a'8.( g16) a8 a,8 | %51
    d8-. d,8-. d8-. d'8-. d8-. d,8-. | %52
    d4 r4 r4 | %53
    fis'8.( gis16) a8.( cis16) b8.( d16) | %54
    cis8.( e16) d8.( b16) cis8.( a16) | %55
    e8-. e,8-. e8-. e'8-. e8-. e,8-. | %56
    e4 r4 e'8.( d16) | %57
    cis4. b8 a8.( cis16) | %58
    d8-. d,8-. d8-. d'8-. d8-. d,8-. | %59
    d8.( d'16) cis8.( b16) cis8.( a16) | %60
    b4. a8 gis8.( e16) | %61
    a8.( d16) e8.( d16) e8 e,8 | %62
    a8-. cis'8-. cis8-. a8-. a8-. fis8-. | %63
    fis4 r4 r4 | %64
    b,8-. b'8-. b8-. gis8-. gis8-. e8-. | %65
    e4 r4 r4 | %66
    a8.( cis16) b8.( a16) gis8.( fis16) | %67
    eis8.( d'16) cis8.( b16) a8.( gis16) | %68
    fis8.( gis16) a8.( b,16) b'8.( a16) | %69
    gis8-. e8-. a8-. d,8-. e8-. e,8-. | %70
    a'8-. a,8-. a8-. a'8-. a8-. a,8-. | %71
    a4 r4 r4\fermata | %72
    % Christe
    eis1\p~ | %73
    eis1~ | %74
    eis2 e'2 | %75
    e1 | %76
    ais,1 | %77
    a1~ | %78
    a2 dis,2~ | %79
    dis2 d'2 | %80
    d1 | %81
    gis,1 | %82
    g'1~ | %83
    g2 cis,2~ | %84
    cis2 c2 | %85
    b2 dis2 | %86
    e1~ | %87
    e8 g8 \appoggiatura fis16 e8 \appoggiatura d16 cis8 ais2 | %88
    b1\fermata | %89
    % Kyrie 2
    b8 b'8 a8 | %90
    gis8 fis8 e8 | %91
    dis8 cis8 b8 | %92
    e4.~ | %93
    e8 d8 g8 | %94
    e8 cis8 fis8 | %95
    b,8 b'8 a8 | %96
    gis8 a8 b8 | %97
    e,8 e,8 e'8 | %98
    a,8 a'8 fis8 | %99
    b8 b,8 c8~ | %100
    c8 a8 b8 | %101
    e,8 e'8 d8 | %102
    cis8 d8 e8 | %103
    a,8 a'8 a,8 | %104
    d,8 d'8 b8 | %105
    e,8 e'8 f8~ | %106
    f8 d8 e8 | %107
    a,8 a'8 g8 | %108
    fis8 g8 a8 | %109
    d,8 d,8 d'8 | %110
    g,8 g'8 e8 | %111
    a8 a,8 b8~ | %112
    b8 g8 a8 | %113
    d16( cis16) e16( d16) cis16( b16) | %114
    ais8( ais8 ais8) | %115
    fis8( fis8 fis8) | %116
    b8( b8 gis8) | %117
    cis8 a8 d8~ | %118
    d8 b8 cis8 | %119
    fis,8 \clef G
    fis''8. fis16 | %120
    b,8. cis16 dis16 e16 | %121
    dis16( fis16 e16 dis16 cis16 b16) | %122
    e8 e8 cis8 | %123
    fis8 fis8 g8~ | %124
    g8 e8 fis8 | %125
    b8 \clef F
    b,8. b16 | %126
    e,8. fis16 gis16 a16 | %127
    gis16( b16) a16( gis16) fis16( e16) | %128
    a8 a8 fis8 | %129
    b8 b8 c8~ | %130
    c8 a8 b8 | %131
    e,8 e8. e16 | %132
    a,8. b16 cis16 d16 | %133
    e8 fis8 g8~ | %134
    g16 fis16 b16( a16) gis16( fis16) | %135
    gis8 e8 a8 | %136
    f8 d8 e8 | %137
    dis16( e16 fis16 gis16 a16 b16) | %138
    c16( b16 a16 g16 fis16 e16) | %139
    dis8 b8 dis8 | %140
    e8 e,8 e'8 | %141
    a8 a,8 bes8~ | %142
    bes8 g8 a8 | %143
    d,4-\fermata r8 | %144
    r8 r8 dis8 | %145
    e8( e8 e8) | %146
    e8( e8 e8) | %147
    a4.-\fermata | %148
}
>>



mvtIfigs = \figuremode {
    s2 <6 4>4 |
    <5 3> s2 |
    s2 <6 4>4 |
    <5 3> s2 |
    <5>2 <6 5>4 |
    <7 _+>2. |
    s2 <6 5>4 |
    <7 _+>2. |
    s4 <\FBx> <7 4 2> |
    \barNumberCheck # 10
    <6 5> <7 _+> s |
    s <6 4\+> <_+> |
    <6>4. <7 5>8 <6 4> <5 3> |
    s2. |
    <6 4>4 <5 3> <6 4> |
    <5 3>2. |
    s |
    <6 4>4 <5 3> <6 4> |
    <5 3>2. |
    s4 <6>8. <6>16 s8. <7>16 |
    \barNumberCheck # 20
    <6>8. <\FBx>16 s8. <6\\>16 <6>4 |
    <_+> <\FBx> <6 4>8 <_+> |
    <5 _+>2 <_+>4 |
    <7> <6>8 <6\\> s4 |
    <7> <6>4. \once \bassFigureExtendersOn <6>8 |
    <4\+ 2>4 <6>4.. \once \bassFigureExtendersOn <6>16 |
    \barNumberCheck # 26
    <5 4>4 <6\\ 3>8 <6 4 2> <6 5>4 |
    s8. <7 5>16 <5 4>4 <5 _+> |
    s2 <6 4>4 |
    <5 3>2. |
    <_+>2 <6 4>4 |
    <5 _+>2. |
    \barNumberCheck # 32
    <5\+ 3>8 <\FBnull \FBnull> \once \bassFigureExtendersOn <\FBnull \FBnull> <6 5> <\FBx \FBx> <7 _+> |
    <7 _+>2. |
    s4. <6 5>8 \once \bassFigureExtendersOn <5> <7 _+> |
    <7 _+>2. |
    \barNumberCheck # 36
    s2 <7 4 2>4 |
    <6 5> <7 _+> 8. <\FBnull>16 \once \bassFigureExtendersOn <\FBnull>4 |
    <5 3>4 <4\+ 2> <_+> |
    <6>8 <7 _+> s <7 5> <6 4> <5 _+> |
    \barNumberCheck # 40
    s2. |
    <6 4>4 <5 3>8 \once \bassFigureExtendersOn <5> <6 4>4 |
    <5 3>2. |
    s |
    <6 4>4 <5 3>8 \once \bassFigureExtendersOn <5> <6 4>4 |
    <5 3>2. |
    \barNumberCheck # 46
    s4 <\FBnull>8. \once \bassFigureExtendersOn <\FBnull>16 <6\\ 3>4 |
    <_!>8. <7 _\!>16 <4>4 <_+> |
    s2 <6! 4>4 |
    <5 3>2. |
    <5 3>4 <7 5 2> <5 3> |
    <6 _!> <4> <3> |
    \barNumberCheck # 52
    s2 <6 4!>4 |
    <5 3>2. |
    s4 <6> <6> |
    <6> s8. <6>16 <6>4 |
    <8> <7> <6 4> |
    s2. |
    \barNumberCheck # 58
    <7>4 <6>2 |
    <7>4 <6> <7 5> |
    <4 2> <6> <6> |
    <7> <6>8 <5> <6 5>4 |
    s8. <7>16 <6 4>4 <5 3> |
    s2. |
    \barNumberCheck # 64
    <7 _+>2. |
    s2 <6 5>4 |
    <7>2. |
    s2 <7 4 2>4 |
    \barNumberCheck # 68
    <6 5>4 <7 _+>4 <\FBnull>8. \once \bassFigureExtendersOn <\FBnull>16 |
    s4 <6 4\+ 2> <_+> |
    <6>8 <7> s <7> s4 |
    s2 <6 4>4 |
    <5 3>2. |
    % \time 4/4
    \barNumberCheck # 73
    <6>1 |
    <\FBx>2 <7 5> |
    <\FBx> <6 4\+ 2> |
    s1 |
    <7! 5> |
    <6 4\+ 2>
    <\FBx>2 <7! 5> |
    \barNumberCheck # 80
    <\FBx>2 <6 4 2> |
    <\FBx>1 |
    <7! 5> |
    \barNumberCheck # 83
    <6 4 2>1 |
    <\FBx>2 <7- 5!> |
    <\FBx> <6 4 2> |
    \barNumberCheck # 86
    <7 _+>2 <7!>4. <6>8 |
    <9 _!>2 <8 5-> |
    <6 4\+ _!> <7! 5> |
    <6! 4>2 <5 _+> |
    \barNumberCheck # 90
    % \time 3/8
    <_+>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    <6>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    <6>4 <7 _+>8 |
    s4. |
    <4\+ 2>8 <6> <5> |
    <_!> <7> <_+> |
    s4. |
    \barNumberCheck # 97
    <6>8 s <6> |
    <8> s <7> |
    <5> <6> <7 5> |
    <7 _+> s <5!> |
    <\FBx> <6 5 _!> <_+> |
    <_!> <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    <6 5!> <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    \barNumberCheck # 104
    <7!> <\FBx> <6>16 <5> |
    <5>8 <6> <7> |
    <7> s <5! 3> |
    s <6 5 _!> s |
    <_!> s <4! 2> |
    <6 5!> s <6 _!> |
    <7!> s <6>16 <5> |
    \barNumberCheck # 111
    <5>8 <6> <7> |
    <7!> s <5> |
    s <6 5> s |
    s <5 2> <7 4 2> |
    <6> <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    <7 _+>4. |
    \barNumberCheck # 117
    <5 4>8 <6 _+> <7> |
    <_+> <5\+> <5> |
    s <6 5> <_+> |
    s4.*7 |
    \barNumberCheck # 127
    <7>8. <\FBnull>8 \once \bassFigureExtendersOn <\FBnull>16 |
    <6 5>8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> s8 |
    \barNumberCheck # 129
    <5>8 <6 _!> <7> |
    <7 _+> s <5! 3> |
    s <6 5> <_+> |
    <_!>4. |
    <7!> |
    <6 _!>8 s <4 2> |
    \barNumberCheck # 135
    <5 2>4. |
    <6 5>8 s <_!> |
    <5! 3> <6 5 _!> s |
    <7! 5>4. |
    <6 4 2\+>8 <\FBnull> \once \bassFigureExtendersOn <\FBnull> |
    <7! 5> <7 _+> <6 5> |
    \barNumberCheck # 141
    <7 _+> <6 _!> <5> |
    <7!> s <5! 3> |
    <\FBx> <6 5 _-> <5 3> |
    <_!>4. |
    s4 <7! 5>8 |
    <5 4> <3> <2> |
    <5 3> <6> <7> |
    s4. |
    \barNumberCheck # 149
}

\addQuote mvtIflI       { \mvtIflI }
\addQuote mvtIsoprano   { \mvtIsoprano }
