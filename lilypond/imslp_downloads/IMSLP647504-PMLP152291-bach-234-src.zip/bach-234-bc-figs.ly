\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-common.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"


\header {
    instrument = "Basso Continuo beziffert"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
   \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            { \dynamicUp \mvtIbc }
            \mvtIfigs
            { s2.*72 | \break }
        >>
    >>

    \header {
        piece = \mvtIpiece
    }
}

\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            { \dynamicUp \mvtIIbc }
            \mvtIIfigs
        >>
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}

\markup\null\pageBreak
%{ % BEGIN OF DUPLEX-ONLY SECTION
\markup\wordwrap{\bold{Note:} Movement \mvtIIIpiece is spread over three pages.
The page order in this document is adapted to allow double-sided printing with
pages 8 and 9 on a fold-out sheet.}
\markup{\vspace #1.0 }
%} % END OF DUPLEX-ONLY SECTION

\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffC <<
            { \dynamicUp \stretchHorizontalSpacing #-0.5 \mvtIIIbc }
            \mvtIIIfigs
        >>
    >>

    \header {
        piece = \mvtIIIpiece
        % breakbefore = ##t
    }
}

%{ % BEGIN OF DUPLEX-ONLY SECTION
\markup\null
\middleBackPage
%} % END OF DUPLEX-ONLY SECTION

% \markup\null\pageBreak
\markup\Tacet{\mvtIVpiece}


\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffC <<
            { \dynamicUp \stretchHorizontalSpacing #1 \mvtVbc }
            \mvtVfigs
        >>
    >>

    \header {
        piece = \mvtVpiece
        % breakbefore = ##t
    }
}


\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            { \dynamicUp \stretchHorizontalSpacing #1 \mvtVIbc }
            \mvtVIfigs
        >>
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}

