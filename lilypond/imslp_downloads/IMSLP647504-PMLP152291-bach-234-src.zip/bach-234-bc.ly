\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-common.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"


\header {
    instrument = "Basso Continuo"
}

\paper {
    ragged-last-bottom = ##f
}


\score {
   \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            \mvtIbc
        >>
    >>

    \header {
        piece = \mvtIpiece
    }
}

\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            \mvtIIbc
        >>
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}

\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffC <<
            \stretchHorizontalSpacing #-1.0
            \mvtIIIbc
        >>
    >>

    \header {
        piece = \mvtIIIpiece
        breakbefore = ##t
    }
}


\markup\null\pageBreak
\markup\Tacet{\mvtIVpiece}


\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffC <<
            \mvtVbc
        >>
    >>

    \header {
        piece = \mvtVpiece
        % breakbefore = ##t
    }
}


\score {
    \keepWithTag #'( PARTS ) <<
        \new Staff = staffJ <<
            \stretchHorizontalSpacing #-0.5
            \mvtVIbc
        >>
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}

