\version "2.21.0"

ownInstr = "Vln."

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"

% \include "last-page-copyright.ily"

\header {
    instrument = "Violino II"
}

\paper {
    page-count = 11
    ragged-last-bottom = ##f
}

\layout {
    \context {
        \StaffGroup {
            \revert StaffGroup.SystemStartBracket.collapse-height
        }
    }
    \context {
        \GrandStaff {
            \revert PianoStaff.SystemStartBrace.collapse-height
        }
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtIvlnII
    >>

    \header {
        piece = \mvtIpiece
    }
}
\score {
    \keepWithTag #'( PARTS ) \new Staff \with {
    } \context Bottom <<
        \mvtIIvlnII
        \mvtIIcuesVl
        {
            s1*9 |
            s2.*16 |
            \barNumberCheck # 26
            s1*11 |
            \barNumberCheck # 37
            s2.*16 |
            \barNumberCheck # 53
            s1*13 |
            \barNumberCheck # 66
            s2.*11 |
            % \pageTurn
        }
    >>

    \header {
        piece = \mvtIIpiece
        breakbefore = ##t
    }
}

\markup\null\pageBreak
\markup\Tacet{\mvtIIIpiece}


\score {
    \new StaffGroup <<
        \new Staff \with {
        } \context Bottom <<
            \clef treble \mvtIVvl
        >>
        \new Staff \with {
        } \context Bottom <<
            \clef alto \mvtIVvl
        >>
    >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}

\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVvl
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}

\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVIvlnII
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
