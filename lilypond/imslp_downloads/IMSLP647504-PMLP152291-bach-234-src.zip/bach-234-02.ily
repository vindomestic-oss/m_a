\version "2.21.0"

\include "include-once.ily"
\includeOnce "bach-234-common.ily"

mvtIItimeline = {
    \key a \major

    \time 4/4
    \tempo \markup\column{\line{Gloria} \line\smaller{Vivace}}
    s1*9 |
    \barNumberCheck # 10
    \time 3/4
    \tempo \markup\column{\line{Et in terra pax} \line\smaller{adagio e piano}}
    s2.*16 |
    \barNumberCheck # 26
    \time 4/4
    \tempo \markup\smaller{Vivace e forte}
    s1*11 |
    \barNumberCheck # 37
    \time 3/4
    \tempo \markup\smaller{adagio e piano}
    s2.*16 |
    \barNumberCheck # 53
    \time 4/4
    \tempo \markup\smaller{Vivace e forte}
    s1*13 |
    \barNumberCheck # 66
    \time 3/4
    \tempo \markup\smaller{adagio e piano}
    s2.*16 |
    \barNumberCheck # 82
    \time 4/4
    \tempo \markup\smaller{Vivace e forte}
    s1*13 |
    \barNumberCheck # 95
    \time 3/4
    \tempo \markup\smaller{adagio}
    s2.*17 |
    \barNumberCheck # 112
    \bar "|."
}


mvtIIbreaks = {
    <>^"Breaks left in"

    % \time 4/4
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \pageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \barNumberCheck # 10
    % \time 3/4
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak | } \pageBreak
    \repeat unfold 5 { s2.\noBreak | } \break\noPageBreak
    \barNumberCheck # 26
    % \time 4/4
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \pageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 1 { s1\noBreak | }
        \barNumberCheck # 37
        % \time 3/4
        \repeat unfold 4 { s2.\noBreak | } \pageBreak
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 53
    % \time 4/4
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \pageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \barNumberCheck # 66
    % \time 3/4
    \repeat unfold 5 { s2.\noBreak | } \pageBreak
    \repeat unfold 6 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 5 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 82
    % \time 4/4
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \pageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \pageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \barNumberCheck # 95
    % \time 3/4
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \repeat unfold 5 { s2.\noBreak | } \break\noPageBreak
    \repeat unfold 6 { s2.\noBreak | } \pageBreak
    \barNumberCheck # 112
}


mvtIIflI = <<
\mvtIItimeline
\relative c'' {
    \tag PARTS \voiceTwo R1*8 \tag PARTS \voiceOne | %1
    r2 r4 \tag PARTS \oneVoice e4~ | %9
    e8. d16 cis8.( d16) e4~ | %10
    e8. gis16 a8.( gis16) a8.( cis16) | %11
    \once \slurDashed d8.( d,16) cis8.( b16) a'8.( gis16) | %12
    a8.( e16) cis8.( d16) e4~ | %13
    e8. g16 fis8.( e16) cis'8.( e,16) | %14
    d8.( fis16) gis8.( fis16) a8.( gis16) | %15
    b8.( e,16) d'8.( b16) cis8.( a16) | %16
    a8.( fis16) gis8.( a16) b4~ | %17
    b8. cis16 a8.( gis16) fis8.( e16) | %18
    dis8.( e16) fis8.( gis16) a8.( b16) | %19
    e,8.( fis16) e4( dis8.) e16 | %20
    \once \slurDashed e8.( fis16) \once \slurDashed e8.( fis16) gis4~ | %21
    gis8. b16 a8.( gis16) a8.( fis16) | %22
    gis8.( a16) b8.( gis16) d4~ | %23
    d8. b16 cis8.( e16) gis8.( a16) | %24
    b,8. cis16 d2 | %25
    R1*10 | %26
    r2 r4 e4~ | %36
    e8. d16 cis8.( d16) e4~ | %37
    e8. gis16 a8.( gis16) a8.( cis16) | %38
    d8.( d,16) cis8.( b16) a'8.( gis16) | %39
    a8.( e16) cis8.( d16) e4~ | %40
    e8. g16 fis8.( e16) cis'8.( e,16) | %41
    d8.( fis16) gis8.( fis16) a8.( gis16) | %42
    b8.( e,16) d'8.( b16) cis8.( a16) | %43
    gis8.( fis16) gis8.( a16) b4~ | %44
    b8. cis16 b8.( a16) gis8.( fis16) | %45
    eis8.( fis16) gis8.( a16) b8.( d16) | %46
    \once \slurDashed cis8.( fis,16) fis4( eis8.) fis16 | %47
    fis4 cis8.( d16) e4~ | %48
    e8. fis16 d8.( cis16) d8.( b16) | %49
    cis8.( b16) a8.( b16) cis4~ | %50
    cis8. d16 b8.( a16) b8.( gis16) | %51
    a8. b16 \appoggiatura \parenthesize a16 gis4. fis8 | %52
    fis4 r4 r2 | %53
    R1*11 | %54
    r2 r4 a'4~ | %65 a8. g16 fis8. g16 a4~ | %66
    a8. g16 \once \slurDashed fis8.( g16) a4~ |
    a8. cis16 d8.( cis16) d8.( fis,16) | %67
    g8.( a16) fis8.( e16) d'8.( cis16) | %68
    d8.( a16) fis8.( g16) a4~ | %69
    a8. c,16 b8.( a16) fis'8.( a,16) | %70
    g8.( b16) cis8.( b16) d8.( cis16) | %71
    e8.( a,16) g'8.( e16) fis8.( d16) | %72
    cis8.( b16) cis8.( d16) e4~ | %73
    e8. gis?16 fis8.( e16) dis8.( cis16) | %74
    bis8.( cis16) dis8.( e16) fis8.( gis16) | %75
    e8.( dis16) cis4( bis8.\trill) cis16 | %76
    cis4 gis'8.( a16) b4~ | %77
    b8. cis16 a8.( gis16) a8.( fis16) | %78
    gis8.( fis16) eis8.( fis16) gis4~ | %79
    gis8. a16 fis8.( eis16) fis8.( dis16) | %80
    eis8. gis16 b2 | %81
    R1*12 | %82
    r2 r4 e,4~ | %94
    e8. d16 cis8.( d16) e4~ | %95
    e8. gis16 a8.( gis16) a8.( cis16) | %96
    d8.( d,16) cis8.( b16) a'8.( gis16) | %97
    a8.( e16) cis8. d16 e4~ | %98
    e8. g16 fis8.( e16) cis'8.( e,16) | %99
    d8.( fis16) gis8.( fis16) a8.( gis16) | %100
    b8.( e,16) d'8.( b16) cis8.( a16) | %101
    gis8.( fis16) gis8.( a16) b4~ | %102
    b8. gis16 a8.( b16) cis4~ | %103
    cis8. a16 b8.( cis16) d8.( e16) | %104
    \once \slurDashed cis8.( b16) a4( gis8.\trill) a16 | %105
    a4 \once \slurDashed e8.( fis16) g4~ | %106
    g8. a16 fis8.( e16) fis8.( d16) | %107
    e8.( d16) cis8.( d16) e4~ | %108
    e8. fis16 d8.( cis16) d8.( b16) | %109
    cis8.( d16) b4.-\parenthesize\trill a8 | %110
    a2.-\fermata | %111
    \barNumberCheck # 112
    <>^"Until HERE"
}
>>


mvtIIflII = <<
\mvtIItimeline
\relative c'' {
    \tag PARTS \voiceTwo R1*8 \tag PARTS \voiceOne | %1
    r2 r4 \tag PARTS \oneVoice b4~ | %9
    b8. gis16 a8.( b16) cis4~ | %10
    cis8. b16 cis8.( b16) cis8.( a16) | %11
    fis8.( b16) a8.( gis16) b8.( e16) | %12
    e,8.( cis'16) a8.( b16) cis4~ | %13
    cis8. b16 ais8.( cis16) e8.( cis16) | %14
    fis,8.( b16) d8.( fis16) e4~ | %15
    e8. b16 b'8.( gis16) a8.( e16) | %16
    e4 \once \slurDashed b8.( cis16) d4~ | %17
    d8. e16 cis8.( b16) a8.( cis16) | %18
    b8.( cis16) dis8.( e16) fis8.( dis16) | %19
    e8.( cis16) b4( a8.) gis16 | %20
    \once \slurDashed gis8.( a16) \once \slurDashed gis8.( b16) d4 | %21
    \once \slurDashed b8.( d16) cis8.( b16) cis8.( a16) | %22
    b8.( cis16) d8.( b16) gis8.( b16) | %23
    e,8.( gis16) a8.( cis16) b8.( cis16) | %24
    gis8. a16 b2 | %25
    R1*10 | %26
    r2 r4 b4~ | %36
    b8. gis16 \once \slurDashed a8.( b16) cis4~ | %37
    cis8. b16 cis8.( b16) cis8.( a16) | %38
    fis8.( b16) a8.( gis16) b8.( e16) | %39
    e,8.( cis'16) a8.( b16) cis4~ | %40
    cis8. b16 ais8.( cis16) e8.( cis16) | %41
    \slurDashed fis,8.( b16) d8.( fis16) e4~ | %42
    e8. b16 b'8.( gis16) a8.( e16) | %43
    e4 b8.( cis16) \undo \slurDashed d4~ | %44
    d8. e16 d8.( cis16) b8.( d16) | %45
    cis8.( dis16) eis8.( fis16) eis8.( b16) | %46
    \once \slurDashed fis'8.( d16) cis4( b8.) a16 | %47
    a8.( gis16) ais8.( b16) cis4~ | %48
    cis8. d16 \slurDashed b8.( ais16) b8.( gis16) | %49
    a8.( gis16) fis8.( gis16) \undo \slurDashed a4~ | %50
    a8. b16 gis8.( fis16) gis8.( eis16) | %51
    fis8. gis16 eis4. fis8 | %52
    fis4 r4 r2 | %53
    R1*11 | %54
    r2 r4 e'4~ | %65
    e8. a,16 \once \slurDashed d8.( e16) fis4~ | %66
    fis8. e16 fis8.( e16) fis8.( d16) | %67
    b8.( e16) d8.( cis16) e8.( a,16) | %68
    \once \slurDashed a8.( fis16) \once \slurDashed d8.( e16) fis4~ | %69
    fis8. e16 dis8.( fis16) a8.( c16) | %70
    b8.( g16) e8.( e'16) a,4~ | %71
    a8. e16 \once \slurDashed e'8.( cis16) \once \slurDashed d8.( a16) | %72
    a8.( e16) a8.( b16) cis4~ | %73
    cis8. b16 a8.( gis16) fis8.( a16) | %74
    fis'8.( a16) bis,8.( cis16) bis8.( dis16) | %75
    \once \slurDashed cis8.( a16) \once \slurDashed gis4( fis8.) e16 | %76
    \once \slurDashed e8.( dis16) eis8.( fis16) gis4~ | %77
    gis8. a16 \slurDashed fis8.( eis16) fis8.( dis16) | %78
    eis8.( fis16) gis8.( a16) \undo \slurDashed b4~ | %79
    b8. cis16 a8.( gis16) a8.( fis16) | %80
    gis8. b16 eis2 | %81
    R1*12 | %82
    r2 r4 b4~ | %94
    b8. e,16 a8.( b16) cis4~ | %95
    cis8. b16 cis8.( b16) cis8.( a16) | %96
    fis8.( b16) a8.( gis16) b8.( e16) | %97
    \once \slurDashed e,8.( cis'16) \once \slurDashed a8.( b16) cis4~ | %98
    cis8. e16 ais,8.( cis16) fis8.( cis16) | %99
    b8.( a16) b8.( d16) cis8.( b16) | %100
    gis8.( b16) e,8.( b'16) e8.( cis16) | %101
    b8.( a16) b8.( cis16) d4~ | %102
    d8. b16 cis8.( d16) e4~ | %103
    e8. cis16 d8.( e16) fis8.( gis16) | %104
    \once \slurDashed a8.( fis16) cis4( b8.\trill) a16 | %105
    a8.( b16) cis8.( d16) e4~ | %106
    e8. a,16 d8.( cis16) d4~ | %107
    d8. fis16 \slurDashed e8.( d16) cis4~ | %108
    cis8. d16 b8.( gis16) a8.( b16) | %109
    a8.( fis16) \undo \slurDashed gis4.-\parenthesize\trill a8 | %110
    a2.-\fermata | %111
    \barNumberCheck # 112
}
>>


mvtIIvlnI = <<
\mvtIItimeline
\relative c'' {
    cis16 e16 a16 a16 e16 a16 cis,16 e16 b16 e16 b'16 b16 gis16 b16 e,16 gis16 | %1
    cis16 a16 b16 gis16 a16 e16 cis'16 a16 b16 gis16 e16 gis16 b16 e,16 e'16 e16 | %2
    e32 e,32( fis32 gis32 a32 b32 cis32 d32 e16) cis16 a16 e16 fis16 d16 fis16 a16 d8 r8 | %3
    r32 cis,32( d32 e32 fis32 gis32 ais32 b32 cis16) ais16 fis16 cis16 d16 b16 d16 fis16 b8 r8 | %4
    r32 gis,32( a32 b32 cis32 dis32 eis32 fis32 gis16) eis16 cis16 gis16 a16 fis16 a16 cis16 fis16 d16 e16 cis16 | %5
    b16 gis16 b16 d16 gis16 e16 fis16 d16 cis32 a32( b32 cis32 d32 e32 fis32 gis32 a16) fis16 gis16 e16 | %6
    d32 b32( cis32 d32 e32 fis32 gis32 a32 b16) gis16 a16 fis16 b,16 e16 gis16 gis16 e16 gis16 b,16 d16 | %7
    cis16 e16 a16 a16 e16 a16 cis,16 e16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %8
    b,16 d16 gis,16 b16 e,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis8 r8 | %9
    <<
        \tag PARTS {
            R2.*8 | %10
            \voiceOne
            R2.*5 | %10
            \oneVoice
            R2.*3 | %10
        }
        \tag SCORE {
            R2.*16 | %10
        }
    >>
    cis'16 e16 a16 a16 e16 a16 cis,16 e16 b16 e16 b'16 b16 gis16 b16 e,16 gis16 | %26
    cis16 a16 b16 gis16 a16 e16 cis'16 a16 b8 e,8 r4 | %27
    cis16 e16 a16 a16 e16 a16 cis,16 e16 b16 e16 b'16 b16 gis16 b16 e,16 gis16 | %28
    cis16 a16 b16 gis16 a16 e16 cis'16 a16 b16 gis16 e16 gis16 b16 e,16 e'16 e16 | %29
    e32 e,32( fis32 gis32 a32 b32 cis32 d32 e16) cis16 a16 e16 fis16 d16 fis16 a16 d8 r8 | %30
    r32 cis,32( d32 e32 fis32 gis32 ais32 b32 cis16) ais16 fis16 cis16 d16 b16 d16 fis16 b8 r8 | %31
    r32 gis,32( a32 b32 cis32 dis32 eis32 fis32 gis16) eis16 cis16 gis16 a16 fis16 a16 cis16 fis16 d16 e16 cis16 | %32
    b16 gis16 b16 d16 gis16 e16 fis16 d16 cis32 a32( b32 cis32 d32 e32 fis32 gis32 a16) fis16 gis16 e16 | %33
    d32 b32( cis32 d32 e32 fis32 gis32 a32 b16) gis16 a16 fis16 b,16 e16 gis16 gis16 e16 gis16 b,16 d16 | %34
    cis16 e16 a16 a16 e16 a16 cis,16 e16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %35
    b,16 d16 gis,16 b16 e,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis8 r8 | %36
    <<
        \tag PARTS {
            R2.*8 | %37
            \voiceTwo
            R2.*8 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    a'16 cis16 fis16 fis16 cis16 fis16 a,16 cis16 gis16 cis16 gis'16 gis16 eis16 gis16 cis,16 gis'16 | %53
    a16 fis16 gis16 eis16 fis16 cis16 a'16 fis16 gis16 eis16 cis16 eis16 gis16 cis,16 gis'16 b,16 | %54
    a16 fis16 a16 cis16 fis16 d16 e16 cis16 d16 b,16 d16 fis16 b16 g16 a16 fis16 | %55
    g32 e32( fis32 g32 a32 b32 cis32 d32 e16) cis16 d16 b16 cis32 a,32( b32 cis32 d32 e32 fis32 g32 a16) fis16 g16 e16 | %56
    fis16 a16 d16 d16 a16 d16 fis,16 a16 e16 a16 e'16 e16 cis16 e16 a,16 cis16 | %57
    fis16 d16 e16 cis16 d16 a16 fis'16 d16 e16 cis16 a16 cis16 e16 a,16 a'16 a16 | %58
    a32 a,32( b32 cis32 d32 e32 fis32 g32 a16) fis16 d16 a16 b16 g16 b16 d16 g8 r8 | %59
    r32 fis,32( g32 a32 b32 cis32 dis32 e32 fis16) dis16 b16 fis16 g16 e16 g16 b16 e8 r8 | %60
    r32 cis,32( d32 e32 fis32 gis32 ais32 b32 cis16) ais16 fis16 cis16 d16 b16 d16 fis16 b16 g16 a16 fis16 | %61
    e16 cis16 e16 g16 cis16 a16 b16 g16 fis32 d32( e32 fis32 g32 a32 b32 cis32 d16) b16 cis16 a16 | %62
    g32 e32( fis32 g32 a32 b32 cis32 d32 e16) cis16 d16 b16 e,16 a16 cis16 cis16 a16 cis16 e,16 g16 | %63
    fis16 a16 d16 d16 a16 d16 fis,16 a16 g16 cis16 e16 e16 cis16 e16 g,16 cis16 | %64
    e,16 g16 cis,16 e16 a,16 a16 a16 a16 a16 a16 a16 a16 a8 r8 | %65
    <<
        \tag PARTS {
            R2.*11 | %37
            \voiceTwo
            R2.*5 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    a'16 cis16 fis16 fis16 cis16 fis16 a,16 cis16 gis16 cis16 gis'16 gis16 eis16 gis16 cis,16 gis'16 | %82
    a16 fis16 gis16 eis16 fis16 cis16 a'16 fis16 gis16 eis16 cis8 r4 | %83
    cis16 fis16 a16 a16 fis16 a16 cis,16 fis16 b,16 e16 b'16 b16 gis16 b16 e,16 gis16 | %84
    cis16 a16 b16 gis16 a16 e16 cis'16 a16 b16 gis16 e8 r4 | %85
    cis16 e16 a16 a16 e16 a16 cis,16 e16 b16 e16 b'16 b16 gis16 b16 e,16 gis16 | %86
    cis16 a16 b16 gis16 a16 e16 cis'16 a16 b16 gis16 e16 gis16 b16 e,16 e'16 e16 | %87
    e32 e,32( fis32 gis32 a32 b32 cis32 d32 e16) cis16 a16 e16 fis16 d16 fis16 a16 d8 r8 | %88
    r32 cis,32( d32 e32 fis32 gis32 ais32 b32 cis16) ais16 fis16 cis16 d16 b16 d16 fis16 b8 r8 | %89
    r32 gis,32( a32 b32 cis32 dis32 eis32 fis32 gis16) eis16 cis16 gis16 a16 fis16 a16 cis16 fis16 d16 e16 cis16 | %90
    b16 gis16 b16 d16 gis16 e16 fis16 d16 cis32 a32( b32 cis32 d32 e32 fis32 gis32 a16) fis16 gis16 e16 | %91
    d32 b32( cis32 d32 e32 fis32 gis32 a32 b16) gis16 a16 fis16 b,16 e16 gis16 gis16 e16 gis16 b,16 d16 | %92
    cis16 e16 a16 a16 e16 a16 cis,16 e16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %93
    b,16 d16 gis,16 b16 d,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis8 r8 | %94
    R2.*3 | %95
    r8 r16 e''16 cis8.( d16) e4~ | %98
    e8. g16 \slurDashed fis8.( e16) cis'8.( e,16) | %99
    d8.( fis16) \undo \slurDashed gis8.( fis16) a8.( gis16) | %100
    b8.( e,16) d'8.( b16) cis8.( a16) | %101
    gis8.( fis16) gis8.( a16) b4~ | %102
    b8. gis16 a8.( b16) cis4~ | %103
    cis8. a16 b8.( cis16) \once \slurDashed d8.( e16) | %104
    cis8.( b16) a4( gis8.\trill) a16 | %105
    a4 e8.( fis16) g4~ | %106
    g8. a16 fis8.( e16) fis8.( d16) | %107
    e8.( d16) cis8.( d16) e4~ | %108
    e8. fis16 d8.( cis16) d8.( b16) | %109
    \once \slurDashed cis8.( d16) b4.\trill a8 | %110
    a2.-\fermata | %111
    \barNumberCheck # 112
}
>>


mvtIIvlnII = <<
\mvtIItimeline
\relative c'' {
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 b16 e16 gis,16 b16 | %1
    e16 cis16 d16 b16 cis16 a16 e'16 cis16 gis'16 e16 b16 e16 e,16 gis16 b16 e16 | %2
    a,,8 r8 r4 a''16 a16 fis16 fis16 d16 d16 a16 a16 | %3
    fis'8 r8 r4 fis16 fis16 d16 d16 b16 b16 fis16 fis16 | %4
    cis'8 r8 r4 r16 a16 a16 a16 a8 r8 | %5
    r16 b16 b16 b16 b8 r8 r16 cis16 cis16 cis16 cis8 r8 | %6
    r16 d16 d16 d16 d8 r8 gis,16 b16 e16 e16 b16 e16 gis,16 b16 | %7
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 b16 d16 gis16 gis16 d16 gis16 b,16 d16 | %8
    gis,16 b16 e,16 gis16 b,16 e16 gis,16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %9
    <<
        \tag PARTS {
            R2.*8 | %10
            \voiceOne
            R2.*5 | %10
            \oneVoice
            R2.*3 | %10
        }
        \tag SCORE {
            R2.*16 | %10
        }
    >>
    a'16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 b16 e16 gis,16 b16 | %26
    e16 cis16 d16 b16 cis16 a16 e'16 cis16 gis'8 b,8 r4 | %27
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 b16 e16 gis,16 b16 | %28
    e16 cis16 d16 b16 cis16 a16 e'16 cis16 gis'16 e16 b16 e16 e,16 gis16 b16 e16 | %29
    a,,8 r8 r4 a''16 a16 fis16 fis16 d16 d16 a16 a16 | %30
    fis'8 r8 r4 fis16 fis16 d16 d16 b16 b16 fis16 fis16 | %31
    cis'8 r8 r4 r16 a16 a16 a16 a8 r8 | %32
    r16 b16 b16 b16 b8 r8 r16 cis16 cis16 cis16 cis8 r8 | %33
    r16 d16 d16 d16 d8 r8 gis,16 b16 e16 e16 b16 e16 gis,16 b16 | %34
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 b16 d16 gis16 gis16 d16 gis16 b,16 d16 | %35
    gis,16 b16 e,16 gis16 b,16 e16 gis,16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %36
    <<
        \tag PARTS {
            R2.*8 | %37
            \voiceTwo
            R2.*8 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    fis'16 a16 cis16 cis16 a16 cis16 fis,16 a16 cis,16 gis'16 cis16 cis16 gis16 cis16 eis,16 gis16 | %53
    cis16 a16 b16 gis16 a16 fis16 cis'16 a16 eis'16 cis16 cis16 cis16 cis8 r8 | %54
    r16 cis16 cis16 cis16 cis8 r8 r16 d16 d16 d16 d8 r8 | %55
    r16 d16 d16 d16 d8 r8 r16 cis16 cis16 cis16 cis8 r8 | %56
    d,16 fis16 a16 a16 fis16 a16 d,16 fis16 a,16 e'16 a16 a16 e16 a16 cis,16 e16 | %57
    a16 fis16 g16 e16 fis16 d16 a'16 fis16 cis'16 a16 e16 a16 a,16 cis16 e16 a16 | %58
    d,8 r8 r4 d'16 d16 b16 b16 g16 g16 d16 d16 | %59
    b'8 r8 r4 b16 b16 g16 g16 e16 e16 b16 b16 | %60
    fis'8 r8 r4 r16 d16 d16 d16 d8 r8 | %61
    r16 e16 e16 e16 e8 r8 r16 fis16 fis16 fis16 fis8 r8 | %62
    r16 g16 g16 g16 g8 r8 cis,16 e16 a16 a16 e16 a16 cis,16 e16 | %63
    d16 fis16 a16 a16 fis16 a16 d,16 fis16 e16 g16 cis16 cis16 g16 cis16 e,16 g16 | %64
    cis,16 e16 a,16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a8 r8 | %65
    <<
        \tag PARTS {
            R2.*11 | %37
            \voiceTwo
            R2.*5 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    fis'16 a16 cis16 cis16 a16 cis16 fis,16 a16 cis,16 gis'16 cis16 cis16 gis16 cis16 eis,16 gis16 | %82
    cis16 a16 b16 gis16 a16 fis16 cis'16 a16 eis'16 cis16 gis8 r4 | %83
    a16 cis16 fis16 fis16 cis16 fis16 a,16 cis16 e,16 b'16 e16 e16 b16 e16 gis,16 b16 | %84
    e16 cis16 d16 b16 cis16 a16 e'16 cis16 gis'16 e16 b8 r4 | %85
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 b16 e16 gis,16 b16 | %86
    e16 cis16 d16 b16 cis16 a16 e'16 cis16 gis'16 e16 b16 e16 e,16 gis16 b16 e16 | %87
    a,,8 r8 r4 a''16 a16 fis16 fis16 d16 d16 a16 a16 | %88
    fis'8 r8 r4 fis16 fis16 d16 d16 b16 b16 fis16 fis16 | %89
    b8 r8 r4 r16 a16 a16 a16 a8 r8 | %90
    r16 b16 b16 b16 b8 r8 r16 cis16 cis16 cis16 cis8 r8 | %91
    r16 d16 d16 d16 d8 r8 gis,16 b16 e16 e16 b16 e16 gis,16 b16 | %92
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 b16 d16 gis16 gis16 d16 gis16 b,16 d16 | %93
    gis,16 b16 d,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %94
    R2.*3 | %95
    r8 r16 cis'16 \once \slurDashed a8.( b16) cis4~ | %98
    cis8. e16 ais,8.( cis16) fis8.( cis16) | %99
    b8.( a16) b8.( d16) cis8.( b16) | %100
    gis8.( b16) e,8.( b'16) e8.( cis16) | %101
    b8.( a16) b8.( cis16) d4~ | %102
    d8. b16 cis8.( d16) e4~ | %103
    e8. cis16 d8.( e16) fis8.( gis16) | %104
    \once \slurDashed a8.( fis16) cis4( b8.\trill) a16 | %105
    \once \slurDashed a8.( b16) \once \slurDashed cis8.( d16) e4~ | %106
    e8. a,16 d8.( cis16) d4~ | %107
    d8. fis16 e8.( d16) cis4~ | %108
    cis8. d16 b8.( gis16) a8.( b16) | %109
    a8.( fis16) \undo \slurDashed gis4.-\parenthesize\trill e8 | %110
    e2.-\fermata | %111
    \barNumberCheck # 112
}
>>


mvtIIvla = <<
\mvtIItimeline
\relative c' {
    \clef C
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 e16 gis16 b16 gis16 e16 gis16 b,16 e16 | %1
    e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 gis16 b16 | %2
    a8 r8 r4 a16 a16 d16 d16 a16 a16 fis16 fis16 | %3
    cis'8 r8 r4 fis,16 fis16 b16 b16 fis16 fis16 d16 d16 | %4
    gis8 r8 r4 r16 cis,16 cis16 cis16 cis8 r8 | %5
    r16 e16 e16 e16 e8 r8 r16 a16 a16 a16 a8 r8 | %6
    r16 fis16 fis16 fis16 b,8 r8 e16 gis16 b16 b16 gis16 b16 e,16 gis16 | %7
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 gis16 b16 d16 d16 b16 d16 gis,16 b16 | %8
    d,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %9
    <<
        \tag PARTS {
            R2.*8 | %37
            \voiceOne
            R2.*5 | %37
            \oneVoice
            R2.*3 |
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    e'16 a16 cis16 cis16 a16 cis16 e,16 a16 e16 gis16 b16 gis16 e16 gis16 b,16 e16 | %26
    e16 e16 e16 e16 e16 e16 e16 e16 e8 gis8 r4 | %27
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 e16 gis16 b16 gis16 e16 gis16 b,16 e16 | %28
    e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 gis16 b16 | %29
    a8 r8 r4 a16 a16 d16 d16 a16 a16 fis16 fis16 | %30
    cis'8 r8 r4 fis,16 fis16 b16 b16 fis16 fis16 d16 d16 | %31
    gis8 r8 r4 r16 cis,16 cis16 cis16 cis8 r8 | %32
    r16 e16 e16 e16 e8 r8 r16 a16 a16 a16 a8 r8 | %33
    r16 fis16 fis16 fis16 b,8 r8 e16 gis16 b16 b16 gis16 b16 e,16 gis16 | %34
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 gis16 b16 d16 d16 b16 d16 gis,16 b16 | %35
    d,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %36
    <<
        \tag PARTS {
            R2.*8 | %37
            \voiceTwo
            R2.*8 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    cis16 fis16 a16 a16 fis16 a16 cis,16 fis16 cis16 eis16 gis16 eis16 cis16 eis16 gis,16 cis16 | %53
    cis16 cis16 cis16 cis16 cis16 cis16 cis16 cis16 cis16 b'16 b16 b16 b8 r8 | %54
    r16 a16 a16 a16 a8 r8 r16 a16 a16 a16 a8 r8 | %55
    r16 g16 g16 g16 g8 r8 r16 g16 g16 g16 g8 r8 | %56
    a,16 d16 fis16 fis16 d16 fis16 a,16 d16 a16 cis16 e16 cis16 a16 cis16 e,16 a16 | %57
    a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 cis16 e16 | %58
    fis8 r8 r4 d16 d16 g16 g16 d16 d16 b16 b16 | %59
    fis'8 r8 r4 b,16 b16 e16 e16 b16 b16 g16 g16 | %60
    cis8 r8 r4 r16 fis,16 fis16 fis16 fis8 r8 | %61
    r16 a16 a16 a16 a8 r8 r16 d16 d16 d16 d8 r8 | %62
    r16 b16 b16 b16 b8 r8 a16 cis16 e16 e16 cis16 e16 a,16 cis16 | %63
    a16 d16 fis16 fis16 d16 fis16 a,16 d16 cis16 e16 g16 g16 e16 g16 cis,16 e16 | %64
    a,16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a16 a8 r8 | %65
    <<
        \tag PARTS {
            R2.*11 | %37
            \voiceTwo
            R2.*5 | %37
            \oneVoice
        }
        \tag SCORE {
            R2.*16 | %37
        }
    >>
    cis16 fis16 a16 a16 fis16 a16 cis,16 fis16 cis16 eis16 gis16 eis16 cis16 eis16 gis,16 cis16 | %82
    cis16 cis16 cis16 cis16 cis16 cis16 cis16 cis16 cis8 eis8 r4 | %83
    fis16 a16 cis16 cis16 a16 cis16 fis,16 a16 e16 gis16 b16 gis16 e16 gis16 b,16 e16 | %84
    e16 e16 e16 e16 e16 e16 e16 e16 e8 gis8 r4 | %85
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 e16 gis16 b16 gis16 e16 gis16 b,16 e16 | %86
    e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 e16 gis16 b16 | %87
    a8 r8 r4 a16 a16 d16 d16 a16 a16 fis16 fis16 | %88
    cis'8 r8 r4 fis,16 fis16 b16 b16 fis16 fis16 d16 d16 | %89
    gis8 r8 r4 r16 cis,16 cis16 cis16 cis8 r8 | %90
    r16 e16 e16 e16 e8 r8 r16 a16 a16 a16 a8 r8 | %91
    r16 fis16 fis16 fis16 b,8 r8 e16 gis16 b16 b16 gis16 b16 e,16 gis16 | %92
    e16 a16 cis16 cis16 a16 cis16 e,16 a16 gis16 b16 d16 d16 b16 d16 gis,16 b16 | %93
    d,16 gis16 b,16 d16 gis,16 gis16 gis16 gis16 gis16 gis16 gis16 gis16 gis8 r8 | %94
    R2.*3 | %95
    r8 r16 a'16 \once \slurDashed e8.( fis16) g4~ | %98
    g8. cis,16 fis4. fis8 | %99
    fis8.( e16) d8.( fis16) e8.( d16) | %100
    e8.( gis16) b8.( gis16) e4~ | %101
    e8. a16 gis8.( fis16) e8.( d16) | %102
    e8.( d16) cis8.( b16) a4~ | %103
    a8. e'16 fis8.( gis16) a8.( d,16) | %104
    e8.( fis16) e4( d8.\trill) cis16 | %105
    cis8.( d16) cis8.( b16) a4~ | %106
    a8. cis16 \once \slurDashed d8.( a16) a'4~ | %107
    a8. fis16 g4. cis,8 | %108
    fis8.( a,16) b8.( e16) a,8.( e16) | %109
    e'8.( fis16) b,8.( cis16) d8( cis8) | %110
    cis2.-\fermata | %111
    \barNumberCheck # 112
}
>>


mvtIIsoprano = <<
\mvtIItimeline
\relative c'' {
    \autoBeamOff
    cis8. cis16 cis4 e8. e16 e4 | %1
    e8 e8 e8 a8 gis8 e8 r4 | %2
    e8 e16 e16 a8 e8 fis8 fis8 r4 | %3
    cis8 cis16 cis16 fis8 cis8 d8 d8 r4 | %4
    cis4~ \melisma cis16[ b16 cis16 b16] a8[ fis8 a8 cis8] | %5
    b4~ b16[ e16 d16 e16] cis8[ a8 cis8 e8] | %6
    d8 \melismaEnd d16 cis16 b8 a'8 gis8 e8 r4 | %7
    a8 e8 cis8 a8 e'4.( d16[ cis16)] | %8
    b2 r2 | %9
    R2.*15 | %10
    r8 e,8 e'4( d16[ cis16)] d8 | %25
    cis4 r4 r2 | %26
    r2 r8 gis8 b8 gis8 | %27
    a4 cis8 a8 e'8 e8 d8 d8 | %28
    cis16[ \melisma e16 b16 d16] cis16[ e16 a,16 cis16] b16[ e16 b16 gis16] e16[ gis16 b16 gis16] | %29
    a8 \melismaEnd a8 a'8 e8 fis8 fis8 fis8 fis8 | %30
    fis16[ \melisma cis16 fis16 cis16] ais16[ cis16 fis,16 cis'16] d8 \melismaEnd d8 r8 d8 | %31
    cis16[ \melisma gis16 cis16 gis16] eis16[ gis16 cis,16 gis'16] a8 \melismaEnd a8 r8 cis16 d16 | %32
    e8 e8 d8 d8 cis4~ \melisma cis16[ d16 b16 cis16] | %33
    d4~ d16[ b16 cis16 a16] gis8 \melismaEnd e8 r8 gis8 | %34
    a8[ e8] a8[ cis8] b8 e,8[ gis8] b8 | %35
    e4 e8 e8 e4 r4 | %36
    R2.*16 | %37
    r2 r8 cis,8 gis'8 b8 | %53
    a8[ \melisma eis'8 fis8 cis8]~ cis8[ eis8 gis8] \melismaEnd b,8 | %54
    a8 r16 cis16 fis8 e8 d8[ \melisma b8 fis8 d'8]~ | %55
    d8.[ b16 e8 d8] cis8[ a8 e8] \melismaEnd cis'8 | %56
    d8 r8 r4 r2 | %57
    r8 a8 d8 fis8 e8[ \melisma cis8 a8 cis8] | %58
    d8[ fis8 a8] \melismaEnd c,8 \appoggiatura c8 b4 r8 b8 | %59
    b8 dis8 fis8 a,8 g4 r8 e'8 | %60
    fis8 cis8 ais8 cis8 d8 fis,8 b8 d8 | %61
    g,8 e'4 e8 e8 fis16 e16 d8 d8 | %62
    g16[ fis16 e8~] e16[ cis16] d8 a'8 a,8 cis8 e8 | %63
    d8 a8 d8 fis8 e8 g,4 g8 | %64
    e'4. g,16 g16 g4 r4 | %65
    R2.*15 | %66
    r4 r8 gis8 cis8. b16 | %81
    a8 a8 r4 r2 | %82
    r2 r8 gis8 cis8 eis8 | %83
    fis8[ \melisma a16 fis16] cis8[ a16 cis16] b8 \melismaEnd e8 e,4 | %84
    r8 e8 a8 cis8 e4. d8 | %85
    cis8 e8 cis8 a8 b8[ \melisma e16 b16 gis8 b8] | %86
    a8[ e8 a8 cis8] e2~ | %87
    e16[ a,16 cis16 e16] a8[ e8] fis2~ | %88
    fis16[ fis,16 ais16 cis16] fis8[ cis8] d2~ | %89
    d16[ cis16 b16 a16] b8 \melismaEnd gis8 a4 r8 a8 | %90
    b8 b8 r8 b16 b16 cis16 cis16 cis8 r8 cis16 cis16 | %91
    d4 d4 d4 r8 b8 | %92
    cis8([ e8)] cis8([ a8)] gis8[ \melisma e8 gis8 b8] | %93
    e8[ e,16 fis16] gis16[ a16] \melismaEnd b16[ cis16] b8 r8 r4 | %94
    r4 e4. d8 | %95
    cis4 a'4. fis8 | %96
    d8.([ e32 fis32)] fis8([ e8 d16\trill cis16 d8)] | %97
    cis2 r4 | %98
    r4 cis4. ais8 | %99
    fis4 b8[ cis16] d16 cis8[ b8] | %100
    gis8 a16 b16 e,4.( cis'8) | %101
    b4 b8. cis16 d4~ | %102
    d8.[ b16 cis8.] d16 e4~ | %103
    \melisma e8.[ cis16] d4. \melismaEnd b8 | %104
    e8.[ d16] cis4( b8.\trill[ a16)] | %105
    a4 e'4. cis8 | %106
    a4 \melisma b8.[ cis16] d4~ | %107
    d8.[ b16 \melismaEnd cis8.] d16 e4~ | %108
    e8.[ fis16 d8. cis16 d8.] b16 | %109
    cis8.[ a16] gis4.\trill( a8) | %110
    a2.\fermata | %111
    \barNumberCheck # 112
}
>>

mvtIIsopranoLyrics = \lyricmode {
    Glo -- ri -- a, glo -- ri -- a, in ex -- cel -- sis De -- o,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    in ex -- cel -- sis De -- o.

    Lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,
    lau -- da -- mus te,
    lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,

    ad -- o -- ra -- mus -- te,
    glo -- ri -- fi -- ca -- mus te.

    Gra -- ti -- as a -- gi -- mus __ ti -- bi,
    gra -- ti -- as,
    gra -- ti -- as a -- gi -- mus ti -- bi
    pro -- pter ma -- gnam glo -- ri -- am tu -- am,
    pro -- pter ma -- gnam glo -- ri -- am tu -- am.
}

mvtIIalto = <<
\mvtIItimeline
\relative c'' {
    \autoBeamOff
    a8. a16 a4 b8. b16 b4 | %1
    a8 gis8 cis8 cis8 b8 gis8 r4 | %2
    a8 a16 a16 a8 a8 a8 a8 r4 | %3
    fis8 fis16 fis16 fis8 fis8 fis8 fis8 r4 | %4
    gis2~ \melisma gis8[ cis,8 fis8 a8] | %5
    b2~ b8[ e,8 a8 cis8] | %6
    b8 \melismaEnd b16 b16 e,8 fis8 b8 gis8 r4 | %7
    e8 a8 cis8 e8 gis,2 | %8
    gis2 r2 | %9
    r4 e4 a8.([ gis16)] | %10
    a4 a,2~ | %11
    a8. fis'16 e4( d16\trill[ cis16)] d8 | %12
    cis4 r4 r4 | %13
    r4 cis'2~ | %14
    cis8. fis,16 b8.([ cis32 d32)] cis8 b8 | %15
    a8([ gis16)] a16 e4. cis'8 | %16
    cis8.([ a16)] b4 r4 | %17
    r4 fis2~ | %18
    fis8. gis16 a16([ gis16)] fis16 e16 \appoggiatura e16 dis8 cis16[ b16] | %19
    b'8. cis16 gis4( fis8.[ e16)] | %20
    e2.~ | %21
    e4 r4 r4 | %22
    R2.*2 | %23
    r4 r8 gis8 b8. gis16 | %25
    a4 r4 r2 | %26
    r2 r8 b,8 e8 e8 | %27
    e4 r4 r4 gis8 e8 | %28
    a8 a8 a8 a8 gis16[ \melisma b16 gis16 e16] gis16[ e16 gis16 b16] | %29
    e,16[ a16 e16 cis16] a8 \melismaEnd a8 a'4 r8 a8 | %30
    cis16[ \melisma ais16 cis16 ais16] fis16[ ais16 cis16 ais16] b8 \melismaEnd b8 r8 fis8 | %31
    gis16[ \melisma eis16 gis16 eis16] cis16[ eis16 gis16 eis16] fis8 \melismaEnd fis8 r8 a16 a16 | %32
    b8 b8 b8 b8 a4~ \melisma a16[ b16 gis16 a16] | %33
    fis4~ fis16[ d16 e16 fis16] b,8 \melismaEnd b8 r8 e8 | %34
    e8([ cis8)] e8([ a8)] gis4 r8 gis16 gis16 | %35
    gis4 gis8 gis8 gis4 r4 | %36
    R2.*16 | %37
    r8 cis,8 fis8 a8 gis8[ \melisma eis8 cis8 gis'8] | %53
    fis8[ gis8 cis,8 a'8] eis8[ gis8 cis,8] \melismaEnd gis'8 | %54
    fis8 r8 r4 r8 r16 fis16 b8 a8 | %55
    g8[ e8 b8 g'8~] g8.[ e16 a8] \melismaEnd g8 | %56
    fis8 r8 r4 r8 a,8 e'8 g8 | %57
    fis8[ \melisma cis'8 d8 a8]~ a8[ cis8 e8 a,8]~ | %58
    a16[ g16 fis16 e16] fis8 \melismaEnd a8 g4 r8 g8 | %59
    fis8 fis8 dis8 fis8 e4 r8 g8 | %60
    fis8 ais8 cis8 e,8 d4 r4 | %61
    r8 e8 a8 cis8 fis,8 fis4 fis8 | %62
    fis8 g16 fis16 e8 b'8 cis8 a8 e8 e8 | %63
    fis8 a8 fis8 d8 a'8 cis8 e8 e,8~ | %64
    e8 cis8 cis8 cis16 d16 e4 r4 | %65
    R2.*15 | %66
    r4 r8 eis8 gis8. eis16 | %81
    fis8 fis8 r4 r2 | %82
    r8 cis8 fis8 a8 cis4. b8 | %83
    a8 r8 r4 r8 b,8 e8 gis8 | %84
    a4. a8 gis8 b8 b8 b8 | %85
    a8[ \melisma cis8 a8 e8] gis8[ e8 b'8 gis8] | %86
    e8[ gis8 e8 a8] gis8[ b16 gis16 e8 gis8] | %87
    a8 \melismaEnd a8 r8 a8 a8 a16[ gis16] a16([ b16 a16 b16] | %88
    cis8) fis,8 r8 fis8 fis8 fis16[ e16] fis8[ \melisma b8~] | %89
    b16[ a16 gis16 fis16] eis8 \melismaEnd gis8 fis4 r8 fis8 | %90
    b8 gis8 r8 b16 b16 a16 a16 a8 r8 e16 a16 | %91
    fis4 e8([ fis8)] gis4 r8 gis8 | %92
    a8[ cis8] a8[ e8] b'8[ \melisma e8 b8 gis8] | %93
    e16[ fis16 gis16 a16] b16[ cis16] \melismaEnd d8 gis,8 r8 r4 | %94
    r4 r4 a4~ | %95
    a8 gis8 fis4 cis'4~ | %96
    cis8 b16 a16 a4( gis4) | %97
    a2 r4 | %98
    e4. cis8 ais8[ fis8] | %99
    b8. cis16 d8 fis8[ e8] d8 | %100
    e8([ b8)] b'4( a4) | %101
    gis4 gis4 gis4 | %102
    r4 e8. fis16 g4~ | %103
    g8.[ e16 fis8.] gis16 a8. gis16 | %104
    a8.[ b16] a4( gis8.[ a16)] | %105
    a4 r4 a4~ | %106
    a8. fis16 d4 a'4 | %107
    a8.[ \melisma fis16] g4. \melismaEnd fis8 | %108
    fis4 b8.([ gis16 a8.)] b16 | %109
    a8.[ fis16] e2 | %110
    e2.-\fermata | %111
    \barNumberCheck # 112
}
>>

mvtIIaltoLyrics = \lyricmode {
    Glo -- ri -- a, glo -- ri -- a, in ex -- cel -- sis De -- o,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    in ex -- cel -- sis De -- o.

    et in ter -- ta, __ in ter -- ra pax,
    pax __ ho -- mi -- ni -- bus
    bo -- nae vo -- lun -- ta -- tis,
    pax __ ho -- mi -- ni -- bus
    bo -- nae vo -- lun -- ta -- tis. __

    Lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus te,
    lau -- da -- mus,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,
    lau -- da -- mus te,
    lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,

    ad -- o -- ra -- mus -- te,
    glo -- ri -- fi -- ca -- mus te.

    Gra -- ti -- as a -- gi -- mus ti -- bi,
    gra -- ti -- as,
    gra -- ti -- as a -- gi -- mus ti -- bi
    pro -- pter, pro -- pter ma -- gnam glo -- ri -- am tu -- am,
    pro -- pter ma -- gnam glo -- ri -- am, glo -- ri -- am tu -- am.
}

mvtIItenor = <<
\mvtIItimeline
\relative c' {
    \autoBeamOff
    e8. e16 e4 e8. e16 e4 | %1
    e8 e8 a8 e8 e8 e8 r4 | %2
    e8 e16 e16 cis8 e8 d8 d8 r4 | %3
    cis8 cis16 cis16 ais8 cis8 b8 b8 r4 | %4
    r8 gis8 \melisma cis4~ cis16[ b16 a16 b16] cis8[ a8] | %5
    e'8[ b8] e4~ e16[ d16 cis16 d16] e8[ cis8] | %6
    fis8 \melismaEnd fis16 fis16 b,8 d8 e8 b8 r4 | %7
    cis8 cis8 e8 cis8 b2 | %8
    e2 r2 | %9
    R2.*15 | %10
    r4 r8 b8 e8. e16 | %25
    e4 r4 r2 | %26
    r4 r8 e,8 e'4( d16[ cis16)] d8 | %27
    cis4 r4 r2 | %28
    r4 cis8 a8 e'8 e8 d8 d8 | %29
    cis16[ \melisma e16 cis16 a16] cis16[ a16 cis16 e16] d8 \melismaEnd d8 r8 d8 | %30
    cis16[ \melisma fis,16 ais16 cis16] fis16[ cis16 ais16 fis16] b8 \melismaEnd b8 r8 b8 | %31
    gis16[ \melisma cis,16 eis16 gis16] cis16[ gis16 eis16 cis16] fis8 \melismaEnd fis8 r8 fis'16 fis16 | %32
    b,8 e8 e8 e8 a,8[ \melisma e8] cis'4~ | %33
    cis8[ fis,8] d'4~ d8 \melismaEnd gis,8 r8 b8 | %34
    cis8([ a8)] cis8([ e8)] e4 r8 e16 e16 | %35
    e4 b8 b8 b4 r4 | %36
    R2.*16 | %37
    R1 | %53
    r8 cis8 a8 fis8 cis'2~ | %54
    \melisma cis8[ a8 fis8 cis'8] b8[ d8 fis8 d8] | %55
    b8[ g8 e8 b'8] a8[ cis8 e8] \melismaEnd e8 | %56
    d8 a8 d8 fis8 e8[ \melisma cis8 a8 e'8] | %57
    d8[ a8 fis8 d8] a'8[ e'8 cis8 a8] | %58
    fis'8[ d8 a8] \melismaEnd d8 d4 r8 d8 | %59
    b8 b8 b8 b8 b4 r8 b8 | %60
    cis8 fis8 fis8 fis8 fis4 r4 | %61
    r2 r8 a,8 d8 fis8 | %62
    b,8 e4 e8 e8 cis16 d16 e8 a,8 | %63
    d8 fis8 d8 a16 a16 cis8 e16 e16 a,8 cis8~ | %64
    cis8 a8 a8 a16 b16 cis4 r4 | %65
    r4 d2~ | %66
    d2.~ | %67
    d8. b16 a4( g16[ fis16)] g8 | %68
    fis4 r4 r4 | %69
    r4 fis'2~ | %70
    fis8. b,16 e8.[ fis32 g32] fis8[ e8] | %71
    \appoggiatura d8 cis8. d16 a4. fis'8 | %72
    e4 r4 r4 | %73
    r4 dis2(~ | %74
    dis4 fis8.) e16 dis8 cis16[ bis16] | %75
    gis'8. a16 e4( dis8.) cis16 | %76
    cis4 cis4 cis4 | %77
    cis2.~ | %78
    cis2.~ | %79
    cis4 cis8. cis16 fis8.([ gis32 a32)] | %80
    gis8. eis16 cis8 cis8 cis8. cis16 | %81
    cis8 cis8 r4 r8 gis8 cis8 eis8 | %82
    fis4. fis8 eis8 eis8 cis8 cis8 | %83
    cis8[ \melisma fis,8 a8 cis8] e4. \melismaEnd d8 | %84
    cis8 e8 cis8 a8 e8[ \melisma gis8 b8 e8~] | %85
    e8[ a,8 cis8 e8~] e8[ gis8 e8 b8] | %86
    e8[ b8 e,8 e'8~] e8[ d16 cis16 b8 gis8] | %87
    e8 \melismaEnd e8 r8 cis'8 d8 d16[ e16] fis16([ e16 fis16 d16] | %88
    cis8) cis8 r8 ais8 b8 b16[ cis16] d16[ \melisma cis16 d16 b16] | %89
    gis'8[ eis8 cis8] \melismaEnd cis8 cis4 r8 cis8 | %90
    e8 e8 r8 b16 e16 e16 e16 e8 r8 cis16 fis16 | %91
    b,4 b4 b4 r8 e8 | %92
    e8([ a,8)] cis8([ e8)] e8[ \melisma b8] e4~ | %93
    e8[ d16 cis16] b16[ a16] \melismaEnd gis16[ a16] b8 r8 r4 | %94
    R2. | %95
    cis4. eis8 fis4~ | %96
    fis8. d16([ cis8.)] b16 e4 | %97
    e4 a,4 cis4~ | %98
    cis8 ais8 fis4 fis'4~ | %99
    fis8. e16 d4 e8. b16 | %100
    b4 e2 | %101
    e4 e4 e4 | %102
    e8.([ d16 cis8. b16)] a4 | %103
    r4 d8. e16 fis8. d16 | %104
    e8. fis16 e4 d8.([ cis16)] | %105
    cis4 r4 r4 | %106
    d4. a8 fis8.([ a16] | %107
    cis8.[ d16)] e8.([ d16)] cis4~ | %108
    cis8.[ d16 b8. e16 a,8.] e16 | %109
    e'8.[ fis16] b,8.([ cis16 d8 cis8)] | %110
    cis2.-\fermata | %111
    \barNumberCheck # 112
}
>>

mvtIItenorLyrics = \lyricmode {
    Glo -- ri -- a, glo -- ri -- a, in ex -- cel -- sis De -- o,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    in ex -- cel -- sis De -- o.

    Lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,
    be -- ne -- di -- ci -- mus te,

    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,

    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,

    ad -- o -- ra -- mus -- te,
    glo -- ri -- fi -- ca -- mus te.

    Gra -- ti -- as __ a -- gi -- mus __ ti -- bi,
    gra -- ti -- as,
    gra -- ti -- as a -- gi -- mus ti -- bi
    pro -- pter ma -- gnam, pro -- pter ma -- gnam glo -- ri -- am tu -- am,
    pro -- pter ma -- gnam glo -- ri -- am tu -- am.
}

mvtIIbass = <<
\mvtIItimeline
\relative c' {
    \autoBeamOff
    \clef F
    a8. a16 a4 gis8. gis16 gis4 | %1
    a8 e'8 cis8 a8 e'8 e,8 r4 | %2
    cis'8 cis16 cis16 a8 cis8 d8 d8 r4 | %3
    ais8 ais16 ais16 fis8 ais8 b8 b8 r4 | %4
    eis,16[ \melisma fis16 eis16 dis16] cis8[ eis8] fis8[ cis'8 a8 fis8] | %5
    gis16[ fis16 gis16 fis16] e8[ gis8] a8[ e'8 cis8 a8] | %6
    b8 \melismaEnd a16 a16 gis8 fis8 e8 e'8 r4 | %7
    e8 e,8 a8 cis8 e2 | %8
    e,2 r2 | %9
    R2.*15 | %10
    r4 r8 e8 gis8. e16 | %25
    a4 r4 r2 | %26
    r2 r8 e8 gis8 e8 | %27
    a4 r4 r2 | %28
    r2 r4 gis8 e8 | %29
    a8 a8 g8 g8 fis16[ \melisma a16 d,16 fis16] a16[ fis16 d16 fis16] | %30
    ais,8 \melismaEnd ais8 r8 fis'8 fis16[ \melisma d16 b16 d16] fis16[ d16 b16 d16] | %31
    eis,8 \melismaEnd eis8 r8 cis''8 cis16[ \melisma a16 fis16 a16] cis16[ a16 fis16 a16] | %32
    gis16[ e16 gis16 b16] e8 \melismaEnd gis,8 a4 r8 a8 | %33
    b8[ a8] gis8[ fis8] e8 b8 e4~ | %34
    e4 e4 e8 e16 e16 e'4~ | %35
    e4 e,8 e8 e4 r4 | %36
    r4 a2~ | %37
    a2.~ | %38
    a8. fis16 e4( d16[ cis16)] d8 | %39
    cis4 r4 r4 | %40
    r4 cis'2~ | %41
    cis8. fis,16 b8.([ cis32 d32)] cis8([ b8)] | %42
    \appoggiatura a8 gis8. a16 e4. cis'8 | %43
    b4 r4 r4 | %44
    r4 gis2~ | %45
    \melisma gis4 b8. \melismaEnd a16 gis8 fis16[ eis16] | %46
    cis'16. d16 a4( gis16.) fis4 | %47
    fis4 fis4 fis4 | %48
    fis2.~ | %49
    \melisma fis2.~ | %50
    fis8.[ b16] d4. \melismaEnd b8 | %51
    cis8. fis,16 cis8[ b8] cis4 | %52
    fis4 r4 r2 | %53
    r2 r8 gis8 eis8 cis8 | %54
    fis8[ \melisma cis'8 a8 fis8] b8[ fis8 d8 b8] | %55
    e8[ b'8 g8 e8] a8[ e8 cis8] \melismaEnd a8 | %56
    d8 r8 r4 r2 | %57
    r2 r8 a'8 cis8 e8 | %58
    d8[ a8 d,8] fis8 g4 r8 g8 | %59
    dis8 fis8 b,8 dis8 e4 r8 e'8 | %60
    ais,8 cis8 fis,8 ais8 b4 r4 | %61
    R1 | %62
    r8 b,8 e8 g8 cis,8 a'4 a8 | %63
    a4. a16 a16 a8 a,8 cis8 e8 | %64
    a8 cis16 cis16 e8 cis16 cis16 a4 r4 | %65
    R2.*15 | %66
    r4 r8 cis,8 eis8. cis16 | %81
    fis8[ \melisma cis8 fis8 a8] cis4. \melismaEnd b8 | %82
    a8 cis8 a8 fis8 cis8[ gis'8 eis8] cis8 | %83
    fis8 r8 r4 r2 | %84
    r2 r8 b,8 e8 gis8 | %85
    a8[ \melisma e8 a8 cis8] e8[ gis,8 b8 d8] | %86
    cis8[ e8 cis8 a8] e8[ b'8 gis8 e8] | %87
    cis8[ e8 cis8 a8] d8[ a'8 fis8 d8] | %88
    ais8[ cis8 ais8 fis8] b8[ fis'8 d8 b8] | %89
    eis8[ gis8 cis,8] \melismaEnd eis8 fis4 r8 fis8 | %90
    gis8 gis8 r8 gis16 gis16 a16 a16 a8 r8 a16 a16 | %91
    b8[ a8] gis8[ fis8] e4 r8 e8 | %92
    a8[ e8] a8[ cis8] b8[ \melisma gis8 b8 d8] | %93
    e,4 \melismaEnd e4 e8 r8 r4 | %94
    R2. | %95
    r4 fis4. a8 | %96
    b4 e4 e,8 e8 | %97
    a8 a,8 e'4. cis8 | %98
    ais4 cis'8. ais16 fis4 | %99
    r4 b4( cis8.) d16 | %100
    d4 gis,4( a4) | %101
    e4 e'8.([ d16)] cis8.([ b16)] | %102
    a8.[ b16 a8. g16] fis8.([ e16)] | %103
    d8.[ e16 d8. cis16 b8.] b'16 | %104
    cis8.[ d16] \once \slurDashed e4( e,4) | %105
    a4 r4 r4 | %106
    r4 d,4. fis8 | %107
    a4 ais2 | %108
    b8.[ fis16 gis8. e16 fis8.] gis16 | %109
    a8.([ d,16)] e2 | %110
    a,2.\fermata | %111
    \barNumberCheck # 112
}
>>

mvtIIbassLyrics = \lyricmode {
    Glo -- ri -- a, glo -- ri -- a, in ex -- cel -- sis De -- o,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    glo -- ri -- a in ex -- cel -- sis,
    in ex -- cel -- sis De -- o.

    Lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus,
    lau -- da -- mus,
    lau -- da -- mus,
    lau -- da -- mus te,
    lau -- da -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,
    ad -- o -- ra -- mus,
    ad -- o -- ra -- mus te,

    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,
    lau -- da -- mus te,
    be -- ne -- di -- ci -- mus te,

    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    glo -- ri -- fi -- ca -- mus te,
    lau -- da -- mus,
    be -- ne -- di -- ci -- mus,

    ad -- o -- ra -- mus -- te,
    glo -- ri -- fi -- ca -- mus te.

    Gra -- ti -- as a -- gi -- mus ti -- bi,
    gra -- ti -- as,
    gra -- ti -- as a -- gi -- mus __ ti -- bi
    pro -- pter ma -- gnam glo -- ri -- am tu -- am,
    pro -- pter ma -- gnam glo -- ri -- am tu -- am.
}

mvtIIbc = <<
\mvtIItimeline
\relative c' {
    \clef F
    a8-. a,8-. r4 gis'8 gis,8 r4 | %1
    a'16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 gis,16 b16 e,16 gis16 | %2
    cis,8 cis'8 r4 d,16 fis16 a16 a16 fis16 a16 d,16 fis16 | %3
    ais,8 ais'8 r4 b,16 d16 fis16 fis16 d16 fis16 b,16 d16 | %4
    eis,8 eis'8 r4 fis16 a16 cis16 cis16 a16 a16 fis16 fis16 | %5
    gis16 b16 d16 d16 b16 b16 gis16 gis16 a16 a16 e16 e16 cis16 cis16 a16 a16 | %6
    b16 b16 a16 a16 gis16 gis16 fis16 fis16 e8 e'8 r4 | %7
    e,8 e'8 r4 e,8 e'8 r4 | %8
    e16 gis16 b16 b16 gis16 b16 e,16 gis16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %9
    cis,4 r4 r4 | %10
    fis4 r4 r4 | %11
    b,4 e4 e,4 | %12
    a4 r4 r4 | %13
    ais4 r4 r4 | %14
    b4 r4 r4 | %15
    d4 cis4 a4 | %16
    e'4 r4 r4 | %17
    a,4 r4 r4 | %18
    a'4 r4 r4 | %19
    \once \slurDashed gis8.( a16) b4 b,4 | %20
    e4 r4 r4 | %21
    a,4 r4 r4 | %22
    e4 r4 r4 | %23
    a4 r4 r4 | %24
    e'4 r4 r4 | %25
    a8 a,8 r4 gis'8 gis,8 r4 | %26
    a'16 cis16 e16 e16 cis16 e16 a,16 cis16 e,8 e'8 r4 | %27
    a,8 a,8 r4 gis'8 gis,8 r4 | %28
    a'16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 gis,16 b16 e,16 gis16 | %29
    cis,8 cis'8 r4 d,16 fis16 a16 a16 fis16 a16 d,16 fis16 | %30
    ais,8 ais'8 r4 b,16 d16 fis16 fis16 d16 fis16 b,16 d16 | %31
    eis,8 eis'8 r4 fis16 a16 cis16 cis16 a16 a16 fis16 fis16 | %32
    gis16 b16 d16 d16 b16 b16 gis16 gis16 a16 a16 e16 e16 cis16 cis16 a16 a16 | %33
    b16 b16 a16 a16 gis16 gis16 fis16 fis16 e8 e'8 r4 | %34
    e,8 e'8 r4 e,8 e'8 r4 | %35
    e16 gis16 b16 b16 gis16 b16 e,16 gis16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %36
    cis,4 r4 r4 | %37
    fis4 r4 r4 | %38
    b,4 e4 e,4 | %39
    a4 r4 r4 | %40
    ais4 r4 r4 | %41
    b4 r4 r4 | %42
    d4 cis4 a4 | %43
    e'4 r4 r4 | %44
    eis4 r4 r4 | %45
    b'4 r4 r4 | %46
    a8.( b16) cis4 cis,4 | %47
    fis4 r4 r4 | %48
    b,4 r4 r4 | %49
    fis4 r4 r4 | %50
    d'4 r4 r4 | %51
    cis8.( b16) cis4 cis,4 | %52
    fis8 fis'8 r4 eis,8 eis'8 r4 | %53
    fis16 a16 cis16 cis16 a16 cis16 fis,16 a16 cis,16 gis'16 cis16 cis16 eis,16 gis16 cis,16 eis16 | %54
    fis,16 a16 cis16 cis16 a16 a16 fis16 fis16 b16 d16 fis16 fis16 d16 d16 b16 b16 | %55
    e16 g16 b16 b16 g16 g16 e16 e16 a16 cis16 e16 e16 cis16 cis16 a16 a16 | %56
    d8 d,8 r4 cis'8 cis,8 r4 | %57
    d16 fis16 a16 a16 fis16 a16 d,16 fis16 a,16 e'16 a16 a16 cis,16 e16 a,16 cis16 | %58
    fis,8 fis'8 r4 g16 b16 d16 d16 b16 d16 g,16 b16 | %59
    dis,8 dis'8 r4 e,16 g16 b16 b16 g16 b16 e,16 g16 | %60
    ais,8 ais'8 r4 b,16 d16 fis16 fis16 d16 d16 b16 b16 | %61
    cis16 e16 g16 g16 e16 e16 cis16 cis16 d16 d16 a16 a16 fis16 fis16 d16 d16 | %62
    e16 e16 d'16 d16 cis16 cis16 b16 b16 a8 a'8 r4 | %63
    a,8 a'8 r4 a,8 a'8 r4 | %64
    a,16 cis16 e16 e16 cis16 e16 a,16 cis16 g16 cis16 e16 e16 cis16 e16 g,16 cis16 | %65
    fis,4 r4 r4 | %66
    b4 r4 r4 | %67
    e4 a4 a,4 | %68
    d4 r4 r4 | %69
    dis4 r4 r4 | %70
    e4 r4 r4 | %71
    g4 fis4 d4 | %72
    a'4 r4 r4 | %73
    fis4 r4 r4 | %74
    dis4 r4 r4 | %75
    e8.( fis16) gis4 gis,4 | %76
    cis4 r4 r4 | %77
    fis,4 r4 r4 | %78
    cis'4 r4 r4 | %79
    fis4 r4 r4 | %80
    cis'4 r4 r4 | %81
    fis,8 fis,8 r4 eis'8 eis,8 r4 | %82
    fis'16 a16 cis16 cis16 a16 cis16 fis,16 a16 cis,16 gis'16 cis16 cis16 eis,16 gis16 cis,16 eis16 | %83
    fis,8 fis'8 r4 gis,8 gis'8 r4 | %84
    a16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 gis,16 b16 e,16 gis16 | %85
    a8 a,8 r4 gis'8 gis,8 r4 | %86
    a'16 cis16 e16 e16 cis16 e16 a,16 cis16 e,16 b'16 e16 e16 gis,16 b16 e,16 gis16 | %87
    cis,8 cis'8 r4 d,16 fis16 a16 a16 fis16 a16 d,16 fis16 | %88
    ais,8 ais'8 r4 b,16 d16 fis16 fis16 d16 fis16 b,16 d16 | %89
    eis,8 eis'8 r4 fis16 a16 cis16 cis16 a16 a16 fis16 fis16 | %90
    gis16 b16 d16 d16 b16 b16 gis16 gis16 a16 a16 e16 e16 cis16 cis16 a16 a16 | %91
    b16 b16 a16 a16 gis16 gis16 fis16 fis16 e8 e'8 r4 | %92
    e,8 e'8 r4 e,8 e'8 r4 | %93
    e16 gis16 b16 b16 gis16 b16 e,16 gis16 d16 gis16 b16 b16 gis16 b16 d,16 gis16 | %94
    cis,4 r4 r4 | %95
    fis4 r4 r4 | %96
    b,4 e4 e,4 | %97
    a4 r4 r4 | %98
    ais4 r4 r4 | %99
    b4 r4 r4 | %100
    d4 gis,4 a4 | %101
    e'4 r4 r4 | %102
    a,4 r4 r4 | %103
    d4 r4 b4 | %104
    cis8.( d16) e4 e,4 | %105
    a4 r4 r4 | %106
    d4 r4 r4 | %107
    a'4 r4 ais4 | %108
    b8.( fis16) gis8.( e16) fis8.( gis16) | %109
    a8. d,16 e4 e,4 | %110
    a2.-\fermata | %111
    \barNumberCheck # 112
}
>>

mvtIIfigs = \figuremode {
    s2 <6> |
    s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6>2 <6>4 |
    <6>2 s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6>4 |
    <6>2 s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6>4 |
    \barNumberCheck # 5
    <6>2. <6>4 |
    <6>4 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> s8 s4 <6> |
    s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6 5>4 <7>2 |
    <6 4> <5 4> |
    s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> s4 <6 4>2 |
    \barNumberCheck # 10
    <6>2. |
    <7 5> |
    <7>4 <6 4> <5 3> |
    s2. |
    <6 5> |
    <9>4 <8> s |
    <4 2> <6> s |
    s2. |
    <9 7 4>4 <8 6 3> <5> |
    <4\+ 2>2. |
    <6>4 <6 4> <5 _+> |
    \barNumberCheck # 21
    <8>4 s <7> |
    <9 4> <8 3> s |
    s <7> s |
    <9 4> <8 3> s |
    <8> <7> s |
    \barNumberCheck # 26
    s2 <6> |
    s4 <6>2. |
    s2 <6> |
    \barNumberCheck # 29
    s4 <6> s <6> |
    <6>2. <6>4 |
    <6>2. <6>4 |
    <6 5>2. <6>4 |
    \barNumberCheck # 33
    <6>4 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> s8 s4 <6> |
    <5 3> <7 5> <7>2 |
    <6 4> <5 3> |
    s4 <6> <6 4 2> s |
    \barNumberCheck # 37
    <6>2. |
    <7> |
    <7>4 <6 4> <5 3> |
    s2. |
    \barNumberCheck # 41
    <6 5> |
    <9>4 <8> s |
    <4 2> <6> s |
    s2. |
    <7 5> |
    <4\+ 2> |
    <6>4 <6 4> <5 _+> |
    s s <7 _+> |
    <9 4> <8 3> s |
    <6 4> <5 3> s |
    <7 5> <6 4 3> s |
    <6 4> <5 _+> s |
    \barNumberCheck # 53
    s2 <6> |
    s4 <6> <_+> <6> |
    s <6> s <6> |
    <_!> <6> s <6> |
    s2 <6> |
    s4 <6> s <6> |
    \barNumberCheck # 59
    <6> s s <6!> |
    <6 5> s <_!> <6> |
    <6 5> s s <6> |
    <6> <6 _!> s <6> |
    s8 <6 4! 2> <6 5!> <6!> <7! 5> s s4 |
    <6 4>2 <5 3> |
    s4 <6> <6 4 2> <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> s8 |
    \barNumberCheck # 66
    s2. |
    <7 5> |
    <7 _!>4 <6 4> <5 3> |
    s2. |
    <6 5> |
    \barNumberCheck # 71
    <9 4>4 <8 _!> s |
    <4 2> <6> s |
    s2. |
    <7 5>4 <6\\> s |
    <6\\ 5>2. |
    <6>4 <6 4> <5 _+> |
    s s <7 _+> |
    <9 4> <8 3> s |
    <5 _!> s <7> |
    <9 4> <8 3> s |
    <5 _+>2. |
    \barNumberCheck # 82
    s2 <6> |
    s4 <6> <_+> <6> |
    s2 <6> |
    s4 <6> s <6> |
    s2 <6> |
    s4 <6> s <6> |
    \barNumberCheck # 88
    <6> s s <6> |
    <6> s s <6> |
    <6 5> s s <6> |
    <6> <6 4 3> s8 <\FBnull>16 \once \bassFigureExtendersOn <\FBnull> <6>4 |
    \barNumberCheck # 92
    s8 <6 4 2> <6 5> <6> <7 3>4 s |
    <6 4> s <5 3> s |
    s16 <\FBnull>8 \once \bassFigureExtendersOn <\FBnull>16 <6>4 <6 4 2>2 |
    \barNumberCheck # 95
    <6>2. |
    <7> |
    <7>4 <6 4> <5 3> |
    s2. |
    <6 5> |
    <9>4 <8> s |
    <4 2> <6 5> s |
    s2. |
    <7!> |
    <4!>4 <3> <6> |
    <6> <6 4> <5 3> |
    <8> s <7!> |
    <4!> <3> s |
    <6 4> <5 3> <6 5> |
    s <6 5>8. <\FBnull>4 \once \bassFigureExtendersOn <\FBnull>16 |
    s8. <6 5>16 <6 4>4 <5 3> |
    s2. |
    \barNumberCheck # 112
}

\addQuote mvtIIvlnI     { \mvtIIvlnI }
\addQuote mvtIIalto     { \mvtIIalto }
\addQuote mvtIItenor    { \mvtIItenor }
\addQuote mvtIIbass     { \mvtIIbass }

#(define ownInstr  (if (defined? 'ownInstr) #{ \markup\halign #-0.5 \normalsize\upright\concat{( \ownInstr )} #}  #{ \markup\halign #0.5 \normalsize\upright{(Vln.)} #}))

mvtIIcuesVl = <<
    \new Voice = mvtIIcueVoice {
        s1*9 |
        s2.*8 |
        \barNumberCheck # 18
        <>^\markup\normalsize{Alto}
        \quoteDuring mvtIIalto {
            \cueClef treble \tiny \voiceTwo \autoBeamOff
            s2.*5 |
            \cueClefUnset
        }
        s2.*3 |
        <>^\ownInstr
        \barNumberCheck # 26
        s1*11 |
        \barNumberCheck # 37
        s2.*8 |
        \barNumberCheck # 45
        <>^\markup\normalsize{Basso}
        \quoteDuring mvtIIbass {
            \cueClef bass \tiny \voiceOne \autoBeamOff
            s2.*8 |
            \cueClefUnset
        }
        \barNumberCheck # 53
        <>^\ownInstr
        s1*13 |
        \barNumberCheck # 66
        s2.*11 |
        \barNumberCheck # 77
        <>^\markup\normalsize{Tenore}
        \quoteDuring mvtIItenor {
            \cueClef "treble_8" \tiny \voiceOne \autoBeamOff
            s2.*5 |
            \cueClefUnset
        }
        <>^\ownInstr
    }
    \new Lyrics \with {
        \override LyricText.font-size = #-1.5
    } \lyricsto mvtIIcueVoice {
        \lyricmode {
            pax __ ho -- mi -- ni -- bus
            bo -- nae vo -- lun -- ta -- tis __

            ad -- o -- ra -- mus,
            ad -- o -- ra -- mus te,
            ad -- o -- ra -- mus,
            ad -- o -- ra -- mus % te,

            te,
            ad -- o -- ra -- mus,
            ad -- o -- ra -- mus te,
            glo -- ri -- fi
        }
    }
>>

