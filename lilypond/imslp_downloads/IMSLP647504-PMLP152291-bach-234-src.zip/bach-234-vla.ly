\version "2.21.0"

ownInstr = "Vla."

\include "include-once.ily"
\includeOnce "bach-234-01.ily"
\includeOnce "bach-234-02.ily"
\includeOnce "bach-234-03.ily"
\includeOnce "bach-234-04.ily"
\includeOnce "bach-234-05.ily"
\includeOnce "bach-234-06.ily"

\includeOnce "bach-234-title.ily"
\includeOnce "bach-paged-title.ily"

% \include "last-page-copyright.ily"

\header {
    instrument = "Viola"
}

\paper {
    page-count = 8      % finalize
    % ragged-last-bottom = ##f
}

\layout {
    \context {
        \StaffGroup {
            \revert StaffGroup.SystemStartBracket.collapse-height
        }
    }
    \context {
        \GrandStaff {
            \revert PianoStaff.SystemStartBrace.collapse-height
        }
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtIvla
    >>

    \header {
        piece = \mvtIpiece
    }
}
\score {
    \keepWithTag #'( PARTS ) \new Staff \with {
    } \context Bottom <<
        \mvtIIvla
        \mvtIIcuesVl
        {
            s1*9 |
            s2.*16 |
            \barNumberCheck # 26
            s1*11 |
            \barNumberCheck # 37
            s2.*8 |
            \barNumberCheck # 45
            \pageTurn
            s2.*8 |
            \barNumberCheck # 53
            s1*13 |
            \barNumberCheck # 66
            s2.*11 |
            \barNumberCheck # 77
            % \pageTurn
        }
    >>

    \header {
        piece = \mvtIIpiece
        % breakbefore = ##t
    }
}

\markup\Tacet{\mvtIIIpiece}

\score {
    \new StaffGroup <<
        \new Staff \with {
        } \context Bottom <<
            \clef alto \mvtIVvl
        >>
    >>

    \header {
        piece = \mvtIVpiece
        % breakbefore = ##t
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \clef alto \mvtVvl
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }
}


\score {
    \new Staff \with {
    } \context Bottom <<
        \mvtVIvla
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }
}
