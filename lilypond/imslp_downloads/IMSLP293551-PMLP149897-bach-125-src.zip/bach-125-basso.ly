\version "2.18.0"

\include "bach-125-2.ly"

% #(set-global-staff-size 17)

\include "bach-125-title.ly"
\include "bach-paged-title.ly"

\paper {
    two-sided = ##t
    indent = 0
    page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##f
}

\header {
    instrument = "Basso Continuo"
}


% %{

\score {
    \new Staff <<
	\mvtIIbasso
    >>

    \header {
	piece = \mvtIIpiece
    }

    \layout {
    }
}
