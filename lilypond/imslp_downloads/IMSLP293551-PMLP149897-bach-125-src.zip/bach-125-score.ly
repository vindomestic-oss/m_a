\version "2.18.0"

\include "baroque-clefs.ly"
\include "bach-125-score-common.ly"
