\version "2.18.0"

\include "bach-125-score-common.ly"
