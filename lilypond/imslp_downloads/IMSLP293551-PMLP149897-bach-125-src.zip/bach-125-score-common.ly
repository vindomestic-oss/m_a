\version "2.18.0"

\include "common-grand-score.ly"

\include "bach-125-2.ly"

\include "bach-125-title.ly"
\include "bach-paged-title.ly"

\paper {
    indent = 12
    short-indent = 8
    ragged-last-bottom = ##f
    % system-system-spacing = #'((basic-distance . 4) (minimum-distance . 4) (padding . 1) (stretchability . 60))
    % % system-system-spacing #'basic-distance = #25
    % system-system-spacing #'minimum-distance = #15
    % page-count = 9
}

\markup\null
\pageBreak


#(set-global-staff-size 15)


mvtIIbreaks = {
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \pageBreak

    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \pageBreak

    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \pageBreak

    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \pageBreak

    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \pageBreak

    s2.*5
    \break
    s2.*5
    \break
    s2.*5
    \break
    s2.*4
    \pageBreak

    s2.*4
    \break
    s2.*4
    \break
    s2.*4
    \break
    s2.*4
    \bar "||"
}


\score {
    \new StaffGroup <<
        \new GrandStaff <<
            \new Staff = staffA <<
                \mvtIIfl

                \set Staff.instrumentName = \markup{\center-column{"Flauto" "traverso"}}
                \set Staff.shortInstrumentName = "Fl."
                % \mvtIIbreaks
            >>

            \new Staff = staffB <<
                \transpose \transpObDAm c \mvtIIobda
                \set Staff.instrumentName = \markup\center-column{"Oboe" "d'amore"}
                \set Staff.shortInstrumentName = "Ob.d'A."
            >>
        >>

        \new Staff = staffC <<
	    \clefAlto \mvtIIalto
	    \set Staff.instrumentName = \markup\bold{"Alto"}
	    \set Staff.shortInstrumentName = \markup\bold{"A."}
        >>

        \new Staff = staffD <<
	    \mvtIIbasso
	    \set Staff.instrumentName = "Continuo"
	    \set Staff.shortInstrumentName = "B.C."
        >>
    >>

    \header {
	piece = \mvtIIpiece
    }
}
