\version "2.18.0"

\header {
    title = \markup{ "Mit Fried und Freud ich fahr dahin" }
    opus = \markup{ BWV 125 }
    subtitle = \markup{ Mariae Reinigung }
    composer = "J.S. Bach"
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2015 Creative Commons Attribution Non-commercial ShareAlike 3.0}}
}

\layout {
}

mvtIIpiece = \markup{II. Aria}
