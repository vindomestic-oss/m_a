\version "2.18.0"

\include "common.ly"

mvtIItimeLine = {
    \time 3/4
    \key b \minor

    s2.
    \segno
    s2.*134
    \dalSegno
    \bar "||"
}


mvtIIfl = \relative c'' <<
{
    r4 r8 r16 fis16_\markup{piano sempre}  \appoggiatura{ fis8 } e8. d16 | % bar 1
    \appoggiatura{ d8 } cis4. r16 d16 \appoggiatura{ d8 } cis8. d16 | % bar 2
    \appoggiatura{ d8 } e4 g,8. g'16 \appoggiatura{ g8 } fis8. e16 | % bar 3
    \appoggiatura{ e8 } d8.( cis16) e8.( d16) \appoggiatura{ d8 } cis8.( b16) | % bar 4
    fis'4. r16 g16 \appoggiatura{ g8 } fis8. e16 | % bar 5
    \appoggiatura{ e8 } dis4. r16 e16 \appoggiatura{ e8 } fis8. g16 | % bar 6
    \appoggiatura{ g8 }  a4 c,8. a'16 \appoggiatura{ a8 }  g8. fis16 | % bar 7
    \appoggiatura{ fis8 }  g4. r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 8
    \appoggiatura{ b8 }  cis4 e,8. cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 9
    \appoggiatura{ e8 }  fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 10
    b16( d16 cis16 b16) eis4-\trill r8 r16 \schleifer fis16 | % bar 11
    d'8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 12
    b4-\fermata r4 r4 | % bar 13
    r8 r16 fis16_"piano" \appoggiatura{ fis8 }  e8. d16 \appoggiatura{ d8 }  cis4 | % bar 14
    r4 r8 r16 g'16 \appoggiatura{ g8 }  fis8. e16 | % bar 15
    \appoggiatura{ e8 }  d8. \schleifer cis16 e8.( d16) \appoggiatura{ d8 }  cis8.( b16) | % bar 16
    fis'4. r16 g16_"poco forte" \appoggiatura{ g8 }  fis8. e16 | % bar 17
    \appoggiatura{ e8 }  dis4. r16 e16 \appoggiatura{ e8 }  fis8. g16 | % bar 18
    \appoggiatura{ g8 }  a4 c,8. a'16 \appoggiatura{ a8 }  g8. fis16 | % bar 19
    \appoggiatura{ fis8 }  g4. r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 20
    \appoggiatura{ b8 }  cis4 e,8. cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 21
    \appoggiatura{ e8 }  fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 22
    b16( d16 cis16 b16) eis4-\trill r8 r16 \schleifer fis16 | % bar 23
    d'8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 24
    b4 r8 r16 b16_\markup{piano} \appoggiatura{ b8 }  ais8. b16 | % bar 25
    \appoggiatura{ fis8 }  e4. r16 g16 \appoggiatura{ fis8 }  fis8. g16 | % bar 26
    \appoggiatura{ d8 }  cis4~  cis16 e16( d16 cis16) fis4~  | % bar 27
    fis8. a16 \appoggiatura{ a8 }  g8. fis16 \appoggiatura{ fis8 }  e8. b'16 | % bar 28
    \appoggiatura{ b8 }  ais4 r4 r8 r16 cis16 | % bar 29
    fis,4~  fis16 e16(  d16 e16) \appoggiatura{ e8 }  fis8. d16 | % bar 30
    \appoggiatura{ cis8 }  b8. e,16 d'2~  | % bar 31
    d8. gis,16 \appoggiatura{ gis8 }  a8. b16 \appoggiatura{ b8 }  cis4~  | % bar 32
    cis4 r4 r8 r16 a'16 | % bar 33
    d,4 r8 r16 b16 \appoggiatura{ b8 }  cis8. d16 | % bar 34
    a4 r8 r16 a16 \appoggiatura{ a8 }  b8. cis16 | % bar 35
    \appoggiatura{ cis8 }  d4 ~ d16 fis16( e16 d16) a'8. b16 | % bar 36
    \appoggiatura{ b8 }  c8. fis,16 \appoggiatura{ e8 }  dis8. e16 \appoggiatura{ e8 }  dis8. e16 | % bar 37
    \appoggiatura{ e8 }  fis4 a,8. a'16 \appoggiatura{ a8 }  g8. fis16 | % bar 38
    \appoggiatura{ fis8 }  e8. d16 g8. fis16 \appoggiatura{ fis8 }  e8. d16 | % bar 39
    e4~  e16 g16( fis16 e16) \appoggiatura{ b'8 }  ais4 | % bar 40
    r4 r8 r16 fis16 \appoggiatura{ fis8 }  e8. d16 | % bar 41
    e16( cis16 d16 e16) a,2 | % bar 42
    R2. | % bar 43
    r4 r8 r16 fis'16_\markup{poco forte} \appoggiatura{ fis8 }  e8. d16 | % bar 44
    \appoggiatura{ d8 }  cis4. r16 d16 \appoggiatura{ d8 }  cis8. d16 | % bar 45
    \appoggiatura{ d8 }  e4 g,8. g'16 \appoggiatura{ g8 }  fis8. e16 | % bar 46
    \appoggiatura{ e8 }  d8. cis16 \appoggiatura{ cis8 }  b8. a16 \appoggiatura{ a8 }  gis8. d'16 | % bar 47
    \appoggiatura{ d8 }  cis4.-\trill d8 \appoggiatura{ d8 }  e4~  | % bar 48
    e8. a,16 d8. e16 \appoggiatura{ e8 }  fis8. g16 | % bar 49
    \appoggiatura{ g8 }  a2. ~ | % bar 50
    a8. d,16 g8. fis16 e8.-\trill d16 | % bar 51
    cis'4. r16 cis,16 \appoggiatura{ cis8 }  d8. e16 | % bar 52
    \appoggiatura{ e8 }  fis8. e16 \appoggiatura{ d8 }  cis4.-\trill d8 | % bar 53
    d4~  d16 fis16(  e16 d16) a'4~  | % bar 54
    a8. b16 \appoggiatura{ fis8 }  e4.-\trill d8 | % bar 55
    d4 r4 r4 | % bar 56
    R2. | % bar 57
    r4 r8 r16 g16_\markup{(piano)} \appoggiatura{ g8 }  a8. b16 | % bar 58
    c,4. c8 e8. d16 | % bar 59
    \appoggiatura{ c8 }  b4 b'4 r4 | % bar 60
    c,8. e16 a8. fis16 \appoggiatura{ e8 }  dis8. e16 | % bar 61
    e2.~  | % bar 62
    e4 d8.-\trill c16 d4~  | % bar 63
    d8. c16 b8. d16 a'8. gis16 | % bar 64
    \appoggiatura{ gis8 }  a4 r4 r4 | % bar 65
    R2. | % bar 66
    r4 r8 r16 g16 \appoggiatura{ g8 }  fis8. e16 | % bar 67
    \appoggiatura{ e8 }  dis4 r4 r4 | % bar 68
    R2.*3 | % bar 69
    r4 r8 r16 b16_\markup{poco forte} \appoggiatura{ b8 }  a8. g16 | % bar 72
    \appoggiatura{ g8 }  fis4. r16 g16 \appoggiatura{ g8 }  fis8. g16 | % bar 73
    \appoggiatura{ g8 }  a4. r16 c16 \appoggiatura{ c8 }  b8. a16 | % bar 74
    \appoggiatura{ a8 }  gis4. r16 a16 \appoggiatura{ a8 }  gis8. a16 | % bar 75
    \appoggiatura{ a8 }  b4. r16 f'16 \appoggiatura{ f8 }  e8. d16 | % bar 76
    \appoggiatura{ d8 }  c8. b16 d8. c16 \appoggiatura{ c8 }  b8. a16 | % bar 77
    dis4~  dis16 fis16(  e16 dis16) b'4~  | % bar 78
    b8. c16 \appoggiatura{ g8 }  fis4.-\trill e8 | % bar 79
    e4 r4 r4 | % bar 80
    R2. | % bar 81
    r4 r8 r16 d16_\markup{piano} \appoggiatura{ d8 }  cis8. b16 | % bar 82
    \appoggiatura{ fis'8 }  eis4. r16 fis16 \appoggiatura{ fis8 }  gis8. b,16 | % bar 83
    \appoggiatura{ b8 }  a2. ~ | % bar 84
    a8 gis8 gis2 ~ | % bar 85
    gis2. ~ | % bar 86
    gis8 fis8 fis4 dis'4( ~  | % bar 87
    dis4 e8.) b16 \appoggiatura{ a8 }  gis8. a16 | % bar 88
    \appoggiatura{ a8 }  b4 ~ b16 d16( cis16 b16) gis'4~  | % bar 89
    gis16 b16( a16 gis16) cis8 r8 r4 | % bar 90
    r4 r8 r16 a16 \appoggiatura{ a8 }  gis8. fis16 | % bar 91
    \appoggiatura{ fis8 }  eis4. fis8 \appoggiatura{ fis8 }  eis8. fis16 | % bar 92
    \appoggiatura{ fis8 }  gis4 r4 r4 | % bar 93
    R2. | % bar 94
    r4 r8 r16 fis16 \appoggiatura{ fis8 }  e8. d16 | % bar 95
    \appoggiatura{ d8 }  cis4. r16 d16 \appoggiatura{ d8 }  cis8. d16 | % bar 96
    \appoggiatura{ d8 }  e4. r16 g16 fis8. e16 | % bar 97
    \appoggiatura{ e8 }  d8. b16 e8. d16 \appoggiatura{ d8 }  cis8. b16 | % bar 98
    \appoggiatura{ e8 }  fis4. r16 g16_\markup{(poco forte)} \appoggiatura{ g8 }  fis8. e16 | % bar 99
    \appoggiatura{ e8 }  dis4. r16 e16 \appoggiatura{ e8 }  fis8. g16 | % bar 100
    \appoggiatura{ g8 }  a4 c,8. a'16 \appoggiatura{ a8 }  g8. fis16 | % bar 101
    \appoggiatura{ fis8 }  g4. r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 102
    \appoggiatura{ b8 }  cis4 e,8. cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 103
    \appoggiatura{ e8 }  fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 104
    b16( d16 cis16 b16) eis4-\trill r8 r16 \schleiferVH fis16 #0.2 #0.3 | % bar 105
    d'8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 106
    b4 r4 r4 | % bar 107
    r8 r16 fis16_"(piano)" \appoggiatura{ fis8 }  e8. d16 \appoggiatura{ d8 }  cis4 | % bar 108
    r4 r8 r16 g'16 \appoggiatura{ g8 }  fis8. e16 | % bar 109
    \appoggiatura{ e8 }  d8. \schleiferVH cis16 #-0.7 #1.5 e8. d16 \appoggiatura{ d8 }  cis8. b16 | % bar 110
    fis'4. r16 fis16_\markup{(poco forte)} g8. fis16 | % bar 111
    \appoggiatura{ fis8 }  eis4. r16 e16 \appoggiatura{ e8 }  fis8. e16 | % bar 112
    \appoggiatura{ e8 }  dis4. r16 d16 \appoggiatura{ d8 }  e8. d16 | % bar 113
    \appoggiatura{ d8 }  cis8. d16 \appoggiatura{ d8 }  e8. fis16 \appoggiatura{ e8 }  d8. cis16 | % bar 114
    \appoggiatura{ cis8 }  d8. b16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 115
    b4 r8 r16 b'16_\markup{(piano)} \appoggiatura{ b8 }  ais8. b16 | % bar 116
    \appoggiatura{ fis8 }  e4. r16 g16 \appoggiatura{ g8 }  fis8. g16 | % bar 117
    \appoggiatura{ d8 }  cis4 ~ cis16 e16(  d16 cis16) fis4 ~ | % bar 118
    fis8. a16 \appoggiatura{ a8 }  g8. fis16 \appoggiatura{ fis8 }  e8. b'16 | % bar 119
    \appoggiatura{ b8 }  ais4 r4 r8 r16 cis16 | % bar 120
    fis,4 ~ fis16 e16( d16 e16) \appoggiatura{ e8 }  fis8. d16 | % bar 121
    \appoggiatura{ cis8 }  b8. e,16 d'2~  | % bar 122
    d8. gis,16 \appoggiatura{ gis8 }  a8. b16 \appoggiatura{ b8 }  cis4~ | % bar 123
    cis4 r4 r8 r16 a'16 | % bar 124
    d,4 r8 r16 b16 \appoggiatura{ b8 }  cis8. d16 | % bar 125
    a4 r8 r16 a16 \appoggiatura{ a8 }  b8. cis16 | % bar 126
    \appoggiatura{ cis8 }  d4 ~ d16 fis16( e16 d16) a'8. b16 | % bar 127
    \appoggiatura{ b8 }  c8. fis,16 \appoggiatura{ e8 }  dis8. e16 \appoggiatura{ e8 }  dis8. e16 | % bar 128
    \appoggiatura{ e8 }  fis4 a,8. a'16 \appoggiatura{ a8 }  g8. fis16 | % bar 129
    \appoggiatura{ fis8 }  e8. d16 \appoggiatura{ d8 }  cis8. d16 \appoggiatura{ d8 }  cis8. d16 | % bar 130
    \appoggiatura{ d8 }  e4 r8 r16 cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 131
    \appoggiatura{ e8 }  d8. g16 \appoggiatura{ g8 }  fis8. e16 \appoggiatura{ e8 }  d8. cis16 | % bar 132
    \appoggiatura{ cis8 }  b4 ~ b16 d16( cis16 b16) g'8 r8 | % bar 133
    R2. | % bar 134
    r4 r8 r16 fis16 \appoggiatura{ fis8 }  e8. d16 | % bar 135
}
\mvtIItimeLine
>>


mvtIIobda = \relative c'' <<
{
    r4 r8 r16 d16_\markup{piano sempre}  cis8.-\trill b16 | % bar 1
    \appoggiatura{ b8 }  ais4. r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 2
    \appoggiatura{ b8 }  cis4 e,8. e'16 d8.-\trill cis16 | % bar 3
    \appoggiatura{ cis8 }  b8.( a16) \appoggiatura{ a8 }  g8.( fis16) \appoggiatura{ fis8 }  e8.( b'16) | % bar 4
    \appoggiatura{ b8 }  ais4. r16 b16 \appoggiatura{ b8 }  a8. g16 | % bar 5
    \appoggiatura{ g8 }  fis4. r16 cis'16 \appoggiatura{ cis8 }  dis8. e16 | % bar 6
    \appoggiatura{ e8 }  fis4 a,8. fis'16 \appoggiatura{ fis8 }  e8. dis16 | % bar 7
    \appoggiatura{ dis8 }  e4. r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 8
    \appoggiatura{ b8 }  ais8. b16 \appoggiatura{ b8 }  cis8. ais16 \appoggiatura{ ais8 }  b8. cis16 | % bar 9
    \appoggiatura{ cis8 }  d8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 10
    b4 ~ b16 d16( cis16 b16) fis'4~  | % bar 11
    fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 12
    b4-\fermata r4 r4 | % bar 13
    r8 r16 d16_"piano" \appoggiatura{ d8 }  cis8. b16 \appoggiatura{ b8 }  ais4 | % bar 14
    r4 r8 r16 e'16 \appoggiatura{ e8 }  d8. cis16 | % bar 15
    \appoggiatura{ cis8 }  b8. a16 \appoggiatura{ a8 }  g8. fis16 \appoggiatura{ fis8 }  e8. b'16 | % bar 16
    ais4. r16 b16_"(poco) forte" \appoggiatura{ b8 }  a8. g16 | % bar 17
    \appoggiatura{ g8 }  fis4. r16 cis'16 \appoggiatura{ cis8 }  dis8. e16 | % bar 18
    \appoggiatura{ e8 }  fis4 a,8. fis'16 \appoggiatura{ fis8 }  e8. dis16 | % bar 19
    \appoggiatura{ dis8 }  e4. r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 20
    \appoggiatura{ b8 }  ais8. b16 \appoggiatura{ b8 }  cis8. ais16 \appoggiatura{ ais8 }  b8. cis16 | % bar 21
    \appoggiatura{ cis8 }  d8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 22
    b4 ~ b16 d16( cis16 b16) fis'4~  | % bar 23
    fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 24
    b4 r8 r16 fis'16_\markup{piano} \appoggiatura{ fis8 }  e8. d16 | % bar 25
    \appoggiatura{ d8 }  cis4. r16 d16 \appoggiatura{ d8 }  cis8. d16 | % bar 26
    e,16( g16 fis16 e16) cis'4~  cis8. ais16 | % bar 27
    \appoggiatura{ ais8 }  b4 r8 r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 28
    \appoggiatura{ b8 }  cis8. fis,16 e'2~  | % bar 29
    e8. ais,16 \appoggiatura{ ais8 }  b8. cis16 \appoggiatura{ cis8 }  d4 ~ | % bar 30
    d4 r4 r8 r16 b16 | % bar 31
    e,4 ~ e16 d16( cis16 d16) e8. cis16 | % bar 32
    a8. d16 c'2 ~ | % bar 33
    c8. b16 g'8.(  a32 b32) a8.(  g16) | % bar 34
    \appoggiatura{ fis8 }  e4 r8 r16 cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 35
    a,16( cis16 b16 a16) d4 r4 | % bar 36
    r8 r16 a16 \appoggiatura{ g8 }  fis8. g16 \appoggiatura{ g8 }  fis8. g16 | % bar 37
    \appoggiatura{ g8 }  a4 fis8. c'16 \appoggiatura{ c8 }  b8. a16 | % bar 38
    \appoggiatura{ a8 }  g8. b16 e8. d16 \appoggiatura{ d8 }  cis8. b16 | % bar 39
    fis'16 ais,16( gis16 fis16) cis'4 r4 | % bar 40
    r4 r8 r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 41
    a4 ~ a16 e16( fis16 g16) cis,4 | % bar 42
    R2. | % bar 43
    r4 r8 r16 a'16_\markup{(poco) forte} \appoggiatura{ a8 }  g8. fis16 | % bar 44
    \appoggiatura{ fis8 }  e4. r16 fis \appoggiatura{ fis8 }  e8. fis16 | % bar 45
    \appoggiatura{ fis8 }  g4 a,8. b'16 \appoggiatura{ b8 }  a8. g16 | % bar 46
    \appoggiatura{ g8 }  fis8. e16 \appoggiatura { \parenthesize a8 } g8. fis16 \appoggiatura{ fis8 }  e8. d16 | % bar 47
    a'4. r16 b16 \appoggiatura{ b8 }  a8. g16 | % bar 48
    \appoggiatura{ g8 }  fis4. r16 g16 \appoggiatura{ g8 }  a8. b16 | % bar 49
    \appoggiatura{ b8 }  c4 d,8. c'16 \appoggiatura{ c8 }  b8. a16 | % bar 50
    \appoggiatura{ a8 }  b4. r16 d16 \appoggiatura{ d8 }  cis8. d16 | % bar 51
    \appoggiatura{ d8 }  e4 g,8. e16 \appoggiatura{ e8 }  fis8. g16 | % bar 52
    \appoggiatura{ g8 }  a8. b16 \appoggiatura{ fis8 }  e4.-\trill d8 | % bar 53
    d16( fis16 e16 d16) gis4-\trill r8 r16 a16 | % bar 54
    fis'8. e16 \appoggiatura{ d8 }  cis4.-\trill d8 | % bar 55
    d8. e16 \appoggiatura{ e8 }  fis4._\markup{piano} fis,8 | % bar 56
    \appoggiatura{ fis8 }  gis8. b16 e8. cis16 \appoggiatura{ b8 }  ais4 | % bar 57
    b2.~  | % bar 58
    b4 a8.-\trill g16 \appoggiatura{ g8 }  a4 | % bar 59
    r4 r8 r16 e'16 \appoggiatura{ e8 }  fis8. g16 | % bar 60
    a,4. r16 a16 \appoggiatura{ b8 }  c8. b16 | % bar 61
    \appoggiatura{ a8 }  g4 g'4 r8 r16 e16 | % bar 62
    \appoggiatura{ d8 }  c8. b16 \appoggiatura{ a8 }  gis8. b16 f'8.( e16) | % bar 63
    e2.~  | % bar 64
    e4 r4 r4 | % bar 65
    r4 r8 r16 c16 \appoggiatura{ c8 }  b8. a16 | % bar 66
    \appoggiatura{ a8 }  g4. r16 b16 \appoggiatura{ b8 }  a8. g16 | % bar 67
    \appoggiatura{ g8 }  fis4 r4 r4 | % bar 68
    R2.*3 | % bar 69
    r4 r8 r16 g16_\markup{(poco) forte} \appoggiatura{ g8 }  fis8. e16 | % bar 72
    \appoggiatura{ e8 }  dis4. r16 e16 \appoggiatura{ e8 }  dis8. e16 | % bar 73
    \appoggiatura{ e8 }  fis4. r16 a16 \appoggiatura{ a8 }  g8. fis16 | % bar 74
    \appoggiatura{ fis8 }  e4. r16 fis16 \appoggiatura{ fis8 }  e8. fis16 | % bar 75
    \appoggiatura{ fis8 }  gis8. f'16 \appoggiatura{ f8 }  e8. d16 \appoggiatura{ d8 }  c8. b16 | % bar 76
    a2.~  | % bar 77
    a16 c16(  b16 a16) fis'?4. r16 b,16 | % bar 78
    g'8. fis16 \appoggiatura{ e8 }  dis4.-\trill e8 | % bar 79
    e4 r4 r4 | % bar 80
    R2. | % bar 81
    r4 r8 r16 fis,16_\markup{piano} \appoggiatura{ fis8 }  e8. d16 | % bar 82
    gis4. r16 a16 \appoggiatura{ a8 }  b8. gis16 | % bar 83
    gis8-\trill fis8 fis2~  | % bar 84
    fis2. | % bar 85
    r4 r8 r16 e16 \appoggiatura{ e8 }  dis8. cis16 | % bar 86
    a'4. r16 b16 \appoggiatura{ b8 }  c8. a16 | % bar 87
    e4. r16 d16 \appoggiatura{ fis8 }  eis8. fis16 | % bar 88
    gis16( b16 a16 gis16) cis4 ~ cis16 eis16( dis16 cis16) | % bar 89
    gis'4 r4 r4 | % bar 90
    r4 r8 r16 fis16 \appoggiatura{ fis8 }  eis8. fis16 | % bar 91
    \appoggiatura{ cis8 }  b4. cis8 \appoggiatura{ cis8 }  b8. cis16 | % bar 92
    d4 r4 r4 | % bar 93
    R2. | % bar 94
    r4 r8 r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 95
    \appoggiatura{ b8 }  ais4. r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 96
    \appoggiatura{ b8 }  cis4. r8 r4 | % bar 97
    r8 r16 a16 \appoggiatura{ a8 }  g8. fis16 \appoggiatura{ fis8 }  e8. b'16 | % bar 98
    \appoggiatura{ b8 }  ais4. r16 b16_\markup{(poco) forte} \appoggiatura{ b8 }  a8. g16 | % bar 99
    \appoggiatura{ g8 }  fis4. r16 cis'16 \appoggiatura{ cis8 }  dis8. e16 | % bar 100
    \appoggiatura{ e8 }  fis4 a,8. fis'16 \appoggiatura{ fis8 }  e8. dis16 | % bar 101
    \appoggiatura{ dis8 }  e4. r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 102
    \appoggiatura{ b8 }  ais8. b16 \appoggiatura{ b8 }  cis8. ais16 \appoggiatura{ ais8 }  b8. cis16 | % bar 103
    \appoggiatura{ cis8 }  d8. cis16 \appoggiatura{ b8 }  ais4.-\trill b8 | % bar 104
    b4~  b16 d16( cis16 b16) fis'4 ~ | % bar 105
    fis8. g16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 106
    b4 r4 r4 | % bar 107
    r8 r16 d16_"piano" \appoggiatura{ d8 }  cis8. b16 \appoggiatura{ b8 }  ais4 | % bar 108
    r4 r8 r16 e'16 \appoggiatura{ e8 }  d8. cis16 | % bar 109
    \appoggiatura{ cis8 }  b8. a16 \appoggiatura{ a8 }  g8. fis16 \appoggiatura{ fis8 }  e8. b'16 | % bar 110
    \appoggiatura{ b8 }  ais4 d2_\markup{(poco) forte} ~ | % bar 111
    d8. b16 \appoggiatura{ b8 }  cis2~  | % bar 112
    cis8. fis,16 b4. r16 b16 | % bar 113
    \appoggiatura{ b8 }  ais8. b16 \appoggiatura{ b8 }  cis8. d16 \appoggiatura{ cis8 }  b8. ais16 | % bar 114
    \appoggiatura{ ais8 }  b8. d,16 \appoggiatura{ d8 }  cis4.-\trill b8 | % bar 115
    b4 r8 r16 fis''16_\markup{piano} \appoggiatura{ fis8 }  e8. d16 | % bar 116
    \appoggiatura{ d8 }  cis4. r16 d16 \appoggiatura{ d8 }  cis8. d16 | % bar 117
    e,16( g16 fis16 e16) cis'4 ~ cis8. ais16 | % bar 118
    \appoggiatura{ ais8 }  b4 r8 r16 b16 \appoggiatura{ b8 }  ais8. b16 | % bar 119
    \appoggiatura{ b8 }  cis8. fis,16 e'2 ~ | % bar 120
    e8. ais,16 \appoggiatura{ ais8 }  b8. cis16 \appoggiatura{ cis8 }  d4~  | % bar 121
    d4 r4 r8 r16 b16 | % bar 122
    e,4~  e16 d16(  cis16 d16) \appoggiatura{ d8 }  e8. cis16 | % bar 123
    a8. d16 c'2 ~ | % bar 124
    c8. b16 g'8.( a32 b32) a8. g16 | % bar 125
    \appoggiatura{ fis8 }  e4 r8 r16 cis16 \appoggiatura{ cis8 }  d8. e16 | % bar 126
    a,16( cis16 b16 a16) d4 r4 | % bar 127
    r8 r16 a16 \appoggiatura{ g8 }  fis8. g16 \appoggiatura{ g8 }  fis8. g16 | % bar 128
    \appoggiatura{ g8 }  a4 fis8. c'16 \appoggiatura{ c8 }  b4 ~ | % bar 129
    b8. b16 \appoggiatura{ b8 }  ais8. b16 \appoggiatura{ b8 }  ais8. b16 | % bar 130
    \appoggiatura{ b8 }  cis4 r4 r8 r16 cis16 | % bar 131
    fis,8. e'16 \appoggiatura{ e8 }  d8. g,16 \appoggiatura{ g8 }  fis8. e16 | % bar 132
    d16( fis16 e16 d16) b'4 r4 | % bar 133
    R2. | % bar 134
    r4 r8 r16 d16 \appoggiatura{ d8 }  cis8. b16 | % bar 135
}
\mvtIItimeLine
>>



mvtIIalto = \relative c'' <<
{
    \autoBeamOff

    R2.*12 | % bar 1
    r4\fermata r8 b8 \appoggiatura{ b8 }  ais8. b16 | % bar 13
    \appoggiatura{ a4 }  g4. fis8 g8. e16 | % bar 14
    ais8.[( b32 cis32]) cis4 r8 fis,8 | % bar 15
    d'4 r8 b8 \appoggiatura{ b8 }  ais8. b16 | % bar 16
    e,8. cis'16 \appoggiatura{ b8 }  ais4 r4 | % bar 17
    R2.*7 | % bar 18
    r4 r8 d8 \appoggiatura{ d8 }  cis8. b16 | % bar 25
    \appoggiatura{ b4 }  ais4. b8 ais8. b16 | % bar 26
    \appoggiatura{ b8 }  cis4 e,8. g16 \appoggiatura{ g8 }  fis8. e16 | % bar 27
    \appoggiatura{ e8 }  d8. cis16 e8.[( d16]) cis8.[( b16]) | % bar 28
    fis'4 r8 fis8 cis'4 | % bar 29
    r8 fis,8 d'8.[(  cis16]) b8.[( a16]) | % bar 30
    \appoggiatura{ a8 }  gis8.[ fis16] gis8. e16 b'4 | % bar 31
    r8 e,8 cis'8.[( b16]) a8.[( g16]) | % bar 32
    fis8.[(  g32 a32]) d,8. a'16 d4 | % bar 33
    r8 b8 e,8.[( fis32 g32])  fis8.[( e16]) | % bar 34
    d8. cis16 a'2 ~ | % bar 35
    a4 r8 d8 \appoggiatura{ d8 }  cis8. d16 | % bar 36
    a4. b8 c8. b16 | % bar 37
    \appoggiatura{ b8 }  c8.[( b16]) b4 r8 fis8 | % bar 38
    g8. e16 \appoggiatura{ b'4 }  ais4. b8 | % bar 39
    cis8.[( ais16]) fis4 r8 fis8 | % bar 40
    d'8. b16 \appoggiatura{ a4 }  gis4. a8 | % bar 41
    a4 e8. fis16 g8. b16 | % bar 42
    a8. g16 fis8.[( e16]) d'8.[( cis16]) | % bar 43
    \appoggiatura{ cis8 }  d4 r4 r4 | % bar 44
    R2.*11 | % bar 45
    r4 r8 fis,8 \appoggiatura{ b8 }  ais8. b16 | % bar 56
    e,4. \set melismaBusyProperties = #'() \schleiferV e8 #-0.4 g8. fis16 | % bar 57
    \set melismaBusyProperties = #'( melismaBusy slurMelismaBusy tieMelismaBusy beamMelismaBusy )
    \appoggiatura{ e8 }  d4 d'4 r4 | % bar 58
    e,8. g16 c8.[( a16]) fis8.[( g16]) | % bar 59
    g2.( ~ | % bar 60
    g4 fis8.) g16 a4 | % bar 61
    r4 r8 c8 \appoggiatura{ c8 }  b8. c16 | % bar 62
    f,4. \set melismaBusyProperties = #'() \schleiferV f8 #-0.4 a8. g16 | % bar 63
    \set melismaBusyProperties = #'( melismaBusy slurMelismaBusy tieMelismaBusy beamMelismaBusy )
    \appoggiatura{ f8 }  e4 d'4 r4 | % bar 64
    c8. b16 a8.[( g16]) fis8.[( g32 e32]) | % bar 65
    b'2.~  | % bar 66
    b2.~  | % bar 67
    b8. a16 c4 r8 b8 | % bar 68
    \appoggiatura{ a8 }  g8. e16 \appoggiatura{ d8 }  c4 r8 e8 | % bar 69
    a8. fis16 \appoggiatura{ e8 }  dis8. c'16 b4 ~ | % bar 70
    b8. a16 g4 fis16[-\trill( e16 fis8]) | % bar 71
    e4 r4 r4 | % bar 72
    R2.*7 | % bar 73
    r4 r8 g8 \appoggiatura{ g8 }  fis8. e16 | % bar 80
    \appoggiatura{ b'4 }  ais4. b8 cis8. e,16 | % bar 81
    d2.~  | % bar 82
    d8[ cis8] cis2 | % bar 83
    r4 r8 a'8 \appoggiatura{ a8 }  gis8. fis16 | % bar 84
    \appoggiatura{ cis'4 }  bis4. cis8 dis8. fis,16 | % bar 85
    e2.~  | % bar 86
    e8.[ dis16] dis2 | % bar 87
    r4 r8 e8 b'8. d,16 | % bar 88
    cis2. ~ | % bar 89
    cis8[ b8] b4 r4 | % bar 90
    r4 r8 cis'8 \appoggiatura{ cis8 }  b8. a16 | % bar 91
    \appoggiatura{ a4 }  gis4. a8 gis8. a16 | % bar 92
    \appoggiatura{ a4 }  b4. d,8 cis8. b'16 | % bar 93
    a8. gis16 \appoggiatura{ fis4 }  eis4. fis8 | % bar 94
    fis4 r4 fis4 | % bar 95
    g2.~  | % bar 96
    g4( fis8.) e16 d8. cis16 | % bar 97
    d8. fis16 \appoggiatura{ b4 }  ais4. b8 | % bar 98
    \appoggiatura{ d8 }  cis4 r4 r4 | % bar 99
    R2.*7 | % bar 100
    r4 r8 b8 \appoggiatura{ b8 }  ais8. b16 | % bar 107
    \appoggiatura{ a4 }  g4. fis8 g8. e16 | % bar 108
    ais8.[(  b32 cis32]) cis4 r8 fis,8 | % bar 109
    d'4 r8 b8 \appoggiatura{ b8 }  ais8. b16 | % bar 110
    e,8. cis'16 \appoggiatura{ b8 }  ais4 r4 | % bar 111
    R2.*4 | % bar 112
    r4 r8 d8 \appoggiatura{ d8 }  cis8. b16 | % bar 116
    \appoggiatura{ b4 }  ais4. b8 ais8. b16 | % bar 117
    \appoggiatura{ b8 }  cis4 e,8. g16 \appoggiatura{ g8 }  fis8. e16 | % bar 118
    \appoggiatura{ e8 }  d8. cis16 e8.[( d16]) cis8.[( d32 b32]) | % bar 119
    fis'4 r8 fis8 cis'4 | % bar 120
    r8 fis,8 d'8.[( cis16])  b8.[( a16]) | % bar 121
    \appoggiatura{ a8 }  gis8.[ fis16] gis8. e16 b'4 | % bar 122
    r8 e,8 cis'8.[( b16]) a8.[( g16]) | % bar 123
    fis8.[( g32 a32]) d,8. a'16 d4 | % bar 124
    r8 b8 e,8.[( fis32 g32]) fis8.[( e16]) | % bar 125
    d8. cis16 a'2~  | % bar 126
    a4 r8 d8 \appoggiatura{ d8 }  cis8. d16 | % bar 127
    a4. b8 c8. b16 | % bar 128
    \appoggiatura{ b8 }  c8.[( b16]) b4 r8 b8 | % bar 129
    \appoggiatura{ a4 }  g4. fis8 g8. fis16 | % bar 130
    g8.[( fis16]) \appoggiatura{ fis8 }  g4 r8 fis8 | % bar 131
    d'8. cis16 \appoggiatura{ b4 }  ais4. b8 | % bar 132
    << { \shiftOn b4 } \new Voice { \stemUp \tiny b16[( ais16 b8]) \normalsize } >> cis,8. d16 e8. g16 | % bar 133
    \appoggiatura{ g8 } fis8. e16 d8.[( cis16]) b'8.[( ais16]) | % bar 134
    \appoggiatura{ ais8 }  b4 r4 r4 | % bar 135
}
\addlyrics {
    Ich will auch mit ge -- broch' -- nen Au -- gen
    nach dir, mein treu -- er Hei -- land, sehn,
    ich will auch mit ge -- broch' -- nen Au -- gen
    nach dir, mein treu -- er Hei -- land, sehn,
    nach dir, mein treu -- er Hei -- land,
    nach dir, mein treu -- er Hei -- land,
    nach dir, mein treu -- er Hei -- land, sehn, __
    ich will auch mit ge -- broch' -- nen Au -- gen,
    auch mit ge -- broch' -- nen Au -- gen,
    nach dir, mein treu -- er Hei -- land,
    nach dir, mein treu -- er Hei -- land, sehn.

    Wenn -- gleich des Lei -- bes Bau zer -- bricht,
    doch fällt mein Herz und Hof -- fen nicht,
    wenn -- gleich des Lei -- bes Bau zer -- bricht,
    doch fällt mein Herz und Hof -- fen nicht,
    doch fällt mein Herz und Hof -- fen nicht,
    mein Herz und Hof -- fen nicht.

    Mein Je -- sus sieht auf mich im Ster -- ben,
    mein Je -- sus sieht auf mich im Ster -- ben,
    auf mich im Ster -- ben,
    und läs -- set mir kein Leid ge -- schehn,
    und läs -- set mir kein Leid ge -- schehn,
    kein Leid, __
    und läs -- set mir kein Leid ge -- schehn.

    Ich will auch mit ge -- broch' -- nen Au -- gen
    nach dir, mein treu -- er Hei -- land, sehn,
    ich will auch mit ge -- broch' -- nen Au -- gen
    nach dir, mein treu -- er Hei -- land, sehn,
    nach dir, mein treu -- er Hei -- land,
    nach dir, mein treu -- er Hei -- land,
    nach dir, mein treu -- er Hei -- land, sehn, __
    ich will auch mit ge -- broch' -- nen Au -- gen,
    auch mit ge -- broch' -- nen Au -- gen,
    nach dir, mein treu -- er Hei -- land
    nach dir, mein treu -- er Hei -- land, sehn.
}
\mvtIItimeLine
>>

    
mvtIIbasso = \relative c <<
{
    \clef F
    b8(^\markup{ tutto ligato } b8) b'8( b8) b8( b8) | % bar 1
    b8( b8) b8( b8) b8( b8) | % bar 2
    b8( b8) ais( ais8) fis( fis8) | % bar 3
    b8 b8 a8 a8 g8 g8 | % bar 4
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 5
    a8 a8 a8 a8 a8 a8 | % bar 6
    dis,8 dis8 dis8 dis8 b8 b8 | % bar 7
    e8 e8 e8 e8 e8 e8 | % bar 8
    e8 e8 ais,8 g'8 fis8 e8 | % bar 9
    d8 e8 fis8 fis8 fis,8 fis8 | % bar 10
    g8 g8 gis8 gis8 ais8 ais8 | % bar 11
    b8 e8 fis8 fis8 fis,8 fis8 | % bar 12
    b8-\fermata b8 b'8 b8 b8 b8 | % bar 13
    b8 b8 b8 b8 b8 b8 | % bar 14
    b8 b8 ais8 ais8 fis8 fis8 | % bar 15
    b8 b8 a8 a8 g8 g8 | % bar 16
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 17
    a8 a8 a8 a8 a8 a8 | % bar 18
    dis,8 dis8 dis8 dis8 b8 b8 | % bar 19
    e8 e8 e8 e8 e8 e8 | % bar 20
    e8 e8 ais,8 g'8 fis8 e8 | % bar 21
    d8 e8 fis8 fis8 fis,8 fis8 | % bar 22
    g8 g8 gis8 gis8 ais8 ais8 | % bar 23
    b8 e8 fis8 fis8 fis,8 fis8 | % bar 24
    b8 b8 b'8 b8 b8 b8 | % bar 25
    b8 b8 b8 b8 b8 b8 | % bar 26
    b8 b8 ais8 ais8 fis8 fis8 | % bar 27
    b8 b8 a8 a8 g8 g8 | % bar 28
    fis8 fis8 fis8 fis8 ais8 ais8 | % bar 29
    b8 b8 b8 b8 b8 b8 | % bar 30
    e,8 e8 e8 e8 gis8 gis8 | % bar 31
    a8 a8 a8 a8 a8 a8 | % bar 32
    d,8 d8 d8 d8 fis8 fis8 | % bar 33
    g8 g8 g8 g8 g8 g8 | % bar 34
    g8 g8 g8 g8 g8 g8 | % bar 35
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 36
    e8 e8 e8 e8 e8 e8 | % bar 37
    dis8 dis8 dis8 dis8 dis8 dis8 | % bar 38
    e8 e8 e8 e8 e8 e8 | % bar 39
    ais,8 ais8 ais8 ais8 fis8 fis8 | % bar 40
    b8 b8 b8 b8 b8 b8 | % bar 41
    cis8 cis8 cis8 cis8 e,8 e8 | % bar 42
    fis8 g8 a8 a8 a8 a8 | % bar 43
    d,8 d8 d'8 d8 d8 d8 | % bar 44
    d8 d8 d8 d8 d8 d8 | % bar 45
    d8 d8 cis8 cis8 a8 a8 | % bar 46
    b8 b8 b8 b8 b8 b8 | % bar 47
    a8 a8 fis'8 fis8 cis8 cis8 | % bar 48
    d8 d8 c8 c8 b8 b8 | % bar 49
    fis8 fis8 fis'8 fis8 d8 d8 | % bar 50
    g8 g8 e8 e8 g8 g8 | % bar 51
    g,8 g8 a8 g'8 fis8 e8 | % bar 52
    d8 g8 a8 a8 a,8 a8 | % bar 53
    b8 b8 b8 b8 cis8 cis8 | % bar 54
    d8 g8 a8 a8 a,8 a8 | % bar 55
    d8 d8 d8 d8 d8 d8 | % bar 56
    d8 d8 cis8 cis8 cis8 cis8 | % bar 57
    b8 b8 b'8 b8 g8 g8 | % bar 58
    a8 a8 fis8 fis8 d8 d8 | % bar 59
    g8 g8 e8 e8 cis8 cis8 | % bar 60
    fis8 fis8 dis8 dis8 b8 b8 | % bar 61
    e8 e8 e8 e8 e8 e8 | % bar 62
    a,8 a8 b8 b8 a8 a8 | % bar 63
    gis8 gis8 gis8 gis8 e8 e8 | % bar 64
    a8 a8 a8 a8 a8 a8 | % bar 65
    a8 a8 dis,8 dis8 dis8 dis8 | % bar 66
    e8 e8 e'8 e8 g8 g8 | % bar 67
    a8 a8 dis,8 dis8 b8 b8 | % bar 68
    e8 e8 e,8 e8 e'8 e8 | % bar 69
    fis8 fis8 fis,8 fis8 a8 a8 | % bar 70
    g8 a8 b8 b8 b8 b8 | % bar 71
    e,8 e8 e'8 e8 e8 e8 | % bar 72
    e8 e8 e8 e8 e8 e8 | % bar 73
    e8 e8 dis8 dis8 b8 b8 | % bar 74
    d8 d8 d8 d8 d8 d8 | % bar 75
    d8 d8 gis,8 gis8 e8 e8 | % bar 76
    a8 a8 a'8 a8 fis8 fis8 | % bar 77
    b8 b8 c8 c8 dis,8 dis8 | % bar 78
    e8 a8 b8 b8 b,8 b8 | % bar 79
    e,8 e8 e'8 e8 e8 e8 | % bar 80
    e8 e8 cis8 cis8 ais8 ais8 | % bar 81
    b8 b8 b8 b8 b8 b8 | % bar 82
    b8 b8 b8 b8 eis,8 eis8 | % bar 83
    fis8 fis8 fis'8 fis8 fis8 fis8 | % bar 84
    dis8 dis8 bis8 bis8 gis8 gis8 | % bar 85
    cis8 cis8 cis8 cis8 cis8 cis8 | % bar 86
    fis,8 fis8 fis8 fis8 fis8 fis8 | % bar 87
    g8 g8 g8 g8 fis8 fis8 | % bar 88
    eis8 eis8 eis8 eis8 eis8 eis8 | % bar 89
    eis4 r4 r4 | % bar 90
    fis8 fis8 fis'8 fis8 fis8 fis8 | % bar 91
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 92
    fis8 fis8 eis8 eis8 eis8 eis8 | % bar 93
    fis8 b,8 cis8 cis8 cis8 cis8 | % bar 94
    fis,8 fis8 fis8 fis8 fis8 fis8 | % bar 95
    e8 e8 e'8 e8 cis8 cis8 | % bar 96
    ais8 ais8 ais'8 ais8 fis8 fis8 | % bar 97
    b8 b8 a8 a8 g8 g8 | % bar 98
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 99
    a8 a8 a8 a8 a8 a8 | % bar 100
    dis,8 dis8 dis8 dis8 b8 b8 | % bar 101
    e8 e8 e8 e8 e8 e8 | % bar 102
    e8 e8 ais,8 g'8 fis8 e8 | % bar 103
    d8 e8 fis8 fis8 fis,8 fis8 | % bar 104
    g8 g8 gis8 gis8 ais8 ais8 | % bar 105
    b8 e8 fis8 fis8 fis,8 fis8 | % bar 106
    b8 b8 b'8 b8 b8 b8 | % bar 107
    b8 b8 b8 b8 b8 b8 | % bar 108
    b8 b8 ais8 ais8 fis8 fis8 | % bar 109
    b8 b8 a8 a8 g8 g8 | % bar 110
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 111
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 112
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 113
    g8 g8 ais,8 ais8 fis8 fis8 | % bar 114
    b8 e8 fis8 fis8 fis,8 fis8 | % bar 115
    b8 b8 b'8 b8 b8 b8 | % bar 116
    b8 b8 b8 b8 b8 b8 | % bar 117
    b8 b8 ais8 ais8 fis8 fis8 | % bar 118
    b8 b8 a8 a8 g8 g8 | % bar 119
    fis8 fis8 fis8 fis8 ais8 ais8 | % bar 120
    b8 b8 b8 b8 b8 b8 | % bar 121
    e,8 e8 e8 e8 gis8 gis8 | % bar 122
    a8 a8 a8 a8 a8 a8 | % bar 123
    d,8 d8 d8 d8 fis8 fis8 | % bar 124
    g8 g8 g8 g8 g8 g8 | % bar 125
    g8 g8 g8 g8 g8 g8 | % bar 126
    fis8 fis8 fis8 fis8 fis8 fis8 | % bar 127
    e8 e8 e8 e8 e8 e8 | % bar 128
    dis8 dis8 dis8 dis8 dis8 dis8 | % bar 129
    e8 e8 e8 e8 e8 e8 | % bar 130
    ais,8 ais8 ais8 ais8 ais8 ais8 | % bar 131
    b8 e8 fis8 fis8 fis,8 fis8 | % bar 132
    g8 g8 g'8 g8 cis,8 cis8 | % bar 133
    d8 e8 fis8 fis8 fis,8 fis8 | % bar 134
    b8 b8 b'8 b8 b8 b8 | % bar 135
}
\mvtIItimeLine
>>

