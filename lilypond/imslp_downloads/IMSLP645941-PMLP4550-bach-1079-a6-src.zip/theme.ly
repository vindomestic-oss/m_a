\version "2.21.0"
% s\breve^"Clar" | % bar 1
% s\breve*3 | % bar 4
% s\breve^"Ob" | % bar 5
% s\breve*3 | % bar 8
% s\breve^"ClB" | % bar 9
% s\breve*3 | % bar 12
% s\breve^"Cor" | % bar 13
% s\breve*5 | % bar 18
% s\breve^"Fl" | % bar 19
% s\breve*5 | % bar 24
% s\breve^"Fag" | % bar 25
% s\breve*22 | % bar 47
% s\breve^"ClB" | % bar 48
% s\breve*9 | % bar 57
% s\breve^"Cl" | % bar 58
% s\breve*7 | % bar 65
% s\breve^"Fl" | % bar 66
% s\breve*6 | % bar 72
% s\breve^"Cor" | % bar 73
% s\breve*12 | % bar 85
% s\breve^"Ob" | % bar 86
% s\breve*12 | % bar 98
% s\breve^"Fag" | % bar 99
% s\breve*4 | % bar 103

s\breve*4^"Clar" | % bar 1
s\breve*4^"Ob" | % bar 5
s\breve*4^"ClB" | % bar 9
s\breve*6^"Cor" | % bar 13
s\breve*6^"Fl" | % bar 19
s\breve*23^"Fag" | % bar 25
s\breve*10^"ClB" | % bar 48
s\breve*8^"Cl" | % bar 58
s\breve*7^"Fl" | % bar 66
s\breve*13^"Cor" | % bar 73
s\breve*13^"Ob" | % bar 86
s\breve*5^"Fag" | % bar 99

