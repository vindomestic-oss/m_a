\version "2.21.0"

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Functions, macros
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% muta = -\markup\rounded-box\italic\line \etc
muta = #(define-event-function (m) (markup?)
    #{
        -\markup\upright\rounded-box #m
    #}
)

% bow = -\markup\upright\center-align \etc
bow = #(define-event-function (m) (markup?)
    #{
        -\markup\upright\center-align #m
    #}
)

#(define CH (if (defined? 'CH) CH #{ \clef treble  #}))
#(define CL (if (defined? 'CL) CL #{ \clef bass  #}))

#(define RH (if (defined? 'RH) RH #{ \change Staff = "up" #}))
#(define LH (if (defined? 'LH) LH #{ \change Staff = "down" #}))

#(define BarNumberSize (if (defined? 'BarNumberSize) BarNumberSize -0.5))

% This is a sensible value for part files.
% For full scores, better to override to #0.8.
#(define HairpinOffset (if (defined? 'HairpinOffset) HairpinOffset 0.33))


LXS = #(define-music-function (staff rh lh) (markup? ly:music? ly:music?)
"Make cross-staff connection to LH. lh is in absolute mode!"
#{
    <<
        { \override Stem.direction = #UP $rh \revert Stem.direction }
        \new Voice { \autoBeamOff \change Staff = $staff \stemUp \crossStaff { $lh } }
    >>
#})


RXS = #(define-music-function (staff lh rh) (markup? ly:music? ly:music?)
"Make cross-staff connection to RH. rh is in absolute mode!"
#{
    <<
        { \override Stem.direction = #DOWN $lh \revert Stem.direction }
        \new Voice { \autoBeamOff \change Staff = $staff \stemDown \crossStaff { $rh } }
    >>
#})


LX = #(define-music-function (rh lh) (ly:music? ly:music?)
"Make cross-staff connection to staff 'down'. lh is in absolute mode!"
#{
    \LXS "down" $rh $lh
#})


RX = #(define-music-function (lh rh) (ly:music? ly:music?)
"Make cross-staff connection to staff 'up'. rh is in absolute mode!"
#{
    \RXS "up" $lh $rh
#})


LXBS = #(define-music-function (staff rh lh) (markup? ly:music? ly:music?)
"Make cross-staff cross-beam connection to LH. lh is in absolute mode!"
#{
    <<
        { \override Stem.direction = #DOWN $rh \revert Stem.direction }
        \new Voice { \change Staff = $staff \stemUp \crossStaff { \override NoteColumn.X-offset = #-1.15 $lh } }
    >>
#})


RXBS = #(define-music-function (staff lh rh) (markup? ly:music? ly:music?)
"Make cross-staff cross-beam connection to RH. rh is in absolute mode!"
#{
    <<
        { \override Stem.direction = #UP $rh \revert Stem.direction }
        \new Voice { \change Staff = $staff \stemDown \crossStaff { \override NoteColumn.X-offset = #1.15 $lh } }
    >>
#})


LXB = #(define-music-function (rh lh) (ly:music? ly:music?)
"Make cross-staff cross-beam connection to staff 'down'. lh is in absolute mode!"
#{
    \LXBS "down" $rh $lh
#})


RXB = #(define-music-function (lh rh) (ly:music? ly:music?)
"Make cross-staff cross-beam connection to staff 'up'. rh is in absolute mode!"
#{
    \RXBS "up" $lh $rh
#})


daCapo = {
    \once \override Score.RehearsalMark.break-visibility = #end-of-line-visible
    \once \override Score.RehearsalMark.self-alignment-X = #RIGHT
    \once \override Score.RehearsalMark.direction = #DOWN
    \mark \markup\bold{"Da Capo"}
}

dalSegno = {
    \once \override Score.RehearsalMark.break-visibility = #end-of-line-visible
    \once \override Score.RehearsalMark.self-alignment-X = #RIGHT
    \once \override Score.RehearsalMark.direction = #DOWN
    \mark \markup\bold{Dal Segno \raise #1.0 \tiny{\musicglyph "scripts.segno"}}
}

segno = \mark \markup{\musicglyph "scripts.segno"}

VS = {
    \once \override Score.RehearsalMark.break-visibility = #end-of-line-visible
    \once \override Score.RehearsalMark.self-alignment-X = #RIGHT
    \once \override Score.RehearsalMark #'direction = #DOWN
    \mark \markup\bold{V.S.}
}

TacetAlFine = <>^\markup\bold\italic{Tacet al Fine}

barFermata = {
    \once \override Score.RehearsalMark.break-visibility = #begin-of-line-invisible
    \mark \markup { \musicglyph "scripts.ufermata" }
}

videSeparator = \markup {
    \center-align
    \vcenter \combine
    \beam #2.0 #0.5 #0.48
    \raise #0.7 \beam #2.0 #0.5 #0.48
}

videStart = {
    \once \override Score.RehearsalMark.self-alignment-X = #LEFT
    \mark \markup\bold\large{\concat{"Vi- " \raise #0.9 \videSeparator}}
}

videEnd = {
    \once \override Score.RehearsalMark.self-alignment-X = #-0.5
    \mark \markup\bold\large{\concat{\raise #0.9 \videSeparator " -de"}}
}

attacca = {
    \once \override Score.RehearsalMark.break-visibility = #end-of-line-visible
    \once \override Score.RehearsalMark.self-alignment-X = #RIGHT
    \once \override Score.RehearsalMark.direction = #DOWN
    \mark \markup\bold\italic{attacca}
}

railroad = {
    \once \override BreathingSign.text = \markup {
        \musicglyph "scripts.caesura.straight"
    }
    \breathe
}

Breathe = \markup\line{\null \raise #1.3 \huge\bold{\musicglyph "scripts.rcomma"}}

emdash = \markup{—}
endash = \markup{–}

PedalStart = \markup\concat{\musicglyph "pedal.Ped" .}
PedalEnd   = \markup{\musicglyph "pedal.*"}
Pfermata = \markup\concat{( \musicglyph "scripts.ufermata" )}

% Pedal symbols start/end in a spanner: at the same distance to the staff
PedOn = -\tweak direction #DOWN -\tweak bound-details.left.text \PedalStart -\tweak bound-details.right.text \markup\halign #-3.0 \PedalEnd -\tweak style #'none \=Pedal\startTextSpan
PedOff = \=Pedal\stopTextSpan

Toff = { \once \override TupletBracket.bracket-visibility = ##f \once \override TupletNumber.text = \markup\null }

tsharp = \markup{\raise #1.0 \smaller\smaller \sharp}
tnat = \markup{\raise #1.0 \smaller\smaller \natural}
tflat = \markup{\raise #1.0 \smaller\smaller \flat}

Premier = \markup\concat{1 \raise #0.8 \smaller\smaller er}
Premiere = \markup\concat{1 \raise #0.8 \smaller\smaller ère}
Premiers = \markup\concat{1 \raise #0.8 \smaller\smaller ers}
Second = \markup\concat{2 \raise #0.8 \smaller\smaller nd}
Seconde = \markup\concat{2 \raise #0.8 \smaller\smaller e}
Seconds = \markup\concat{2 \raise #0.8 \smaller\smaller nds}
Primo = \markup\concat{1 \raise #0.8 \smaller\smaller o}
Secondo = \markup\concat{2 \raise #0.8 \smaller\smaller o}
Terzo = \markup\concat{3 \raise #0.8 \smaller\smaller o}
Quarto = \markup\concat{4 \raise #0.8 \smaller\smaller o}

% By Harm (Thomas Morley)
% http://lists.gnu.org/archive/html/lilypond-user/2014-03/msg00817.html
#(define-markup-command (vstrut layout props)
  ()
    #:category other
      "
      @cindex creating vertical space in text

      Create a box of the same height as the current font numerals."
        (let ((ref-mrkp (interpret-markup layout props "0")))
            (ly:make-stencil (ly:stencil-expr empty-stencil)
                             empty-interval
                             (ly:stencil-extent ref-mrkp Y))))

% Figured Bass extender line that is just part of the figure column
FBx = \markup{\vstrut\raise #0.2 \endash}
FBxx = \markup{\vstrut\raise #0.2 \emdash}
FBnull = \markup{\vstrut\raise #-1.0 \null}

% Baroque-ish stuff
%
% Override *before* including this file to choose something else than the
% modern default

#(define clefSoprano  (if (defined? 'clefSoprano)  clefSoprano  #{ \clef treble #}))
#(define clefMezzo    (if (defined? 'clefMezzo)    clefMezzo  #{ \clef treble #}))
#(define clefAlto     (if (defined? 'clefAlto)     clefAlto  #{ \clef treble #}))
#(define clefTenor    (if (defined? 'clefTenor)    clefTenor #{ \clef "treble_8" #}))
#(define clefBaritone (if (defined? 'clefBaritone) clefBaritone #{ \clef bass #}))

#(define clefFrench   (if (defined? 'clefFrench)   clefFrench  #{ \clef treble #}))
#(define clefObDAm    (if (defined? 'clefObDAm)    clefObDAm  #{ \clef treble #}))
#(define transpObDAm  (if (defined? 'transpObDAm)  transpObDAm  #{ a, #}))
#(define clefObDaC    (if (defined? 'clefObDaC)    clefObDaC  #{ \clef treble #}))
#(define transpObDaC  (if (defined? 'transpObDaC)  transpObDaC  #{ f, #}))
#(define clefTaille   (if (defined? 'clefTaille)   clefTaille  #{ \clef treble #}))
#(define transpTaille (if (defined? 'transpTaille) transpTaille  #{ f, #}))

#(define transpChorton (if (defined? 'transpChorton) transpChorton #{ c #}))

#(define clefG     (if (defined? 'clefG) clefG #{ #}))
#(define clefF     (if (defined? 'clefF) clefF #{ #}))
#(define clefOldHornF (if (defined? 'clefOldHornF) clefOldHornF #{ #}))
#(define clefBclrBass (if (defined? 'clefBclrBass) clefBclrBass #{ \clef "treble_8" #}))

PZ = \markup\upright\bold\halign #-0.2 {pizz.}
AC = \markup\upright\bold\halign #-0.2 {arco}
PPZ = \markup\upright\bold\halign #-0.2 {(pizz.)}
PAC = \markup\upright\bold\halign #-0.2 {(arco)}

% Definitions for international scores
PmD  = \markup\italic\halign #0.5 \line{(con sord.)}
PoD  = \markup\italic\halign #0.7 \line{(senza sord.)}
Dauf = \markup\rounded-box\italic\halign #-0.5 \line{con sord.}
Dsauf = \Dauf
Dab  = \markup\italic\halign #-0.7 \line{senza sord.}
% Dauf = \markup\italic\center-align\rounded-box\line{con sord.}
% Dab  = \markup\italic\center-align\rounded-box\line{senza sord.}
Daufc = \markup\rounded-box\italic\halign #-0.5 \override #'(baseline-skip . 2) \left-column{con sord.}
Dabc  = \markup\italic \override #'(baseline-skip . 2) \left-column{senza sord.}
Dmit = \markup\rounded-box\italic\halign #0.5 \line{con sord.}
Dohne = \markup\rounded-box\italic\halign #0.7 \line{senza sord.}
        
Get = \markup\upright\halign #1.5 {div.}
GetaII = \markup\upright\halign #1.5 \line{div.a 2}
GetaIII = \markup\upright\halign #1.5 \line{div.a 3}
GetaIV = \markup\upright\halign #1.5 \line{div.a 4}
GetaIIc = \markup\upright\halign #1.5 \column{"div." "a 2"}
GetaIIIc = \markup\upright\halign #1.5 \column{"div." "a 3"}
GetaIVc = \markup\upright\halign #1.5 \column{"div." "a 4"}
Zus = \markup\upright\halign #1.5 {unis.}
Getc = \markup\upright\halign #0 {div.}
Zusc = \markup\upright\halign #0 {unis.}
Alle = \markup\upright\halign #1.5 {tutti}
AlleW = \markup\upright\halign #1.5 {tutte}
PGet = \markup\upright\halign #1.5 {(div.)}
PZus = \markup\upright\halign #1.5 {(unis.)}
PAlle = \markup\upright\halign #1.5 {(tutti)}
PAlleW = \markup\upright\halign #1.5 {(tutte)}

Gest = \markup\upright\halign #0.5 {\italic chiuso}
PGest = \markup\upright\right-align{\italic{(chiuso)}}
Offen = \markup\upright\right-align{\italic aperto}
POffen = \markup\upright\right-align{\italic{(aperto)}}

Flatt = \markup\upright\halign #1.3 {frull.}
Gew = \markup\upright\halign #0.7 {ord.}
Gewc = \Gew
PGew = \markup\upright\halign #0.7 {(ord.)}
BGew = \markup\upright\halign #0.7 {[ord.]}

MPicc = \markup\rounded-box\italic\line{muta Picc.}
MFl = \markup\rounded-box\italic\line{muta Fl.Gr.}
MObII = \markup\rounded-box\italic\line{muta 2.Ob.}
MEh = \markup\rounded-box\italic\line{muta C.I.}

% Italian, French
Sib = \markup\concat{Si \raise #0.8 \smaller\smaller \flat}
Mib = \markup\concat{Mi \raise #0.8 \smaller\smaller \flat}
PSib = \markup\concat{( Si \raise #0.8 \smaller\smaller \flat )}
PMib = \markup\concat{( Mi \raise #0.8 \smaller\smaller \flat )}

Trill = ^\markup\halign #-0.5 \upright\bold\larger{tr}


% More dynamics

FMarkup = \markup{\normal-text\bold{f}}
F = #(make-dynamic-script FMarkup)
FFMarkup = \markup{\normal-text\bold{ff}}
FF = #(make-dynamic-script FFMarkup)
PMarkup = \markup{\normal-text\bold{p}}
P = #(make-dynamic-script PMarkup)
PPMarkup = \markup{\normal-text\bold{pp}}
PP = #(make-dynamic-script PPMarkup)
FPMarkup = \markup{\normal-text\bold{fp}}
FP = #(make-dynamic-script FPMarkup)

% More for the Urtext stuff

ForMarkup = \markup{\normal-text\italic{forte}}
For = \tweak DynamicText.self-alignment-X #LEFT
      \tweak DynamicText.X-offset -0.5
            #(make-dynamic-script ForMarkup)
PiaMarkup = \markup{\normal-text\italic{piano}}
Pia = \tweak DynamicText.self-alignment-X #LEFT
      \tweak DynamicText.X-offset -0.5
            #(make-dynamic-script PiaMarkup)
FForMarkup = \markup{\normal-text\italic{fortiss:}}
FFor = \tweak DynamicText.self-alignment-X #LEFT
      \tweak DynamicText.X-offset -0.5
            #(make-dynamic-script FForMarkup)
PPiaMarkup = \markup{\normal-text\italic{pianissimo}}
PPia = \tweak DynamicText.self-alignment-X #LEFT
       \tweak DynamicText.X-offset -0.5
            #(make-dynamic-script PPiaMarkup)

fpp = #(make-dynamic-script "fpp")
ffpp = #(make-dynamic-script "ffpp")
ffp = #(make-dynamic-script "ffp")
fpp = #(make-dynamic-script "fpp")
mfp = #(make-dynamic-script "mfp")
mfpp = #(make-dynamic-script "mfpp")

rf = #(make-dynamic-script "rf")
sfff = #(make-dynamic-script "sfff")
sfzp = #(make-dynamic-script "sfzp")
sffz = #(make-dynamic-script "sffz")
sfffz = #(make-dynamic-script "sfffz")
sffp = #(make-dynamic-script "sffp")
sfpp = #(make-dynamic-script "sfpp")

% molto
moltoMarkup = \markup{\normal-text\italic molto}
molto = -\tweak self-alignment-X #-0.5 #(make-dynamic-script moltoMarkup)
moltopMarkup = \markup{\normal-text\italic molto \magnify #1.0 \dynamic p}
moltop = -\tweak self-alignment-X #-0.5 #(make-dynamic-script moltopMarkup)
moltofMarkup = \markup{\normal-text\italic molto \magnify #1.0 \dynamic f}
moltof = -\tweak self-alignment-X #-0.5 #(make-dynamic-script moltofMarkup)

% meno
menoffMarkup = \markup{\normal-text\italic meno \magnify #1.0 ff}
menoff = -\tweak self-alignment-X #-0.5 #(make-dynamic-script menoffMarkup)
menofMarkup = \markup{\normal-text\italic meno \magnify #1.0 \dynamic f}
menof = -\tweak self-alignment-X #-0.5 #(make-dynamic-script menofMarkup)
menopMarkup = \markup{\normal-text\italic meno \magnify #1.0 \dynamic p}
menop = -\tweak self-alignment-X #-0.5 #(make-dynamic-script menopMarkup)


% sempre
sempreffMarkup = \markup{\normal-text\italic sempre \magnify #1.0 \dynamic ff}
sempreff = -\tweak self-alignment-X #-0.5 #(make-dynamic-script sempreffMarkup)
semprefMarkup = \markup{\normal-text\italic sempre \magnify #1.0 \dynamic f}
sempref = -\tweak self-alignment-X #-0.5 #(make-dynamic-script semprefMarkup)
semprepMarkup = \markup{\normal-text\italic sempre \magnify #1.0 \dynamic p}
semprep = -\tweak self-alignment-X #-0.5 #(make-dynamic-script semprepMarkup)
sempreppMarkup = \markup{\normal-text\italic sempre \magnify #1.0 \dynamic pp}
semprepp = -\tweak self-alignment-X #-0.5 #(make-dynamic-script sempreppMarkup)
semprepppMarkup = \markup{\normal-text\italic sempre \magnify #1.0 \dynamic ppp}
sempreppp = -\tweak self-alignment-X #-0.5 #(make-dynamic-script semprepppMarkup)
semprepppCMarkup = \markup\override #'(baseline-skip . 1.8) \center-column{\normal-text\italic sempre \magnify #1.0 \dynamic ppp}
semprepppC = -\tweak self-alignment-X #0.0 #(make-dynamic-script semprepppCMarkup)

ppsempreMarkup = \markup{\dynamic pp \normal-text\italic\magnify #1.0 sempre}
ppsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppsempreMarkup)
pppsempreMarkup = \markup{\dynamic ppp \normal-text\italic\magnify #1.0 sempre}
pppsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pppsempreMarkup)
ppPsempreMarkup = \markup{pp \normal-text\magnify #1.0 {(sempre)}}
ppPsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppPsempreMarkup)
ppsempreMarkup = \markup{\dynamic pp \normal-text\italic\magnify #1.0 sempre}
ppsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppsempreMarkup)
psempreMarkup = \markup{\dynamic p \normal-text\italic\magnify #1.0 sempre}
psempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script psempreMarkup)
mpsempreMarkup = \markup{\dynamic mp \normal-text\italic\magnify #1.0 sempre}
mpsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mpsempreMarkup)
mfsempreMarkup = \markup{\dynamic mf \normal-text\italic\magnify #1.0 sempre}
mfsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfsempreMarkup)
fsempreMarkup = \markup{\dynamic f \normal-text\italic\magnify #1.0 sempre}
fsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fsempreMarkup)
ffsempreMarkup = \markup{\dynamic ff \normal-text\italic\magnify #1.0 sempre}
ffsempre = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ffsempreMarkup)

sempremoltofMarkup = \markup{\normal-text\italic {sempre molto} \magnify #1.0 \dynamic f}
sempremoltof = -\tweak self-alignment-X #-0.5 #(make-dynamic-script sempremoltofMarkup)

ppppossibMarkup = \markup{\dynamic ppp \normal-text\italic\magnify #1.0 possibile}
ppppossib = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppppossibMarkup)

% subito
subitoppMarkup = \markup{\normal-text\italic subito \magnify #1.0 \dynamic pp}
subitopp = -\tweak self-alignment-X #-0.5 #(make-dynamic-script subitoppMarkup)
subitopMarkup = \markup{\normal-text\italic subito \magnify #1.0 \dynamic p}
subitop = -\tweak self-alignment-X #-0.5 #(make-dynamic-script subitopMarkup)
psubitoMarkup = \markup{p \normal-text\italic\magnify #1.0 subito}
psubito = -\tweak self-alignment-X #-0.5 #(make-dynamic-script psubitoMarkup)
subitofMarkup = \markup{\normal-text\italic subito \magnify #1.0 \dynamic f}
subitof = -\tweak self-alignment-X #-0.5 #(make-dynamic-script subitofMarkup)
subitoffMarkup = \markup{\normal-text\italic subito \magnify #1.0 \dynamic ff}
subitoff = -\tweak self-alignment-X #-0.5 #(make-dynamic-script subitoffMarkup)
subitomoltofMarkup = \markup{\normal-text\italic {subito molto} \magnify #1.0 \dynamic f}
subitomoltof = -\tweak self-alignment-X #-0.5 #(make-dynamic-script subitomoltofMarkup)

% piu
piuMarkup = \markup{\normal-text\italic\magnify #1.0 più}
piu = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piuMarkup)
piufMarkup = \markup{\normal-text\italic più \magnify #1.0 \dynamic f}
piuf = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piufMarkup)

piuppMarkup = \markup{\normal-text\italic più \magnify #1.0 \dynamic pp}
piupp = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piuppMarkup)
piupMarkup = \markup{\normal-text\italic più \magnify #1.0 \dynamic p}
piup = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piupMarkup)
piufMarkup = \markup{\normal-text\italic più \magnify #1.0 \dynamic f}
piuf = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piufMarkup)
piuffMarkup = \markup{\normal-text\italic più \magnify #1.0 \dynamic ff}
piuff = -\tweak self-alignment-X #-0.5 #(make-dynamic-script piuffMarkup)

% quasi
quasifMarkup = \markup{\normal-text\italic quasi \magnify #1.0 \dynamic f}
quasif = -\tweak self-alignment-X #-0.5 #(make-dynamic-script quasifMarkup)

% espr
esprMarkup = \markup{\normal-text\italic\magnify #1.0 espr.}
espr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script esprMarkup)
ffesprMarkup = \markup{\dynamic ff \normal-text\italic\magnify #1.0 espr.}
ffespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ffesprMarkup)
fesprMarkup = \markup{\dynamic f \normal-text\italic\magnify #1.0 espr.}
fespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fesprMarkup)
mfesprMarkup = \markup{\dynamic mf \normal-text\italic\magnify #1.0 espr.}
mfespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfesprMarkup)
mpesprMarkup = \markup{\dynamic mp \normal-text\italic\magnify #1.0 espr.}
mpespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mpesprMarkup)
pesprMarkup = \markup{\dynamic p \normal-text\italic\magnify #1.0 espr.}
pespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pesprMarkup)
ppesprMarkup = \markup{\dynamic pp \normal-text\italic\magnify #1.0 espr.}
ppespr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppesprMarkup)

% cantabile
mfcantabileMarkup = \markup{mf \normal-text\italic\magnify #1.0 cantabile}
mfcantabile = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfcantabileMarkup)
fcantabileMarkup = \markup{f, \normal-text\italic\magnify #1.0 cantabile}
fcantabile = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fcantabileMarkup)

% appassionato
ffappassionatoMarkup = \markup{ff \normal-text\italic\magnify #1.0 appassionato}
ffappassionato = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ffappassionatoMarkup)

% molto tranquillo
pmoltotranquilloMarkup = \markup{\dynamic p \normal-text\italic\tiny {molto tranquillo}}
pmoltotranquillo = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pmoltotranquilloMarkup)
pmoltotranquilloMarkup = \markup{\dynamic p \normal-text\italic\tiny {molto tranquillo}}
pmoltotranquillo = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pmoltotranquilloMarkup)

% furioso
fffuriosoHereMarkup = \markup{\halign #6.0 ff \normal-text\italic\magnify #1.0 furioso}
fffuriosoHere = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fffuriosoHereMarkup)
fffuriosoMarkup = \markup{\hspace #6.0 ff \normal-text\italic\magnify #1.0 furioso}
fffurioso = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fffuriosoMarkup)

% poco
pocoMarkup = \markup{\normal-text\italic\magnify #1.0 poco}
poco = -\tweak self-alignment-X #-0.0 #(make-dynamic-script pocoMarkup)
PpocoMarkup = \markup\normal-text\italic\line{ \hspace #-0.5 \magnify #1.0 {(poco)} \hspace #-0.5 }
Ppoco = -\tweak self-alignment-X #-0.0 #(make-dynamic-script PpocoMarkup)
npocoMarkup = \markup\normal-text\italic\line{ \hspace #-1.0 \magnify #1.0 {poco} \hspace #-1.0 }
npoco = -\tweak self-alignment-X #-0.0 #(make-dynamic-script npocoMarkup)

pocofMarkup = \markup{\normal-text\italic poco \magnify #1.0 \dynamic f}
pocof = -\tweak self-alignment-X #0.4 #(make-dynamic-script pocofMarkup)
pocopMarkup = \markup{\normal-text\italic poco \magnify #1.0 \dynamic p}
pocop = -\tweak self-alignment-X #0.4 #(make-dynamic-script pocopMarkup)
PpocofMarkup = \markup\normal-text\italic\line{ ( poco \concat{ \magnify #1.0 \dynamic f )}}
Ppocof = -\tweak self-alignment-X #0.4 #(make-dynamic-script PpocofMarkup)
pocosfMarkup = \markup{\normal-text\italic poco \magnify #1.0 \dynamic sf}
pocosf = -\tweak self-alignment-X #0.4 #(make-dynamic-script pocosfMarkup)
pocosfzMarkup = \markup{\normal-text\italic poco \magnify #1.0 \dynamic sfz}
pocosfz = -\tweak self-alignment-X #0.4 #(make-dynamic-script pocosfzMarkup)
pocosfzpMarkup = \markup{\normal-text\italic poco \dynamic sfz \magnify #1.0 \dynamic p}
pocosfzp = -\tweak self-alignment-X #0.4 #(make-dynamic-script pocosfzpMarkup)
sfpocoMarkup = \markup{sf \normal-text\italic poco}
sfpoco = -\tweak self-alignment-X #-0.2 #(make-dynamic-script sfpocoMarkup)

% dolce
dolcepMarkup = \markup{\normal-text\italic dolce p}
dolcep = -\tweak self-alignment-X #-0.2 #(make-dynamic-script dolcepMarkup)
ffdolceMarkup = \markup{ff \normal-text\italic dolce}
ffdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ffdolceMarkup)
fdolceMarkup = \markup{f \normal-text\italic dolce}
fdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fdolceMarkup)
sfdolceMarkup = \markup{sf \normal-text\italic dolce}
sfdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script sfdolceMarkup)
mfdolceMarkup = \markup{mf \normal-text\italic dolce}
mfdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfdolceMarkup)
mpdolceMarkup = \markup{mp \normal-text\italic dolce}
mpdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mpdolceMarkup)
pdolceMarkup = \markup{p \normal-text\italic dolce}
pdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pdolceMarkup)
ppdolceMarkup = \markup{pp \normal-text\italic dolce}
ppdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppdolceMarkup)
pppdolceMarkup = \markup{ppp \normal-text\italic dolce}
pppdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pppdolceMarkup)
pPdolceMarkup = \markup{p \normal-text\italic\magnify #1.0 (dolce)}
pPdolce = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pPdolceMarkup)

% dolciss.
ffdolcisMarkup = \markup{ff \normal-text\italic dolciss.}
ffdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ffdolcisMarkup)
fdolcisMarkup = \markup{f \normal-text\italic dolciss.}
fdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fdolcisMarkup)
mfdolcisMarkup = \markup{mf \normal-text\italic dolciss.}
mfdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfdolcisMarkup)
mpdolcisMarkup = \markup{mp \normal-text\italic dolciss.}
mpdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mpdolcisMarkup)
pdolcisMarkup = \markup{p \normal-text\italic dolciss.}
pdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pdolcisMarkup)
ppdolcisMarkup = \markup{pp \normal-text\italic dolciss.}
ppdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppdolcisMarkup)
pppdolcisMarkup = \markup{ppp \normal-text\italic dolciss.}
pppdolcis = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pppdolcisMarkup)

% espress.
mpespresMarkup = \markup{mp \normal-text\italic espress.}
mpespres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mpespresMarkup)
pespresMarkup = \markup{p \normal-text\italic espress.}
pespres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pespresMarkup)

% marc.
fmarcMarkup = \markup{f \normal-text\italic\magnify #1.0 marc.}
fmarc = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fmarcMarkup)
sfmarcMarkup = \markup{sf \normal-text\italic\magnify #1.0 marc.}
sfmarc = -\tweak self-alignment-X #-0.5 #(make-dynamic-script sfmarcMarkup)
pmarcMarkup = \markup{p \normal-text\italic marc.}
pmarc = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pmarcMarkup)
ppmarcMarkup = \markup{pp \normal-text\italic marc.}
ppmarc = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppmarcMarkup)

% cantabile
ppcantabileMarkup = \markup{pp \normal-text\italic cantabile}
ppcantabile = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppcantabileMarkup)

% leggiero
ppleggieroMarkup = \markup{pp \normal-text\italic leggiero}
ppleggiero = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppleggieroMarkup)

% dim cresc
pdimMarkup = \markup{p \normal-text\italic {dim.}}
pdim = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pdimMarkup)
ppcresMarkup = \markup{pp \normal-text\italic {cresc.}}
ppcres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script ppcresMarkup)
pcresMarkup = \markup{p \normal-text\italic {cresc.}}
pcres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script pcresMarkup)
dmmoltoMarkup = \markup\magnify #1.1 {\normal-text\italic {dim.molto}}
dmmolto = -\tweak self-alignment-X #-0.5 #(make-dynamic-script dmmoltoMarkup)
fcresMarkup = \markup{f \normal-text\italic {cresc.}}
fcres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fcresMarkup)
fdimMarkup = \markup{f \normal-text\italic {dim.}}
fdim = -\tweak self-alignment-X #-0.5 #(make-dynamic-script fdimMarkup)
mfdimMarkup = \markup{mf \normal-text\italic {dim.}}
mfdim = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfdimMarkup)
mfcresMarkup = \markup{mf \normal-text\italic {cresc.}}
mfcres = -\tweak self-alignment-X #-0.5 #(make-dynamic-script mfcresMarkup)

crMarkup = \markup\magnify #1.0 {\normal-text\italic cresc.}
cr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script crMarkup)
decrMarkup = \markup\magnify #1.0 {\normal-text\italic decresc.}
decr = -\tweak self-alignment-X #-0.5 #(make-dynamic-script decrMarkup)
dmMarkup = \markup\magnify #1.0 {\normal-text\italic dim.}
dm = -\tweak self-alignment-X #-0.5 #(make-dynamic-script dmMarkup)

Cresc = \markup\italic{\magnify #1.0 cresc.}
Decresc = \markup\italic{\magnify #1.0 decresc.}
Dim = \markup\italic{\magnify #1.0 dim.}



% Control length of laissezVibrer ties
% Usage:
% 	\extendLV #3.0
extendLV = #(define-music-function (further) (number?) #{
    \override LaissezVibrerTie.X-extent = #'(0 . 0)
    \override LaissezVibrerTie.details.note-head-gap = #(/ further -2)
    \override LaissezVibrerTie.extra-offset = #(cons (/ further 2) 0)
#})


% Notes in markup
#(define-markup-command (sixteenth layout props) ()
    "sixteenth note in markup"
    (interpret-markup layout props
        #{\markup \raise #0.5 \smaller\smaller\smaller \note-by-number #4 #0 #UP #}))
#(define-markup-command (eighth layout props) ()
    "eighth note in markup"
    (interpret-markup layout props
        #{\markup \raise #0.5 \smaller\smaller\smaller \note-by-number #3 #0 #UP #}))
#(define-markup-command (quarter layout props) ()
    "quarter note in markup"
    (interpret-markup layout props
        #{\markup \raise #0.5 \smaller\smaller\smaller \note-by-number #2 #0 #UP #}))
#(define-markup-command (half layout props) ()
    "half note in markup"
    (interpret-markup layout props
        #{\markup \raise #0.5 \smaller\smaller\smaller \note-by-number #1 #0 #UP #}))
#(define-markup-command (whole layout props) ()
    "whole note in markup"
    (interpret-markup layout props
        #{\markup \raise #0.5 \smaller\smaller\smaller \note-by-number #0 #0 #UP #}))


% Id-ed spanner
% Usage:
%	b\spid2( c\spid2)
spid=#(define-event-function (n e) (index? ly:event?)
     (set! (ly:music-property e 'spanner-id) (format "sp~a" n))
     e)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Hairpin section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Controllable espressivo; each dynamic takes its own time. Gap between the two.
% Usage: \EspOff 4 4 f1 #1.5
EspOff = #(define-music-function
            (t-cr t-decr music shorten)
            (ly:duration? ly:duration? ly:music? number?)
    "Put an < > under the music, with a gap between the two"
    #{ \context Bottom <<
        { <>\HslOff $shorten \< \skip $t-cr <>\HsrOff $shorten\> \skip $t-decr }
        { $music }
    >> #}
)

% Controllable espressivo; each dynamic takes its own time. Gap between the two.
% Usage: \Esp 4 4 f1
Esp = #(define-music-function
            (t-cr t-decr music)
            (ly:duration? ly:duration? ly:music?)
    #{ \EspOff $t-cr $t-decr $music #1.0 #}
)

% Controllable espressivo; each dynamic takes @var{time} of time
% Usage:
% 	\Espr 16. f4.
EsprWithTwoMins = #(define-music-function (min-open min-close time music)
        (number? number? ly:duration? ly:music?)
        "Put an < > under the music; each dynamic takes @var{time} of time; set hairpin minimum-length to @var{min-lin}"
        #{ \context Bottom << { \once \override Hairpin.minimum-length = $min-open <>\Hsl\< \skip $time \once \override Hairpin.minimum-length = $min-close <>\Hsr\> \skip $time <>\! } { $music } >> #}
    )

% Controllable espressivo; each dynamic takes @var{time} of time
% Usage:
% 	\Espr 16. f4.
EsprWithMin = #(define-music-function (min-len time music)
        (number? ly:duration? ly:music?)
        "Put an < > under the music; each dynamic takes @var{time} of time; set hairpin minimum-length to @var{min-lin}"
        #{ \EsprWithTwoMins #min-len #min-len #time #music #}
    )

%{
% Controllable espressivo; each dynamic takes @var{time} of time
% Usage:
% 	\Espr 16. f4.
Espr = #(define-music-function (time music)
    (ly:duration? ly:music?)
    "Put an < > under the music; each dynamic takes @var{time} of time"
    #{ \EsprWithTwoMins 3.0 3.0 #time #music #}
)
%}


% For espressivo that starts from the note, not before the note.
% For espressivo from before the note, use \espressivo or \scaleEspr <factor>.
HesprW = #(define-event-function (width hairpin) (number? ly:event?)
    "pseudo espressivo for hairpin as a tweak"
    #{
        -\tweak Hairpin.minimum-length #width -\tweak Hairpin.height #0.45 #hairpin
    #}
)


% For espressivo that starts from the note, not before the note.
% For espressivo from before the note, use \espressivo or \scaleEspr <factor>.
Hespr = #(define-event-function (hairpin) (ly:event?)
    "pseudo espressivo for hairpin as a tweak"
    (HesprW 2.5 hairpin)
)

% Controllable espressivo; each dynamic takes @var{time} of time
% Usage:
% 	\Espr 16. f4.
Espr = #(define-music-function (time music)
    (ly:duration? ly:music?)
    "Put an < > under the music; each dynamic takes @var{time} of time"
    #{ << { \context Bottom \skip #time <>\Hespr\> \skip #time <>\! } #music \Hespr\< >> #}
)

HesprOn = {
    \temporary \override Hairpin.minimum-length = #2.5
    \temporary \override Hairpin.height = #0.45
}

HesprOff = {
    \revert Hairpin.minimum-length
    \revert Hairpin.height
}

% Hairpin to barline
Hb = {
    \once \override Hairpin.to-barline = ##f
}
HbOn = {
    \temporary \override Hairpin.to-barline = ##f
}
HbOff = {
    \revert Hairpin.to-barline
}


#(define ((longer-script x) grob)
  (let* ((stil (ly:script-interface::print grob)))
  (ly:stencil-scale stil x 1)))

scaleEspr =
#(define-event-function (x-val) (number?)
#{
    \tweak #'stencil #(longer-script x-val)
    \espressivo
#})

% Usage:
% \relative c'' {
%   c4 e f\scaleEspr #2 g |
%   f e g f |
% }

% Lilypond mailing list 2019/03/10 by Thomas Morley

hairpinWithCenteredText =
#(define-music-function (parser location text) (markup?)
#{
  \once \override Hairpin.stencil =
    #(lambda (grob)
       (let* ((stencil (ly:hairpin::print grob))
              (stencil-x-ext (ly:stencil-extent stencil X))
              (txt-stil (grob-interpret-markup grob text))
              ;; Get 'direction from DynamicLineSpanner
              (par-y (ly:grob-parent grob Y))
              (dir (ly:grob-property par-y 'direction))
              (new-stencil
                (ly:stencil-combine-at-edge
                  stencil
                  Y dir
                  (ly:stencil-translate-axis
                    (ly:stencil-aligned-to txt-stil X CENTER)
                    (interval-center stencil-x-ext)
                    X)
                  ;; TODO make padding settable?
                  ;;      For now zero is hardcoded
                  0)))
         (ly:grob-set-property! grob 'Y-offset 0)
         new-stencil))
#})



%{
% LSR 233
%
% This example provides a function to typeset a hairpin (de)crescendo with
% some additional text below it, such as molto or poco. The added text
% will change the direction according to the direction of the hairpin. The
% Hairpin is aligned to DynamicText.
% 
% The example also illustrates how to modify the way an object is normally
% printed, using some Scheme code.

hairpinWithCenteredText =
#(define-music-function (text) (markup?)
  #{
    \once \override Voice.Hairpin.after-line-breaking =
      #(lambda (grob)
        (let* ((stencil (ly:hairpin::print grob))
               (par-y (ly:grob-parent grob Y))
               (dir (ly:grob-property par-y 'direction))
               (new-stencil (ly:stencil-aligned-to
                 (ly:stencil-combine-at-edge
                   (ly:stencil-aligned-to stencil X CENTER)
                   Y dir
                   (ly:stencil-aligned-to
                     (grob-interpret-markup grob text) X CENTER))
                 X LEFT))
               (staff-space (ly:output-def-lookup
                 (ly:grob-layout grob) 'staff-space))
               (staff-line-thickness
                 (ly:output-def-lookup (ly:grob-layout grob) 'line-thickness))
               (par-x (ly:grob-parent grob X))
               (dyn-text (grob::has-interface par-x 'dynamic-text-interface))
               (dyn-text-stencil-x-length
                 (if dyn-text
                   (interval-length
                     (ly:stencil-extent (ly:grob-property par-x 'stencil) X))
                   0))
               (x-shift
                 (if dyn-text
                   (-
                     (+ staff-space dyn-text-stencil-x-length)
                     (* 0.5 staff-line-thickness)) 0)))

        (ly:grob-set-property! grob 'Y-offset 0)
        (ly:grob-set-property! grob 'stencil
           (ly:stencil-translate-axis
            new-stencil
            x-shift X))))
  #})
%}


hairpinWithInsideText = 
#(define-music-function (text) (markup?)
#{
  \once \override Voice.Hairpin #'after-line-breaking = 
    #(lambda (grob)
      (let* ((stencil (ly:hairpin::print grob))
             (new-stencil (ly:stencil-aligned-to
               (ly:stencil-add (ly:stencil-aligned-to stencil X RIGHT)
                               (ly:stencil-aligned-to (grob-interpret-markup grob text)
                                                 X RIGHT))
               X LEFT))
             (staff-space (ly:output-def-lookup (ly:grob-layout grob) 'staff-space))
             (staff-line-thickness
               (ly:output-def-lookup (ly:grob-layout grob) 'line-thickness))
             (grob-name (lambda (x) (assq-ref (ly:grob-property x 'meta) 'name)))
             (par-x (ly:grob-parent grob X))
             (dyn-text (eq? (grob-name par-x) 'DynamicText ))
             (dyn-text-stencil-x-length
               (if dyn-text
                 (interval-length 
                   (ly:stencil-extent (ly:grob-property par-x 'stencil) X))
                 0))
             (x-shift 
               (if dyn-text 
                 (- 
                   (+ staff-space dyn-text-stencil-x-length)
                   (* 0.5 staff-line-thickness)) 0)))

      (ly:grob-set-property! grob 'Y-offset 0)
      (ly:grob-set-property! grob 'stencil 
         (ly:stencil-translate-axis
          new-stencil
          x-shift X))))
#})

hairpinWithTextThrough = 
#(define-music-function (text) (markup?)
#{
  \once \override Voice.Hairpin #'after-line-breaking = 
    #(lambda (grob)
      (let* ((stencil (ly:hairpin::print grob))
             (par-y (ly:grob-parent grob Y))
             (dir (ly:grob-property par-y 'direction))
             (new-stencil (ly:stencil-aligned-to
               (ly:stencil-add (ly:stencil-aligned-to stencil X CENTER)
                 (ly:stencil-aligned-to (grob-interpret-markup grob text) X CENTER))
               X LEFT))
             (staff-space (ly:output-def-lookup (ly:grob-layout grob) 'staff-space))
             (staff-line-thickness
               (ly:output-def-lookup (ly:grob-layout grob) 'line-thickness))
             (grob-name (lambda (x) (assq-ref (ly:grob-property x 'meta) 'name)))
             (par-x (ly:grob-parent grob X))
             (dyn-text (eq? (grob-name par-x) 'DynamicText ))
             (dyn-text-stencil-x-length
               (if dyn-text
                 (interval-length 
                   (ly:stencil-extent (ly:grob-property par-x 'stencil) X))
                 0))
             (x-shift 
               (if dyn-text 
                 (- 
                   (+ staff-space dyn-text-stencil-x-length)
                   (* 0.5 staff-line-thickness)) 0)))

      (ly:grob-set-property! grob 'Y-offset 0)
      (ly:grob-set-property! grob 'stencil 
         (ly:stencil-translate-axis
          new-stencil
          x-shift X))))
#})

SlashedHairpin = \hairpinWithTextThrough \markup\huge\lower #1.1 {/}

%%%%%%%%%%%%% examples
hairpinMolto = \hairpinWithCenteredText \markup\italic{molto}
hairpinPoco = \hairpinWithCenteredText \markup\italic{poco}
TextedHairpin = #(define-event-function (text hairpin) (markup? ly:event?)
#{
    -\single \hairpinWithCenteredText #text #hairpin
#})

% 
% hairpinMore = 
% \hairpinWithCenteredText \markup { \larger moltissimo }
% 
% \layout { ragged-right = ##f }
% 
% \relative c' {
%   \hairpinMolto
%   c2\< c\f
%   \hairpinMore
%   c2\ppppp\< c\f
%   \break
%   \hairpinMolto
%   c2^\< c\f
%   \hairpinMore
%   c2\ppppp\< c\f
% }

% shortening of hairpins.
% FIXME todo: respect the other side of shorten-pair if it is already set.

HsrOff = #(define-event-function (shorten dyn) (number? ly:event?)
    "shorten a spanner (hairpin etc) at the right-hand side"
    (let* ((shorten-pair (cons 0 shorten)))
        #{
            -\tweak Hairpin.shorten-pair #shorten-pair #dyn
        #}
    )
)

HslOff = #(define-event-function (shorten dyn) (number? ly:event?)
    "shorten a spanner (hairpin etc) at the left-hand side"
    (let* ((shorten-pair (cons shorten 0)))
        #{
            -\tweak Hairpin.shorten-pair #shorten-pair #dyn
        #}
    )
)

HsoOff = #(define-event-function (shorten dyn) (number? ly:event?)
    "shorten a hairpin at the open side"
    (if (equal? (ly:music-property dyn 'name) 'CrescendoEvent)
        (HsrOff shorten dyn)
        (HslOff shorten dyn)
    )
)

Hsr = \HsrOff \HairpinOffset \etc
Hsl = \HsrOff \HairpinOffset \etc
Hso = \HsoOff \HairpinOffset \etc
Hxsr = \HsrOff #(* 2 HairpinOffset) \etc
Hxsl = \HslOff #(* 2 HairpinOffset) \etc
Hxso = \HsoOff #(* 2 HairpinOffset) \etc

%{
\score {
    <<
        \new Staff {
            \relative c'' {
                c2\< c\> <>\! |
                \after 2 \> c1\< <>\! |
            }
        }

        \new Staff {
            \relative c'' {
                c2-\tweak shorten-pair #'(0 . 2) \< c\> <>\! |
                \after 2 -\tweak shorten-pair #'(1 . 0) \> c1 -\tweak shorten-pair #'(0 . 1) \< <>\! |
            }
        }

        \new Staff {
            \relative c'' {
                c2 \HsrOff #2.0 \< c\> <>\! |
                \after 2 \HslOff #1.0 \> c1 \HsrOff #1.0 \< <>\! |
            }
        }

        \new Staff {
            \relative c'' {
                c2 \Hsr \< c\> <>\! |
                \after 2 \Hsl \> c1 \Hsr \< <>\! |
            }
        }
    >>
}
%}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% End of hairpin section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Accidental section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Suppress accidentals
% use a tweak here because it (also) works inside chords
Sa = #(define-music-function (note) (ly:music?)
    "suppress accidental and cautionary"
    #{
        \tweak Accidental.stencil ##f
        \tweak AccidentalCautionary.stencil ##f
        $note
    #}
)

SaOn = {
    \temporary \override Accidental.stencil = ##f
    \temporary \override AccidentalCautionary.stencil = ##f
}
SaOff = {
    \revert Accidental.stencil
    \revert AccidentalCautionary.stencil
}

% Force accidental
Fa = #(define-music-function (note) (ly:music?)
    "forced accidental"
    (set! (ly:music-property note 'force-accidental) #t)
    note
)

% Force cautionary accidental
Fc = #(define-music-function (note) (ly:music?)
    "forced cautionary"
    (set! (ly:music-property note 'force-accidental) #t)
    (set! (ly:music-property note 'cautionary) #t)
    note
)

% Suppress parenthesis from forced accidental which has been turned into a cautionary
% http://lsr.di.unimi.it/LSR/Snippet?id=874
#(define (remove-parenthesis-from-accidental grob)
  (let ((accidental (ly:grob-object grob 'accidental-grob)))
     (if (not (null? accidental))
         (ly:grob-set-property! accidental 'parenthesized #f)
             (display " accidental-grob not found! "))))

sPA = #(define-music-function (music) (ly:music?)
#{
    \tweak before-line-breaking #remove-parenthesis-from-accidental
    $music
#})


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% End of accidental section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Set the various attributes to completely change the staff size
staffSize = #(define-music-function (new-size) (number?) #{
    \set fontSize = #new-size
    \override StaffSymbol.staff-space = #(magstep new-size)
    \override StaffSymbol.thickness = #(magstep new-size)
#})



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Parenthesize/bracketize section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%
%
% Definitions by Reinhold Kainhofer, Lilypond user list sep 28 2012
%
%%%%%%%%%%%%%

#(define-public (parentheses-item::calc-parenthesis-left-stencils grob)
  (let* ((font (ly:grob-default-font grob)))
    (list (ly:font-get-glyph font "accidentals.leftparen") empty-stencil)))

#(define-public (parentheses-item::calc-parenthesis-right-stencils grob)
  (let* ((font (ly:grob-default-font grob)))
    (list empty-stencil (ly:font-get-glyph font "accidentals.rightparen"))))

parenthesizeLeft = #(define-music-function (arg) (ly:music?)
#{
  -\tweak ParenthesesItem.stencils
#parentheses-item::calc-parenthesis-left-stencils
  -\parenthesize $arg
#})
parenthesizeRight = #(define-music-function (arg) (ly:music?)
#{
  -\tweak ParenthesesItem.stencils
#parentheses-item::calc-parenthesis-right-stencils
  -\parenthesize $arg
#})

%%%%%%%%%%%%% Shorter aliases

Pl = #parenthesizeLeft
Pr = #parenthesizeRight

%{
% Doesn't work like this, need to draw the brackets a la angled-bracket in /usr/share/lilypond/current/scm/output-lib.scm
%
#(define-public (parentheses-item::calc-bracket-left-stencils grob)
  (let* ((font (ly:grob-default-font grob)))
    (list (ly:font-get-glyph font "accidentals.leftbracket") empty-stencil)))

#(define-public (parentheses-item::calc-bracket-right-stencils grob)
  (let* ((font (ly:grob-default-font grob)))
    (list empty-stencil (ly:font-get-glyph font "accidentals.rightbracket"))))

bracketizeLeft = #(define-music-function (arg) (ly:music?)
#{
  -\tweak ParenthesesItem.stencils
#parentheses-item::calc-bracket-left-stencils
  -\parenthesize $arg
#})
bracketizeRight = #(define-music-function (arg) (ly:music?)
#{
  -\tweak ParenthesesItem.stencils
#parentheses-item::calc-bracket-right-stencils
  -\parenthesize $arg
#})

bL = #bracketizeLeft
bR = #bracketizeRight
%}

%%%%%%%%%%%%%



% Parenthesize things

% (|
PkO = -\parenthesizeLeft-!
% |)
PkS = -\parenthesizeRight-!
Pk = -\parenthesize-!
% (.
PdO = -\parenthesizeLeft-.
% .)
PdS = -\parenthesizeRight-.
Pd = -\parenthesize-.

paren = #(define-event-function (dyn) (ly:event?)
            (make-dynamic-script
             #{ \markup\pad-x #-0.6 {\concat{
                \normal-text\upright\fontsize #1 (
                \pad-x #0.0 #(ly:music-property dyn 'text)
                \normal-text\upright\fontsize #1 )
                }}
             #}
            )
        )

brack = #(define-event-function (dyn) (ly:event?)
            (make-dynamic-script
             #{ \markup\pad-x #-0.6 {\concat{
                \normal-text\upright\fontsize #2 [
                \pad-x #0.0 #(ly:music-property dyn 'text)
                \normal-text\upright\fontsize #2 ]
                }}
             #}
            )
        )

Pppp = \paren\ppp
Ppp = \paren\pp
Pp = \paren\p
Pmp = \paren\mp
Pmf = \paren\mf
Pf = \paren\f
Pff = \paren\ff
Pfff = \paren\fff
Prf = \paren\rf
Psf = \paren\sf
Pfz = \paren\fz
Psfz = \paren\sfz
Pfp = \paren\fp
Pt = -\parenthesize\trill

Bppp = \brack\ppp
Bpp = \brack\pp
Bp = \brack\p
Bmp = \brack\mp
Bmf = \brack\mf
Bf = \brack\f
Bff = \brack\ff
Bfff = \brack\fff
Brf = \brack\rf
Bsf = \brack\sf
Bfz = \brack\fz
Bfp = \brack\fp

Pk = -\parenthesize-!
Pd = -\parenthesize-.

%%http://lsr.di.unimi.it/LSR/Item?id=902
%
%=> http://lilypond.1069038.n5.nabble.com/parenthesize-groups-of-notes-td501.html
%LSR by Gilles Thibault
%I take the way of how works ParenthesesItem #'stencils from here
%http://lsr.di.unimi.it/LSR/Item?id=564
%It's probably possible to automate a bit more but that is the general idea.

startParenthesis = {
    \once \override ParenthesesItem.stencils = #(lambda (grob)
        (let ((par-list (parentheses-item::calc-parenthesis-stencils grob)))
            (list (car par-list) point-stencil )))
}

endParenthesis = {
    \once \override ParenthesesItem.stencils = #(lambda (grob)
        (let ((par-list (parentheses-item::calc-parenthesis-stencils grob)))
            (list point-stencil (cadr par-list))))
} 

% %%%%%% Example:
% {
%     \override ParenthesesItem.font-size = #5
%     \startParenthesis <c \parenthesize c'>
%     d' e' f'
%     \endParenthesis \parenthesize g'
% } 

% parenthesize or otherwise modify crescendo text:
% \once \override DynamicTextSpanner.bound-details.left.text = \markup{\concat{\upright{(}\italic{cresc.}\upright{)}}}

%%%%%%%%%%%%%%

% este fragmento sirve para poner un regulador de angulo entre dos markups, p.e.
% parentesis, corchetes, barras o cualquier otro texto

% leftText y rightText serán los textos a la izquierda y a la derecha respectivamente
% leftText and rightText will be the markup texts on each side of the hairpin

% FIXME:
%    smarter handling of shorten-pair and X-offset:
%    1) depend on the markup lengths
%    2) incorporate values already set
hairpinBetweenText =
#(define-music-function (leftText rightText) (markup? markup?)
   #{
     % FIXME: the amount to be shortened/shifted should depend on
     % the length of leftText and rightText
     % \once \override Hairpin.shorten-pair = #'(0.0 . 2.0)
     % \once \override Hairpin.X-offset = #2.0
     \once \override Hairpin.stencil =
     #(lambda (grob)
        (ly:stencil-combine-at-edge
         (ly:stencil-combine-at-edge
          (ly:stencil-aligned-to (grob-interpret-markup grob leftText) Y CENTER)
          X RIGHT
          (ly:stencil-aligned-to (ly:hairpin::print grob) Y CENTER)
          0)
         X RIGHT
         (ly:stencil-aligned-to (grob-interpret-markup grob rightText) Y CENTER)
         0.6))
   #})

%cambiando el contenido de los \markup cambiamos el objeto de texto (elemento
%de marcado y aceptara cualquier cosa que se pueda incluir en estos.

%you can change de content of the \markup to show diferent texts
%or any other thing you can put in a \markup

parenthesizedHairpin = \hairpinBetweenText \markup "(" \markup ")"

% standard use:
%   -\single \parenthesizeOpenHairpin
%   -\tweak X-offset #0.0
%   -\tweak shorten-pair #'(1 . 0.5)
%   -\tweak minimum-length #6.0
parenthesizeOpenHairpin = \hairpinBetweenText \markup "(" \markup ""

% standard use:
%   -\single \parenthesizeCloseHairpin
%   -\tweak X-offset #0.0
%   -\tweak shorten-pair #'(0.5 . 1)
%   -\tweak minimum-length #6.0
parenthesizeCloseHairpin = \hairpinBetweenText \markup "" \markup ")"

bracketedHairpin = \hairpinBetweenText \markup "[" \markup "]"


% Bracketize articulations by replacing the parenthesize stencil
% Thomas Morley, https://lists.gnu.org/archive/html/lilypond-user/2018-02/msg00065.html


#(define parentheses-item::bracket-stencils
  (lambda (grob)
    (let* ((details (ly:grob-property grob 'details))
           (protrusion (assoc-get 'protrusion details 0.2))
           (thick (ly:grob-property grob 'thickness 0.1))
           (shorten-pair (ly:grob-property grob 'shorten-pair '(0 . 0)))
           (half-y (magstep (ly:grob-property grob 'font-size)))
           (bracket-y-ext
             (cons
               (- (- half-y (car shorten-pair)))
               (- half-y (cdr shorten-pair)))))
      (list
        (ly:bracket Y bracket-y-ext thick protrusion)
        (ly:bracket Y bracket-y-ext thick (- protrusion))))))

% foild it into a parenthesize-like function
bracketize = #(define-music-function (articulation) (ly:music?)
#{
    -\tweak ParenthesesItem.stencils #parentheses-item::bracket-stencils
    -\parenthesize #articulation
#})


Bk = -\bracketize -!
Bd = -\bracketize -.

%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% EXAMPLES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\markup "default, sometimes need to tweak ParenthesesItem"
{
  c'2-\parenthesize-!
  c'2-\parenthesize-.
  c'2-\parenthesize-"otto"
  c'2-\parenthesize-"-"
}

\markup "bracket-stencils, sometimes need to tweak ParenthesesItem as well"
{
  \override ParenthesesItem.stencils = #parentheses-item::bracket-stencils

  c'2-\parenthesize-!
  c'2-\parenthesize-.
  c'2-\parenthesize-"otto"
  c'2-\parenthesize-"-"
}


\markup "bracket-stencils, adjusted"
{
  \override ParenthesesItem.stencils = #parentheses-item::bracket-stencils

  \once \override ParenthesesItem.font-size = -4
  c'2-\parenthesize-!

  \once \override ParenthesesItem.font-size = -8
  c'2-\parenthesize-\tweak padding #0.3 -.

  \textLengthOn
  \once \override ParenthesesItem.font-size = 0
  c'2-\parenthesize-"FOO"
  %\override ParenthesesItem.shorten-pair = #'(0.6 . 0.6)
  \once \override ParenthesesItem.font-size = -12
  c'2-\parenthesize-"-"
}

\markup "bracket-stencils, other examples/tweaks"
{
  \override ParenthesesItem.stencils = #parentheses-item::bracket-stencils

  \override ParenthesesItem.padding = 0.5
  <c' \parenthesize e' g'>
  \override ParenthesesItem.padding = 2
  \override ParenthesesItem.details.protrusion = 0.5
  \override ParenthesesItem.thickness = 0.3
  \override ParenthesesItem.shorten-pair = #'(0.3 . -1)
  c'2-\parenthesize-"-"
}
%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% End of parenthesize/bracketize section
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% first a pageBreak
blankPage = \markup{
		\column {
		    \combine \null \vspace #25.0
		    "This page intentionally blank to facilitate page turning."
		    \combine \null \vspace #25.0
		}
	    }

% surround by pageBreaks
middleBackPage = \markup{
    \fill-line {
	\center-column{
	    \combine \null \vspace #25.0
	    "This page is intended as the back"
	    "of one of 3 pages that must be put"
	    "beside each other on the stand."
	    \combine \null \vspace #25.0
	}
    }
}


%% Usage:
%%   \new Staff \with {
%%     \override RestCollision #'positioning-done = #merge-rests-on-positioning
%%   } << \somevoice \\ \othervoice >>
%% or (globally):
%%   \layout {
%%     \context {
%%       \Staff
%%       \override RestCollision #'positioning-done = #merge-rests-on-positioning
%%     }
%%   }
%%
%% Limitations:
%% - only handles two voices
%% - does not handle multi-measure/whole-measure rests

#(define (rest-score r)
  (let ((score 0)
	(yoff (ly:grob-property-data r 'Y-offset))
	(sp (ly:grob-property-data r 'staff-position)))
    (if (number? yoff)
	(set! score (+ score 2))
	(if (eq? yoff 'calculation-in-progress)
	    (set! score (- score 3))))
    (and (number? sp)
	 (<= 0 2 sp)
	 (set! score (+ score 2))
	 (set! score (- score (abs (- 1 sp)))))
    score))

#(define (merge-rests-on-positioning grob)
  (let* ((can-merge #f)
	 (elts (ly:grob-object grob 'elements))
	 (num-elts (and (ly:grob-array? elts)
			(ly:grob-array-length elts)))
	 (two-voice? (= num-elts 2)))
    (if two-voice?
	(let* ((v1-grob (ly:grob-array-ref elts 0))
	       (v2-grob (ly:grob-array-ref elts 1))
	       (v1-rest (ly:grob-object v1-grob 'rest))
	       (v2-rest (ly:grob-object v2-grob 'rest)))
	  (and
	   (ly:grob? v1-rest)
	   (ly:grob? v2-rest)
	   (let* ((v1-duration-log (ly:grob-property v1-rest 'duration-log))
		  (v2-duration-log (ly:grob-property v2-rest 'duration-log))
		  (v1-dot (ly:grob-object v1-rest 'dot))
		  (v2-dot (ly:grob-object v2-rest 'dot))
		  (v1-dot-count (and (ly:grob? v1-dot)
				     (ly:grob-property v1-dot 'dot-count -1)))
		  (v2-dot-count (and (ly:grob? v2-dot)
				     (ly:grob-property v2-dot 'dot-count -1))))
	     (set! can-merge
		   (and
		    (number? v1-duration-log)
		    (number? v2-duration-log)
		    (= v1-duration-log v2-duration-log)
		    (eq? v1-dot-count v2-dot-count)))
	     (if can-merge
		 ;; keep the rest that looks best:
		 (let* ((keep-v1? (>= (rest-score v1-rest)
				      (rest-score v2-rest)))
			(rest-to-keep (if keep-v1? v1-rest v2-rest))
			(dot-to-kill (if keep-v1? v2-dot v1-dot)))
		   ;; uncomment if you're curious of which rest was chosen:
		   ;;(ly:grob-set-property! v1-rest 'color green)
		   ;;(ly:grob-set-property! v2-rest 'color blue)
		   (ly:grob-suicide! (if keep-v1? v2-rest v1-rest))
		   (if (ly:grob? dot-to-kill)
		       (ly:grob-suicide! dot-to-kill))
		   (ly:grob-set-property! rest-to-keep 'direction 0)
		   (ly:rest::y-offset-callback rest-to-keep)))))))
    (if can-merge
	#t
	(ly:rest-collision::calc-positioning-done grob))))


%LSR contributed by Valentin as per request http://code.google.com/p/lilypond/issues/detail?id=503

schleiferVH =
#(define-music-function (start upstep leftstep) (ly:music? number? number?)
  #{\once \override Slur $'direction = #UP
    \once \override Slur $'stencil = $(lambda (grob)
    (let* ((slur-stencil (ly:slur::print grob))
           (Y-ext (ly:stencil-extent slur-stencil Y))
           (text-stencil (ly:text-interface::print grob))
           (prall-stencil (ly:stencil-translate text-stencil
                           (cons 2.5 (car Y-ext))))
           (combo-stencil (ly:stencil-combine-at-edge
                           prall-stencil X RIGHT
                           slur-stencil 0))
            (combo-X-ext (ly:stencil-extent combo-stencil X)))
      (ly:stencil-translate combo-stencil (cons leftstep upstep ))))
    \once \override Slur #'positions = #'(-1 . 2)
    \once \override Slur #'text = \markup {
    \musicglyph "scripts.prall" }
    \once \override Slur $'control-points = $(lambda (grob)
    (let* ((coords (ly:slur::calc-control-points grob))
            (point-0 (list-ref coords 0))
            (point-1 (list-ref coords 1))
            (point-2 (list-ref coords 2))
            (point-3 (list-ref coords 3)))
    (set-car! point-0 (+ (car point-0) 2))
    (set-car! point-1 (+ (car point-1) 1.5))
    (set-car! point-2 (+ (car point-2) -1))
    (set-car! point-3 (+ (car point-3) -1))
    coords))
    s1*0( $start \noBreak
    \once \override Rest #'transparent = ##t
    \once \override Rest #'X-extent = #'(0 . 1.7)
    \grace r1
    s1*0) #})

schleiferV =
#(define-music-function (start upstep) (ly:music? number?)
    #{
	\schleiferVH #start #upstep #1.2
    #})

schleifer =
#(define-music-function (start) (ly:music?)
    #{
	\schleiferV #start #0.2
    #})

% Example usage:
% \relative c'' { \schleifer a2 d }


%%%%%% snippet %%%%%%

#(define (make-bend x)
    (make-music 'BendAfterEvent
                'delta-step x))

bend = #(define-music-function (delta) (integer?)
    (make-bend (* -1 delta)))

bendBefore = #(define-music-function (argument) (integer?)
    #{
	\once \override BendAfter #'rotation = #'(180 -1 -1) \bend #$argument 
    #} )


% Usage:
%    c'1\bendAfter #5 e'1 d' \bendBefore #5 e'


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% \epsfile-mm includes an eps at a nonscaling width
% Thanks to Marc Hohl 2014/04/28
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#(define-markup-command (epsfile-mm layout props axis size file-name)
  (number? number? string?)
  (let* ((o-s (ly:output-def-lookup layout 'output-scale))
         (scaled-size (abs (/ size o-s))))
  (if (ly:get-option 'safe)
      (interpret-markup layout props "not allowed in safe")
      (eps-file->stencil axis scaled-size file-name)
      ))) 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Keep empty staves for the current Staff context
% By Kieren MacMillan
% From http://osdir.com/ml/lilypond-user-gnu/2014-02/msg00549.html
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

KeepEmptyStaves = \set Staff.keepAliveInterfaces = 
			#'( rhythmic-grob-interface 
			    multi-measure-rest-interface 
			    lyric-interface 
			    stanza-number-interface 
			    text-interface
			    text-script-interface
			    percent-repeat-interface) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% snippet-title = "Adjusting horizontal spacing"
% snippet-author = "David Nalesnik, Janek Warchoł"
% snippet-description = \markup {
% Sometimes you want to change horizontal spacing relative to what
% LilyPond calculated by default.  You could do this by overriding
% common-shortest-duration property of the SpacingSpanner, but that
% requires some tial-and-error to figure out what values make the
% spacing tighter, and what values make it looser.  Additionally,
% this is different for different pieces - in one piece overriding
% common-shortest-duration to 1/8 may make the spacing looser than
% the default, but in another piece it may make the spacing tighter.
% 
% This function allows you to adjust spacing without having to
% figure out anything.  Positive values make spacing looser,
% negative make it tighter, working similarly in any score.
% There are two predefined “shorthands”.
% 
% This can also be used inside a "\layout" block.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

stretchHorizontalSpacing =
#(define-music-function (exponent) (number?)
   (_i "This function determines the default value of the property
@var{common-shortest-duration} and multiplies it by a moment
derived from the @var{exponent} passed as an argument.
Negative values of @var{exponent} make the spacing tighter,
while positive values make the spacing looser.
")
   #{
     \override Score.SpacingSpanner #'common-shortest-duration =
     #(lambda (grob)
        (let* ((func (assoc-get 'common-shortest-duration
                       (reverse (ly:grob-basic-properties grob))))
               (default-value (func grob))
               ;; When dealing with moments, we need to operate on an
               ;; exponential scale. We use 'inexact->exact' to make sure
               ;; that 'rationalize' will return an exact result as well.
               (factor (inexact->exact (expt 2 (- 0 exponent))))
               ;; The second argument to 'rationalize' has to be fairly
               ;; small to allow lots of stretching/squeezing.
               (multiplier (ly:make-moment (rationalize factor 1/2000))))
          (ly:moment-mul default-value multiplier)))
   #})

horizontalSpacingLoose = \stretchHorizontalSpacing #1
horizontalSpacingTight = \stretchHorizontalSpacing #-1


% By Robin Bannister. Replacement for vspace with absolute dimensions.
#(define-markup-command (mm-feed layout props amount) (number?)
  (let ((o-s (ly:output-def-lookup layout 'output-scale)))
      (ly:make-stencil "" '(0 . 0) (cons 0 (abs (/ amount o-s))))))

#(define-markup-command (put-mm layout props dir amount arg)
  (ly:dir? number? markup?) (interpret-markup layout props
      (markup #:put-adjacent Y dir arg #:mm-feed amount)))

% example:
% dedication = \markup \put-mm #DOWN #10 "dedicated to me"


% By Nick Payne. Hide notes etc but also avoid (invisible) collisions.

transOn = {
  \override NoteColumn.ignore-collision = ##t
  \override NoteHead.no-ledgers = ##t
  \hide NoteHead
  \hide Stem
  \hide Flag
  \hide Beam
  \hide Dots
  \hide Accidental
  \hide TupletBracket
  \hide TupletNumber
}

transOff = {
  \revert NoteColumn.ignore-collision
  \revert NoteHead.no-ledgers
  \revert NoteHead.transparent
  \revert Stem.transparent
  \revert Beam.transparent
  \revert Flag.transparent
  \revert Dots.transparent
  \revert Accidental.transparent
  \revert TupletBracket.transparent
  \revert TupletNumber.transparent
} 


% https://lists.gnu.org/archive/html/lilypond-user/2018-09/msg00084.html

#(define (widen-arp grob)
   (let* ((pos (ly:arpeggio::calc-positions grob))
          (lower-corr 0.75)
          (upper-corr 0.5))
    (cons (- (car pos) lower-corr) (+ (cdr pos) upper-corr))))

#(define (regular-arp grob)
   (let* ((pos (ly:arpeggio::calc-positions grob))
          (lower-corr 0.0)
          (upper-corr 0.0))
    (cons (- (car pos) lower-corr) (+ (cdr pos) upper-corr))))

#(define (narrow-arp grob)
   (let* ((pos (ly:arpeggio::calc-positions grob))
          (lower-corr 0.0)
          (upper-corr 0.0))
    (cons (+ (car pos) lower-corr) (- (cdr pos) upper-corr))))

ArpBrack = {
    \once \override Arpeggio.positions = #regular-arp
    \once \arpeggioBracket
}

ArpBrackR = {
    \once \override Arpeggio.positions = #regular-arp
    \once \override Arpeggio.direction = #RIGHT
    \once \override Arpeggio.protrusion = #-0.5
    \once \override Arpeggio.X-offset = #2.5
    \once \arpeggioBracket
}

ArpParen = {
    \once \override Arpeggio.positions = #regular-arp
    \once \arpeggioParenthesis
}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% +thumb bracket
% Robin Bannister
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% +thumb bracket

#(define (make-thumb-bracket-props location spec-str settings-alist) 
  (define (inchar? index) (> (string-length spec-str) index))
  (define (inchar  index) (string-ref spec-str index))
  (define (char->dir ch) 
   (case (char-upcase ch) ((#\R) 1) ((#\L) -1) (else 0))) 
  (define (char->digit ch)
   (if (char-numeric? ch) (- (char->integer ch) (char->integer #\0)) 0))
  (define (inhit->1 key-str) (if (string-contains spec-str key-str) 1 0))
  (define (get key) (assq-ref settings-alist key))
  (define (warn p1 p2) (ly:input-warning location 
   (_ " bad thumb-bracket:   ~a ~a~a~a") p1 "\"" p2 "\""))
  (let* ( ;% decode spec                                                                     
    (vdir            (if (inchar? 0) (char->dir   (inchar 0)) 0))
    (vbigger  (* 0.5 (if (inchar? 1) (char->digit (inchar 1)) 0)))
    (vfurther (* 0.5 (if (inchar? 2) (char->digit (inchar 2)) 0)))
    (hcloser  (* 0.5 (if (inchar? 3) (char->digit (inchar 3)) 0)))
    (hrear    (* 0.5 (if (inchar? 4) (char->digit (inchar 4)) 0)))
    (vbigger+ (* 5 (string-count spec-str #\|)))
    (posdir   ((if (string-contains spec-str "*") - +) vdir))
    (hcloser? (eq? (string-contains spec-str "!") #f))
    (vtip=?   (string-contains spec-str "="))
    (hdir-req (- (inhit->1 "]") (inhit->1 "[")))
    (closed? (char-lower-case? (inchar 0))))
   (if (zero? vdir) (begin (warn "first char in" spec-str) '())
   (let* ( ;% collect settings
    (hdir-init (get 'hdir-init))   (htip (get 'htip)) 
    (vtip (get (if vtip=? 'vtip= 'vtip)))  
    (vstem (get 'vstem))   (vmin (get 'vmin))   (hvernier (get 'hvernier))
    (vO 0) (hO 0) (hpad-base 0.5) ;% givens
    (hdir (if (zero? hdir-req) hdir-init hdir-req))
    (hflip? (positive? hdir))
    (h-interval 
     (if (positive? hdir) (cons hO (+ htip hrear)) (cons (- hrear) htip)))
    (vsize (+ vtip (if closed? vtip vstem) vbigger vbigger+))
    (vsize+ (if (and closed? (< vsize vmin)) (- vmin vsize) 0))
    (vshift (+ vfurther vtip (* 0.5 vsize+)))
    (bracket (lambda (grob) (let* ( ;% collect chord range from grob
      (vnote-lo-hi (ly:grob-property grob 'positions))
      (vnote ((if (eq? posdir 1) cdr car) vnote-lo-hi)))
     (grob-interpret-markup grob (markup #:translate (cons 
        ((if (positive? hdir) - +) hvernier) (- vnote (* vdir vshift)))
       #:combine #:draw-line (cons htip vO) #:combine 
        #:translate (cons hO (if closed? (* vdir (+ vsize vsize+)) vO))
         #:draw-line (cons htip vO)
        #:translate (cons (if (positive? hdir) htip hO) vO)
         #:draw-line (cons hO (* vdir (+ vsize vsize+)))))))))
    ;% alist of props for misusing Arpeggio as a thumb bracket
    `((stencil . ,bracket) 
      (X-extent . ,h-interval) 
      (padding . ,((if hcloser? - +) hpad-base hcloser)) 
      (direction . ,hdir) 
      (thickness . ,(get 'weight)))))))

thumbBracketEx = #(define-music-function 
  (spec settings) (string? list?)
 (let* (
   (props (make-thumb-bracket-props (*location*) spec settings)))
   (define (get key) (assq-ref props key))
  (if (null? props) #{ #} ;% abort without bracket
   #{
     \once \override Arpeggio.positions = #regular-arp
     \once \override Arpeggio.stencil   = #(get 'stencil)
     \once \override Arpeggio.X-extent  = #(get 'X-extent)
     \once \override Arpeggio.padding   = #(get 'padding)
     \once \override Arpeggio.direction = #(get 'direction) 
     \once \override Arpeggio.thickness = #(get 'thickness)
     $(make-music 'EventChord 'elements (list (make-music 'ArpeggioEvent)))
   #})))

thumbBracket = #(define-music-function (spec) (string?)
 (let ((settings thumbBracketSettings)) ;% as Defaults, or user defined
   ((ly:music-function-extract thumbBracketEx) spec settings)))

thumbBracketDefaults = #(quasiquote( 
  (hdir-init . ,LEFT) ;% usual placement wrt note: on RIGHT or LEFT
  (weight    . 1.5  ) ;% line thickness
  (htip      . 0.8  ) ;% horizontal length of bracket tip
  (vtip      . 0.75 ) ;% usual vertical overlap beyond notehead centre 
  (vtip=     . 0.30 ) ;% alternative vertical overlap 
  (vstem     . 1.25 ) ;% length of an unextended open bracket (excl. tip)
  (vmin      . 0.6  ) ;% minimum length of a closed bracket
  (hvernier  . 0.2  ) ;% horizontal quasi-extra-offset
  ))

thumbBracketSettings =  \thumbBracketDefaults

#(define thBr thumbBracket) thbR = \thBr "R" thbL = \thBr "L"
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% -thumb bracket



%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key f \major
  \time 4/4
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { c'''16--[ b''16-- d'''16--  f''16--] }
rhlo = { d''32[ \thBr "L9" f''32 ees''32 d''32 ~ d''16 c''32 b'32] }
lhhi = { g'32[ aes'32 g'32 f'32 g'32 f'32 ees'32 d'32] }
lhlo = { s4 }
\markup "Reger 14"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef treble \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key bes \major
  \time 4/4
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { <bes' bes''>4 <c''! a''>16[ <bes' g''>16 c''16 <ees''! g''>16] }
rhlo = { d''8[ ees''!8] \thBr "L" fis'16[ g'16 \thBr "R" a'16 <g' bes'>16] }
lhhi = { d'8[ ees'!8] c'16[ bes16 c'16 bes16] }
lhlo = { bes4 fis16[ g16 a16 bes16] }

\markup "Reger 17"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef treble \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key bes \major
  \time 4/4
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { <ees' g' bes' ees''>2-> <c' f' a' c''>-> <f' f''>2.*2/3-> }
rhlo = { s1  <a' c''>8--[ <f' a'>8--] <f' ~ bes'>8--[ <f' c''>8--]  }
lhhi = { c8[ g16 a16] bes16[ g16 c'8]  
         \thBr "R" c'16[ d'16 ees'16 d'16] c'16[ d'16 ees'16 c'16] 
         \thBr "L4*" <a c'>8--[ <f a>8--] <f bes>8--[ c'8--] }
lhlo = { <c, c>4.-- c8-. <f, f>4.-- a,8-. d4-- d8--[ c8--] }

\markup "Reger 60"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key aes \major
  \time 9/8
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { ees''4.-> ees''4.-> ~ ees''8[ d''8 ees''8] }
rhlo = { \thBr "L" <aes aes'>8.[ <aes aes'>16 <aes aes'>8] r8 
         \thBr "R*" <ees' g'>8-.[ <ees' g'>8-.] <ees' aes'>4. }
lhhi = { \oneVoice s4. r8 s4 s4. } 
lhlo = { \thBr "R" <c ees ees'>8.[ <c ees ees'>16 <c ees ees'>8] s8 
          <bes, ees des'>8^.[ <beses, ees des'>8^.] <aes, ees c'>4.^> }

\markup "Scriabin IMSLP #02002 II bar48"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key fis \major
  \time 12/8
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { eis'2. ~ eis'4. eis'4. }
rhlo = { cis'2. ~ cis'4. cis'4. }
lhhi = { \thBr "r4*=" <eis gis>2. ~ gis4 cis8 gis!4 g8 } 
lhlo = { <cis, cis>2. <gisis,, gisis,>2. }

\markup "Scriabin IMSLP 10999 p5"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key bes \major
  \time 9/8
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
  \override Staff.TimeSignature.stencil = ##f
}
rhhi = { \partial 4 <cis' cis''>8[\( <d' d''>8] <ees' ees''>4 
         <e' e''>8 <fis' fis''>4 <g' g''>8 <g' g''>4 <fis' fis''>8\) }
rhlo = { \partial 4 r8 r8 r8 bes'8[ bes'8] r8 e''8[ e''8] 
         <a' ees''>8[ <a' ees''>8 <c'' ees''>8] }
lhhi = { \partial 4 \oneVoice r8 r8 r8 s4 
         \once \override Rest.X-extent = #'(0 . 2.5) 
         r8 s4 s4.}
lhlo = { \partial 4 s4 s8 <cis, cis>8[ 
         \thBr "R" <g bes g'>8] s8 
         \thBr "R1=" <bes e' bes'>8[ <cis, cis>8] 
         \stemUp <cis, cis>8[<c, c>8 <a, a>] }

\markup "Scriabin IMSLP 08382 p47"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key bes \major
  \time 4/4
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
  \override Staff.TimeSignature.stencil = ##f
}
arpLengthenTo = #(define-music-function (bound) (integer?)
#{ \once \override Arpeggio.positions = #(lambda (grob)
   (interval-union (cons bound bound) (ly:arpeggio::calc-positions grob)))
#})

%%% saw what looked like tie pushing arpeggio vertically when doubled up alto
rhhiA = {
  \once \override Arpeggio.arpeggio-direction = #down 
  \once \override NoteColumn.force-hshift = #-0.2 
  <\tweak transparent ##t  d' ees'' g'' c'''>1\arpeggio ~ <ees'' g'' c'''>1 }
rhhiB = {
  \once \override Arpeggio.arpeggio-direction = #down 
  \arpLengthenTo #-4
  <ees'' g'' c'''>1\arpeggio  ~ <ees'' g'' c'''>1 }
rhhi = { \rhhiA \rhhiB }
rhlo = \repeat unfold 2 { \thBr "l22]" <f' bes'>1 ~ <f' bes'>1 }
lhhi = \repeat unfold 2 { \oneVoice r1 r1}
lhlo = \repeat unfold 2 { s1 s1 }

\markup "F9sus"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global = {
  \key f \major
  \time 3/4
  \mergeDifferentlyHeadedOn
  \mergeDifferentlyDottedOn
}
rhhi = { a'2. }
rhlo = { r4 
  \thumbBracketEx "L442" #(acons 'htip 2.5 thumbBracketSettings) 
  <a c'>8[ <bes d'>8] <c' e'>8[ <a c'>8] }
lhhi = { f,2.}
lhlo = { \hideNotes f,16 } % spacing hack

\markup "Possibility"
\score {
\new PianoStaff <<
  \new Staff = "rh" { \clef treble \global << \rhhi \\ \rhlo >>}
  \new Staff = "lh" { \clef bass   \global << \lhhi \\ \lhlo >>}
>>
\layout { indent = 0.0\cm }
}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%}


%% http://lsr.dsi.unimi.it/LSR/Item?id=748
%% see also http://www.lilypond.org/doc/v2.17/Documentation/notation/modifying-shapes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% \appoggiatura function to modify the shape of slurs by offsetting the positions property
% from default control-point values. Setting either y1 or y2 to zero will leave
% that attachment-point unchanged. Syntax: \offsetPositions #'(y1 . y2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

offsetPositions =
  #(define-music-function (offsets) (pair?)
    #{
       \once \override Slur.positions = #(lambda (grob) 
     `(,(+ (car offsets) (cdar (ly:slur::calc-control-points grob))) . 
       ,(+ (cdr offsets) (cdr (cadddr (ly:slur::calc-control-points grob))))))
    #})

%{
\relative c'' {
  c4(^"default" c, d2)
  \offsetPositions #'(0 . 1)
  c'4(^"(0 . 1)" c, d2)
  \offsetPositions #'(0 . 2)
  c'4(^"(0 . 2)" c, d2)
  \bar "||"
  g4(^"default" a d'2)
  \offsetPositions #'(1 . 0)
  g,,4(^"(1 . 0)" a d'2)
  \offsetPositions #'(2 . 0)
  g,,4(^"(2 . 0)" a d'2)
}
%}


%{
\header {
  snippet-title = "merge-rests-engraver"
  snippet-author = "Jay Anderson"
  snippet-source =
    "http://www.mail-archive.com/lilypond-user%40gnu.org/msg69608.html"
  snippet-description = \markup {
    Merge rests of equal duration in different voice
  }
  tags = "merge, rest, rests, voice, voices"
  status = "ready"
}
%}

#(define has-one-or-less (lambda (lst) (or (null? lst) (null? (cdr lst)))))
#(define has-at-least-two (lambda (lst) (not (has-one-or-less lst))))
#(define (all-equal lst pred)
   (or (has-one-or-less lst)
       (and (pred (car lst) (cadr lst)) (all-equal (cdr lst) pred))))

#(define merge-rests-engraver
   (lambda (context)
     (let ((rest-same-length
            (lambda (rest-a rest-b)
              (eq? (ly:grob-property rest-a 'duration-log)
                   (ly:grob-property rest-b 'duration-log))))
           (rests '()))
       `((start-translation-timestep . ,(lambda (trans)
                                          (set! rests '())))
         (stop-translation-timestep . ,(lambda (trans)
                                         (if (and (has-at-least-two
                                                   rests) (all-equal rests rest-same-length))
                                             (for-each
                                              (lambda (rest)
                                                (ly:grob-set-property! rest 'Y-offset 0))
                                              rests))))
         (acknowledgers
          (rest-interface . ,(lambda (engraver grob source-engraver)
                               (if (eq? 'Rest (assoc-ref
                                               (ly:grob-property grob 'meta) 'name))
                                   (set! rests (cons grob rests))))))))))

#(define merge-mmrests-engraver
   (lambda (context)
     (let* ((mmrest-same-length
             (lambda (rest-a rest-b)
               (eq? (ly:grob-property rest-a 'measure-count)
                    (ly:grob-property rest-b 'measure-count))))
            (merge-mmrests
             (lambda (rests)
               (if (all-equal rests mmrest-same-length)
                   (let ((offset (if (eq? (ly:grob-property (car rests)
                                            'measure-count) 1) 1 0)))
                     (for-each
                      (lambda (rest) (ly:grob-set-property! rest
                                       'Y-offset offset))
                      rests)))))
            (curr-rests '())
            (rests '()))
       `((start-translation-timestep . ,(lambda (trans)
                                          (set! curr-rests '())))
         (stop-translation-timestep . ,(lambda (trans)
                                         (if (has-at-least-two curr-rests)
                                             (set! rests (cons curr-rests rests)))))
         (finalize . ,(lambda (translator)
                        (for-each merge-mmrests rests)))
         (acknowledgers
          (rest-interface . ,(lambda (engraver grob source-engraver)
                               (if (eq? 'MultiMeasureRest (assoc-ref
                                                           (ly:grob-property grob 'meta) 'name))
                                   (set! curr-rests (cons grob curr-rests))))))))))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% "Tacet" directive. Usage: \markup \Tacet {\mvtIIIpiece \mvtIVpiece}
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#(define-markup-list-command (Tacet layout props arg) (markup-list?)
    "Centered, enlarged Tacet markup command"
    (interpret-markup-list layout props
        #{
            \markuplist{\fill-line{\center-column{
                \combine \null \vspace #0.6
                \line{\bold{ \fontsize #3 { #arg — \smallCaps Tacet }}}
                \combine \null \vspace #0.2
            }}}
        #}
    ))

#(define-markup-list-command (TacetPiece layout props arg) (markup-list?)
    "Tacet markup command in the style of the piece command"
    (interpret-markup-list layout props
        #{
            \markuplist{
                \line{\bold{ #arg — \smallCaps Tacet }}
            }
        #}
    ))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ifDefined
% ifDefinedThen
% ifDefinedElse
%
% Johan Vromans
% http://lists.gnu.org/archive/html/lilypond-user/2015-01/msg00372.html
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% \ifDefined symbol
%%
%% If the symbol is defined, returns its music expression value.
%% Otherwise, returns a void expression.

ifDefined =
#(define-music-function (sym) (symbol?)
  (let ((music (ly:parser-lookup sym)))
   (if (ly:music? music)
    music
    (make-music 'Music 'void #t))))

%% \ifDefinedElse symbol expression
%%
%% If the symbol is defined, returns its music expression value.
%% Otherwise, returns the expression.

ifDefinedElse =
#(define-music-function (sym else) (symbol? ly:music?)
  (let ((music (ly:parser-lookup sym)))
   (if (ly:music? music) music else)))

%% \ifDefinedThen symbol expression
%%
%% If the symbol is defined, returns the expression.
%% Otherwise, returns a void expression.

ifDefinedThen =
#(define-music-function (sym music) (symbol? ly:music?)
  (if (defined? sym)
   music
   (make-music 'Music 'void #t)))

%% \ifDefinedThenElse symbol expression else-expression
%%
%% If the symbol is defined, returns the expression.
%% Otherwise, returns the else-expression.

ifDefinedThenElse =
#(define-music-function (sym music else) (symbol? ly:music? ly:music?)
  (if (defined? sym)
   music else))

%% Example:
%%
%% \ifDefinedThen #'leadWords  \lyricsto lead \ifDefined #'leadWords

% Thanks to: Dan Eble <address@hidden>
% Usage:
%
% aNotes = \relative c' { c1 e1 g1 }
% bNotes = \relative c' { }
%
% \ifThenElse \bNotes \aNotes \bNotes
%
% Note the test is on emptyness, not definedness.

#(define-public (music-empty? m)
   (let ((void-music (ly:music-property m 'void)))
     (or (and (not (null? void-music)) void-music)
	 (and (null? (ly:music-property m 'element))
	      (null? (ly:music-property m 'elements))))))

ifThenElse =
#(define-music-function
   (if-music then-music else-music)
   (ly:music? ly:music? ly:music?)

   (if (music-empty? if-music)
       else-music
       then-music))


% Thanks to David Nalesnik

#(define (sort-by-X-coord sys grob-lst)
"Arranges a list of grobs in ascending order by their X-coordinates"
   (let* ((X-coord (lambda (x) (ly:grob-relative-coordinate x sys X)))
          (comparator (lambda (p q) (< (X-coord p) (X-coord q)))))
          
     (sort grob-lst comparator)))
    
#(define (find-bounding-grobs note-column grob-lst)
   (let* ((sys (ly:grob-system note-column))
          (X-coord (lambda (n) (ly:grob-relative-coordinate n sys X)))
          (note-column-X (X-coord note-column)))
    
      (define (helper lst)
        (if (and (< (X-coord (car lst)) note-column-X)
                 (> (X-coord (cadr lst)) note-column-X))
            (cons (car lst) (cadr lst))
            (if (null? (cddr lst))
                (cons note-column note-column)
                (helper (cdr lst)))))
                
      (helper grob-lst)))        

#(define (read-out ls1 ls2 ls3 symbol)
"Filters all elements of ls1 from ls2 and appends it to ls3"
(set! ls3 (append ls3 (filter (lambda (x) (eq? (car ls1) (symbol x))) ls2)))
  (if (null? (cdr ls1))
      ls3
      (read-out (cdr ls1) ls2 ls3 symbol)))
      
#(define ((center-note-column x-offs) grob)
     (let* ((sys (ly:grob-system grob))
            (elements-lst (ly:grob-array->list (ly:grob-object sys 'all-elements)))
            (grob-name (lambda (x) (assq-ref (ly:grob-property x 'meta) 'name)))
            (X-extent (lambda (q) (ly:grob-extent q sys X)))
      ;; NoteColumn
            (note-column-coord (ly:grob-relative-coordinate grob sys X))
            (grob-ext (X-extent grob))
            (grob-length (interval-length grob-ext))
      ;; NoteHeads
            (note-heads (ly:grob-object grob 'note-heads))
            (note-heads-grobs (if (not (null? note-heads))
                         (ly:grob-array->list note-heads)
                         '()))
            (one-note-head (if (not (null? note-heads-grobs))
                        (car note-heads-grobs)
                        '()))
            (one-note-head-length (if (not (null? one-note-head))
                             (interval-length (X-extent one-note-head)) ;; NB
                             0))
      ;; Stem
            (stem (ly:grob-object grob 'stem))
            (stem-dir (ly:grob-property stem 'direction))
            (stem-length-x (interval-length (X-extent stem))) ;; NB
      ;; DotColumn
            (dot-column (ly:note-column-dot-column grob))
      ;; AccidentalPlacement
            (accidental-placement (ly:note-column-accidentals grob))
      ;; Arpeggio
            (arpeggio (ly:grob-object grob 'arpeggio))
      ;; Rest
            (rest (ly:grob-object grob 'rest))
      ;; Grobs to center between
            (args (list 'BarLine 
             	        'Clef 
             	        'KeySignature
             	        'KeyCancellation
             	        'TimeSignature))
            (grob-lst (read-out args elements-lst '() grob-name)) 
            (new-grob-lst (remove (lambda (x) (interval-empty? (X-extent x))) grob-lst))
            (sorted-grob-lst (sort-by-X-coord sys new-grob-lst))
      ;; Bounds
            (bounds (find-bounding-grobs grob sorted-grob-lst))
            (left (cdr (X-extent (car bounds))))
            (right (car (X-extent (cdr bounds))))
            
            ;;(bounds-coord (cons left right)) ;; delete
            
            (basic-offset
              (- (average left right)
                 (interval-center (X-extent grob))
                 (* -1 x-offs)))
            (dir-correction
              (if (> grob-length one-note-head-length)
                  (* stem-dir (* -2 stem-length-x) grob-length)
                  0))

            ) ;; End of Defs in let*
         
   ;; Calculation
   (begin
     ;;(display "\n\tbounds: \t")(write bounds)
     (for-each
       (lambda (x)
         (cond ((ly:grob? x)
          (ly:grob-translate-axis!
            x
            (- basic-offset dir-correction)
            X))))
        (list
          (cond ((not (null? note-heads)) grob))
          dot-column accidental-placement arpeggio rest))
  )))

centerNoteColumnOn = \override Staff.NoteColumn #'after-line-breaking = #(center-note-column 0)

centerNoteColumnOff = \revert Staff.NoteColumn #'after-line-breaking

onceCenterNoteColumn =
#(define-music-function (x-offs)(number?)
#{
        \once \override Staff.NoteColumn #'after-line-breaking = #(center-note-column x-offs)
#})

%{
%------------ Test

\paper {
        ragged-right = ##f
}
% Jean-Charles' example:

\version "2.21.0"

\score { <<
  \new Staff  { \relative c'' {
    c4 c c c R1 }}
  \new Staff { \relative c'' {
    c1 \centerNoteColumnOn c1 }} >>
  \layout {}
}
%}

%------------- LSR 464

#(define-markup-command (columns layout props args) (markup-list?)
   (let ((line-width (/ (chain-assoc-get 'line-width props
                         (ly:output-def-lookup layout 'line-width))
                        (max (length args) 1))))
     (interpret-markup layout props
       (make-line-markup (map (lambda (line)
                                (markup #:pad-to-box `(0 . ,line-width) '(0 . 0)
                                  #:override `(line-width . ,line-width)
                                  line))
                               args)))))

%{
%------------- http://lists.gnu.org/archive/html/lilypond-user/2013-05/msg00405.html
% By Thomas Morley (Harm)

addTextSpannerText =
#(define-music-function (text)(string?)
   "
   Add text to TextSpanner.

   @var{text} should be entered using dashes to indicate hyphenation.
   Additional dashes may be used to affect spacing.
   "
#{
   \once \override TextSpanner.after-line-breaking =
     #(lambda (grob)
       (let* ((stil (ly:grob-property grob 'stencil))
              (layout (ly:grob-layout grob))
              (staff-space (ly:staff-symbol-staff-space grob))
              (line-thickness (ly:output-def-lookup layout 'line-thickness))
              ;; have we been split?
              (orig (ly:grob-original grob))
              ;; if yes, get the split pieces (our siblings)
              (siblings (if (ly:grob? orig)
                            (ly:spanner-broken-into orig)
                            '()))
              ;; get all (broken) stencils
              (stils
                (if (null? siblings)
                  (list stil)
                  (map
                    (lambda (x) (ly:grob-property x 'stencil))
                    siblings)))
              ;; get the length of all stencils
              (stil-x-lengths
                (map
                  (lambda (x) (interval-length (ly:stencil-extent x X)))
                  stils))
              ;; split the input-string into parts
              (text-lst (string-split text #\-))
              ;; how many parts did we get
              (txt-lst-length (length text-lst))
              ;; get a divisor to split `text-lst' into parts to be printed
              ;; before and after the line break.
              ;; TODO: find better method
              (partial (if (null? siblings)
                           1
                           (floor (/ txt-lst-length (length siblings)))))
              ;; get the parts
              ;; adding an empty string at end of first line,
              ;; an start of second line
              (head (append (list-head text-lst partial) '("")))
              (tail (cons "" (list-tail text-lst partial)))
              ;; get lists of whiteout-markups
              (mrkp-whiteout-proc
                (lambda (x) (markup
                              #:whiteout
                              #:pad-markup line-thickness
                              x)))
              (lst (map mrkp-whiteout-proc text-lst))
              (lst-head (map mrkp-whiteout-proc head))
              (lst-tail (map mrkp-whiteout-proc tail))
              ;; procedures to get the text-stencils.
              (mrkp
                (lambda (x y)
                #{
                   \markup
                     \override #`(line-width . ,(+ staff-space y))
                     \fill-line
                     $x
                #}))
              (text-stil (lambda (x y) (grob-interpret-markup grob
(mrkp x y)))))

    (ly:grob-set-property! grob 'stencil
      (cond ((null? siblings)

                 (ly:stencil-add
                   stil
                   (text-stil lst (car stil-x-lengths))))
            ((and (= (length siblings) 2)
                  (eq? (car siblings) grob))
                 (ly:stencil-add
                   stil
                   (text-stil lst-head (car stil-x-lengths))))
            ((and (= (length siblings) 2)
                  (eq? (cadr siblings) grob))
                 (ly:stencil-add
                   stil
                   (text-stil lst-tail
                              (+ (* 4 staff-space) (cadr stil-x-lengths)))))
            (else (begin
                     (ly:warning "More than two linebreaks are not supported.")
                     stil))))))
#})
%}


%{
% Main program to illustrate addTextSpannerText
  \relative c'' {
    \addTextSpannerText "cres-cen-do"
    c1\startTextSpan
    d'2 d\stopTextSpan
    \addTextSpannerText "cres-cen-do"
    c1\startTextSpan
    \break
    d'2 d\stopTextSpan
    \break
    \addTextSpannerText "ral-len-tan-do"
    c1\startTextSpan
    d'2 d\stopTextSpan
    \addTextSpannerText "ral-len-tan-do"
    c,1\startTextSpan
    \break
    d2 d\stopTextSpan
    \break
    \addTextSpannerText "poco-a-poco-cres-cen-do"
    c,1\startTextSpan
    d2 d\stopTextSpan
    \addTextSpannerText "poco-a-poco-cres-cen-do"
    c,1\startTextSpan
    \break
    d2 d\stopTextSpan
    \break
    \addTextSpannerText "You-may-want-to-use-additional-------dashes"
    c'1\startTextSpan
    \break
    d2 d d d\stopTextSpan
  }
%}

% David Kastrup on -user 2012-10-22
at =
#(define-music-function (time event music)
  (ly:duration? ly:music? ly:music?)
  "Place @var{event} at a relative duration @var{time} in relation to @var{music}."
  ; #{ \context Bottom << { \skip $time <>-\tweak extra-spacing-width #empty-interval $event } $music >> #})
  #{ \context Bottom << { \skip $time <> $event } $music >> #})

after = #at

%{
{
    \at 1\!
    \at 1*1/2 \>
    c1\<
}
%}


% Example:
% <b b'>~ << r8 { \tieEnd q } >>
% b~ << r16 { \tieEnd b\noBeam } >> if otherwise the thing would be within an autobeam
tieEnd = { \Sa \once \override NoteHead.no-ledgers = ##t \once \hide NoteHead \once \hide Stem \once \hide Flag \once \hide Dots }


% Create cross-staff chords with stems that 'cross' at the beam, with the beam in
% the middle
%
% Helper to flip the noteheads to the left, clip the stem, etc
%
flipNoteLeft = #(define-music-function (span) (ly:dimension?)
"Flip noteheads and shorten stem. @var{span}: the extent of the chord in half-staff-spaces. FIXME: take the chord as an argument and calculate its extent."
#{
    \once \override Flag.transparent = ##t
    \once \override Stem.Y-offset = #0.25
    \once \override NoteHead.X-offset = #-1.175
    \once \override Stem.length = #span
    \once \stemDown
#})

% Helper to flip the noteheads to the right, clip the stem, etc
%
flipNoteRight = #(define-music-function (span) (ly:dimension?)
"Flip noteheads and shorten stem. @var{span}: the extent of the chord in half-staff-spaces. FIXME: take the chord as an argument and calculate its extent."
#{
    \once \override Flag.transparent = ##t
    \once \override Stem.Y-offset = #-0.25
    \once \override NoteHead.X-offset = #1.175
    \once \override Stem.length = #span
    \once \stemUp
#})

%{
% Example from Alban Berg Kammerkonzert bar 152
\new PianoStaff <<
    \new Staff = RH {
        \relative c
        \cleff bass
        <g,= a d>16
            \crossStaff bes
            ges
            \crossStaff es
            \change Staff = "LH" b g ges bes
    }
    \new Staff = LH {
    \relative c {
        \clef bass
        s16
            \flipNoteLeft #3.0 <a d>16
            s
            \flipNoteLeft #0.0 bes
    }
>>

% Example from Alban Berg Kammerkonzert bar 195
\new PianoStaff \with {
    \consists #Span_stem_engraver
} <<
    \new Staff = RH {
        \relative c' {
            \clef bass
            \voiceOne s4*2/3
                \flipNoteRight #0.0
                a8*2/3--
        }
    }
    \new Staff = LH {
        \time 3/4
        \new Voice \relative c {
            \clef bass
            \voiceOne \tuplet 3/2 4 { <e g>8 <f as>-- \crossStaff fis }
        }
    }
>>
%}


% from https://lists.gnu.org/archive/html/lilypond-user/2015-09/txtkw606WVD9y.txt
%% CUSTOM GROB PROPERTIES

% Taken from http://www.mail-archive.com/lilypond-user%40gnu.org/msg97663.html
% (Paul Morris)

% function from "scm/define-grob-properties.scm" (modified)
#(define (cn-define-grob-property symbol type?)
   (set-object-property! symbol 'backend-type? type?)
   (set-object-property! symbol 'backend-doc "custom grob property")
   symbol)

% For internal use.
#(cn-define-grob-property 'text-spanner-stencils list?)

% user interface
#(cn-define-grob-property 'text-spanner-line-count number-list?)

% List of booleans describing connections between text items regardless
% of line breaks.
#(cn-define-grob-property 'connectors list?)

% How much space between line and object to left and right?
% Default is '(0.0 . 0.0).
#(cn-define-grob-property 'line-offset number-pair?)

#(define (get-text-distribution text-list line-extents)
   ;; Given a list of texts and a list of line extents, attempt to
   ;; find a decent line distribution.  The goal is to put more texts
   ;; on longer lines, while ensuring that all lines are texted.
   ;; TODO: ideally, we should consider extents of text, rather than
   ;; simply their number.
   (let* ((line-count (length line-extents))
          (text-count (length text-list))
          (line-lengths
           (map (lambda (line) (interval-length line))
             line-extents))
          (total-line-len (apply + line-lengths))
          (exact-per-line
           (map (lambda (line-len)
                  (* text-count (/ line-len total-line-len)))
             line-lengths))
          ;; First and last lines can't be untexted.
          (adjusted
           (let loop ((epl exact-per-line) (idx 0) (result '()))
             (if (null? epl)
                 result
                 (if (and (or (= idx 0)
                              (= idx (1- line-count)))
                          (< (car epl) 1))
                     (loop (cdr epl) (1+ idx)
                       (append result (list 1.0)))
                     (loop (cdr epl) (1+ idx)
                       (append result (list (car epl)))))))))

     ;; The idea is to raise the "most roundable" line's count, then the
     ;; "next most roundable," and so forth, until we account for all texts.
     ;; Everything else is rounded down (except those lines which need to be
     ;; bumped up to get the minimum of one text), so we shouldn't exceed our
     ;; total number of texts.
     ;; TODO: Need a promote-demote-until-flush to be safe, unless this is
     ;; mathematically sound!
     (define (promote-until-flush result)
       (let* ((floored (map floor result))
              (total (apply + floored)))

         (if (>= total text-count)
             (begin
              ;(format #t "guess: ~a~%~%~%" result)
              floored)
             (let* ((decimal-amount
                     (map (lambda (x) (- x (floor x))) result))
                    (maximum (apply max decimal-amount))
                    (max-location
                     (list-index
                      (lambda (x) (= x maximum))
                      decimal-amount))
                    (item-to-bump (list-ref result max-location)))
               ;(format #t "guess: ~a~%" result)
               (list-set! result max-location (1+ (floor item-to-bump)))
               (promote-until-flush result)))))

     (let ((result (map inexact->exact
                     (promote-until-flush adjusted))))
       (if (not (= (apply + result) text-count))
           ;; If this doesn't work, discard, triggering crude
           ;; distribution elsewhere.
           '()
           result))))

#(define (get-connectors grob text-distribution)
   "Modify @var{text-distribution} to reflect line breaks.  Return a list
of lists of booleans representing whether to draw a connecting line
between successive texts."
   ;; The property TextSpanner.connectors holds a list of booleans representing
   ;; whether a line will be drawn between two texts.  (Thus, there will be
   ;; one fewer boolean than texts.)  This does NOT include spacers: "".
   ;; This function transforms the list of booleans into a list of lists
   ;; of booleans which reflects line breaks and the additional lines
   ;; which must be drawn.
   ;;
   ;; Given an input of '(#t #t #f)
   ;;
   ;;    '((#t        #t            #f))
   ;; one_ _ _ _two_ _ _ _ _three        four  (one line)
   ;;
   ;;     '((#t       #t)
   ;; one_ _ _ _two_ _ _ _ _                   (two lines)
   ;;   (#t         #f))
   ;; _ _ _ _three     four
   ;;
   ;;     '((#t)
   ;; one_ _ _ _                               (four lines/blank)
   ;; (#t       #t)
   ;; _ _ _two_ _ _
   ;;      (#t)
   ;; _ _ _ _ _ _ _
   ;; (#t      #f))
   ;; _ _three    four
   (let* ((connectors? (ly:grob-property grob 'connectors))
          (text-distribution (vector->list text-distribution)))

     (if (pair? connectors?)
         (let loop ((td text-distribution)
                    (c? connectors?)
                    (result '()))
           (if (null? td)
               result
               (let inner ((texts (car td))
                           (bools c?)
                           (inner-result '()))
                 (cond
                  ((null? (cdr texts))
                   (loop (cdr td) bools
                     (append result (list inner-result))))
                  ((null? bools)
                   (ly:warning
                    "too few connections specified.  Reverting to default.")
                   '())
                  ;; Ignore spacers since they don't represent a new line.
                  ((equal? "" (cadr texts))
                   (inner (cdr texts) bools inner-result))
                  ((equal? (cadr texts) #{ \markup \null #})
                   (inner (cdr texts) bools
                     (append inner-result (list (car bools)))))
                  (else
                   (inner (cdr texts) (cdr bools)
                     (append inner-result (list (car bools)))))))))
         '())))


#(define (get-line-arrangement siblings extents texts)
   "Given a list of spanner extents and texts, return a vector of lists
of the texts to be used for each line.  Using @code{'()} for @var{siblings}
returns a vector for an unbroken spanner."
   (let ((sib-len (length siblings)))
     (if (= sib-len 0)
         ;; only one line...
         (make-vector 1 texts)
         (let* ((texts-len (length texts))
                (text-counts
                 (ly:grob-property
                  (car siblings) 'text-spanner-line-count))
                (text-counts
                 (cond
                  ((pair? text-counts) text-counts) ; manual override
                  ((null? siblings) '())
                  (else (get-text-distribution texts extents))))
                (text-counts
                 (if (and (pair? text-counts)
                          (not (= (apply + text-counts) texts-len)))
                     (begin
                      (ly:warning "Count doesn't match number of texts.")
                      '())
                     text-counts))
                (text-lines (make-vector sib-len 0))
                ;; If user hasn't specified a count elsewhere, or the result
                ;; from 'get-text-distribution' failed, we have this method.
                ;; Populate vector in a simple way: with two lines,
                ;; give one text to the first line, one to the second,
                ;; a second for the first, and second for the second--
                ;; and so forth, until all texts have been exhausted.  So
                ;; for 3 lines and 7 texts we would get this arrangement:
                ;; 3, 2, 2.
                (text-counts
                 (cond
                  ((null? text-counts)
                   (let loop ((txts texts) (idx 0))
                     (cond
                      ((null? txts) text-lines)
                      ;; We need to ensure that the last line has text.
                      ;; This may require skipping lines.
                      ((and (null? (cdr txts))
                            (< idx (1- sib-len))
                            (= 0 (vector-ref text-lines (1- sib-len))))
                       (vector-set! text-lines (1- sib-len) 1)
                       text-lines)
                      (else
                       (vector-set! text-lines idx
                         (1+ (vector-ref text-lines idx)))
                       (loop (cdr txts)
                         (if (= idx (1- sib-len)) 0 (1+ idx)))))))
                  (else (set! text-lines (list->vector text-counts)))))
                ;; read texts into vector
                (texts-by-line
                 (let loop ((idx 0) (texts texts))
                   (if (= idx sib-len)
                       text-lines
                       (let ((num (vector-ref text-lines idx)))
                         (vector-set! text-lines idx
                           (list-head texts num))
                         (loop (1+ idx)
                           (list-tail texts num)))))))

           text-lines))))

#(define (add-markers text-lines)
   ;; Markers are added to the broken edges of spanners to serve as anchors
   ;; for connector lines beginning and ending systems.
   ;; Add null-markup at the beginning of lines 2...n.
   ;; Add null-markup at the end of lines 1...(n-1).
   ;; Note: this modifies the vector 'text-lines'.
   (let loop ((idx 0))
     (if (= idx (vector-length text-lines))
         text-lines
         (begin
          (if (> idx 0)
              (vector-set! text-lines idx
                (cons #{ \markup \null #}
                  (vector-ref text-lines idx))))
          (if (< idx (1- (vector-length text-lines)))
              (vector-set! text-lines idx
                (append (vector-ref text-lines idx)
                  (list #{ \markup \null #}))))
          (loop (1+ idx))))))

%% Adapted from 'justify-line-helper' in scm/define-markup-commands.scm.
#(define (markup-list->stencils-and-extents-for-line grob texts extent padding)
   "Given a list of markups @var{texts}, return a list of stencils and extents
spread along an extent @var{extent}, such that the intervening spaces are
equal."
   (let* ((orig-stencils
           (map (lambda (a) (grob-interpret-markup grob a)) texts))
          (stencils
           (map (lambda (stc)
                  (if (ly:stencil-empty? stc X)
                      (ly:make-stencil (ly:stencil-expr stc)
                        '(0 . 0) (ly:stencil-extent stc Y))
                      stc))
             orig-stencils))
          (line-contents
           (if (= (length stencils) 1)
               (list point-stencil (car stencils) point-stencil)
               stencils))
          (text-extents
           (map (lambda (stc) (ly:stencil-extent stc X))
             line-contents))
          (te1 text-extents)
          ;; How much shift is necessary to align left edge of first
          ;; stencil with extent?  Apply this shift to all stencils.
          (text-extents
           (map (lambda (stc)
                  (coord-translate
                   stc
                   (- (car extent) (caar text-extents))))
             text-extents))
          ;; how much does the last stencil need to be translated for
          ;; its right edge to touch the end of the spanner?
          (last-shift (- (cdr extent) (cdr (last text-extents))))
          (word-count (length line-contents))
          ;; Make a list of stencils and their extents, scaling the
          ;; extents across extent. The right edge of the last stencil
          ;; is now aligned with the right edge of the spanner.  The
          ;; first stencil will be moved 0.0, the last stencil the
          ;; amount given by last-shift.
          (stencils-shifted-extents-list
           (let loop ((contents line-contents) (exts text-extents)
                       (idx 0) (result '()))
             (if (null? contents)
                 result
                 (loop
                  (cdr contents) (cdr exts) (1+ idx)
                  (append result
                    (list
                     (cons (car contents)
                       (coord-translate
                        (car exts)
                        (* idx
                          (/ last-shift (1- word-count)))))))))))
          ;; Remove non-marker spacers from list of extents.  This is done
          ;; so that a single line is drawn to cover the total gap rather
          ;; than several. (A single line is needed since successive dashed
          ;; lines will not connect properly.)
          (stencils-extents-list-no-spacers
           (let loop ((orig stencils-shifted-extents-list) (idx 0) (result '()))
             (cond
              ((= idx (length stencils-shifted-extents-list)) result)
              ;; Ignore first and last stencils, which--if point stencil--
              ;; will be markers.
              ((or (= idx 0)
                   (= idx (1- (length stencils-shifted-extents-list))))
               (loop (cdr orig) (1+ idx)
                 (append result (list (car orig)))))
              ;; Remove spacers.  Better way to identify them than comparing
              ;; left and right extents?
              ((= (cadar orig) (cddar orig))
               (loop (cdr orig) (1+ idx) result))
              ;; Keep any visible stencil.
              (else (loop (cdr orig) (1+ idx)
                      (append result (list (car orig)))))))))

     stencils-extents-list-no-spacers))

#(define (check-for-overlaps stil-extent-list)
   (let* ((collision
           (lambda (line)
             (let loop ((exts line) (result '()))
               (if (null? (cdr exts))
                   result
                   (loop (cdr exts)
                     (append result
                       (list
                        (not (interval-empty?
                              (interval-intersection
                               (cdar exts) (cdadr exts)))))))))))
          ;; List of lists of booleans comparing first element to second,
          ;; second to third, etc., for each line.  #f = no collision
          (all-successive-collisions
           (map (lambda (line) (collision line))
             stil-extent-list)))

     ;; For now, just print a warning and return #t if any collision anywhere.
     (let loop ((lines all-successive-collisions) (idx 0) (collisions? #f))
       (cond
        ((null? lines) collisions?)
        ((any (lambda (p) (eq? p #t)) (car lines))
         (ly:warning
          "overlap(s) found on line ~a; redistribute manually"
          (1+ idx))
         (loop (cdr lines) (1+ idx) #t))
        (else
         (loop (cdr lines) (1+ idx) collisions?))))))


#(define (make-distributed-line-stencil grob stil-stil-extent-list connectors)
   ;; Should take connectors? argument.
   "Take a list of stencils and arbitrary extents and return a combined
stencil conforming to the given extents.  Lines separate the stencils.
TODO: lines should be suppressed if not enough space."
   (let* ((padding (ly:grob-property grob 'line-offset (cons 0.0 0.0)))
          (padding-L (car padding))
          (padding-R (cdr padding))
          (padded-stencils-extents-list
           (let loop ((orig stil-stil-extent-list) (idx 0) (result '()))
             (cond
              ((= idx (length stil-stil-extent-list)) result)
              ;; don't widen line markers
              ((= (cadar orig) (cddar orig))
               (loop (cdr orig) (1+ idx)
                 (append result (list (car orig)))))
              ;; right padding only if object starts line
              ((= idx 0)
               (loop (cdr orig) (1+ idx)
                 (append
                  result
                  (list (cons (caar orig)
                          (coord-translate
                           (cdar orig) (cons 0 padding-R)))))))
              ;; left padding only if object ends a line
              ((= idx (1- (length stil-stil-extent-list)))
               (loop (cdr orig) (1+ idx)
                 (append
                  result
                  (list (cons (caar orig)
                          (coord-translate
                           (cdar orig) (cons (- padding-L) 0.0)))))))
              ;; otherwise right- and left-padding
              (else
               (loop (cdr orig) (1+ idx)
                 (append
                  result
                  (list (cons (caar orig)
                          (coord-translate
                           (cdar orig)
                           (cons (- padding-L)
                             padding-R))))))))))
          ;; Spaces between the text stencils will be filled with lines.
          (spaces
           (if (> (length padded-stencils-extents-list) 1)
               (let loop ((orig padded-stencils-extents-list)
                          (result '()))
                 (if (null? (cdr orig))
                     result
                     (loop
                      (cdr orig)
                      (append
                       result
                       (list (cons (cdr (cdr (first orig)))
                               (car (cdr (second orig)))))))))
               '()))
          ;; TODO: Do this when making lines.  Otherwise will disrupt
          ;; show/hide connectors.
          (spaces (remove interval-empty? spaces))
          (line-contents
           (let loop ((contents stil-stil-extent-list)
                      (stil empty-stencil))
             (if (null? contents)
                 stil
                 (loop
                  (cdr contents)
                  (ly:stencil-add stil
                    (ly:stencil-translate-axis
                     (caar contents)
                     (- (car (cdr (car contents)))
                       (car (ly:stencil-extent (car (car contents)) X)))
                     X))))))
          ;; By default, lines are drawn between all texts
          (join-all (null? connectors))
          (line-contents
           (let loop ((exts spaces)
                      (result line-contents)
                      (join connectors))
             (if (null? exts)
                 result
                 (loop
                  (cdr exts)
                  (if (and
                       ;; space too short for line
                       (not (interval-empty? (car exts)))
                       (or join-all
                           (car join)))
                      (ly:stencil-add
                       result
                       ;(make-line-stencil 0.1
                       ;; For versions < 2.19.27, replace line below with
                       ;; commented line.  No dashed lines!
                       (ly:line-interface::line grob
                         (caar exts) 0.0
                         (cdar exts) 0.0))
                      result)
                  (if join-all join (cdr join)))))))

     line-contents))


#(define (make-stencils grob siblings stil-extent-list connectors)
   ;; entry point for stencil construction
   (if (null? siblings)
       (list (make-distributed-line-stencil grob
               (car stil-extent-list)
               (if (pair? connectors)
                   (car connectors)
                   connectors)))
       (map (lambda (sib)
              (make-distributed-line-stencil sib
                (list-ref
                 stil-extent-list
                 (list-index
                  (lambda (x) (eq? x sib))
                  siblings))
                (if (pair? connectors)
                    (list-ref
                     connectors
                     (list-index
                      (lambda (x) (eq? x sib))
                      siblings))
                    '())))
         siblings)))

%% Based on addTextSpannerText, by Thomas Morley.  See
%% http://www.mail-archive.com/lilypond-user%40gnu.org/msg81685.html
addTextSpannerText =
#(define-music-function (texts) (list?)
   (if (< (length texts) 2)
       (begin
        (ly:warning "At least two texts required for `addTextSpannerText'.")
        (make-music 'Music))

       #{
         % The following overrides of 'bound-details are needed to give the
         % correct length to the default spanner we replace.
         \once \override TextSpanner.bound-details.left.text = #(car texts)
         \once \override TextSpanner.bound-details.left-broken.text = ##f
         \once \override TextSpanner.bound-details.right.text = #(last texts)
         \once \override TextSpanner.bound-details.right-broken.text = ##f

         \once \override TextSpanner.stencil =
         #(lambda (grob)
            (let* (;; have we been split?
                    (orig (ly:grob-original grob))
                    ;; if yes, get the split pieces (our siblings)
                    (siblings (if (ly:grob? orig)
                                  (ly:spanner-broken-into orig)
                                  '()))
                    (stils (ly:grob-property grob 'text-spanner-stencils)))
              ;; If stencils haven't been calculated, calculate them.  Once
              ;; we have results prompted by one sibling, no need to go
              ;; through elaborate calculation (stencils, collisions, ideal
              ;; line contents...) for remaining pieces.
              (if (null? stils)
                  (let* (;; pieces and their default stencils
                          (grobs-and-stils
                           (if (null? siblings) ; unbroken
                               (list (cons grob (ly:line-spanner::print grob)))
                               (map
                                (lambda (sib)
                                  (cons sib (ly:line-spanner::print sib)))
                                siblings)))
                          (line-stils
                           (map (lambda (gs) (cdr gs)) grobs-and-stils))
                          (line-extents
                           (map (lambda (s) (ly:stencil-extent s X))
                             line-stils))
                          (our-stil
                           (cdr (find (lambda (x) (eq? (car x) grob))
                                  grobs-and-stils)))
                          (padding (ly:grob-property grob 'padding 0.0)))

                    (define (get-stil-extent-list text-distrib)
                      (if (null? siblings)
                          (list
                           (markup-list->stencils-and-extents-for-line
                            grob
                            (vector-ref text-distrib 0)
                            (ly:stencil-extent our-stil X)
                            padding))
                          (map
                           (lambda (sib)
                             (markup-list->stencils-and-extents-for-line
                              sib
                              (vector-ref text-distrib
                                (list-index
                                 (lambda (y) (eq? y sib)) siblings))
                              (ly:stencil-extent
                               (cdr (find
                                     (lambda (z) (eq? (car z) sib))
                                     grobs-and-stils))
                               X)
                              padding))
                           siblings)))

                    (let*
                     (;; vector which gives the text for unbroken spanner
                       ;; or for siblings.  This is a preliminary
                       ;; arrangement, to be tweaked below.
                       (text-distribution
                        (get-line-arrangement siblings line-extents texts))

                       (text-distribution (add-markers text-distribution))
                       (connectors (get-connectors grob text-distribution))
                       (all-stils-and-extents
                        (get-stil-extent-list text-distribution))
                       ;; warning printed
                       (overlaps (check-for-overlaps all-stils-and-extents))
                       ;; convert stencil/extent list into finished stencil
                       (line-stils
                        (make-stencils
                         grob siblings all-stils-and-extents connectors)))

                     (if (null? siblings)
                         (set! (ly:grob-property grob 'text-spanner-stencils)
                               line-stils)
                         (for-each
                          (lambda (sib)
                            (set!
                             (ly:grob-property sib 'text-spanner-stencils)
                             line-stils))
                          siblings))

                     (set! stils line-stils))))

              ;; Return our stencil
              (if (null? siblings)
                  (car stils)
                  (list-ref stils
                    (list-index (lambda (x) (eq? x grob)) siblings)))))
       #}))


%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXAMPLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\markup \bold "Default (no inner text possible)"

\relative c'' {
  \textLengthOff
  \override TextSpanner.bound-details.left.text = #"ral"
  \override TextSpanner.bound-details.left-broken.text = ##f
  \override TextSpanner.bound-details.right.text = #"do"
  \override TextSpanner.bound-details.right-broken.text = ##f
  c,1\startTextSpan
  d'1\stopTextSpan
}

\markup \bold "All on one line"

\relative c' {
  \addTextSpannerText #'("ral" "len" "tan" "do")
  c1\startTextSpan
  d'1\stopTextSpan
}

\markup \bold "Broken"

\relative c' {
  %% to show collision detection
  %\override TextSpanner.text-spanner-line-count = #'(2 2)
  \addTextSpannerText #'("ral" "len" "tan" "do")
  c1\startTextSpan
  \break
  d'1\stopTextSpan
}

\markup \bold "Empty line/manual distribution"

\relative c' {
  \override TextSpanner.text-spanner-line-count = #'(1 0 1 1)
  \addTextSpannerText #(list "one" "two" "three")
  c1~\startTextSpan
  \break
  c1~
  \break
  c1~
  \break
  c1\stopTextSpan
}

\markup \bold "Changes of ends"

\relative c' {
  \addTextSpannerText #'("one" "two" "three")
  c1\startTextSpan
  c1\stopTextSpan
  \once \override TextSpanner.bound-details.left.padding = #-2
  \once \override TextSpanner.bound-details.right.padding = #-5
  \addTextSpannerText #'("one" "two" "three")
  c1\startTextSpan
  c1\stopTextSpan
}

\markup \bold "Markups"

\relative c' {
  \addTextSpannerText #(list
                        #{ \markup "one" #}
                        #{ \markup "two" #}
                        #{ \markup "three" #})
  c1\startTextSpan
  c1\stopTextSpan
  \addTextSpannerText
  #(list
    #{ \markup "one" #}
    #{ \markup \with-color #red \translate #'(-3 . 0) "two" #}
    #{ \markup "three" #})
  c1\startTextSpan
  c1\stopTextSpan
  \override TextSpanner.style = #'dotted-line
  \override TextSpanner.dash-period = #0.5
  \addTextSpannerText #(list
                        #{ \markup \right-align  "one" #}
                        "two"
                        #{ \markup \center-align "three" #})
  c1\startTextSpan
  c1\stopTextSpan
}

\relative c'' {
  \override TextSpanner.style = #'zigzag
  \override TextSpanner.line-offset = #'(0.5 . 0.5)
  \addTextSpannerText
  #(list
    #{ \markup \draw-circle #1 #0.2 ##f #}
    #{ \markup \with-color #grey \draw-circle #1 #0.2 ##t #}
    #{ \markup \draw-circle #1 #0.2 ##t #}
    #{ \markup \with-color #grey \draw-circle #1 #0.2 ##t #}
    #{ \markup \draw-circle #1 #0.2 ##f #} )
  c1\startTextSpan
  %\break
  d'1 d\stopTextSpan
}

\relative c'' {
  \override TextSpanner.line-offset = #'(0.7 . 0.4)
  \override TextSpanner.style = #'trill
  r2 r4 r8 r16
  \addTextSpannerText
  #(append
    (make-list 29
      #{ \markup \general-align #Y #CENTER \musicglyph "scripts.trill" #})
    (list #{ \markup \musicglyph "scripts.caesura.straight" #} ))
  d'16~\startTextSpan
  \break
  \repeat unfold 3 {
    d1~
    \break
  }
  d8~ d\stopTextSpan r4 r2
}

\markup \bold "Showing/hiding connectors"

\relative c' {
  c1
  \override TextSpanner.padding = 3
  \override TextSpanner.direction = #DOWN
  \override TextSpanner.connectors = #'(#f #f #f #t)
  \override TextSpanner.text-spanner-line-count = #'(4 0 1)
  \addTextSpannerText
  #(list "poco" "a" "poco" "dim." #{ \markup \dynamic "mf" #})
  c1\startTextSpan
  c1 c1
  \break
  c1 c1 c1 c1
  \break
  c1 c1 c1
  c1\stopTextSpan
}

\layout {
  indent = 0
  ragged-right = ##f
}
%}

% Text spanner that takes the length of the markup
% Based on https://lists.gnu.org/archive/html/lilypond-user/2013-02/msg00201.html
% by Mike Solomon
StartWideTextSpan = #(define-music-function (start) (markup?)
"Set test spanner start text, and increase its minimum length accordingly"
#{
    \override TextSpanner.bound-details.left.text = $start
    \override TextSpanner.minimum-length =
        #(lambda (grob)
            (interval-length (ly:stencil-extent (grob-interpret-markup grob start) X)))
#}
)

% TextSpanners that are aware of the spanner-id
% By David Nalesnik
% https://lists.gnu.org/archive/html/lilypond-devel/2015-10/msg00118.html
% http://lists.gnu.org/archive/html/lilypond-user/2016-10/msg00110.html
% http://lists.gnu.org/archive/html/lilypond-user/2016-10/msg00117.html

%% Incorporating some code from the rewrite in Scheme of
%% Text_spanner_engraver in input/regression/scheme-text-spanner.ly

#(define (add-bound-item spanner item)
   (if (null? (ly:spanner-bound spanner LEFT))
       (ly:spanner-set-bound! spanner LEFT item)
       (ly:spanner-set-bound! spanner RIGHT item)))

#(define (axis-offset-symbol axis)
   (if (eq? axis X) 'X-offset 'Y-offset))

#(define (set-axis! grob axis)
   (if (not (number? (ly:grob-property grob 'side-axis)))
       (begin
        (set! (ly:grob-property grob 'side-axis) axis)
        (ly:grob-chain-callback
         grob
         (if (eq? axis X)
             ly:side-position-interface::x-aligned-side
             side-position-interface::y-aligned-side)
         (axis-offset-symbol axis)))))

#(define (assign-spanner-index spanner orig-ls)
   "Determine the position of a new spanner in an ordered sequence
of spanners.  The goal is for the sequence to begin with zero and
contain no gaps.  Return the index representing the spanner's position."
   (if (null? orig-ls)
       0
       (let loop ((ls orig-ls) (insert? #t) (result 0))
         (cond
          ((null? ls) result)
          ;; position at head of list
          ((and insert? (> (caar orig-ls) 0))
           (loop ls #f 0))
          ;; no gaps, put at end of list
          ((and insert? (null? (cdr ls)))
           (loop (cdr ls) #f (1+ (caar ls))))
          ;; fill lowest position of gap
          ((and insert?
                (> (caadr ls) (1+ (caar ls))))
           (loop (cdr ls) #f (1+ (caar ls))))
          (else (loop (cdr ls) insert? result))))))

alternateTextSpannerEngraver =
#(lambda (context)
   (let (;; a list of pairs comprising a spanner index
          ;;  (not spanner-id) and a spanner which has been begun
          (spanners '())
          (finished '()) ; list of spanners in completion stage
          (start-events '()) ; list of START events
          (stop-events '())) ; list of STOP events
     (make-engraver
      ;; \startTextSpan, \stopTextSpan, and the like create events
      ;; which we collect here.
      (listeners
       ((text-span-event engraver event)
        (if (= START (ly:event-property event 'span-direction))
            (set! start-events (cons event start-events))
            (set! stop-events (cons event stop-events)))))
      ;; Populate 'note-columns property of spanners.  Bounds are
      ;; set to note columns, and each spanner keeps a record of
      ;; the note columns it traverses.
      (acknowledgers
       ((note-column-interface engraver grob source-engraver)
        (for-each (lambda (s)
                    (ly:pointer-group-interface::add-grob
                     (cdr s) 'note-columns grob)
                    (if (null? (ly:spanner-bound (cdr s) LEFT))
                        (add-bound-item (cdr s) grob)))
          spanners)
        ;; finished only contains spanners, no indices
        (for-each (lambda (f)
                    (ly:pointer-group-interface::add-grob
                     f 'note-columns grob)
                    (if (null? (ly:spanner-bound f RIGHT))
                        (add-bound-item f grob)))
          finished)))

      ((process-music trans)
       ;; Move begun spanners from 'span' to 'finished'.  We do this
       ;; on the basis of 'spanner-id.  If we find a match--either
       ;; the strings are the same, or both are unset--a transfer
       ;; can be made.  Return a warning if we find no match: spanner
       ;; hasn't been properly begun.
       (for-each
        (lambda (es)
          (let ((es-id (ly:event-property es 'spanner-id)))
            (let loop ((sp spanners))
              (if (null? sp)
                  (ly:warning "No spanner to end!!")
                  (let ((sp-id (ly:event-property
                                (event-cause (cdar sp)) 'spanner-id)))
                    (cond
                     ; ((or
                       ; (and
                        ; (string? sp-id)
                        ; (string? es-id)
                        ; (string=? sp-id es-id))
                       ; ;; deal with \startTextSpan, \stopTextSpan
                       ; (and
                        ; (null? sp-id)
                        ; (null? es-id)))
                      ((equal? sp-id es-id)
                      (set! finished (cons (cdar sp) finished))
                      (set! spanners (remove (lambda (s) (eq? s (car sp))) spanners)))
                     (else (loop (cdr sp)))))))))
        stop-events)

       ;; The end of our spanners can be acknowledged by other engravers.
       (for-each
        (lambda (f)
          (ly:engraver-announce-end-grob trans f (event-cause f)))
        finished)

       ;; Make spanners in response to START events.
       ;;
       ;; Each new spanner is assigned an index denoting its position relative to
       ;; other active spanners.  This is enforced (for the moment) by adding
       ;; a small amount to the spanner's 'outside-staff-priority proportional to
       ;; this index.  This is unlikely to result in conflicts, though a better
       ;; solution may be to organize the spanners by a new alignment grob.
       ;;
       ;; Also, add any existing spanners to the 'side-support-elements array of
       ;; the new spanner.  This ensures correct ordering over line breaks when
       ;; 'outside-staff-priority is set to #f (which means that it is no longer
       ;; an outside-staff-object--not the default).
       (for-each
        (lambda (es)
          (let* ((new (ly:engraver-make-grob trans 'TextSpanner es))
                 (new-idx (assign-spanner-index new spanners))
                 (new-osp (ly:grob-property new 'outside-staff-priority))
                 (new-osp (if (number? new-osp)
                              (+ new-osp (/ new-idx 1000.0))
                              new-osp)))
            (set! (ly:grob-property new 'outside-staff-priority) new-osp)
            (set-axis! new Y)
            ;; Add spanners with a lower index than new spanner to
            ;; its 'side-support-elements.  This allows new spanners
            ;; to fill gaps under the topmost spanner.
            (for-each
             (lambda (sp)
               (if (< (car sp) new-idx)
                   (ly:pointer-group-interface::add-grob new
                     'side-support-elements (cdr sp))))
             spanners)
            (set! spanners (cons (cons new-idx new) spanners))
            (set! spanners
                  (sort spanners (lambda (x y) (< (car x) (car y)))))))
        start-events)
       ;; Events have served their purpose for this timestep.  Clear
       ;; the way for new events in later timesteps.
       (set! start-events '())
       (set! stop-events '()))

      ((stop-translation-timestep trans)
       ;; Set bounds of spanners to PaperColumns if they haven't been set.
       ;; This allows spanners to be drawn between spacers.  Other uses?
       ;; Doesn't appear to affect whether spanners can de drawn between
       ;; rests.
       (for-each
        (lambda (s)
          (if (null? (ly:spanner-bound (cdr s) LEFT))
              (ly:spanner-set-bound! (cdr s) LEFT
                (ly:context-property context 'currentMusicalColumn))))
        spanners)

       (for-each
        (lambda (f)
          (if (null? (ly:spanner-bound f RIGHT))
              (ly:spanner-set-bound! f RIGHT
                (ly:context-property context 'currentMusicalColumn))))
        finished)

       (set! finished '()))
       ((finalize trans)
             ;; If spanner ends on spacer at end of context?
             (for-each
              (lambda (f)
                (if (null? (ly:spanner-bound f RIGHT))
                    (ly:spanner-set-bound! f RIGHT
                      (ly:context-property context 'currentMusicalColumn))))
             finished)
            (set! finished '())
            ;; User didn't end spanner.
            (for-each
             (lambda (sp)
               (ly:warning "incomplete spanner removed!")
               (ly:grob-suicide! (cdr sp)))
             spanners)
            (set! spanners '())))))

startTextSpanOne =
#(make-music 'TextSpanEvent 'span-direction START 'spanner-id "1")

stopTextSpanOne =
#(make-music 'TextSpanEvent 'span-direction STOP 'spanner-id "1")

startTextSpanTwo =
#(make-music 'TextSpanEvent 'span-direction START 'spanner-id "2")

stopTextSpanTwo =
#(make-music 'TextSpanEvent 'span-direction STOP 'spanner-id "2")

startTextSpanThree =
#(make-music 'TextSpanEvent 'span-direction START 'spanner-id "3")

stopTextSpanThree =
#(make-music 'TextSpanEvent 'span-direction STOP 'spanner-id "3")

%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXAMPLE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\layout {
  \context {
    \Voice
    \remove #"Text_spanner_engraver"
    \consists \alternateTextSpannerEngraver
  }
}


% David Kastrup on -user 2012-10-22
after =
#(define-music-function (time event music)
  (ly:duration? ly:music? ly:music?)
  "Place @var{event} at a relative duration @var{time} in relation to @var{music}."
  #{ \context Bottom << { \skip $time <>$event } $music >> #})

\score {
  <<
    \new Staff <<
      \relative c'' {
        % a1^"Cannot leave this out" |
        \after 4*0
            -\tweak bound-details.left.text "ON"
            -\tweak bound-details.right.text "OFF"
            \=1\startTextSpan
        \after 4*3
            -\tweak bound-details.left.text "NO"
            -\tweak bound-details.right.text "FFO"
            -\tweak direction #DOWN
            \=2\startTextSpan
            a1
        % << a1 { s4 <>\=1\stopTextSpan s2 <>\=2\stopTextSpan } >>
        \after 4 \=1\stopTextSpan \after 4*3 \=2\stopTextSpan a1
      }
    >>
    \new Staff {
      \repeat unfold 12 c''4
    }
  >>
}


\relative c' {
  \override TextSpanner.style = ##f
  \override TextSpanner.thickness = 10
  %\override TextSpanner.to-barline = ##t
  a4
  -\tweak color #red
  \startTextSpan
  b
  -\tweak color #green
  \startTextSpanOne
  c
  -\tweak color #blue
  \startTextSpanTwo
  d
  \startTextSpanThree

  a4\stopTextSpan
  b
  \stopTextSpanOne
  -\tweak color #red
  \startTextSpan
  c
  \stopTextSpanTwo
  -\tweak color #green
  \startTextSpanOne
  d
  \stopTextSpanThree
  -\tweak color #blue
  \startTextSpanTwo

  a4
  \startTextSpanThree
  b c d
  \break

  a4 b c d

  a1\stopTextSpan\stopTextSpanOne\stopTextSpanTwo\stopTextSpanThree
}
%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Make transparent in scheme
% RFHH 2016-09

TransOne = #(define-music-function (symbol chord) (symbol? ly:music?)
    "Suppress one notational element"
    (make-music 'SequentialMusic 'elements (list
        (make-music 'SequentialMusic 'elements (list
            (make-music
                'ContextSpeccedMusic 'context-type 'Bottom 'element
                    (make-music
                        'OverrideProperty 'once #t 'pop-first #t
                        'grob-property-path (list (quote transparent))
                        'grob-value #t 'symbol symbol
                    )
            )
        ))
        chord
    ))
)

TransList = #(define-music-function (chord suppress) (ly:music? list?)
    "Suppress the notation elements in list suppress"
    (make-music 'SequentialMusic
        'elements (list
             (make-music
               'ContextSpeccedMusic 'context-type 'Bottom
               'element (make-music
                 'OverrideProperty 'once #t 'pop-first #t 'grob-value #t
                 'grob-property-path (list (quote ignore-collision))
                 'symbol 'NoteColumn)
             )
             (make-music
               'ContextSpeccedMusic 'context-type 'Bottom
               'element (make-music
                 'OverrideProperty 'once #t 'pop-first #t 'grob-value #f
                 'grob-property-path (list (quote stencil))
                 'symbol 'AccidentalCautionary)
             )
             (make-music
               'ContextSpeccedMusic 'context-type 'Bottom
               'element (make-music
                 'OverrideProperty 'once #t 'pop-first #t 'grob-value #t
                 'grob-property-path (list (quote no-ledgers))
                 'symbol 'NoteHead)
             )
             (fold TransOne chord suppress)
        )
    )
)

TransDots = #(define-music-function (chord) (ly:music?)
    "Suppress visible aspects of a note, including Dots"
    (TransList chord '(NoteHead Dots Stem Beam Flag Accidental))
)

Trans = #(define-music-function (chord) (ly:music?)
    "Suppress visible aspects of a note, excluding Dots"
    (TransList chord '(NoteHead Stem Beam Flag Accidental))
)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Make tie from note to next void
% RFHH 2016-09

%%%%%%%% FIXME omit (cautionary) accidentals which may occur in the piano accidental style

TFrac = #(define-music-function (chord fraction) (ly:music? fraction?)
    "Add a tie to a fraction of its duration"
    (set! (ly:music-property chord 'articulations)
        (cons (make-music 'TieEvent)
            (ly:music-property chord 'articulations)))
    (let* ((elts (ly:music-property chord 'elements))
           (outer-duration (ly:music-property chord 'duration))
           (duration (if (null? outer-duration)
                        (ly:music-property (car elts) 'duration)
                        outer-duration))
           (dlog  (ly:duration-log duration))
           (dots  (ly:duration-dot-count duration))
           (during (car fraction))
           (total (cdr fraction))
           (scale (ly:duration-scale duration))
           (scale-during (* (/ scale total) during))
           (scale-rest (* (/ scale total) (- total during)))
           (t-short (ly:make-duration dlog dots scale-during))
           (note2 (make-music 'NoteEvent
                    'duration (ly:make-duration dlog dots scale-rest)))
          )
        (set! (ly:music-property note2 'articulations)
           (cons (make-music 'BeamForbidEvent)
                (ly:music-property note2 'articulations)))
        (if (null? outer-duration)
            (map (lambda (note) (set! (ly:music-property note 'duration) t-short))
                 elts
            )
            (set! (ly:music-property chord 'duration) t-short)
        )
        (make-music 'SequentialMusic 'elements (list chord (TransDots note2)))
    )
)

TH = #(define-music-function (chord) (ly:music?)
    (TFrac chord '(1 . 2))
)

TQ = #(define-music-function (chord) (ly:music?)
    (TFrac chord '(3 . 4))
)

TT = #(define-music-function (chord) (ly:music?)
    "Add a tie from chord until its duration end"
    (ly:expect-warning "cannot have note heads and rests together on a stem")
    (ly:expect-warning "maybe input should specify polyphonic voices")
    (set! (ly:music-property chord 'articulations)
        (cons (make-music 'TieEvent) (ly:music-property chord 'articulations)))
    (let* ((note2
            (make-music 'NoteEvent 'duration (ly:make-duration 1 0 0))))
        (set! (ly:music-property note2 'articulations)
            (cons (make-music 'BeamForbidEvent)
                 (ly:music-property note2 'articulations)))
        (make-music 'SequentialMusic 'elements (list chord (Trans note2)))
    )
)


%{
DEPRECATE
textCresc = #(define-music-function (cresc) (markup?)
    #{
        \set crescendoText = \markup\italic{ #cresc }
        \once \set crescendoSpanner = #'text
        \once \override DynamicTextSpanner.style = #'dashed-line
    #}
)

textDecresc = #(define-music-function (cresc) (markup?)
    #{
        \set decrescendoText = \markup\italic{ #cresc }
        \once \set decrescendoSpanner = #'text
        \once \override DynamicTextSpanner.style = #'dashed-line
    #}
)
%}

% textCresc in -\tweak form. Don't specify a following hairpin.
TextCresc = #(define-music-function (text) (markup?)
    (make-music 'CrescendoEvent 'span-direction START 'span-type 'text 'span-text text)
)

% textDecresc in -\tweak form. Don't specify a following hairpin.
TextDecresc = #(define-music-function (text) (markup?)
    (make-music 'DecrescendoEvent 'span-direction START 'span-type 'text 'span-text text)
)

dimin = \TextDecresc "dimin."


XStaffBracket = {
    \once \set PianoStaff.connectArpeggios = ##t
    \once \override PianoStaff.Arpeggio.stencil = #ly:arpeggio::brew-chord-bracket 
    \once \override Score.Arpeggio.stencil = #ly:arpeggio::brew-chord-bracket 
}


%% Fake time signature: doesn't meddle with the timing

fakeTimeSig = #(define-music-function (num denom) (markup? markup?)
#{
    <>
        -\tweak extra-offset #'( -2.7 . 2.4 )
        -\tweak baseline-skip #0.2
        -\tweak direction #DOWN
        -\markup{\concat{{\lower #0.4 {|}} \hspace #0.3 \column{{\number $num } {\number $denom }}}}
#})

fakeParenTimeSig = #(define-music-function (num denom) (markup? markup?)
#{
    <>
        -\tweak extra-offset #'( -2.7 . 2.4 )
        -\tweak baseline-skip #0.2
        -\tweak direction #DOWN
        -\markup\upright{\concat{\lower #1.5 \magnify #2.0 {(} \column{{\number $num } {\number $denom }}\lower #1.5 \magnify #2.0 {)}}}
#})

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Inherit from Dynamics for a tempi-line
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\layout {
    \context {
        \name MarkLine
        \type "Engraver_group"

        \consists Dynamic_engraver
        \consists Text_engraver
        \consists Mark_engraver
        \consists Metronome_mark_engraver
        \consists Output_property_engraver
        \consists Axis_group_engraver

        \remove Text_spanner_engraver
        \consists \alternateTextSpannerEngraver

        \accepts TimedSpanner

        \override VerticalAxisGroup.minimum-Y-extent = #'(-2 . 2)
        \override VerticalAxisGroup.staff-affinity = ##f
        % Narrow vertical spacing for parts. In full scores, increase
        % that, and the spacing from the Staff(Group) above. See
        % common-grand-score.ily for preferred spacing in full scores.
        \override VerticalAxisGroup.staff-staff-spacing =
            #'((basic-distance . 2)
               (minimum-distance . 1)
               (padding . 1)
               (stretchability . 30))

        \override MetronomeMark.extra-spacing-width = #'(-0.5 . -inf.0)
        % \override Score.MetronomeMark.extra-spacing-width = #'(-0.5 . 0)

        \override TimeSignature.Y-offset = #2
        \override TimeSignature.X-offset = #-2
        \override TimeSignature.font-size = #4

        % otherwise, the RH of the TextSpanner may disappear. No idea why.
        \override TextSpanner.bound-details.left.padding = #-0.1
        \override TextSpanner.bound-details.right.padding = #-0.1

        \alias Dynamics
    }

    \inherit-acceptability "MarkLine" "Dynamics"
}

\layout {
    \context {
        \name BarNumberer
        \type "Engraver_group"
        \consists Timing_translator
        \consists Default_bar_line_engraver
        \consists Bar_number_engraver
        % \consists Output_property_engraver
        % \consists Axis_group_engraver

        \override VerticalAxisGroup.minimum-Y-extent = #'(-2 . 2)
        \override VerticalAxisGroup.staff-affinity = #DOWN
        \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
            #'((basic-distance . 0)
               (minimum-distance . 0)
               (padding . 0)
               (stretchability . 0))

        \alias Dynamics
    }

    \inherit-acceptability "BarNumberer" "Dynamics"
}

\layout {
    \context {
        \name TimedSpanner
        \type "Engraver_group"

        \accepts "Lyrics"

        \override VerticalAxisGroup.minimum-Y-extent = #'(-4 . 4)
        \override VerticalAxisGroup.staff-affinity = #DOWN

        \override LyricText.self-alignment-X = #LEFT
        \override LyricText.extra-spacing-width = #empty-interval
        \override LyricText.X-offset = #-1
        \override LyricText.Y-offset = #0.97
        % \override LyricText.Y-offset = #-1.8

        \override LyricHyphen.dash-period = #3.0
        \override LyricHyphen.length = #0.8
        \override LyricHyphen.thickness = #0.8
        \override LyricHyphen.extra-offset = #'(0 . 0.57)
        \override LyricHyphen.minimum-distance = #1

        \override LyricSpace.minimum-distance = #1

        \alias Lyrics
    }

    \inherit-acceptability "TimedSpanner" "Lyrics"
}

% To actually suppress Marks and Tempi in the Score for use of a TimeLine:
%{
\layout {
    \context {
        \Score
            \remove "Mark_engraver"
            \remove "Metronome_mark_engraver"
            \remove "Staff_collecting_engraver"
            \accepts MarkLine   % is this really necessary?

            \override BarNumber.padding = #3.5
    }
}
%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% By Schneidy (Pierre Perol-Schneider
% From http://lists.gnu.org/archive/html/lilypond-user/2014-05/msg00025.html

BrackRH = \tweak padding #-0.8 \rightHandFinger \markup \concat {
    \override #'(thickness . 2.5)\draw-line #'(0 . 2.25)
    \hspace #-.2
    \override #'(thickness . 2.5)\draw-line #'(1 . 0)
}


BrackLH = \tweak padding #-0.8 \rightHandFinger \markup \concat {
  \override #'(thickness . 2.5) \draw-line #'(0 . -2.25)
  \hspace #-.2
  \override #'(thickness . 2.5) \draw-line #'(1 . 0)
}


%{
\relative c'' {
  \set strokeFingerOrientations = #'(left)
  c\BrackRH c\BrackLH f,\BrackRH f\BrackLH
}
%}

%%%%%%%%%%%%%%%%%%%%%%


% Lilypond User List: Thomas Morley (Harm) 2017-04-13
%

#(define-public (format-bass-figures figure event context)
  (let* ((fig (ly:event-property event 'figure))
         (fig-markup (if (number? figure)

                         ;; this is not very elegant, but center-aligning
                         ;; all digits is problematic with other markups,
                         ;; and shows problems in the (lack of) overshoot
                         ;; of feta-alphabet glyphs.
                         ((if (<= 10 figure)
                              (lambda (y) (make-translate-scaled-markup
                                           (cons -0.7 0) y))
                              identity)

                          (cond
                           ((eq? #t (ly:event-property event 'diminished))
                            (markup #:slashed-digit figure))
                           ((eq? #t (ly:event-property event 'augmented-slash))
                            (markup #:backslashed-digit figure))
                           (else (markup #:number (number->string figure 10)))))
                         #f))

         (alt (ly:event-property event 'alteration))
         (alt-markup
          (if (number? alt)
              (markup
               #:general-align Y DOWN #:fontsize
;; !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
               (if (not (= alt DOUBLE-SHARP))
                   ;-2 2 :; is the default
                   1 3 ;; 4 4 ;; changed
                 )
;; !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
               (alteration->text-accidental-markup alt))
              #f))

         (plus-markup (if (eq? #t (ly:event-property event 'augmented))
                          (markup #:number "+")
                          #f))

         (alt-dir (ly:context-property context 'figuredBassAlterationDirection))
         (plus-dir (ly:context-property context 'figuredBassPlusDirection)))

    (if (and (not fig-markup) alt-markup)
        (begin
          (set! fig-markup (markup #:left-align #:pad-around 0.3 alt-markup))
          (set! alt-markup #f)))


    ;; hmm, how to get figures centered between note, and
    ;; lone accidentals too?

    ;;    (if (markup? fig-markup)
    ;;  (set!
    ;;   fig-markup (markup #:translate (cons 1.0 0)
    ;;                      #:center-align fig-markup)))

    (if alt-markup
        (set! fig-markup
              (markup #:put-adjacent
                      X (if (number? alt-dir)
                            alt-dir
                            LEFT)
                      fig-markup
                      #:pad-x 0.2 alt-markup)))

    (if plus-markup
        (set! fig-markup
              (if fig-markup
                  (markup #:put-adjacent
                          X (if (number? plus-dir)
                                plus-dir
                                LEFT)
                          fig-markup
                          #:pad-x 0.2 plus-markup)
                  plus-markup)))

    (if (markup? fig-markup)
        (markup #:fontsize -2 fig-markup)
        empty-markup)))


%{
\layout {
  \context {
    \Score
    figuredBassFormatter = #format-bass-figures
  }
}

\figures {
  <7! 6+ 4-> <5++> <3--> < _+ > < 7 _!>
}
%}

%% http://lsr.di.unimi.it/LSR/Item?id=772
% double tongueing, triple tongueing etc

tongue = #(define-music-function (dots) (integer?)
  #{
    \tweak stencil
      #(lambda (grob)
        (let ((stil (ly:script-interface::print grob)))
          (let loop ((count (1- dots)) (new-stil stil))
            (if (> count 0)
                (loop (1- count)
                      (ly:stencil-combine-at-edge new-stil X RIGHT stil 0.2))
                (ly:stencil-aligned-to new-stil X CENTER)))))
     \staccato
  #})

%{
\relative c' {
  \tuplet 3/2 { \repeat tremolo 3 c8-\tongue #3 }
}
%}

addStaccato = #(define-music-function (note-event) (ly:music?)
  "Add a staccato ArticulationEvent to the articulations of `note-event',
  which is supposed to be a NoteEvent expression."
  (set! (ly:music-property note-event 'articulations)
        (cons (make-music 'ArticulationEvent
                'articulation-type "staccato")
              (ly:music-property note-event 'articulations)))
  note-event)

DoubleT = #(define-music-function (dots note) (integer? ly:music?)
    "Add a multi-dot tongue to note."
    "FIXME: \tongue is an Event, how do I convert it to an override?"
    #{
        #(ly:expect-warning "Unattached ArticulationEvent")
        \once \tongue #dots \repeat tremolo #dots \addStaccato #note
    #}
)


% control the divisi-staves (remove-layer) stuff
boring = \set Staff.keepAliveInterfaces = #'()
tricky = \unset Staff.keepAliveInterfaces

targetstaff = #(define-scheme-function (ctx) (string?)
    #{
        \set Staff.keepAliveInterfaces = #'()
        \context Staff = #ctx { \unset Staff.keepAliveInterfaces }
    #})

%% http://lsr.di.unimi.it/LSR/Item?id=874
% Context to remove cautionary parentheses if a forced accidental (!) is present

#(define (Parenthesis_on_cautionary_accidentals_purger ctx)
    `((acknowledgers
       (accidental-interface
        . ,(lambda (trans grob source)
            (let*
             ((grob-meta (ly:grob-property grob 'meta))
              (grob-name (ly:assoc-get 'name grob-meta)))
             (if (equal? (symbol->string grob-name) "AccidentalCautionary")
              (let*
               ((my-notehead-grob (ly:grob-property grob 'cause))
                (my-notehead-prob (ly:grob-property my-notehead-grob 'cause))
                (accidental-is-forced (and
                  (ly:prob-property my-notehead-prob 'force-accidental #f)
                  (not (ly:prob-property my-notehead-prob 'cautionary #f)))))
               (if accidental-is-forced (ly:grob-set-property! grob 'parenthesized #f))))))))))

%{
\score {
  \new Staff \with {
    \consists #Parenthesis_on_cautionary_accidentals_purger
  } {
    \partial 4
    s4*0^"modern:"
    \modern
    \MusicIII
    \bar "||"
    s4*0^"modern-cautionary:"
    \modernCautionary
    \MusicIII
    \bar "|."
  }
  \header {
    piece = "remove all parenthesis from cautionary accidentals by an engraver, if a »force« flag is found"
  }
}
%}


%% http://lsr.di.unimi.it/LSR/Item?id=782
%% see also http://lilypond.org/doc/v2.18/Documentation/notation/displaying-rhythms
%% see also http://lilypond.org/doc/v2.18/Documentation/snippets/staff-notation#staff-notation-time-signature-in-parentheses-_002d-method-3

#(define ((time-parenthesized-time up down upp downp) grob)
   (grob-interpret-markup grob
     (markup #:override '(baseline-skip . 0) #:number
       (#:line (
           (#:column (up down))
           (#:concat (#:vcenter "("
            (#:column (upp downp))
            #:vcenter ")" )))))))

#(define ((parenthesized-time up down) grob)
   (grob-interpret-markup grob
     (markup #:override '(baseline-skip . 0) #:number
       (#:line (
           #:vcenter "("
           (#:column (up down))
           #:vcenter ")" )))))

#(define ((fake-time up down) grob)
    (grob-interpret-markup grob
        (markup #:override '(baseline-skip . 0 ) #:number
            (#:column (up down))
        )
    )
)

%{
\relative c' {
   \override Staff.TimeSignature.stencil = #(time-parenthesized-time "3" "4" "6" "8")      
   \time 3/4
   b8 b8 gis8 gis4 gis8
}

\relative c' {
   \override Staff.TimeSignature.stencil = #(fake-time "11" "30")      
   \time 3/4
   b8 b8 gis8 gis4 gis8
}
%}

%% Kieren MacMillan on mailing list 17 May 2019

showMMRs =
  \set Staff.keepAliveInterfaces =
    #'( rhythmic-grob-interface
        multi-measure-rest-interface
        lyric-interface
        stanza-number-interface
        percent-repeat-interface)

%%
% Number bars for repetetive notes etc.
%
%% Toine Schreurs privately by email 2012/07/11

numberedRepeats =
#(define-music-function
  (numberRpts theMusic ) ( integer?  ly:music?)
  (let* (
    (mom (ly:music-length theMusic))
    (num (ly:moment-main-numerator mom ))
    (denom (ly:moment-main-denominator mom))
    (dur (ly:make-duration 0 0 num denom))
    (nrp (ly:number->string numberRpts))
    (skipmusic (make-music 'SequentialMusic 'elements
		(list
		 (make-music 'EventChord 'elements
		  (list
		   (make-music 'SkipEvent 'duration dur ))))))
  )
   #{
   <<
    \repeat unfold $numberRpts $theMusic
    {
     \set countPercentRepeats = ##t
%    \override PercentRepeatCounter #'Y-offset = 4
     \override PercentRepeatCounter #'padding = #1.0
     \override PercentRepeatCounter #'font-size = #-4
     \override PercentRepeat #'transparent = ##t
     \override DoublePercentRepeatCounter #'extra-offset = #'(-6.0 . 0.0)
     \override DoublePercentRepeatCounter #'padding = #2.5
     \override DoublePercentRepeatCounter #'font-size = #-4
     \override DoublePercentRepeat #'transparent = ##t
     \repeat percent $numberRpts $skipmusic
    }
    {
     s32-\tweak font-size #-2 ^\markup \concat { "(1-" $nrp ")"}
    }
   >>
   #}
 )
)

numberedRepeatsClose =
#(define-music-function
  (parser location numberRpts theMusic ) ( integer?  ly:music?)
  (let* (
    (nrp (ly:number->string numberRpts))
  )
   #{
   <<
   \repeat unfold $numberRpts $theMusic
    {
   \set countPercentRepeats = ##t
%    \override PercentRepeatCounter #'Y-offset = 4
   \override PercentRepeatCounter #'padding = #1
   \override PercentRepeatCounter #'font-size = #-4
%    \override DoublePercentRepeatCounter #'X-offset = #-6
   \override DoublePercentRepeatCounter #'extra-offset = #'(-6.0 . 0.0)
   \override DoublePercentRepeatCounter #'padding = #1
   \override DoublePercentRepeatCounter #'font-size = #-4
   \override PercentRepeat #'transparent = ##t
   \override DoublePercentRepeat #'transparent = ##t
   \repeat percent $numberRpts #(ly:export (skip-of-length $theMusic))
 }
   {
     s32-\tweak font-size #-2 ^\markup \concat { "(1-" $nrp ")"}
   }
  >>
   #}
)
)

%{
\new Staff
{ \time 3/4
  \numberedRepeats #10 { c4 c c | }
%  \override DoublePercentRepeatCounter #'extra-offset = #'(-7.0 . 0)
  <<
   { \numberedRepeats #10 { c4 c c | } }
   { s4\p s s | s4\< s s | s2.*5 | s2\! s s }
  >>
}
%}

TrillNat = -\tweak extra-offset #' ( 1.0 . -1.0 ) -\markup\tiny\natural
TrillFlat = -\tweak extra-offset #' ( 1.1 . -1.0 ) -\markup\tiny\flat
TrillDoubleFlat = -\tweak extra-offset #' ( 1.2 . -1.0 ) -\markup\tiny\doubleflat
TrillSharp = -\tweak extra-offset #' ( 1.0 . -1.0 ) -\markup\tiny\sharp
TrillDoubleSharp = -\tweak extra-offset #' ( 1.0 . -1.0 ) -\markup\tiny\doublesharp

#(define aDueAlign (if (defined? 'aDueAlign) aDueAlign #{ #1.8 #}))

soloI = \markup\upright\bold\halign #aDueAlign {1.}
soloII = \markup\upright\bold\halign #aDueAlign {2.}
soloIII = \markup\upright\bold\halign #aDueAlign {3.}
soloIV = \markup\upright\bold\halign #aDueAlign {4.}
aDue = \markup\upright\bold\halign #aDueAlign {a2}
aDueIeII = \markup\upright\bold\halign #aDueAlign {1.2.}
aDueIeIII = \markup\upright\bold\halign #aDueAlign {1.3.}
aDueIIeIII = \markup\upright\bold\halign #aDueAlign {2.3.}
aDueItoIII = \markup\upright\bold\halign #aDueAlign {1.2.3.}
aDueItoIV = \markup\upright\bold\halign #aDueAlign {1.-4.}
aDueIIeIV = \markup\upright\bold\halign #aDueAlign {2.4.}
aDueIItoIV = \markup\upright\bold\halign #aDueAlign {2.3.4.}
aDueIIIeIV = \markup\upright\bold\halign #aDueAlign {3.4.}
aTre = \markup\upright\bold\halign #aDueAlign {a3}
aQuattro = \markup\upright\bold\halign #aDueAlign {a4}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Poor-man's Partcombine
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

voice-prefix = #(define-music-function (voice-id) (integer?)
"Helper"
    (define (voice-converter i)
        (if (zero? i)
            (context-spec-music (make-voice-props-revert) 'Voice)
            (context-spec-music (make-voice-props-set (- i 1)) 'Voice)
        )
    )
    (let ((voice (voice-converter voice-id))
          (dyn (if (zero? voice-id)
                    #{ #}
                    (if (odd? voice-id)
                        #{
                            \temporary \override DynamicText.direction = #UP
                            \temporary \override DynamicLineSpanner.direction = #UP
                        #}
                        #{
                            \temporary \override DynamicText.direction = #DOWN
                            \temporary \override DynamicLineSpanner.direction = #DOWN
                        #}
                    )
                )
          )
         )
        #{ #voice #dyn #}
    )
)

voice-suffix = #(define-music-function (voice-id) (integer?)
"Helper"
    (if (zero? voice-id)
        #{ #}
        #{
            \oneVoice
            \dynamicNeutral
            \revert TextScript.direction
            \revert TextSpanner.direction
        #}
    )
)

voice-line = #(define-music-function (q duration voice-id remove-quoted?)
            (string? ly:music? integer? boolean?)
"Helper to set one quotation for this duration, parameterized"
    (if (not (string-null? q))
        (let ((prefix (voice-prefix voice-id))
              (suffix (voice-suffix voice-id))
             )
            (if remove-quoted?
                #{ #prefix \removeWithTag KEEPQUOTED \quoteDuring #q { #duration } #suffix #}
                #{ #prefix
                    \temporary \override TextScript.direction = #UP
                    \temporary \override TextSpanner.direction = #UP
                    \quoteDuring #q { #duration } #suffix #}
            )
        )
        #{ #}
    )
)

PMPc = #(define-music-function (quotes duration voice-id first-remove-quoted?)
            (list? ly:music? integer? boolean?)
"Helper to set a list of quotations for this duration, parameterized"
    (define (range from n)
        (if (eq? from n) '() (cons from (range (1+ from) n))))
    (define (voice-converter i)
        (if (zero? i)
            (context-spec-music (make-voice-props-revert) 'Voice)
            (context-spec-music (make-voice-props-set (1- i)) 'Voice)))
    (define (create-voice qv)
        (let ((q (car qv))
              (count (car (cdr qv)))
             )
            (voice-line q duration voice-id (or (> count 0) first-remove-quoted?))
        )
    )
    (make-simultaneous-music
        (map create-voice (zip quotes (range 0 (length quotes)))))
)


PMPChords = #(define-music-function (quotes duration) (list? ly:music?)
"Set the quotations in chord mode for this duration"
    (PMPc quotes duration 0 #f)
)


PMPApart = #(define-music-function (quotes duration) (list? ly:music?)
"Set the quotations in multiple-voice mode for this duration. Each quote can
be a list, which is then typeset as chords."
    (define (range from n) (if (eq? from n) '() (cons from (range (1+ from) n))))
    (define (to-list q) (if (list? q) q (list q)))
    (define (create-voice qv)
        (let* ((voice-number (1+ (car (cdr qv))))
               (voice (to-list (car qv)))
               (remove-first-quoted (> voice-number 1))
              )
            (if (= voice-number 1)
                #{ { #(PMPc voice duration voice-number remove-first-quoted) } #}
                #{ \new Voice { #(PMPc voice duration voice-number remove-first-quoted) } #}
                )
            )
        )
    (make-simultaneous-music
        (map create-voice (zip quotes (range 0 (length quotes)))))
)

% Lilypond user list, 2019-09-28 Aaron Hill
#(define ly:expect-warning-times (lambda args
    (for-each (lambda _ (apply ly:expect-warning (cdr args)))
        (iota (car args)))))


% inverted portato
% Follow Urs Liska, David Nalesnik http://lilypond.1069038.n5.nabble.com/Creating-new-articulation-adding-to-an-internal-alist-td172689.html

#(set! default-script-alist
    (append! default-script-alist
        (list
            `("iportato"
                . (
                    (script-stencil . (feta . ("dportato" . "uportato")))
                    (avoid-slur . around)
                    (padding . 0.45)
                    (side-relative-direction . ,DOWN))))
    )
)

iportato = #(make-articulation "iportato")



%{
\score {
    \new Staff <<
        \relative c'' {
            c-_ \displayMusic c-\tweak outside-staff-priority #460 -. -\tweak outside-staff-priority #450 -- \displayMusic c-\iportato
        }
    >>
}
%}


Slashed = { \once \override Flag.stroke-style = #"grace" }



% Posted by Andrew Bernard https://lists.gnu.org/archive/html/lilypond-user/2016-06/msg00416.html
%

tupletAngles =
#(define-music-function (y-off angl)(number? number?)
   "
 y-off a (possible) offset in Y-direction
 angl is supposed to be the angle of the TupletBracket in degrees,
 "
   #{
     \once\override TupletBracket.stencil =
     #(lambda (grob)
        (let* ((pos (ly:grob-property grob 'positions))
               (y-length (interval-length pos))
               (st (ly:tuplet-bracket::print grob))
               (st-x-ext (ly:stencil-extent st X))
               (st-x-length (interval-length st-x-ext))
               (alpha (degrees->radians angl))
               (dir (ly:grob-property grob 'direction))
               (new-start (+ (if (= dir 1)
                                 (max (car pos)(cdr pos))
                                 (min (car pos)(cdr pos)))
                            y-off))
               (new-y (* st-x-length (tan alpha))))
          (ly:grob-set-property! grob 'positions (cons new-start (+
new-start new-y)))
          (ly:tuplet-bracket::print grob)))
   #})

horizontalTuplets = \override TupletBracket.stencil =
    #(lambda (grob)
       (let* ((pos (ly:grob-property grob 'positions))
              (dir (ly:grob-property grob 'direction))
              (new-pos (if (= dir 1)
                           (max (car pos)(cdr pos))
                           (min (car pos)(cdr pos)))))
         (ly:grob-set-property! grob 'positions (cons new-pos new-pos))
         (ly:tuplet-bracket::print grob)))

%% ===========================================


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% StaffGroup subclass just for the verticalFollower
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\layout {
    \context {
        \StaffGroup
        \name VoiceFollowerGroup
        \alias StaffGroup

        \description "Just like @code{StaffGroup}, but no bracket or connecting bars."

        \remove System_start_delimiter_engraver
        \remove Span_bar_engraver

        topLevelAlignment = ##f

        instrumentName = #'()
        shortInstrumentName = #'()
    }

    \context {
        \Score
            \accepts VoiceFollowerGroup
    }
}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Vertical voice follower line, optionally with an arrow.
% Hacks Arpeggio.
% Requires a patch to the brew_chord_bracket C++ for drawing the arrow.
%    Limitations:
%       - only one arpeggio or follower at a time.
%       - need to pack the score into one monolithic StaffGroup.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#(define (arp-positions grob up-chord-span down-chord-span)
    (let* ((pos (ly:arpeggio::calc-positions grob))
           (lower-corr (- 1.75 (- down-chord-span)))
           (upper-corr (+ 1.75 (- up-chord-span)))
           ; (upper (format #t "upper pos ~a~%" (car pos)))
           ; (lower (format #t "lower pos ~a~%" (cdr pos)))
          )
        (cons (+ (car pos) lower-corr) (- (cdr pos) upper-corr))))


verticalFollower = #(define-music-function (dir up-chord-span down-chord-span chord) ((integer? CENTER) (number? 0) (number? 0) ly:music?)
    (let* (
           (is-chord? (eq? (ly:music-property chord 'name) 'EventChord))
           (top-note (if is-chord?
                        (car (extract-named-music chord 'NoteEvent))
                        chord))
           (duration (ly:music-property top-note 'duration))
           (duration-log (ly:duration-log duration))
           (head-offset (if (<= duration-log 0) 1.0 0.8))
           (up-chord-pos (if (eq? dir UP) (1- up-chord-span) up-chord-span))
           (down-chord-pos (if (eq? dir DOWN) (1+ down-chord-span) down-chord-span))
          )
#{
    \once \override VoiceFollowerGroup.Arpeggio.stencil = #ly:arpeggio::brew-chord-bracket
    \once \override VoiceFollowerGroup.Arpeggio.positions = #(lambda (arp) (arp-positions arp up-chord-pos down-chord-pos))
    \once \override VoiceFollowerGroup.Arpeggio.X-offset = #head-offset
    \once \override VoiceFollowerGroup.Arpeggio.protrusion = #0
    \once \override VoiceFollowerGroup.Arpeggio.arpeggio-direction = #dir
    \once \set VoiceFollowerGroup.connectArpeggios = ##t
    #chord
    -\arpeggio
#}
)
)

%{
% chord = <c' g' d'' a''>2         % absolute, in order
% chord = <a'' d'' g' c'>2         % absolute, other order
chord = <c, g' d' a'> 2          % relative, in order
% chord = <a' c,, d' g,>2          % relative, other order

\score {
    \new StaffGroup \with {
    } <<
        \new Staff = up <<
            \relative c'' {
                <>^"arpeggio"
                \verticalFollower #DOWN c1 |
                \verticalFollower #CENTER c1 |
                \verticalFollower #UP c1 |
                % % c4\arpeggio c bes\arpeggio c |
                \verticalFollower #DOWN #0 #4.5 c1 |
                % <c, e g c e>1\arpeggio
                % % a4\arpeggio c c\arpeggio c |
            }
        >>
        \new Staff = middle <<
            \relative c'' {
                c1 |
                c1 |
                % \absolute { \chord \chord-spread \chord | }
                % \transpose c c \relative c'' \chord \my-absolute \relative c'' \chord |
                % \chord \chord-spread \chord \check-mode \chord |
                % \chord \check-mode \chord |
                % \relative c'' \chord \chord-spread \relative c'' \chord |
            }
        >>
        \new Staff = down <<
            \relative c'' {
                \verticalFollower #DOWN c1 |
                \verticalFollower #CENTER c1 |
                \verticalFollower #UP c1 |
                % c4\arpeggio c beses\arpeggio c |
                \verticalFollower #DOWN #0 #4.5 <c, e g c e>1
                % c4\arpeggio c c''\arpeggio c |
            }
        >>
    >>
}
%}


% Hack to stop a multi-note tremolo at the end of a quotation.
%
stopTremolo = #(define-music-function () ()
    (make-music 'TremoloSpanEvent
        'span-direction STOP))

%{
% Usage example:

music = \relative c'' {
    \repeat tremolo 16 { c32 d | } |
    c4
}

\addQuote music         { \music }

\score {
    \new Staff {
        \quoteDuring music { s1 \stopTremolo | }
    }
}
%}


showMMRs = \set Staff.keepAliveInterfaces = #'(
    multi-measure-rest-interface rest-interface

    ;; copy the other interfaces from ly/engraver-init.ly
    bass-figure-interface
    chord-name-interface
    cluster-beacon-interface
    fret-diagram-interface
    lyric-syllable-interface
    note-head-interface
    tab-note-head-interface
    lyric-interface
    percent-repeat-item-interface
    percent-repeat-interface

    ;; need this, as stanza numbers are items, and appear only once.
    stanza-number-interface
)


hideMMRs = \unset Staff.keepAliveInterfaces
