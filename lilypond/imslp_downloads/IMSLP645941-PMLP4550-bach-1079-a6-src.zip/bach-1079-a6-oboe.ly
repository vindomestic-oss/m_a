\version "2.21.0"

\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
    instrument = "Oboe"
}

\paper {
    ragged-last-bottom = ##f
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \context Bottom <<
	{ \vII }
	{
	    <>^\markup{Clar.} \cueDuring vIII #DOWN { s\breve*4 }
	    s1^\markup\upright{(Oboe)}
	}
	\set Staff.midiInstrument = #"oboe"
    >>
}
