\version "2.21.0"

\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
    instrument = "Corno in Fa"
}

\paper {
    ragged-last-bottom = ##f
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \context Bottom <<
	{ \vIV }
	{
	    <>^\markup{Clar.} \cueDuring vIII #DOWN { s\breve*4 }
	    <>^\markup{Oboe} \cueDuring vII #DOWN { \ottava 0 s\breve*4 \ottava 0 }
	    <>^\markup{Cl.B.} \cueDuring vVup #DOWN { s\breve*4 }
	    s1^\markup\upright{(Corno)}
	}
	\set Staff.midiInstrument = #"horn"
    >>
}
