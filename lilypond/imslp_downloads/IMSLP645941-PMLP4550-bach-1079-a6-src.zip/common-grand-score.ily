\version "2.21.0"

% Include this file BEFORE common/common-defs/common-settings.ily to
% ensure the defaults are overridden.
%
% For full scores, override to #0.8.
#(define HairpinOffset (if (defined? 'HairpinOffset) HairpinOffset 0.8))

#(define BarNumberSize (if (defined? 'BarNumberSize) BarNumberSize 3.0))

\include "include-once.ily"
\includeOnce "common.ily"


\layout {
    \context {
	\StaffGroup {
	    \override SystemStartBracket.collapse-height = #4
	}
    }

    \context {
	\GrandStaff {
	    \override SystemStartBrace.collapse-height = #4
	}
    }

    \context {
        % In parts, the MarkLine needs to be attached to its system as tightly
        % as possible. In full scores, at least for MarkLines halfway, the
        % MarkLine should stretch more than the other systems.
        \MarkLine
            \override VerticalAxisGroup.staff-staff-spacing.stretchability = #58
    }
}


\paper {
    system-separator-markup = \markup {
        \center-align
        \vcenter \combine
        \beam #3.5 #0.4 #0.72
        \raise #1.4 \beam #3.5 #0.4 #0.72
    }
    % system-separator-markup = \slashSeparator
}
