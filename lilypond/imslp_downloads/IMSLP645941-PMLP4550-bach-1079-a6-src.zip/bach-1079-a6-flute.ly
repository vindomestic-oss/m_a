\version "2.21.0"

\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
    instrument = "Flauto"
}

\paper {
    ragged-last-bottom = ##f
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \context Bottom <<
	{ \vI }
	{
	    <>^\markup{Clar.} \cueDuring vIII #DOWN { s\breve*4 }
	    <>^\markup{Oboe} \cueDuring vII #DOWN { s\breve*4 }
	    <>^\markup{Cl.B.} \cueDuring vVup #DOWN { s\breve*4 }
	    <>^\markup{Cor.} \cueDuring vIV #DOWN { s\breve*6 }
	    s1^\markup\upright{(Flauto)}
	}
	\set Staff.midiInstrument = #"flute"
    >>
}
