\version "2.21.0"

timeline = {
    \key es \major
    \time 4/2 
    
    s\breve*103 |
    \bar "|."
}


vI = <<
\timeline
\relative c'' {
    \transposition c
    R\breve*18 | % bar 1
    c2 es2 g2 as2 | % bar 19
    b,2 r4 g'4 fis2 f2 | % bar 20
    e2 es2~  es4 d4 des4 c4 | % bar 21
    b4 g4 c4 f4 es2 d2 | % bar 22
    c2. bes8 c8 d4 c8 d8 es4 d4 | % bar 23
    c4 d8 es8 d8 c8 b8 c8 b8 d8 g2 f8 es8 | % bar 24
    d1~  d2 c2~  | % bar 25
    c2 bes2~  bes2 a2 ~ | % bar 26
    a4 g8 fis8 g4 a8 bes8 c1 ~ | % bar 27
    c4 d8 c8 bes4 a4 bes2 c2 ~ | % bar 28
    c4 bes4 g'2~  g2 f4 es4 | % bar 29
    d1~  d4 des4 c2~  | % bar 30
    c2 bes4 as4 g2. a8 bes8 | % bar 31
    c4 bes8 c8 d4 c8 d8 es1 | % bar 32
    f1 es1~  | % bar 33
    es2 d2~  d2 c4 bes4 | % bar 34
    as2 as'2~  as2 g2~  | % bar 35
    g2 f4 es4 d4 c8 d8 es2 ~ | % bar 36
    es4 f8 g8 as2~  as2 g2 | % bar 37
    c1 f,4 bes2 as8 g8 | % bar 38
    f4 g4 as2~  as4 g4 r2 | % bar 39
    R\breve | % bar 40
    r2 bes2~  bes4 % Baerenreiter has aes''4 here; I don't believe it
    a4
    as2 ~ | % bar 41
    as4 g4 ges2 f2. bes4 | % bar 42
    e,2 f2 g2 a2 | % bar 43
    bes1~  bes2 a2 | % bar 44
    bes4 f4 bes2~  bes4 as2 bes8 as8 | % bar 45
    g2 r2 r1 | % bar 46
    r1 r4 g4 c2~  | % bar 47
    c4 bes2 c8 bes8 a4 as2 g4 | % bar 48
    a4 bes8 a8 g2~  g4 a8 g8 fis4 a4 | % bar 49
    d,2. cis8 d8 e2. fis8 g8 | % bar 50
    a4 g8 fis8 g2~  g2 fis2 | % bar 51
    g2 g2 fis2 f2~  | % bar 52
    f4 e8 d8 e8 g8 as4~  as8 g8 f8 e8 f4 g4 | % bar 53
    c,4 f8 es8 des8 c8 bes8 a8 bes8 c8 des2 c4 | % bar 54
    f,4 r4 r2 r1 | % bar 55
    r2 es'2 f2. g4 | % bar 56
    as4 es4 c'2 b2 bes2~  | % bar 57
    bes4 as4. g8 f8 e8 f1 | % bar 58
    r2 r4 as4~  as8 g8 f8 e8 f4 g4 | % bar 59
    c,1~  c4 bes8 c8 bes8 as8 g8 as8 | % bar 60
    g2 r4 g'4~  g4 f2 e4 | % bar 61
    f2 f2 d2 bes2 | % bar 62
    r2 es2 c2 as2 | % bar 63
    R\breve*2 | % bar 64
    es'2 g2 as2 c2 | % bar 66
    d,2 r4 bes'4 a2 as2 | % bar 67
    g2 ges2~  ges4 f4 fes4 es4 | % bar 68
    d4 bes4 es4 as4 g2 f2 | % bar 69
    es4 g4 bes4 es,4 as4 f4 des4 es8 f8 | % bar 70
    ges4 es4 c2 ~ c8 es8 des8 c8 bes2 ~ | % bar 71
    bes4 es8 des8 c4 bes4 a8 g8 a8 bes8 c8 des8 es8 c8 | % bar 72
    des8 es8 des8 c8 bes8 c8 des8 bes8 c2. bes4 | % bar 73
    c8 ges'8 f8 es8 des2~  des8 es8 des8 c8 des8 bes8 f'4 ~ | % bar 74
    f8 es8 d8 c8 bes2 ~ bes2 r8 es8 f8 ges8 | % bar 75
    c,8 es8 des8 c8 bes4 a4 bes2 r2 | % bar 76
    R\breve | % bar 77
    r1 r8 d8 e8 f8 g8 as8 bes8 g8 | % bar 78
    as1~  as4 as4 g2~  | % bar 79
    g2 f4 es4 des1 ~ | % bar 80
    des2 c2 f2 g2 | % bar 81
    as1~  as2 g2 | % bar 82
    as4 r4 r2 r4 g2 f8 es8 | % bar 83
    d2 e2 f8 g8 as8 f8 d8 as'8 g8 f8 | % bar 84
    es2~  es8 d8 c8 b8 c8 bes8 as8 g8 as2 | % bar 85
    g2 r2 r4 c4~  c8 bes8 a8 g8 | % bar 86
    d'2~  d8 c8 bes8 a8 g4 r4 r2 | % bar 87
    R\breve | % bar 88
    r8 es'8 d8 c8 bes8 a8 g8 fis8 g4 g'2 fis4 | % bar 89
    g4 r4 r2 r1 | % bar 90
    R\breve | % bar 91
    r4 f4 d4 g4 c,4 d8 e8 f2~  | % bar 92
    f4 es8 f8 bes,4 c8 d8 es4( f16  es16 d16 es16 f4 g16 f16 es16  f16) | % bar 93
    g4 r4 r2 r1 | % bar 94
    r2 r4 des4~  des4 c8 bes8 a4 f'4~  | % bar 95
    f4 d4 bes4 es4 a,4 b8 c8 d4 des4 ~ | % bar 96
    des4 c2 bes4~  bes4 as8 g8 as4 f'4 | % bar 97
    d4 g4 c,4 d8 e8 f2. es8 d8 | % bar 98
    es4 b4 c4 r4 r4 es4 c4 f4 ~ | % bar 99
    f4 g8 f8 es2~  es4 es4 d2~  | % bar 100
    d4 des4 c2~  c4 c4 b4 c4 | % bar 101
    d4 b4 c2~  c2 b2 | % bar 102
    c\breve | % bar 103
}
>>


vII = <<
\timeline
\relative c'' {
    \transposition c
    R\breve*4 | % bar 1
    g2 bes2 c2 es2 | % bar 5
    fis,2 r4 d'4 cis2 c2 | % bar 6
    b2 bes2~  bes4 a4 as4 g4 | % bar 7
    fis4 d4 g4 c4 bes2 a2 | % bar 8
    g4 as8 g16 f16 g4 c4 bes4 es4 c4 f4~  | % bar 9
    f4 es8 d8 es2~  es4 d4 a4 b4 | % bar 10
    c4 g4 r4 c8 bes8 a8 g8 f4 r4 as4 | % bar 11
    g4. f8 es8 d8 c8 b8 c4 c'4 f,2 ~ | % bar 12
    f4 es4 r4 bes'4 es4 d8 c8 b4 c4 | % bar 13
    d2. e8 f8 e4 fis4 g4 a4 | % bar 14
    d,2. es8 d8 c1~  | % bar 15
    c4 fis,4 g4 a4 bes8 a8 g2 fis4 | % bar 16
    g2 r2 r4 f4 f'2~  | % bar 17
    f4 es2 d8 c8 d2. es8 d8 | % bar 18
    c2 r8 c8 bes8 as8 g4 c2 d4~  | % bar 19
    d4 g8 f8 es8 d8 c8 bes8 a4 b8 c8 d2~  | % bar 20
    d4 c8 b8 c2~  c8 bes8 as2 f4 | % bar 21
    g4 r4 r4 c8 b8 c2. bes8 as8 | % bar 22
    g4 f8 g8 as4 g8 as8 bes1 | % bar 23
    as1 g4. b8 c2~  | % bar 24
    c2 bes2~  bes2. a8 g8 | % bar 25
    a2. g8 fis8 g2. fis8 e8 | % bar 26
    fis4 d4 g2~  g4 a8 g8 fis4 g4 | % bar 27
    a2~  a8 g4 fis8 g2 a2 | % bar 28
    d,2 r2 r2 c'2~  | % bar 29
    c2 bes2~  bes2 as4 g4 | % bar 30
    f1~  f2 es4 f8 g8 | % bar 31
    f2 bes2~  bes4 b4 c2 | % bar 32
    d1~  d2 c2~  | % bar 33
    c2 bes4 as4 g1 ~ | % bar 34
    g4 f4 f'2~  f2 es4 des4 | % bar 35
    c1 bes1 | % bar 36
    c2. d8 es8 f2 es2~  | % bar 37
    es4 f8 g8 f4 es4 d2 es2~  | % bar 38
    es2 d2 es2 r2 | % bar 39
    r1 r2 es2~  | % bar 40
    es4 d4 des2~  des4 c4 ces2 | % bar 41
    bes2. es4~  es4 d8 c8 bes2 | % bar 42
    c2. bes8 c8 des2 c4 des8 es8 | % bar 43
    f2. es8 f8 ges2 f2~  | % bar 44
    f2. es8 d8 c2 r2 | % bar 45
    c2 es2 g4 d4 g2 ~ | % bar 46
    g4 f2 g8 f8 es4 es2 f8 es8 | % bar 47
    d4 g4. f8 es8 d8 c4 f4 bes,4 c4 ~ | % bar 48
    c4 d8 c8 bes4 g4 e'2 r4 a,4~  | % bar 49
    a4 g8 fis8 g4 r4 r1 | % bar 50
    r4 a4 bes4 g8 a8 bes8 c8 d2.~  | % bar 51
    d4 g,4 es'2~  es8 d8 c8 b8 c4 d4 | % bar 52
    g,4. bes8 as8 g8 f8 e8 f8 g8 as2 g4 | % bar 53
    f4 r4 r2 r1 | % bar 54
    r2 r4 bes4 c2. d4 | % bar 55
    es4 bes4 es2 d2 des2 ~  | % bar 56
    des4 c8 des8 es8 g8 as4~  as8 g8 f8 e8 f4 g4 | % bar 57
    c,2 r2 r4 c2 bes8 as8 | % bar 58
    g8 as8 bes4~  bes8 g'8 f8 e8 f8 g8 as2 g4~  | % bar 59
    g4 f4. es8 des8 c8 des1 | % bar 60
    c1 ~ c4 des2 c4~  | % bar 61
    c4 c4 as4 f4 as2 r2 | % bar 62
    r4 bes4 g4 es4 ges2 es2~  | % bar 63
    es2 r4 c'4~  c8 f,8 g8 a8 bes8 c8 des8 bes8 | % bar 64
    es1 ~ es8 as,8 bes8 c8 des8 es8 f8 des8 | % bar 65
    bes4. c8 des8 c8 bes4 as4 es'8 des8 es4 as4 ~ | % bar 66
    as8 c8 bes8 as8 g8 f8 es8 d8 c8 ges'8 f8 es8 d8 c8 bes8 c8 | % bar 67
    des8 fes8 es8 des8 c8 bes8 as8 bes8 ces8 des8 ces8 bes8 as8 ges8 f8 ges8 | % bar 68
    as8 ces8 bes8 as8 g8 f8 es8 d8 es4 es'2 d8 c8 | % bar 69
    des2. c8 bes8 ces2. bes8 a8 | % bar 70
    bes2. a4 f'2. as,4 | % bar 71
    ges2. es'4~  es4 c4 f,2~  | % bar 72
    f4 f'2 e4 es4 d4 des2 | % bar 73
    c2~  c8 c8 bes8 a8 bes2 r4 r8 c8 | % bar 74
    f,2 ~ f8 e4 f8 g8 f8 e8 f8 ges2 | % bar 75
    f2 ~ f8 f8 es8 f8 ges8 as8 ges8 f8 es8 f8 ges8 es8 | % bar 76
    f4 r4 r2 r8 c8 des8 es8 f8 as8 g8 f8 | % bar 77
    c'1 r1 | % bar 78
    r8 c8 d8 e8 f2~  f2 es4 des4 | % bar 79
    c1 ~ c4 c4 bes2 ~ | % bar 80
    bes2 as2 des1 | % bar 81
    es2. d4 es1 ~ | % bar 82
    es4 es2 des8 c8 bes4 r4 r2 | % bar 83
    R\breve*2 | % bar 84
    g2 b2 c2 es2 | % bar 86
    fis,2 r4 d'4 cis2 c2 | % bar 87
    b2 bes2~  bes4 a4 as4 g4 | % bar 88
    fis4 d4 g4 c4 bes2 a2 | % bar 89
    g4 d'4 bes4 es4 a,4 b8 c8 d2 | % bar 90
    g,4 a8 b8 c2 b2 bes2 | % bar 91
    a2 as4 g4 g2 f4 g8 a8 | % bar 92
    bes2 f2 c'2 r4 bes4 ~ | % bar 93
    bes4 as8 bes8 c4 des8 c8 bes2. f4 | % bar 94
    e4 c'2 bes8 as8 g4 c4 f,4 g8 a8 | % bar 95
    bes2 r2 r4 d,2 g8 as8 | % bar 96
    bes4 as2 g4 ~ g4 c2 d8 c8 | % bar 97
    b4 c4 r4 as8 bes8 c2~  c8 d8 c8 b8 | % bar 98
    c4 f,4 g4 r4 r2 r4 as4 | % bar 99
    g4 d'2 c8 b8 c2. f4 | % bar 100
    g4 bes,2 bes4 a4 as2 as4 | % bar 101
    g2. as4 g2 g2 | % bar 102
    g\breve | % bar 103
}
>>


vIII = <<
\timeline
\relative c' {
    \transposition c
    c2 es2 g2 as2 | % bar 1
    b,2 r4 g'4 fis2 f2 | % bar 2
    e2 es2~  es4 d4 des4 c4 | % bar 3
    b4 g4 c4 f4 es2 d2 | % bar 4
    c4 es8(  d16 c16)  d4 g4 es4 as4 g4 c4 ~ | % bar 5
    c4 bes8 a8 bes2~  bes4 a4 e4 fis4 | % bar 6
    g4 d4 r4 g8 f8 es8 d8 c4 r4 es4 | % bar 7
    d4. c8 bes4 a4 g4 g'4 c,4 d4 | % bar 8
    es2 r4 es4 d4 g4 es4 as4 | % bar 9
    g4 g,4 c4 bes4 a2 d2 | % bar 10
    g,4 g'8 as8 g8 f8 es8 d8 c4 d8 e8 f2~  | % bar 11
    f4 b,4 c4 as4 g2 a4 b4 | % bar 12
    c4 c'4 f,8 es8 d4 g4 fis4 g2 | % bar 13
    a4 g8 fis8 g2~  g4 a4 bes4 a4 ~ | % bar 14
    a4 g8 fis8 g2~  g4 a8 g8 fis4 g4 | % bar 15
    a2 d,4 e8 fis8 g8 f8 es8 d8 es4 d8 c8 | % bar 16
    bes4 g4 g'2~  g4 f8 g8 as2 | % bar 17
    g2. f8 es8 f2. g8 f8 | % bar 18
    es4 f8(  es16  d16) c4 r4 r4 g'2 f8 es8 | % bar 19
    d4 b4 g'4 r4 r2 r4 g4~  | % bar 20
    g4 g2 f8 g8 as8 g8 f2 as4 | % bar 21
    d,4 c8 b8 c2 g'4. fis8 g2 | % bar 22
    c,1 bes2 r2 | % bar 23
    r2 f'4. es8 d2 g2~  | % bar 24
    g4 d4 g4 f4 es2 r2 | % bar 25
    R\breve | % bar 26
    r4 d2 c8 d8 es1 | % bar 27
    d2. c4 d4 c8 d8 es4 d8 c8 | % bar 28
    g'2 bes2~  bes2 a2~  | % bar 29
    a2 g4 f4 es1~  | % bar 30
    es2 d2~  d2 c2 ~ | % bar 31
    c2 f2 g4. f8 es4 f8 g8 | % bar 32
    as2 g2~  g2. as8 g8 | % bar 33
    f1~  f2 es2~  | % bar 34
    es2 d2 bes'1~  | % bar 35
    bes2 as4 g4 f2 g4 f8 g8 | % bar 36
    as1 r4 bes2 c8 des8 | % bar 37
    c1 bes1~  | % bar 38
    bes1~  bes2 r2 | % bar 39
    f2. bes4 es,2. as4 | % bar 40
    g4 f8 es8 f4 g4 es4 f8 ges8 f4 es4 | % bar 41
    d2 es2 f2. e8 f8 | % bar 42
    g4 f8 g8 as2 bes2 r2 | % bar 43
    r4 bes2 c8 des8 es2. d8 c8 | % bar 44
    d2 r2 r1 | % bar 45
    r4 g,4 c2~  c4 bes2 c8 bes8 | % bar 46
    as4. g8 as4 bes8 as8 g4 r4 r2 | % bar 47
    R\breve*2 | % bar 48
    r4 d4 g2 g4 a8 bes8 c4 d8 es8 | % bar 50
    d2. es4 d4 g,4 a8 bes8 c4~  | % bar 51
    c4 bes4 r2 r1 | % bar 52
    r2 r4 c,4 d2. e4 | % bar 53
    f4 c4 f2 e2 es2 ~ | % bar 54
    es4 d8 c8 d8 f8 ges4~  ges8 f8 es8 d8 es4 f4 | % bar 55
    bes,4 es'8 des8 ces8 bes8 as8 g8 as8 bes8 ces2 bes4 | % bar 56
    as4 r4 r2 r1 | % bar 57
    f2 as2 c2 des2 | % bar 58
    e,2 r4 c'4 b2 bes2 | % bar 59
    a2 as2~  as4 g4 ges4 f4 | % bar 60
    e4 c4 f4 bes4 as2 g2 | % bar 61
    f2 r2 r4 f4 d4 bes4 | % bar 62
    des2 r2 r4 es4 c4 as4 | % bar 63
    c2 r2 r1 | % bar 64
    r8 es8 f8 g8 as8 bes8 c8 as8 f1 | % bar 65
    es4 g4 bes4 des4 es4 as,4 r2 | % bar 66
    R\breve*10 | % bar 67
    r8 c8 bes8 as8 g8 as8 bes8 g8 as2 r2 | % bar 77
    r8 c8 bes8 as8 g8 f8 e8 g8 c,4 r4 r2 | % bar 78
    r2 r8 es'8 des8 c8 bes1~  | % bar 79
    bes4 bes4 as2~  as2 g4 f4 | % bar 80
    es2. f8 ges8 f4 g8 as8 bes2 | % bar 81
    c4 bes4 as4. bes8 ces4 des2 c8 bes8 | % bar 82
    c4 c2 bes8 as8 g4 bes2 as8 g8 | % bar 83
    f2 g2 c,4 c'4 b2 | % bar 84
    c8 bes8 as8 g8 f4 as4 g2~  g8 g8 f8 es8 | % bar 85
    d8 c8 b8 a8 g4 d'4 c4 es4 g4 r4 | % bar 86
    r4 d4 g2~  g8 bes8 a8 g8 a2~  | % bar 87
    a4 g8 fis8 g4. f8 es8 d8 es4 c4 r4 | % bar 88
    r1 r4 d'4 es4 d8 c8 | % bar 89
    bes4 r4 g2 fis2 f2 | % bar 90
    e2 r4 es4 d4 g4 c,4 d8 e8 | % bar 91
    f4 c4 d8 c8 d4 g,2 a4 f4 | % bar 92
    f'2 r2 r4 a4 f4 bes4 | % bar 93
    es,4 f8 g8 as2~  as4 g8 f8 g2~  | % bar 94
    g4 f8 e8 f4 r4 r1 | % bar 95
    r4 f4 d4 g4 c,4 d8 es8 f4 e8 f8 | % bar 96
    g4 c,4 f2 e4 f8 g8 f2 | % bar 97
    g2. f8 g8 as2. g8 f8 | % bar 98
    g4 d4 c4 r4 r1 | % bar 99
    R\breve | % bar 100
    r2 r4 es4 c4 f2 es4 | % bar 101
    d2 es4 f4 es2 d2 | % bar 102
    c\breve | % bar 103
}
>>


vIV = <<
\timeline
\relative c' {
    \transposition c
    R\breve*12 | % bar 1
    g2 bes2 c2 es2 | % bar 13
    fis,2 r4 d'4 cis2 c2 | % bar 14
    b2 bes2~  bes4 a4 as4 g4 | % bar 15
    fis4 d4 g4 c4 bes2 a2 | % bar 16
    g4 c2 bes4 a4 d2 c4 | % bar 17
    b4 c8 d8(  c2  c4) b8 a8 b2 | % bar 18
    c4 d8(  c16  b16) c2~  c4 es4 c4 f4~  | % bar 19
    f4 es8 d8 es2~  es4 d4 a4 b4 | % bar 20
    c4 g4 c2~  c4 d8 es8 f4 as,4 | % bar 21
    g2. f4 g4 c4 d4 e8 f8 | % bar 22
    e4 d8 e8 f2~  f4 es8 f8 g4. f8 | % bar 23
    es8 c8 b8 c8 d2 g,1 ~ | % bar 24
    g1 ~ g4 a8 bes8 c4 es4 | % bar 25
    d1 e4 es2 d8 c8 | % bar 26
    d4 b4 g2~  g4 fis4 r2 | % bar 27
    r2 r4 a4~  a4 g2 fis4 | % bar 28
    g4 d4 es2~  es4 e4 f2~  | % bar 29
    f4 fis4 g2~  g4 g4 as2~  | % bar 30
    as4 a4 bes2~  bes4 b4 c4 bes4 | % bar 31
    a2 bes4 as4 g2 as4 g4 | % bar 32
    f4 es8 f8 g2~  g4 g4 as2~  | % bar 33
    as4 a4 bes2 bes4 b4 c2~  | % bar 34
    c4 c4 d2~  d4 d4 es2~  | % bar 35
    es4 es4 f2~  f2 es4 d4 | % bar 36
    c1 bes1 | % bar 37
    as1 ~ as2 g4 as4 | % bar 38
    bes1 r2 es2~  | % bar 39
    es4 d4 des2~  des4 c4 ces2 | % bar 40
    bes2. es4 as,2. f4 | % bar 41
    bes1~  bes4 c4 des2 | % bar 42
    c2. des8 c8 bes2 c2 | % bar 43
    bes1 c1 | % bar 44
    bes2 r2 r4 c4 f2~  | % bar 45
    f4 es2 d8 c8 d2. es8 des8 | % bar 46
    c4. b8 c4 d4 es4 r4 r2 | % bar 47
    bes2 d2 es4 r4 r4 g,4 | % bar 48
    d'4 a4 bes2~  bes2 a4 g8 fis8 | % bar 49
    g2~  g8 fis8 g8 bes8 e,2 r2 | % bar 50
    r4 a4 d,4 g4~  g8 a8 bes8 g8 d'2 | % bar 51
    r2 r4 g,4 a2. b4 | % bar 52
    c4 g4 c2 b2 bes2~  | % bar 53
    bes4 a8 g8 a8 c8 des4~  des8 c8 bes8 a8 bes4 c4 ~ | % bar 54
    c4 bes8 as8 ges8 f8 es8 d8 es8 f8 ges2 f4 | % bar 55
    es1~  es2. bes4 | % bar 56
    c4 as4 as'4 r4 r2 r4 c4~  | % bar 57
    c8 bes8 c8 des8 c8 bes8 as8 g8 as2. g8 f8 | % bar 58
    c'2. f,8 g8 as4 r4 r4 r8 g8 | % bar 59
    a8 bes8 c2 f4~  f4 bes,4 r2 | % bar 60
    r4 g'4 as4 g4 c,4. bes16 as16 bes2~  | % bar 61
    bes4 as4 r2 r1 | % bar 62
    R\breve | % bar 63
    r8 g8 a8 bes8 c8 des8 es8 c8 des1~  | % bar 64
    des4 c8 bes8 as4 r4 r1 | % bar 65
    R\breve*7 | % bar 66
    bes2 des2 f2 ges2 | % bar 73
    a,2 r4 f'4 e2 es2 | % bar 74
    d2 des2~  des4 c4 ces4 bes4 | % bar 75
    a4 f4 bes4 es4 des2 c2 | % bar 76
    bes2 c2~  c2. bes4 | % bar 77
    as4 g8 f8 g2~  g4 f2 e4 | % bar 78
    f4 c4 des2~  des8 d8 c8 d8 es2~  | % bar 79
    es8 e8 d8 e8 f2~  f8 f8 e8 f8 g2 ~ | % bar 80
    g8 g8 f8 g8 as2 ~ as2 g4 as8 bes8 | % bar 81
    es,2 as,2 es'1~  | % bar 82
    es2 r2 es2 g2 | % bar 83
    bes8 c8 d8 bes8 g8 des'8 c8 bes8 c4 f2 es8 d8 | % bar 84
    c4. bes8 as4 f'4 c2~  c8 es8 d8 c8 | % bar 85
    b8 c8 d8 es8 f8 g8 as8 f8 g4 r4 r2 | % bar 86
    r1 r2 r8 g8 fis8 e8 | % bar 87
    d8 c8 b8 a8 g4 bes4 c2~  c8 fis,8 g8 a8 | % bar 88
    bes4 a4 g4 a4 bes4 r4 r4 d4 | % bar 89
    d4 r4 r4 bes4 c4 d8 es8 d8 c8 d4~  | % bar 90
    d4 c4 r2 r2 r4 g4 | % bar 91
    a2 b2 c2. bes8 c8 | % bar 92
    f,4 g8 a8 bes2 a2 as2 | % bar 93
    g4 r4 r2 r1 | % bar 94
    r4 c4 as4 des4 g,4 as8 bes8 c2 | % bar 95
    bes2. c8 d8 es4 d4 r4 bes4 ~ | % bar 96
    bes4 f'4 r4 des4 c2 r4 d4~  | % bar 97
    d4 c8 b8 c2~  c2 r2 | % bar 98
    r2 r4 es4 d4 g2 f4 | % bar 99
    g4 r4 r2 r4 c,4 d4 a4 | % bar 100
    b4 g2 c4 f,4 as2 es4 | % bar 101
    g4 f4 es4 d4 es8 f8 g2. | % bar 102
    g\breve | % bar 103
}
>>


vV = <<
\timeline
\relative c {
    \transposition c
    R\breve*8 | % bar 1
    c2 es2 g2 as2 | % bar 9
    b,2 r4 g'4 fis2 f2 | % bar 10
    e2 es2~  es4 d4 des4 c4 | % bar 11
    b4 g4 c4 f4 es2 d2 | % bar 12
    c4 es8(  d16  c16) d4 g4 es4 as4 g4 c4~  | % bar 13
    c4 bes8 a8 bes2~  bes4 a4 e4 fis4 | % bar 14
    g4 d4 r4 g8 f8 es8 d8 c4 r4 es4 | % bar 15
    d4. c8 bes4 a4 g4 g'4 c,4 d4 | % bar 16
    es2 e2 f2. es8 d8 | % bar 17
    g\breve | % bar 18
    as2. g8 f8 es2 f2 | % bar 19
    g2 c4 a4 d4 d,2 g4 | % bar 20
    c4 c,2 d8 es8 f1~  | % bar 21
    f4 es8 d8 es4 as4 g4 bes8 a8 bes2 ~ | % bar 22
    bes2 as2~  as2 g2~  | % bar 23
    g2 f2~  f2 es4 d8 c8 | % bar 24
    d1 es2 g2 | % bar 25
    d4 e8 fis8 g2~  g4 fis8 g8 a2 | % bar 26
    d,2. es8 d8 c2 r2 | % bar 27
    r4 d2 es4 d4 es8 d8 c2 | % bar 28
    d2 r4 bes4 c1 | % bar 29
    d1 es1 | % bar 30
    f1 g2. c,4 | % bar 31
    f1 es1 | % bar 32
    d2. c8 d8 es2. d8 es8 | % bar 33
    f2. es8 f8 g2. f8 g8 | % bar 34
    as2. g8 as8 bes2. as8 bes8 | % bar 35
    c2 f,2 bes1 | % bar 36
    as2. g4 f4 es8 f8 g2~  | % bar 37
    g4 c,4 f2~  f2 es2 | % bar 38
    f1 es2 r2 | % bar 39
    R\breve*2 | % bar 40
    r1 r2 bes'2~  | % bar 42
    bes4 a4 as2 g2 ges2 | % bar 43
    f1 es4 d8 es8 f2 ~ | % bar 44
    f2 r2 f2 as2 | % bar 45
    c4.   bes8[ as8 g8] as4 g4. f8 es2 | % bar 46
    f8 g8 as2 f4 g2 r2 | % bar 47
    g2 bes2 c2 es2 | % bar 48
    fis,2 r4 d'4 cis2 c2 | % bar 49
    b2 bes2~  bes4 a4 as4 g4 | % bar 50
    fis4 d4 g4 c4 bes2 a2 | % bar 51
    g2 r2 r1 | % bar 52
    R\breve | % bar 53
    r2 f2 g2. a4 | % bar 54
    bes4 f4 bes2 a2 as2 ~ | % bar 55
    as4 g8 f8 g8 bes8 ces4~  ces8 bes8 as8 g8 as4 bes4 | % bar 56
    es,4 as8 bes8 as8 g8 f8 e8 f8 g8 as2 g4 | % bar 57
    f2 r2 r1 | % bar 58
    r4 bes8 as8 g4 as8 g8 f8 e8 f2 c'4~  | % bar 59
    c8 des8 c8 bes8 c4 as4 bes8 c8 des8 es8 des4 bes4 | % bar 60
    c1~  c4 f,4 g4 c4~  | % bar 61
    c4 r4 r2 r8 c,8 d8 es8 f8 g8 as8 f8 | % bar 62
    g4 r4 r2 r8 bes,8 c8 des8 es8 f8 ges8 es8 | % bar 63
    f1 ~ f2 g2~  | % bar 64
    g4 es2 as4 ~ as8 f8 g8 as8 bes8 c8 des8 bes8 | % bar 65
    g4 es4 r2 r1 | % bar 66
    R\breve*5 | % bar 67
    r1 f2 a2 | % bar 72
    bes4 as4 g2 a8 f8 g8 a8 bes8 c8 des8 bes8 | % bar 73
    f'4 c4 f8 es8 des8 c8 bes8 c8 bes8 a8 bes4 c4 | % bar 74
    c4 f,4 bes4 as4 g2 r4 bes4 | % bar 75
    c4 r4 r2 r4 bes2 as4~  | % bar 76
    as4 g8 f8 g2~  g2 f2 ~ | % bar 77
    f2 e4 r4 r1 | % bar 78
    r2 r4 as,4 bes2 ~ bes8 bes8 as8 bes8 | % bar 79
    c2~  c8 c8 bes8 c8 des2~  des8 des8 c8 des8 | % bar 80
    es1 des1 | % bar 81
    c2 ces2~  ces4 bes8 as8 bes2 | % bar 82
    as2 c2 es2 r2 | % bar 83
    r4 bes'2 as8 g8 as4 f4 g2 | % bar 84
    as8 g8 f2 es8 d8 es4 e4 f4 f'4~  | % bar 85
    f8 es8 d8 c8 d4 r4 r4 g,2 a8 bes8 | % bar 86
    a2 d,4 r4 r1 | % bar 87
    r2 r8 f8 es8 d8 c4. d8 es2 | % bar 88
    d4 fis4 g4 r4 r2 r4 a4 | % bar 89
    bes4 r4 r4 g4 a2 b2 | % bar 90
    c4 c,8 d8 es8 c8 as'4~  as4 g8 f8 e4 c4 | % bar 91
    f4 r4 f2 e2 es2 | % bar 92
    d4 c4 d4 bes4 c4 d8 es8 d8 c8 d4 | % bar 93
    es2. as4 f4 bes4 es,4 f8 g8 | % bar 94
    as4 g4 f4 as4 bes4 c8 des8 c4 a4 | % bar 95
    f4 g8 a8 bes4 a8 bes8 c4 a4 as4 bes8 as8 | % bar 96
    g4 as4 f4 bes4 g2 r4 as4 | % bar 97
    g2 r2 r1 | % bar 98
    r4 as4 g4 c4~  c4 b4 c2 | % bar 99
    r4 b4 c4 g4 a2. d4 | % bar 100
    g,4 bes4 c4 g4 a4 f2 as4 | % bar 101
    d,2 c2~  c2 d8 e8 f4 | % bar 102
    e\breve | % bar 103
}
>>


vVI = <<
\timeline
\relative c {
    \transposition c
    R\breve*24 | % bar 1
    g2 bes2 c2 es2 | % bar 25
    fis,2 r4 d'4 cis2 c2 | % bar 26
    b2 bes2~  bes4 a4 as4 g4 | % bar 27
    fis4 d4 g4 c4 bes2 a2 | % bar 28
    g1 a1 | % bar 29
    bes1 c1 | % bar 30
    d1 es1 ~ | % bar 31
    es2 d2~  d2 c2~  | % bar 32
    c2 b2 c1 | % bar 33
    d1 es1 | % bar 34
    f1 g1 | % bar 35
    as1~  as2 g2 ~ | % bar 36
    g2 f4 es4 d2 es2 | % bar 37
    as,1 bes1~  | % bar 38
    bes1 es,2 r2 | % bar 39
    R\breve*3 | % bar 40
    r2 f'2~  f4 e4 es2~  | % bar 43
    es4 d4 des2 c2 f2 | % bar 44
    bes,2 d2 f2 r2 | % bar 45
    R\breve | % bar 46
    r1 c2 es2 | % bar 47
    g1 g4 f4 es2 | % bar 48
    d\breve~  | % bar 49
    d2. e8 d8 cis2 c2 ~ | % bar 50
    c2 bes4 c4 d1 | % bar 51
    g,2 r2 r1 | % bar 52
    R\breve*4 | % bar 53
    r2 c2 d2. e4 | % bar 57
    f1~  f8 es8 des8 c8 bes4 bes'4 ~ | % bar 58
    bes8 as8 g8 f8 e4 f4 d2. e4 | % bar 59
    f4. g8 as4 f4 bes1~  | % bar 60
    bes8 g8 c8 bes8 as8 g8 f8 e8 f8 es8 des8 c8 bes4 c4 | % bar 61
    f8 g8 as8 g8 f8 es8 d8 c8 bes1 | % bar 62
    r8 as'8 g8 f8 es8 des8 c8 bes8 as1 | % bar 63
    a4 c4 a4 f4 bes4 des4 bes4 g4 | % bar 64
    c4 es4 c4 as4 des1 ~ | % bar 65
    des8 es8 des8 c8 bes8 as8 g8 bes8 c8 des8 c8 bes8 as8 g8 f8 as8 | % bar 66
    bes,8 bes'8 c8 d8 es8 f8 g4~  g8 c,8 d8 es8 f8 es8 d8 f8 | % bar 67
    bes,4 c8 des8 es8 des8 c8 es8 as,4 as'8 g8 as4 ces4 | % bar 68
    bes1~  bes8 es,8 f8 g8 as8 c8 bes8 as8 | % bar 69
    g8 f8 es8 f8 g8 bes8 as8 ges8 f8 es8 des8 es8 f8 as8 ges8 f8 | % bar 70
    es8 des8 c8 des8 es8 ges8 f8 es8 des8 c8 bes8 c8 des8 es8 f8 d8 | % bar 71
    es8 des8 c8 des8 es8 f8 ges8 es8 f1~  | % bar 72
    f\breve~  | % bar 73
    f2 r4 f4 g2. a4 | % bar 74
    bes4 as4 g4 f4 e2 es2~  | % bar 75
    es4 f8 es8 des4 c4 bes2 c2 | % bar 76
    d4 es2 e4 f4 es4 des2 | % bar 77
    c2. bes4 as2 g2 | % bar 78
    f1 g1 | % bar 79
    as1 bes1 | % bar 80
    c1~  c2 bes2 | % bar 81
    as4 g4 f2 es1 | % bar 82
    as2 r2 r1 | % bar 83
    R\breve*2 | % bar 84
    r4 g'4~  g8 f8 es8 d8 es8 d8 c8 b8 c2 ~ | % bar 86
    c8 es8 d8 c8 bes8 a8 g8 f8 e4 e'4 fis4 d4 | % bar 87
    g2 g,2 a8 bes8 c2 bes8 c8 | % bar 88
    d2 es2~  es8 d8 c8 bes8 c4 d4 | % bar 89
    g4 r4 r2 r1 | % bar 90
    R\breve*3 | % bar 91
    r2 es2 d2 des2 | % bar 94
    c2 f2 e2 es2 | % bar 95
    d2 g2 fis2 f2 | % bar 96
    e4 f4 d4 g4 c,4 d8 e8 f2 ~ | % bar 97
    f4 es4 as2~  as4 g8 f8 c'2 | % bar 98
    c,2 es2 g2 as2 | % bar 99
    b,2 r4 g'4 fis2 f2 | % bar 100
    e2 es2~  es4 d4 des4 c4 | % bar 101
    b4 g4 c4 f,4 g2 g2 | % bar 102
    c\breve | % bar 103
}
>>


\addQuote vI    { \vI }
\addQuote vII   { \vII }
\addQuote vIII  { \vIII }
\addQuote vIV   { \vIV }
\addQuote vV    { \vV }
\addQuote vVup  { \transpose c c' \vV }
\addQuote vVI   { \vVI }
