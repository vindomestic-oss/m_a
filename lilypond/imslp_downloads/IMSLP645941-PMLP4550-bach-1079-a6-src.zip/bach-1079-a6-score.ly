\version "2.21.0"

\include "common.ily"
\include "common-grand-score.ily"
\include "last-page-copyright.ily"

#(set-global-staff-size 15)

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\markup{}
\pageBreak

% 

\header {
    subtitle = "For 6 instruments"
}

\paper {
    % \context {
	% \Staff \override VerticalAxisGroup.minimum-Y-extent = #'(-0 .  0)
    % }
    ragged-last-bottom = ##f
}

\score {
    \new StaffGroup <<
        \new Staff = staffI {
	    \clef treble
	    \vI
        }
        \new Staff = stafII {
	    \clef soprano
	    \vII
        }
        \new Staff = stafIII {
	    \clef alto
	    \vIII
        }
        \new Staff = staffIV {
	    \clef tenor
	    \vIV
        }
        \new Staff = staffV {
	    \clef tenor
	    \vV
        }
        \new Staff = staffVI {
	    \clef bass
	    \vVI
        }
    >>

}
