\version "2.21.0"

\header {
    title = "Ricercar a 6"
    subtitle = "aus dem Musikalischen Opfer"
    composer = "J.S. Bach"
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2020 Creative Commons Attribution ShareAlike 4.0}}
}

\layout {
}


