# Intended to be copied into the current directory by inserting at the end
# of your Makefile:
# #-------------- insert common makefile
# include lilypond.mk
#
# lilypond.mk: $(ROOT)/lilypond.mk
#	cp $^ $@
# #-------------- end of insert
#
# Common stuff for compiling a score and parts
# Include this file from the Makefile.
# The Makefile must define:
#	ROOT	a relative path from the working dir to this dir
#	WORK	a file base for score and part files
#	NOTES	a list of .ly files that contain the notes
#	INSTR	a list of instrument names for the part files (WORK is prepended)

.SUFFIXES:
.SUFFIXES:	.ly .pdf .midi .zip .flac

LILYROOT	?= /usr/share/lilypond/lilypond-2.21-git
LILYPOND	:= $(LILYROOT)/bin/lilypond
LILYFLAGS	:=


.PHONY: all
all:	score parts

NOTES	+= include-once.ily
NOTES	+= common.ily
NOTES	+= common-defs.ily
NOTES	+= common-settings.ily
NOTES	+= common-grand-score.ily
NOTES	+= last-page-copyright.ily
NOTES	+= polyrhythm.ily
NOTES	+= polyrhythm-settings.ily
NOTES   += text-spanner-inner-texts.ily

PARTS	:= $(INSTR:%=$(WORK)-%.ly)

ifneq (, $(wildcard $(WORK)-score.ly))
SCORE		+= $(WORK)-score.ly
endif
SCORE_PDF	:=
SCORE_PDF	+= $(SCORE:%.ly=%.pdf)
PARTS_PDF	:= $(PARTS:%.ly=%.pdf)

ifneq (, $(POST_FILTER))
	POST_FILTER_CMD = 2>&1 | $(POST_FILTER)
endif


DUPLEX_LY	:= $(DUPLEX:%=$(WORK)-%-duplex.ly)
DUPLEX_PDF	:= $(DUPLEX_LY:%.ly=%.pdf)

$(WORK)-%-duplex.ly: $(WORK)-%.ly
	sed 's/^%[{}] % \(BEGIN\|END\) OF DUPLEX-ONLY SECTION$$/% &/' $(WORK)-$*.ly > $@

$(WORK)-%-duplex.pdf: $(WORK)-%-duplex.ly
	sed 's/^%[{}] % \(BEGIN\|END\) OF DUPLEX-ONLY SECTION$$/% &/' $(WORK)-$*.ly > $@
	$(LILYPOND) $(LILYFLAGS) $(WORK)-$*-duplex.ly $(POST_FILTER_CMD)
	@echo $(subst $\",,$(DUPLEX_PAGES-$*))
	pdftk $@ cat $(subst $\",,$(DUPLEX_PAGES-$*)) output junk-$@
	mv junk-$@ $@

.PHONY:	score
score:	$(SCORE_PDF)

.PHONY:	parts
parts:	$(PARTS_PDF) $(DUPLEX_PDF)

%.pdf:	%.ly common.ily
	$(LILYPOND) $(LILYFLAGS) ${PWD}/$*.ly $(POST_FILTER_CMD)

$(WORK)-*.pdf	: $(NOTES)

# include files that will always be needed
ifeq ($(wildcard $(ROOT)/common.ily), $(ROOT)/common.ily)
common.ily: $(ROOT)/common.ily
	cp $< $@

common.ily: include-once.ily
include-once.ily: $(ROOT)/include-once.ily
	cp $< $@

common.ily: common-defs.ily
common-defs.ily: $(ROOT)/common-defs.ily
	cp $< $@

common.ily: common-settings.ily
common-settings.ily: $(ROOT)/common-settings.ily
	cp $< $@

common.ily: common-grand-score.ily
common-grand-score.ily: $(ROOT)/common-grand-score.ily
	cp $< $@

common.ily: text-spanner-inner-texts.ily
text-spanner-inner-texts.ily: $(ROOT)/text-spanner-inner-texts.ily
	cp $< $@

common.ily: staff-bracket.ily
staff-bracket.ily: $(ROOT)/staff-bracket.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/last-page-copyright.ily), $(ROOT)/last-page-copyright.ily)
last-page-copyright.ily: $(ROOT)/last-page-copyright.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/paged-title.ily), $(ROOT)/paged-title.ily)
paged-title.ily: $(ROOT)/paged-title.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/bach-paged-title.ily), $(ROOT)/bach-paged-title.ily)
bach-paged-title.ily: $(ROOT)/bach-paged-title.ily
	cp $< $@

bach-paged-title.ily: bach-monogram.eps

bach-monogram.eps: $(ROOT)/bach-monogram.eps
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/baroque-clefs.ily), $(ROOT)/baroque-clefs.ily)
baroque-clefs.ily: $(ROOT)/baroque-clefs.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/common-defs-wien.ily), $(ROOT)/common-defs-wien.ily)
common-defs-wien.ily: $(ROOT)/common-defs-wien.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/common-defs-french.ily), $(ROOT)/common-defs-french.ily)
common-defs-french.ily: $(ROOT)/common-defs-french.ily
	cp $< $@
endif

ifeq ($(wildcard $(ROOT)/polyrhythm.ily), $(ROOT)/polyrhythm.ily)
polyrhythm.ily: $(ROOT)/polyrhythm.ily
	cp $< $@
endif
ifeq ($(wildcard $(ROOT)/polyrhythm-settings.ily), $(ROOT)/polyrhythm-settings.ily)
polyrhythm-settings.ily: $(ROOT)/polyrhythm-settings.ily
	cp $< $@
endif

.PHONY: convert
convert:
	$(LILYROOT)/bin/convert-ly -e $(wildcard *.ly) $(wildcard *.ily)
	for f in $(wildcard *.ly) $(wildcard *.ily); do sed -i 's/partcombine/partCombine/g;s/fermataMarkup/fermata/g' $$f; done

ZIP_PDF	:= $(WORK)-pdf.zip
ZIP_SRC	:= $(WORK)-src.zip

$(WORK)-pdf.zip:	$(SCORE_PDF) $(PARTS_PDF)
	zip $@ $(SCORE_PDF) $(PARTS_PDF)

SRC	+= $(SCORE)
SRC	+= $(PARTS)
SRC	+= $(NOTES)
SRC	+= $(SCORE_NOTES)
SRC	+= Makefile
SRC	+= lilypond.mk

$(WORK)-src.zip:	$(SCORE) $(PARTS) $(NOTES) Makefile
	zip $@ $(SRC)

.PHONY:	zip
zip:	$(ZIP_SRC) $(ZIP_PDF)

DEPLOY_HOST	:= fluit.few.vu.nl
DEPLOY_DIR	:= www/sheet-music/$(WORK)

DEPLOY_FILES	:=
DEPLOY_FILES	+= $(PARTS_PDF)
DEPLOY_FILES	+= $(SCORE_PDF)
DEPLOY_FILES	+= $(ZIP_SRC)
DEPLOY_FILES	+= $(ZIP_PDF)

.PHONY: deploy
deploy:
	-rm $(DEPLOY_FILES)
	$(MAKE) $(MFLAGS) -f $(firstword $(MAKEFILE_LIST)) LILYFLAGS=-dno-point-and-click parts score
	$(MAKE) -f $(firstword $(MAKEFILE_LIST)) $(MFLAGS) zip
	chmod a+rX $(DEPLOY_FILES)
	ssh $(DEPLOY_HOST) mkdir -p $(DEPLOY_DIR)
	scp $(DEPLOY_FILES) $(DEPLOY_HOST):$(DEPLOY_DIR)

MIDI	:= $(wildcard *.midi)
FLAC	:= $(MIDI:%.midi=%.flac)

.PHONY: flac
flac:	$(FLAC)

.midi.flac:
	timidity -OF $<

.PHONY:	clean
clean:
	rm -f $(SCORE_PDF) $(PARTS_PDF) $(ZIP_PDF) $(ZIP_SRC) *.ly~ *.ily~

# Dependencies.
# Don't try to specify individual dependencies: all PDFs depend on all notes.
# One exception: the parts don't depend on score shared files.
$(SCORE_PDF):	$(NOTES) $(SCORE_NOTES)
$(PARTS_PDF):	$(NOTES)
