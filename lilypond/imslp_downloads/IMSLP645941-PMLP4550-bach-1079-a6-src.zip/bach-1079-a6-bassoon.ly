\version "2.21.0"

\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
    instrument = "Fagotto"
}

\paper {
    ragged-last-bottom = ##f
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \context Bottom <<
	{ \clef bass \vVI }
        {
            \cueClef G
            <>^\markup{Clar.} \cueDuring vIII #DOWN { s\breve*4 }
            \voiceOne
            <>^\markup{Oboe} \cueDuring vII #DOWN { s\breve*4 }
            \oneVoice
            <>^\markup{Clr.B.} \cueDuring vVup #DOWN { s\breve*4 }
            <>^\markup{Cor.} \cueDuring vIV #DOWN { s\breve*6}
            <>^\markup{Fl.} \cueDuring vI #UP { s\breve*6}
            \cueClefUnset
            s1^\markup\upright{(Fagotto)}
        }
	\set Staff.midiInstrument = #"bassoon"
    >>
}
