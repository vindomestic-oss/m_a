\version "2.21.0"

\include "common-grand-score.ily"
\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

#(set-global-staff-size 15)

% 

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
}

\paper {
    ragged-last-bottom = ##f
    indent = #16
    short-indent = #6
    systems-per-page = #4
}


\score {
    \keepWithTag #'( SCORE ) \new StaffGroup <<
        \new Staff = mvtIfl \with {
	    instrumentName = "Flauto"
	    shortInstrumentName = "Fl."
        } {
            \vI
        }
        \new Staff = mvtIob \with {
	    instrumentName = "Oboe"
	    shortInstrumentName = "Ob."
        } {
            \vII
        }
        \new Staff = mvtIclar \with {
	    instrumentName = \markup{Clar. in \Sib}
	    shortInstrumentName = "Clr."
        } \transpose c' d' {
            \vIII
        }
        \new Staff = mvtIcor \with {
	    instrumentName = "Corno in Fa"
	    shortInstrumentName = "Cor."
        } \transpose c' g' {
            \vIV
        }
        \new Staff = mvtIclarB \with {
            instrumentName = \markup\center-column{Clarinetto \line{Basso in \Sib}}
            shortInstrumentName = "Clr.B."
        } \transpose c' d'' {
            \vV
	}
        \new Staff = mvtIfg \with {
	    instrumentName = "Fagotto"
	    shortInstrumentName = "Fg."
        } {
            \clef bass
            \vVI
        }
    >>

}
