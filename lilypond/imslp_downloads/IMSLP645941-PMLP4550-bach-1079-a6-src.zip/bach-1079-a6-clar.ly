\version "2.21.0"

\include "common.ily"
\include "last-page-copyright.ily"

\include "bach-1079-a6.ily"
\include "bach-1079-a6-title.ily"
\include "bach-paged-title.ily"

\header {
    subsubtitle = "Für Bläser-Sextett bearbeitet"
    instrument = \markup{Clarinetto in \Sib}
}

\paper {
    ragged-last-bottom = ##f
}

\score {
    \keepWithTag #'( PARTS ) \new Staff \context Bottom <<
	\transpose c' d' \vIII
	\set Staff.midiInstrument = #"clarinet"
    >>
}
