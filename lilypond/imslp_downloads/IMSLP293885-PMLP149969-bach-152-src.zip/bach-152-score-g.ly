\version "2.17.18"

\include "bach-152-1.ly"

\paper {
    system-separator-markup = \markup {
	\center-align
	\vcenter \combine
	\beam #4.0 #0.5 #0.96
	\raise #1.4 \beam #4.0 #0.5 #0.96
    }
    % system-separator-markup = \slashSeparator
    two-sided = ##t
    indent = 12
    short-indent = 8
    ragged-last-bottom = ##f
    % system-system-spacing = #'((basic-distance . 4) (minimum-distance . 4) (padding . 1) (stretchability . 60))
    % % system-system-spacing #'basic-distance = #25
    % system-system-spacing #'minimum-distance = #15
    % page-count = 9
}

\include "paged-title.ly"
% \include "title.ly"

\markup\null
\pageBreak


#(set-global-staff-size 14)

\score {
    <<
        \new Staff <<
	    \commonScore

            \clef G
	    \key g \minor

	    \mvtIrec

	    \set Staff.instrumentName = "Flauto"
	    \set Staff.shortInstrumentName = "Fl"

	    % \mvtImanuscrBreaks
        >>
        \new Staff <<
	    \key g \minor

	    \mvtIob

	    \set Staff.instrumentName = "Hautbois"
	    \set Staff.shortInstrumentName = "Hb"
        >>
        \new Staff <<
            \clef soprano
	    \key g \minor

	    \removeWithTag #'clefs \mvtIvlaDam

	    \set Staff.instrumentName = "Viola d'Amour"
	    \set Staff.shortInstrumentName = \markup{\center-column{ "Vla d'" "Amour" }}
        >>
        \new Staff <<
	    \clef tenor

	    \transpose e g {
		% \removeWithTag #'clefs
		\removeWithTag #'fClefs
		\mvtIvlaDgam
	    }

	    \set Staff.instrumentName = "Viola da Gamba"
	    \set Staff.shortInstrumentName = \markup{\center-column{ "Vla da" "Gamba" }}
        >>
        \new Staff <<
	    \transpose e g {
		\mvtIbasso
	    }

	    \set Staff.instrumentName = "Organo"
	    \set Staff.shortInstrumentName = "Org"
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) (Kammerton in g)"
    }
}
