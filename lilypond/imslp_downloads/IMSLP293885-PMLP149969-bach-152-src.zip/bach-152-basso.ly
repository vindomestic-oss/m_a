\include "bach-152-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    % page-count = 4
    ragged-last-bottom = ##t
}

\header {
    instr = "Basso"
}


\score {
    \new Staff <<
	\transpose e g {
	    \mvtIbasso
	}
    >>

    \header {
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}


\score {
    \new Staff <<
	\mvtIbasso
    >>

    \header {
	piece = "I. (Sinfonia) -- Chorton & Bach-Ausgabe (in e)"
	breakbefore = ##t
    }
}
