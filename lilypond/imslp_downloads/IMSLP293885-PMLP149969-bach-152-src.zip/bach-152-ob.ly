\include "bach-152-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##t
}

\header {
    instr = "Hautbois"
}


\score {
    <<
        \new Staff <<
	    \key d \minor

	    \mvtIob
        >>
    >>

    \header {
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}

\score {
    <<
        \new Staff <<

	    \transpose g e {
		\key g \minor
		\mvtIob
	    }
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Bach-Ausgabe (in e)"
    }
}
