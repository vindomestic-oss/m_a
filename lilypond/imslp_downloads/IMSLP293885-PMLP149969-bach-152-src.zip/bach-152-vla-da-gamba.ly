\include "bach-152-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##t
}

\header {
    instr = "Viola da Gamba"
}


\score {
    <<
        \new Staff <<
	    \clef F

	    \mvtIvlaDgam
        >>
    >>

    \header {
	piece = "I. (Sinfonia) -- Chorton (in e)"
    }
}

\score {
    <<
        \new Staff <<
	    \clef tenor

	    \transpose e g {
		% \removeWithTag #'clefs
		\removeWithTag #'fClefs
		\mvtIvlaDgam
	    }
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}

\score {
    <<
        \new Staff <<
	    \clef F

	    \removeWithTag #'(clefs fClefs) \mvtIvlaDgam
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Bach-Ausgabe (in e)"
    }
}
