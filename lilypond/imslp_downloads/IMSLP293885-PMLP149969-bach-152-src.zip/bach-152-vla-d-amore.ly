\include "bach-152-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##t
}

\header {
    instr = "Viola d'Amour"
}


\score {
    <<
        \new Staff <<
            \clef soprano
	    \key d \minor

	    \mvtIvlaDam
        >>
    >>

    \header {
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}

\score {
    <<
        \new Staff <<
            % \clef soprano
	    \clef alto
	    \key g \minor

	    % \removeWithTag #'clefs
	     	\mvtIvlaDam
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}

\score {
    <<
        \new Staff <<
            \clef alto

	    \transpose g e {
		\key g \minor
		\removeWithTag #'clefs \mvtIvlaDam
	    }
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Bach-Ausgabe (in e)"
    }
}
