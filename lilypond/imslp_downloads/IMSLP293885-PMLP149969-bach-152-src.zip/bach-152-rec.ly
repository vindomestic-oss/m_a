\include "bach-152-1.ly"

% #(set-global-staff-size 17)

\include "paged-title.ly"
% \include "title.ly"

\paper {
    two-sided = ##t
    indent = 0
    % page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##t
}

\header {
    instr = "Flauto"
}


\score {
    <<
        \new Staff <<
            \clef french
	    \key d \minor

	    \mvtIrec
        >>
    >>

    \header {
	piece = "I. (Sinfonia) -- Kammerton (in e)"
    }
}

\score {
    <<
        \new Staff <<
            \clef G
	    \key g \minor

	    \mvtIrec
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Kammerton (in g)"
    }
}

\score {
    <<
        \new Staff <<
            \clef G

	    \transpose g e {
		\key g \minor
		\mvtIrec
	    }
        >>
    >>

    \header {
	breakbefore = ##t
	piece = "I. (Sinfonia) -- Bach-Ausgabe (in e)"
    }
}
