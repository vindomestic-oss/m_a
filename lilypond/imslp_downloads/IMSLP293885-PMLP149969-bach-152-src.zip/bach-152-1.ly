\version "2.17.18"

\include "common.ly"

mvtImarks = {
    \time 4/4

    s1*4 |
    \break
    \time 3/8
    \tempo "Allegro ma non presto"
    s4.*139
    \bar "|."
}

% BO = -[
% BS = -]
BO = -\markup\null
BS = -\markup\null


mvtIrec = \transpose d f \relative c''' <<
{
    \commonMusic

    r4 g8(   fis8) fis2 ~  | % bar 1
    fis32 a32 g32 fis32 e16 fis32 dis32 e4 ~  e32 dis32 cis32 dis32 e32 fis32 g32 a32 dis,8. e16 | % bar 2
    e4 ~  e32 b32 c32 d32 e32 fis16 gis32 a16(  b32 a32 b16  c16) dis,8. e16 | % bar 3
    e4 ~  e16 c'16 a16 fis16 \appoggiatura e8 dis2\trill\fermata | % bar 4
    R4.*8 | % bar 5
    fis4 g8 | % bar 13
    e8 fis4 | % bar 14
    d4 e8 | % bar 15
    cis8 d4 | % bar 16
    b4 g'8 | % bar 17
    ais,16\BO cis16\BS e8. fis16 | % bar 18
    d16\BO cis16\BS cis8. b16 | % bar 19
    b16 cis16 d16 e16 fis16 g16 | % bar 20
    a4. ~  | % bar 21
    a16 a16 g16 fis16 e16 g16 | % bar 22
    fis16 e16 dis16 fis16 b,16 dis16 | % bar 23
    e16 d16 c16 b16 c8 ~  | % bar 24
    c16 c16 b16 d16 g,16 b16 | % bar 25
    c16 b16 a16 g16 a8 | % bar 26
    a8. c16 b16 dis16 | % bar 27
    e16\BO fis16\BS dis8. e16 | % bar 28
    e4 r8 | % bar 29
    R4. | % bar 30
    g16 fis16 e16 d16 cis16 b16 | % bar 31
    ais8 b16 ais16 b8 ~  | % bar 32
    b16\BO e16\BS cis8. b16 | % bar 33
    b8 b'16 a16 g16 fis16 | % bar 34
    e16 a,16 a'16 g16 fis16 e16 | % bar 35
    d16 g,16 g'16 fis16 e16 d16 | % bar 36
    cis8. e16 d16 cis16 | % bar 37
    b8 g'16 fis16 e16 fis16 | % bar 38
    d8 b8 d8 ~  | % bar 39
    d8 c16 b16 c8 ~  | % bar 40
    c8 b16 a16 b16 c16 | % bar 41
    a16 b16 c16 d16 e16 fis16 | % bar 42
    g8 b8 e8 ~  | % bar 43
    e16 c16 a8 d8 ~  | % bar 44
    d16 b16 g8 c8~ | % bar 45
    c16 a16 fis8 b8 ~  | % bar 46
    b16 b16 c16 d16 e8 ~  | % bar 47
    e16\BO c16\BS fis,8. a16 | % bar 48
    d,16\BO g16\BS fis8. g16 | % bar 49
    g4 r8 | % bar 50
    R4.*2 | % bar 51
    a4 b8 | % bar 53
    g8 a4 | % bar 54
    fis4 g8 | % bar 55
    e8 fis4 | % bar 56
    d4 b'8 | % bar 57
    cis,16\BO e16\BS g8. a16 | % bar 58
    fis16\BO e16\BS e8. d16 | % bar 59
    d4 r8 | % bar 60
    e4. ~  | % bar 61
    e8 d16 c16 d8 | % bar 62
    c16 b16 c16 d16 e16 fis16 | % bar 63
    g16 a16 b16 a16 g16 fis16 | % bar 64
    g16 a16 fis16 a16 d,16 fis16 | % bar 65
    g16 fis16 e16 dis16 e8 ~  | % bar 66
    e16 e16 dis16 fis16 b,16 dis16 | % bar 67
    e16 d16 c16 b16 c8 | % bar 68
    c8. e16 d16 fis16 | % bar 69
    g8. a16 fis8 ~  | % bar 70
    fis16\BO g16\BS e8. fis16 | % bar 71
    d16 cis16 e16 d16 cis16 b16 | % bar 72
    ais16 gis16 fis16 cis'16 fis16 e16 | % bar 73
    d16 e16 d16 cis16 d16 b16 | % bar 74
    cis4 cis'8 ~  | % bar 75
    cis16 fis,16 b16 a16 g16 fis16 | % bar 76
    e16 a,16 a'16 g16 fis16 e16 | % bar 77
    d16 g,16 g'16 fis16 e16 d16 | % bar 78
    cis8. e16 d16 cis16 | % bar 79
    fis16\BO g16\BS ais,8. b16 | % bar 80
    b4 d8 | % bar 81
    c8. e16 d16 c16 | % bar 82
    b4.~ | % bar 83
    b8 a16 g16 a8 ~  | % bar 84
    a16 fis16 g8 g'8 ~  | % bar 85
    g8 f16 e16 f8 ~  | % bar 86
    f8 dis8 e8 | % bar 87
    fis8 g16\trill(  fis32  g32) a8 ~  | % bar 88
    a16 c16 b16 a16 g16 fis16 | % bar 89
    g16 b16 a16 g16 fis16 e16 | % bar 90
    dis8 e8 fis8 | % bar 91
    e8 fis8 g8 | % bar 92
    a8. b16 g16 fis16 | % bar 93
    g16\BO a16\BS fis8. e16 | % bar 94
    e4 r8 | % bar 95
    R4.*4 | % bar 96
    b'4 c8 | % bar 100
    a8 b4 | % bar 101
    g4 a8 | % bar 102
    f8 g4 | % bar 103
    e4 c'8 | % bar 104
    dis,16\BO fis16\BS a8.\trill b16 | % bar 105
    g16[ fis16] fis8. e16 | % bar 106
    e4. ~  | % bar 107
    e4. | % bar 108
    dis8 r8 r8 | % bar 109
    R4. | % bar 110
    c'4. | % bar 111
    b4. | % bar 112
    a4. | % bar 113
    g4. | % bar 114
    fis8. g16 g16[\trill fis32 g32] | % bar 115
    a8. dis,16 e8 ~  | % bar 116
    e16\BO fis16\BS dis8. e16 | % bar 117
    e4 f8 | % bar 118
    d8 e4 | % bar 119
    c4 d8 | % bar 120
    b8 c4 | % bar 121
    a4 f'8 | % bar 122
    gis,16\BO b16\BS d8. e16 | % bar 123
    c16\BO b16\BS b8. a16 | % bar 124
    a8 a'4 ~  | % bar 125
    a8 g16 fis16 g8 ~  | % bar 126
    g8 fis16 g16 a16 b16 | % bar 127
    g16 fis16 g16 a16 b16 c16 | % bar 128
    b16 a16 g16 fis16 e16 d16 | % bar 129
    c4. | % bar 130
    b4. | % bar 131
    a4. | % bar 132
    g4 e'8 | % bar 133
    a16 g16 fis16 e16 dis16 e16 | % bar 134
    dis16 b16 cis16 dis16 e16 fis16 | % bar 135
    g4 a8 | % bar 136
    fis8 g4 | % bar 137
    e4 fis8 | % bar 138
    dis8 e4 ~  | % bar 139
    e16 g16 fis16 e16 dis16 e16 | % bar 140
    a,8. c16 b16 dis16 | % bar 141
    e16\BO fis16\BS dis8. e16 | % bar 142
    e4.\fermata | % bar 143
}
\mvtImarks
>>


mvtIob = \transpose d f \relative c' <<
{
    \commonMusic

    r4 e4 c'4.\trill b16 c16 | % bar 1
    b4 r8 e16(   c16) a4\trill ~  a32 c32 b32 a32 g16 a32 fis32 | % bar 2
    g32 fis32 e32 fis32 g32 a32 b32 d64 c64 d16 e32 f32 e16\BO d16\BS c8.\trill b16 b4~ | % bar 3
    b16 e16 c16 b16 a8.\trill b16 b2\fermata | % bar 4
    b4 c8 | % bar 5
    a8 b4 | % bar 6
    g4 a8 | % bar 7
    fis8 g4 | % bar 8
    e4 c'8 | % bar 9
    dis,16\BO fis16\BS a8. b16 | % bar 10
    g16[ fis16] fis8. e16 | % bar 11
    e16(  fis16 g16 a16 b16  cis16) | % bar 12
    d16 cis16 b16 ais16 b8~ | % bar 13
    b16 b16 ais16 cis16 fis,16 ais16 | % bar 14
    b16 a16 g16 fis16 g8 ~  | % bar 15
    g16 g16 fis16 a16 d,16 fis16 | % bar 16
    g16 fis16 e16 d16 e8 | % bar 17
    e8. g16 fis16 ais16 | % bar 18
    b16\BO cis16\BS ais8. b16 | % bar 19
    b4. | % bar 20
    a16 g16 fis16 e16 dis16 cis16 | % bar 21
    b8 e16 dis16 e8 ~  | % bar 22
    e16\BO a16\BS fis8. e16 | % bar 23
    e8 e'16 d16 c16 b16 | % bar 24
    a16 d,16 d'16 c16 b16 a16 | % bar 25
    g16 c,16 c'16 b16 a16 g16 | % bar 26
    fis8. a16 g16 fis16 | % bar 27
    e8 c'16 b16 a16 b16 | % bar 28
    g8 e8 r8 | % bar 29
    fis'16 e16 d16 cis16 b16 a16 | % bar 30
    b16 a16 g16 fis16 e16 d16 | % bar 31
    cis8 fis'8 d8 | % bar 32
    g8 cis,8 fis8~ | % bar 33
    fis16 d b8 e8~ | % bar 34
    e16 cis16 a8 d8 ~  | % bar 35
    d16 d16 e16 fis16 g8 ~  | % bar 36
    g16\BO e16\BS ais,8. e'16 | % bar 37
    d16\BO cis16\BS cis8. b16 | % bar 38
    b4. ~  | % bar 39
    b8 a16 g16 a8 | % bar 40
    g16 a16 b16 c16 d16 e16 | % bar 41
    d8 a8 r8 | % bar 42
    d4 e8 | % bar 43
    c8 d4 | % bar 44
    b4 c8 | % bar 45
    a8 b4 | % bar 46
    g4 e'8 | % bar 47
    fis,16\BO a16\BS c8. d16 | % bar 48
    b16\BO a16\BS a8. g16 | % bar 49
    g16 a16 b16 cis16 d16 e16 | % bar 50
    fis4. ~  | % bar 51
    fis16 fis16 e16 d16 e8 ~  | % bar 52
    e16 e16 d16 cis16 d8 ~  | % bar 53
    d16 d16 cis16 e16 a,16 cis16 | % bar 54
    d16 cis16 b16 ais16 b8~ | % bar 55
    b16 b16 ais16 cis16 fis,16 ais16 | % bar 56
    b16 a16 g16 fis16 g8 | % bar 57
    g8. b16 a16 cis16 | % bar 58
    d16\BO e16\BS cis8. d16 | % bar 59
    d8 a8 d8 ~  | % bar 60
    d8 c16 b16 c8 | % bar 61
    b,16 c16 d16 e16 fis16 g16 | % bar 62
    a16 g16 a16 b16 c16 d16 | % bar 63
    b16 a16 g16 fis16 g8 ~  | % bar 64
    g16 e'16 d16 c16 b16 a16 | % bar 65
    b16 d16 g16 fis16 e16 d16 | % bar 66
    c16 fis,16 fis'16 e16 dis16 \once \set suggestAccidentals = ##t cis16 | % bar 67
    b16 e,16 e'16 d16 c16 b16 | % bar 68
    a8. c16 b16 a16 | % bar 69
    g16 e'16 a,16 b16 c16(   b16) | % bar 70
    b8 r8 r8 | % bar 71
    R4.*2 | % bar 72
    fis'4 g8 | % bar 74
    e8 fis4 | % bar 75
    d4 e8 | % bar 76
    cis8 d4 | % bar 77
    b4 g'8 | % bar 78
    ais,16\BO cis16\BS e8. fis16 | % bar 79
    d16\BO cis16\BS cis8. b16 | % bar 80
    b8 b4 ~  | % bar 81
    b8 a16 g16 a8 ~  | % bar 82
    a16 fis16 g8 b8 | % bar 83
    e8.\trill dis32 e32 fis8 | % bar 84
    b,4 b8 | % bar 85
    c8.\trill b32 c32 d8 | % bar 86
    g,8( fis8\trill) g8 | % bar 87
    c16 b16 a16 g16 fis16 e16 | % bar 88
    dis8 e8 fis8 | % bar 89
    e8 fis8 g8 | % bar 90
    a16 c16 b16 a16 g16 fis16 | % bar 91
    g16 b16 a16 g16 fis16 e16 | % bar 92
    dis8 cis16 b16 e16 dis16 | % bar 93
    e16\BO fis16\BS dis8. e16 | % bar 94
    e4 r8 | % bar 95
    r16 a16 d16 c16 b16 a16 | % bar 96
    g16 e16 c'16 b16 a16 g16 | % bar 97
    fis16 a16 dis,16 fis16 b8 ~  | % bar 98
    b16\BO c16\BS fis,8. e16 | % bar 99
    e16 fis16 g16 fis16 g16 e16 | % bar 100
    fis16 c'16 b16 a16 g16 fis16 | % bar 101
    e16 b'16 e16 d16 c16 b16 | % bar 102
    a16 d,16 d'16 c16 b16 a16 | % bar 103
    g16 c,16 c'16 b16 a16 g16 | % bar 104
    fis8. a16 g16 fis16 | % bar 105
    e16[ c'16] dis,8. e16 | % bar 106
    e4 r8 | % bar 107
    fis4. ~  | % bar 108
    fis4. | % bar 109
    b4. ~  | % bar 110
    b8 a4 ~  | % bar 111
    a8 g4~ | % bar 112
    g8 fis4 ~  | % bar 113
    fis8 e4 ~  | % bar 114
    e8 dis16 e16 e16[\trill dis32 e32] | % bar 115
    fis8. c'16 b8 ~  | % bar 116
    b16 a16 g8 fis16 e16 | % bar 117
    e4 r8 | % bar 118
    R4. | % bar 119
    e4 f8 | % bar 120
    d8 e4 | % bar 121
    c4 d8 | % bar 122
    b8. f'16 e16 gis16 | % bar 123
    a16\BO b16\BS gis8. a16 | % bar 124
    a8 e8 c'8 ~  | % bar 125
    c8 b16 a16 b8 | % bar 126
    a16 g16 a16 b16 cis16 dis16 | % bar 127
    e16 a,16 g16 fis16 e16 g16 | % bar 128
    fis8 g8 b8~ | % bar 129
    b16 b16 a16 g16 fis16 e16 | % bar 130
    d8 g16 fis16 g8 ~  | % bar 131
    g8 fis16 e16 fis8 ~  | % bar 132
    fis8 e16 dis16 e8 ~  | % bar 133
    e16 g16 c16 b16 a16 g16 | % bar 134
    fis8 b,8 r8 | % bar 135
    b'4 c8 | % bar 136
    a8 b4 | % bar 137
    g4 a8 | % bar 138
    fis8 g4 | % bar 139
    e4 c'8 | % bar 140
    dis,16\BO fis16\BS a8. b16 | % bar 141
    g16\BO fis16\BS fis8. e16 | % bar 142
    e4.\fermata | % bar 143
}
\mvtImarks
>>


mvtIvlaDam = \transpose d f \relative c'' <<
{
    \commonMusic

    r4 b16(  e16 dis16  e16) a,8 ~  a32 g32 fis32 g32 a32 c32 b32 a32 g16 a32 fis32 | % bar 1
    g4 ~  g32 fis32 e32 fis32 g16 a32 fis32 fis4.\trill e16 fis16 | % bar 2
    e2 ~  e8 a8 ~  a16 b32 c32 b16 a16 | % bar 3
    g32 a32 g32 fis32 e16 fis32 dis32 e8.\trill fis16 <fis b,>2\fermata | % bar 4
    R4.*17 | % bar 5
    b4 c8 | % bar 22
    a8 b4 | % bar 23
    g4 a8 | % bar 24
    fis8 g4 | % bar 25
    e4 c'8 | % bar 26
    dis,16\BO fis16\BS a8. b16 | % bar 27
    g16\BO fis16\BS fis8. e16 | % bar 28
    e16 fis16 g16 a16 b16 cis16 | % bar 29
    d4. ~  | % bar 30
    d8 cis16 b16 ais16 b16 | % bar 31
    fis16 e16 d16 cis16 b8 ~  | % bar 32
    b16 b16 ais16 cis16 fis,16 ais16 | % bar 33
    \tag clefs {
	\clef C
    }
    b16 a16 g16 fis16 g8~ | % bar 34
    g16 g16 fis16 a16 d,16 fis16 | % bar 35
    g16 fis16 e16 dis16 e8 | % bar 36
    e8. g16 fis16 ais16 | % bar 37
    b16\BO cis16\BS ais8. b16 | % bar 38
    b8 b,8 r8 | % bar 39
    a'16 b16 c16 d16 e16 fis16 | % bar 40
    g4.~ | % bar 41
    g16 g16 fis16 e16 d16 c16 | % bar 42
    d16 c16 b16 a16 g16 fis16 | % bar 43
    g16\BO a16\BS a8. g16 | % bar 44
    g8 g'16 fis16 e16 d16 | % bar 45
    c16 fis,16 fis'16 e16 dis16 cis16 | % bar 46
    b16 e,16 e'16 d16 c16 b16 | % bar 47
    a8. c16 b16 a16 | % bar 48
    g16 e'16 d16 c16 b16 c16 | % bar 49
    b4. | % bar 50
    a16 b16 cis16 d16 e16 fis16 | % bar 51
    g16 fis16 g16 b16 a16 g16 | % bar 52
    fis16 e16 fis8 b8 ~  | % bar 53
    b8 e,8 a8 ~  | % bar 54
    a16 fis16 d8 g8~ | % bar 55
    g16 e16 cis8 fis8 ~  | % bar 56
    fis16 fis16 g16 a16 b8 ~  | % bar 57
    b16\BO g16\BS cis,8. e16 | % bar 58
    a16 b16 e,16 fis16 g16 a16 | % bar 59
    fis8 d8 r8 | % bar 60
    c,16 d16 e16 fis16 g16 a16 | % bar 61
    b4.~ | % bar 62
    b8 a16 g16 fis16 e16 | % bar 63
    d8 d'8 e8 | % bar 64
    c8 d4 | % bar 65
    b4 c8 | % bar 66
    a8 b4 | % bar 67
    g4 e'8 | % bar 68
    fis,16\BO a16\BS c8. d16 | % bar 69
    b16\BO a16\BS a8. g16 | % bar 70
    g8. a16 fis8 ~  | % bar 71
    fis16\BO g16\BS e8. fis16 | % bar 72
    fis16 cis'16 fis16 e16 d16 cis16 | % bar 73
    b16
	\tag clefs {
	    \clef soprano
	}
	fis'16 b16 ais16 b8 ~  | % bar 74
    b16 b16 ais16 cis16 fis,16 ais16 | % bar 75
    b16 a16 g16 fis16 g8~ | % bar 76
    g16 g16 fis16 a16 d,16 fis16 | % bar 77
    g16 fis16 e16 d16 e8 | % bar 78
    e8. g16 fis16 ais16 | % bar 79
    b16 e,16 fis16 e16 fis16 fis,16 | % bar 80
    b16 cis16 d16 e16 fis16 g16 | % bar 81
    a16 g16 fis16 e16 fis16 d16 | % bar 82
    g16 fis16 e16 d16 cis16 b16 | % bar 83
    cis16 b16 cis16 e16 dis16 fis16 | % bar 84
    e16 d16 c16 b16 a16 g16 | % bar 85
    a16 g16 a16 c16 b16 d16 | % bar 86
    c16 b16 a16 g16 fis16 e16 | % bar 87
    \tag clefs {
	\clef C
    }
    a16 g16 fis16 e16 dis16 cis16 | % bar 88
    b4.~  | % bar 89
    b4.~ | % bar 90
    b4.~  | % bar 91
    b4.~  | % bar 92
    b16 b16 cis16 dis16 e16 a16 | % bar 93
    b16 c16 fis,16 b16 a16 b16 | % bar 94
    e,16 b'16 e16 d16 c16 b16 | % bar 95
    a16 d16 b16 d16 g,16 b16 | % bar 96
    c16 b16 a16 g16 a8 | % bar 97
    a8. c16 b16 dis16 | % bar 98
    e16\BO fis16\BS dis8. e16 | % bar 99
    \tag clefs {
	\clef soprano
    }
    e8 g8 c8 ~  | % bar 100
    c16 a16 fis8 b8 ~  | % bar 101
    b16 g16 e8 a8~ | % bar 102
    a16 f16 d8 g8 ~  | % bar 103
    g16 g16 a16 b16 c8~ | % bar 104
    c16\BO a16\BS dis,8.\trill fis16 | % bar 105
    b,16 e,16 b'16 c16 fis,16 a16 | % bar 106
    g16 b16 e16 g16 b,16 d16 | % bar 107
    c16 e16 a16 c16 fis,16 a16 | % bar 108
    dis,16 fis16 b,16 dis16 fis,16 a16 | % bar 109
    \tag clefs {
	\clef C
    }
    g16 b16 e,16 g16 b16 e16 | % bar 110
    <dis b, fis'>4.^"arpeggio"  | % bar 111
    <e b, g'>4.  | % bar 112
    <dis b, a'>4.  | % bar 113
    <e b, g'>4.  | % bar 114
    a16 g16 fis16 e16 dis16 cis16 | % bar 115
    b16 dis16 fis16 a16 g16 fis16 | % bar 116
    \tag clefs {
	\clef soprano
    }
    e16 c'16 b16 c16 fis,16 a16 | % bar 117
    gis16 e'16 c16 e16 a,16 c16 | % bar 118
    b16 d16 gis,16 b16 e,16 gis16 | % bar 119
    a16 e16 c16 e16 a,16 c16 | % bar 120
    \tag clefs {
	\clef C
    }
    f16 d16 gis,16 b16 e,16 gis16 | % bar 121
    a16 e16 c16 e16 d16 f16 | % bar 122
    e16 gis16 fis16 a16 gis16 b16 | % bar 123
    a16 e16 e'16 f16 b,16 d16 | % bar 124
    c8 a8 r8 | % bar 125
    g16 a16 b16 cis16 dis16 e16 | % bar 126
    fis16 g16 fis16 e16 dis16 cis16 | % bar 127
    b16 c16 b16 a16 g16 e'16 | % bar 128
    dis8 b8 e8 ~  | % bar 129
    e8 fis8 d8 ~  | % bar 130
    d16 c16 b16 a16 g16 fis16 | % bar 131
    e8 b8 b'8 ~  | % bar 132
    b8 e,8 e'8 ~  | % bar 133
    e8 a,8
	\tag clefs {
	    \clef soprano
	}
	a'8 ~  | % bar 134
    a16 c16 b16 a16 g16 fis16 | % bar 135
    e16 f16 e16 d16 c16 b16 | % bar 136
    c16 e16 d16 c16 b16 a16 | % bar 137
    b16 d16 c16 b16 a16 g16 | % bar 138
    a16 c16 b16 a16 g16 fis16 | % bar 139
    \tag clefs {
	\clef C
    }
    g16 b16 a16 g16 fis16 e16 | % bar 140
    fis16 a16 g16 fis16 e16 dis16 | % bar 141
    b'16 c16 fis,16 a16 b,16 b'16 | % bar 142
    <e e, b'>4.\fermata  | % bar 143
}
\mvtImarks
>>


mvtIvlaDgam = \relative c <<
{
    \commonMusic

    \key e \minor
    \transposition es

    e8 e8 e'8 e8 e8 e8 dis8 dis8 | % bar 1
    e8 e8 c8 c8 fis,8 fis8 b8 b8 | % bar 2
    e,8 e8 e'8 e8 a,8 a8 b8 b8 | % bar 3
    c8 c8 c8 c8 b2\fermata | % bar 4
    R4.*27 | % bar 5
    fis4 g8 | % bar 32
    e8 fis4 | % bar 33
    d4 e8 | % bar 34
    cis8 d4 | % bar 35
    b4 g'8 | % bar 36
    ais,16\BO cis16\BS e8. cis16 | % bar 37
    d16 e16 fis8 fis,8 | % bar 38
    b16 cis16 d16 e16 fis16 gis16 | % bar 39
    a8 fis8 d8 | % bar 40
    g8 e8 c8 | % bar 41
    d8 e16 fis16 g16 a16 | % bar 42
    b16 a16 g16 fis16 g8 ~  | % bar 43
    g16 g16 fis16 a16 d,16 fis16 | % bar 44
    g16 fis16 e16 dis16 e8 ~  | % bar 45
    e16 e16 dis16 fis16 b,16 dis16 | % bar 46
    e16 d16 c16 b16 c8 ~  | % bar 47
    c8. e16 d16 fis16 | % bar 48
    g16[ c,16] d8 d,8 | % bar 49
    g8 g'16 a16 b16 cis16 | % bar 50
    d4. ~  | % bar 51
    d8 cis16 b16 cis8 | % bar 52
    d16
	\tag fClefs {
	    \clef tenor
	}
	g16 fis16 e16 d16 \once \set suggestAccidentals = ##t cis16 | % bar 53
    d16\BO e16\BS << { e8. d16 } \\ a4 >> | % bar 60
    d16 d,16 d'16 \once \set suggestAccidentals = ##t cis16 b16 a16 | % bar 61
    g16 cis,16 cis'16 b16 ais16 \once \set suggestAccidentals = ##t gis16 | % bar 62
    fis16 b,16 b'16 a16 g16 fis16 | % bar 63
    e8. g16 fis16 e16 | % bar 64
    d16 g16 a8 a,8 | % bar 65
    \tag clefs {
	\clef F
    }
    d16 e16 fis16 g16 a16 b16 | % bar 66
    c8 a8 fis8 | % bar 67
    b8 g8 e8 | % bar 68
    a8 fis8 d8 | % bar 69
    g8 g,8
	\tag clefs {
	    \clef tenor
	}
 	e''8 ~  | % bar 70
    e16 c16 a8 d8 ~  | % bar 71
    d16 b16 g8 c8 ~  | % bar 72
    c16 a16 fis8 b8 ~  | % bar 73
    b16 b16 c16 d16 e8 ~  | % bar 74
    e16\BO c16\BS fis,8. d'16 | % bar 75
    g,16 c16 d16 d,16 dis16 b16 | % bar 76
    \tag clefs {
	\clef F
    }
    e16 d16 cis16 a16 d16 cis16 | % bar 77
    b16 a16 g16 fis16 g8 | % bar 78
    fis4 r8 | % bar 79
    R4.*19 | % bar 80
    b'4 c8 | % bar 99
    a8 b4 | % bar 100
    g4 a8 | % bar 101
    fis8 g4 | % bar 102
    e4 c'8 | % bar 103
    dis,16\BO fis16\BS a8. b16 | % bar 104
    g16 a16 b16 c16 fis,16 a16 | % bar 105
    g16 b16 e16 dis16 e8 ~  | % bar 106
    e16 e16 dis16 fis16 b,16 dis16 | % bar 107
    e16 d16 c16 b16 c8 ~  | % bar 108
    c16 c16 b16 d16 g,16 b16 | % bar 109
    c16 b16 a16 g16 a8 | % bar 110
    a8. c16 b16 dis16 | % bar 111
    e16 a,16 b16 a16 b16 b,16 | % bar 112
    e4 r8 | % bar 113
    a4 r8 | % bar 114
    b4 r8 | % bar 115
    b4 r8 | % bar 116
    b4 r8 | % bar 117
    b4 r8 | % bar 118
    b4 r8 | % bar 119
    b4 r8 | % bar 120
    c16 b16 a16 g16 fis16 e16 | % bar 121
    dis16 fis16 a,16 c16 b16 a16 | % bar 122
    g16 a'16 b16 a16 b16 b,16 | % bar 123
    e4 r8 | % bar 124
    e4 r8 | % bar 125
    e4 r8 | % bar 126
    e4 r8 | % bar 127
    e4 d8 | % bar 128
    d4 gis,8 | % bar 129
    a8 e'8 e,8 | % bar 130
    a16 b16 c16 d16 e16 fis16 | % bar 131
    g8 e8 cis8 | % bar 132
    fis8 dis8 b8 | % bar 133
    e16 dis16 e16 fis16 g16 a16 | % bar 134
    b8 e,8 g8 | % bar 135
    a8 d,8 fis8 | % bar 136
    g8 b,8 e8 | % bar 137
    cis16 e16 dis16 cis16 dis16 b16 | % bar 138
    e16 d16 c16 b16 a16 g16 | % bar 139
    c16 b16 a16 g16 fis16 e16 | % bar 140
    b'16 a16 g16 fis16 e16 dis16 | % bar 141
    e8 e'8 a,8 | % bar 142
    d8 g8 g,8 | % bar 143
    c8 c'8 fis,8 | % bar 144
    b8 e,8 e,8 | % bar 145
    a8 c8 a8 | % bar 146
    fis'8 dis8 b8 | % bar 147
    e16 a16 b8 b,8 | % bar 148
    e,4.\fermata | % bar 149
}
\mvtImarks
>>


mvtIbasso = \relative c, <<
{
    \commonMusic

    \clef F
    \key e \minor
    \transposition es

    e8 e8 e'8 e8 e8 e8 dis8 dis8 | % bar 1
    e8 e8 c8 c8 fis,8 fis8 b8 b8 | % bar 2
    e,8 e8 e'8 e8 a,8 a8 b8 b8 | % bar 3
    c8 c8 c8 c8 b2\fermata | % bar 4
    e,8 e'8 a8 | % bar 5
    fis8 dis8 b8 | % bar 6
    e8 d8 c8 | % bar 7
    d8 b8 g8 | % bar 8
    c8 b8 a8 | % bar 9
    b8 dis8 b8 | % bar 10
    e8 b'8 b,8 | % bar 11
    e,8 e'8 e,8 | % bar 12
    b'8 d8 e8 | % bar 13
    cis8 fis8 fis,8 | % bar 14
    b8 e8 e,8 | % bar 15
    a8_\markup{\tiny{\musicglyph #"seven"}}_\markup{\tiny{\musicglyph #"eight"}} d8 d,8 | % bar 16
    g8 g'16 fis16 e16 d16 | % bar 17
    cis8 ais8 fis8 | % bar 18
    g8 e8 fis8 | % bar 19
    b8 b'8 b,8 | % bar 20
    cis8 dis8 b8 | % bar 21
    e8 e'8 a,8 | % bar 22
    fis8 b8 b,8 | % bar 23
    e8 a8 a,8 | % bar 24
    d8 g8 g,8 | % bar 25
    c8 fis,8 fis'8 | % bar 26
    b,8 dis8 b8 | % bar 27
    c8 a8 b8 | % bar 28
    e,8 e'16 fis16 g16 a16 | % bar 29
    b8 b,8 d8 | % bar 30
    e8. fis16 g16 e16 | % bar 31
    fis4 g8 | % bar 32
    e8 fis4 | % bar 33
    d4 e8 | % bar 34
    cis8 d4 | % bar 35
    b4 g'8 | % bar 36
    ais,16\BO cis?16\BS e8. cis!16 | % bar 37
    d16 e16 fis8 fis,8 | % bar 38
    b16 cis16 d16 e16 fis16 gis?16 | % bar 39
    a8 fis8 d8 | % bar 40
    g8 e8 c8 | % bar 41
    d8 d,8 c'8 | % bar 42
    b8 g8 e8 | % bar 43
    a8 d8 d,8 | % bar 44
    g'8 e8 c8 | % bar 45
    fis8 b8 b,8 | % bar 46
    e8 c8 a8 | % bar 47
    d8 d,8 fis8 | % bar 48
    g16[ c16] d8 d,8 | % bar 49
    g8 g'8 g,8 | % bar 50
    d'8 cis8 b8 | % bar 51
    e8 a8 a,8 | % bar 52
    d,8 d'8 g8 | % bar 53
    e8 a8 a,8 | % bar 54
    d8 g,8 g'8 | % bar 55
    cis,8 fis8 fis,8 | % bar 56
    b8 e,8 g8 | % bar 57
    a8 a'8 a,8 | % bar 58
    d16 g16 a8 a,8 | % bar 59
    d16 e16 fis16 g16 a16 b16 | % bar 60
    c8 a8 fis8 | % bar 61
    b8 g8 e8 | % bar 62
    a8 fis8 d8 | % bar 63
    g8 g,8 c8 | % bar 64
    a8 d8 d,8 | % bar 65
    g8 c8 c'8 | % bar 66
    fis,8 b8 b,8 | % bar 67
    e8 a,8 a'8 | % bar 68
    d,8 fis8 d8 | % bar 69
    g16 c,16 d8 dis8 | % bar 70
    e8 cis8 d8 | % bar 71
    b8 g4 | % bar 72
    fis4 r8 | % bar 73
    R4.*19 | % bar 74
    b4 c8 | % bar 93
    a8 b4 | % bar 94
    g4 a8 | % bar 95
    fis8 g4 | % bar 96
    e4 c'8 | % bar 97
    dis,16\BO fis16\BS a8. b16 | % bar 98
    g16 a16 b8 b'8 | % bar 99
    e,8 e'8 a,8 | % bar 100
    fis8 b8 b,8 | % bar 101
    e8 a8 a,8 | % bar 102
    d8 g8 g,8 | % bar 103
    c8 a8 fis8 | % bar 104
    b8 fis8 dis8 | % bar 105
    e16 a16 b16 a16 b8 | % bar 106
    e,4 r8 | % bar 107
    a4 r8 | % bar 108
    b4 r8 | % bar 109
    b4 r8 | % bar 110
    b4 r8 | % bar 111
    b4 r8 | % bar 112
    b4 r8 | % bar 113
    b4 r8 | % bar 114
    c16 b16 a16 g16 fis16 e16 | % bar 115
    dis16 fis16 a16 fis16 g8 ~  | % bar 116
    g16 a16 b16 a16 b8 | % bar 117
    e,4 r8 | % bar 118
    e4 r8 | % bar 119
    e4 r8 | % bar 120
    e4 r8 | % bar 121
    e4 d8 | % bar 122
    d4 gis8 | % bar 123
    a8 e'8 e,8 | % bar 124
    a16 b16 c16 d16 e16 fis16 | % bar 125
    g8 e8 cis8 | % bar 126
    fis8 dis8 b8 | % bar 127
    e16 dis16 e16 fis16 g16 a16 | % bar 128
    b8 e,8 g8 | % bar 129
    a8 d,8 fis8 | % bar 130
    g8 b,8 e8 | % bar 131
    cis16 e16 dis16 cis16 dis16 b16 | % bar 132
    e16 d16 c16 b16 a16 g16 | % bar 133
    c16 b16 a16 g16 fis16 e16 | % bar 134
    b'16 a16 g16 fis16 e16 dis16 | % bar 135
    e8 e'8 a,8 | % bar 136
    d8 g8 g,8 | % bar 137
    c,8 c'8 fis,8 | % bar 138
    b8 e8 e,8 | % bar 139
    a8 c8 a8 | % bar 140
    fis'8 dis8 b8 | % bar 141
    e16 a16 b8 b,8 | % bar 142
    e,4.\fermata | % bar 143
}
\mvtImarks
>>
