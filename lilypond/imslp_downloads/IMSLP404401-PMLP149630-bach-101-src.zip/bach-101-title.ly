\version "2.19.15"

\header {
    title = \markup{Nimm von ons Herr, du treuer Gott}
    opus = \markup{ BWV 101 }
    subtitle = \markup{ Dominica 10 post F. Trinitatis }
    composer = \markup{J.S. Bach}
    source = \markup{Quelle: D-LEb Thomana 101 \italic{Bach-Archiv Leipzig}}
    copyright = \markup{\abs-fontsize #10 {© Rutger Hofman 2015 Creative Commons Attribution Non-commercial ShareAlike 4.0}}
}


mvtIpiece = "I. Coro"
mvtIIpiece = "II. Aria"
mvtIIIpiece = "III. Recit. (e Chorale)"
mvtIVpiece = "IV. Aria"
mvtVpiece = "V. Recit. (e Chorale)"
mvtVIpiece = \markup{VI. Aria \smallCaps{(DUETTO)}}
mvtVIIpiece = "VII. Chorale"

