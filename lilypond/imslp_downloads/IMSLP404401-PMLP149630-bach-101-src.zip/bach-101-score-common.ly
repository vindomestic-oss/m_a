\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "common-grand-score.ly"
\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\markup\null
\pageBreak


#(set-global-staff-size 14)

\paper {
    indent = #18
    short-indent = #6
    % ragged-last-bottom = ##f
}

\paper {
    % page-count = 16
}

% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) <<
        % \new Dynamics \mvtIbreaks
        % \new Dynamics {
            % s1*69 | %69
            % \repeat unfold 17 { s1\noPageBreak } | %86
            % \pageBreak
        % }

        \new StaffGroup <<

            \new Staff = staffA <<

                \set Staff.instrumentName = \markup\center-column{"Flauto" "Traverso"}
                \set Staff.shortInstrumentName = \markup{"Fl."}

                \mvtIfl
            >>
            \new GrandStaff <<
                \set GrandStaff.instrumentName = "Oboe"
                \set GrandStaff.shortInstrumentName = "Ob."

                \new Staff = staffB <<
                    \set Staff.instrumentName = "1"
                    \set Staff.shortInstrumentName = "1"

                    \mvtIobI
                >>
                \new Staff = staffC <<
                    \set Staff.instrumentName = "2"
                    \set Staff.shortInstrumentName = "2"

                    \mvtIobII
                >>
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = "Taille"
                \set Staff.shortInstrumentName = "Tlle."

                \clefTaille
                \transpose \transpTaille c { \mvtItaille }
            >>
        >>
        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = "Violino"
                \set GrandStaff.shortInstrumentName = "Vln."

                \new Staff = staffE <<
                    \set Staff.instrumentName = "I"
                    \set Staff.shortInstrumentName = "I"

                    \mvtIvlnI
                >>
                \new Staff = staffF <<
                    \set Staff.instrumentName = "II"
                    \set Staff.shortInstrumentName = "II"

                    \mvtIvlnII
                >>
            >>
            \new Staff = staffG <<
                \set Staff.instrumentName = "Viola"
                \set Staff.shortInstrumentName = "Vla."

                \mvtIvla
            >>
         >>
         \new ChoirStaff <<
            \new Staff = staffH <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Soprano"}
                                                "Cornetto"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = mvtIsoprano { \clefSoprano \mvtIsoprano }
                \new Lyrics \lyricsto mvtIsoprano \mvtIsopranoLyrics
            >>
            \new Staff = staffI <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Alto"}
                                                "Trombone I"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"A."}

                \new Voice = mvtIalto { \clefAlto \mvtIalto }
                \new Lyrics \lyricsto mvtIalto \mvtIaltoLyrics
            >>
            \new Staff = staffJ <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Tenore"}
                                                "Trombone II"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"T."}

                \new Voice = mvtItenor { \clefTenor \mvtItenor }
                \new Lyrics \lyricsto mvtItenor \mvtItenorLyrics
            >>
            \new Staff = staffK <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Basso"}
                                                "Trombone III"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"B."}

                \new Voice = mvtIbass { \mvtIbass }
                \new Lyrics \lyricsto mvtIbass \mvtIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffL <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                \mvtIbc
                \mvtIfigs
            >>
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIpiece
    }

    \layout {
        \context {
            \Staff {
                \override VerticalAxisGroup.staff-staff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2)
                       (padding . 1.0)
                       (stretchability . 70))
            }
        }
        \context {
            \Lyrics {
                \override VerticalAxisGroup.nonstaff-unrelatedstaff-spacing =
                    #'((basic-distance . 4)
                       (minimum-distance . 2)
                       (padding . 0.8)
                       (stretchability . 70))
                \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
                    #'((basic-distance . 2)
                       (minimum-distance . 1)
                       (padding . 0.4)
                       (stretchability . 40))
            }
        }
    }

    \midi{ }
}
% %}


% %{
\score {
   \keepWithTag #'( SCORE CELLO ORGAN ) \new StaffGroup <<
        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\center-column{"Flauto Traverso" "o Violino solo"}
            \set Staff.shortInstrumentName = \markup\center-column{"Fl. o" "Vln."}

            \mvtIIfl
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\bold{"Tenore"}
            \set Staff.shortInstrumentName =  \markup\bold{"T."}

            \new Voice = mvtIItenor { \clefTenor \mvtIItenor }
            \new Lyrics \lyricsto mvtIItenor \mvtIIlyrics
        >>
        \new Staff = staffC <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = \markup{"B.C."}

            \mvtIIbc
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIpiece
    }

    \layout {
        indent = #28
    }

    \midi{ }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) \new StaffGroup <<
        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\bold{"Soprano"}
            \set Staff.shortInstrumentName = \markup\bold{"S."}

            \stretchHorizontalSpacing #-0.5
            \new Voice = mvtIIIsoprano \clefSoprano \mvtIIIsoprano
            \new Lyrics \lyricsto mvtIIIsoprano \mvtIIIlyrics
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = \markup{"B.C."}

            \mvtIIIbc
            \mvtIIIfigs
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIIpiece
    }

    \layout { }
    \midi{ }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) <<
        % \new Dynamics \mvtIVbreaks

        \new StaffGroup <<
            \new GrandStaff <<
                \set GrandStaff.instrumentName = "Oboe"
                \set GrandStaff.shortInstrumentName = "Ob."

                \new Staff = staffA <<

                    \set Staff.instrumentName = "1"
                    \set Staff.shortInstrumentName = "1"

                    \mvtIVobI
                >>
                \new Staff = staffB <<
                    \set Staff.instrumentName = "2"
                    \set Staff.shortInstrumentName = "2"

                    \mvtIVobII
                >>
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = "Taille"
                \set Staff.shortInstrumentName = "Tlle."

                \clefTaille
                \transpose \transpTaille c \mvtIVtaille
            >>
        >>

        \new Staff = staffD <<
            \set Staff.instrumentName = \markup\bold{"Basso"}
            \set Staff.shortInstrumentName = \markup\bold{"B."}

            \new Voice = mvtIVbass \mvtIVbass
            \new Lyrics \lyricsto mvtIVbass \mvtIVlyrics
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                \mvtIVbc
            >>
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIVpiece
    }

    \layout { }
    \midi{ }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) \new StaffGroup <<
        \new Staff = staffA <<
            \set Staff.instrumentName = \markup\bold{"Tenore"}
            \set Staff.shortInstrumentName = \markup\bold{"T."}

            \new Voice = mvtVtenor \clefTenor \mvtVtenor
            \new Lyrics \lyricsto mvtVtenor \mvtVlyrics
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
            \set Staff.shortInstrumentName = \markup{"B.C."}

            \mvtVbc
            \mvtVfigs
        >>
        % \new Staff = staffC <<
            % \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo."}
            % \set Staff.shortInstrumentName = \markup{"B.C."}
            % 
            % \transpose d c \mvtVbc
            % \mvtVfigs
        % >>
    >>

    \header {
        piece = \mvtVpiece
        breakbefore = ##t
    }

    \layout { }
    \midi{ }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) <<
        % \new Dynamics \mvtVIbreaks

        \new StaffGroup <<
            \new Staff = staffA <<

                \set Staff.instrumentName = \markup\center-column{"Flauto" "Traverso"}
                \set Staff.shortInstrumentName = \markup{"Fl."}

                \mvtVIfl
            >>
            \new Staff = staffB <<
                \set Staff.instrumentName = \markup\center-column{"Oboe" "da Caccia"}
                \set Staff.shortInstrumentName = \markup\center-column{"Ob." "daC."}

                \transpose \transpObDaC c { \clefObDaC \mvtVIobdc }
            >>
        >>

        \new ChoirStaff <<
            \new Staff = staffC <<
                \set Staff.instrumentName = \markup\bold{"Soprano"}
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = mvtVIsoprano { \clefSoprano \mvtVIsoprano }
                \new Lyrics \lyricsto mvtVIsoprano \mvtVIlyricsSoprano
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup\bold{"Alto"}
                \set Staff.shortInstrumentName = \markup\bold{"A."}

                \new Voice = mvtVIalto { \clefAlto \mvtVIalto }
                \new Lyrics \lyricsto mvtVIalto \mvtVIlyricsAlto
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                \mvtVIbc
            >>
        >>
    >>

    \header {
        piece = \mvtVIpiece
        breakbefore = ##t
    }

    \layout { }
    \midi{ }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE CELLO ORGAN ) <<
        \new ChoirStaff <<
            \new Staff = staffA <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Soprano"}
                                                "Fl. in 8va, Ob.I"
                                                "Cornetto,Vln.I"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"S."}

                \new Voice = mvtVIIsoprano {
                    \horizontalSpacingLoose
                    \clefSoprano \autoBeamOff \mvtVIIsoprano
                }
                \new Lyrics \mvtVIIsopranoLyrics
            >>
            \new Staff = staffB <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Alto"}
                                                "Ob.II,Trom.I"
                                                "Vln.II"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"A."}
                \set Staff.aDueText = ""

                \partcombine
                    { \clefAlto \autoBeamOff \mvtVIIobII }
                    { \clefAlto \autoBeamOff \mvtVIIalto }
                {
                    s4 | %0
                    s1 | %1
                    s4 s2.^\markup\center-align{Oboe II} | %2
                    s1 | %3
                    s4 s2.^\markup\center-align{Oboe} | %4
                    s1*2 | %6
                    s2. s4^"Oboe" | %7
                    s1*3 | %10
                    s2. s4^"Oboe" | %11
                }
                \new Lyrics \mvtVIIaltoLyrics
            >>
            \new Staff = staffC <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Tenore"}
                                                "Taille,Trom.II"
                                                "Vla"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"T."}
                \set Staff.aDueText = ""

                \partcombine
                    { \clefTenor \autoBeamOff \mvtVIItaille }
                    { \clefTenor \autoBeamOff \mvtVIItenor }
                {
                    s4 | %0
                    s1 | %1
                    s1^"Taille" | %2
                    s1 | %3
                    s1^"Taille" | %4
                    s1*6 | %9
                    s1^"Taille" | %10
                }
                \new Lyrics \mvtVIItenorLyrics
            >>
            \new Staff = staffD <<
                \set Staff.instrumentName = \markup\center-column{
                                                \bold{"Basso"}
                                                "Trom.III"
                                            }
                \set Staff.shortInstrumentName = \markup\bold{"B."}

                \new Voice = mvtVIIbass { \autoBeamOff \mvtVIIbass }
                \new Lyrics \mvtVIIbassLyrics
            >>
        >>

        \new StaffGroup <<
            \new Staff = staffE <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{"B.C."}

                \mvtVIIbc
            >>
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVIIpiece
    }

    \layout {
        \context {
            \Staff {
                \set Staff.aDueText = ""
            }
        }
        indent = #26
    }

    \midi{ }
}
% %}
