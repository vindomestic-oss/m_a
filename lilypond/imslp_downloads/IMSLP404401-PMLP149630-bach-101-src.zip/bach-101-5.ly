\version "2.19.11"

\include "common.ly"


mvtVtimeLine = {
    \time 4/4
    \key d \minor

    s1*3 | %3
    s2 \tempo "Recit." s2 | %4
    s1 | %5
    s2 \tempo "a tempo" s2 | %6
    s1*2 | %8
    s2 \tempo "(Recit.)" s2 | %9
    s1*4 | %13
    \tempo "(a tempo)"
    s1*5 | %18
    s2 \tempo "(Recit.)" s2 | %19
    s1*2 | %21
    s2 \tempo "a tempo" s2 | %22
    s1*2 | %24
    \bar "||"
    \tempo "(Recit.)"
    s1*2 | %26
    \tempo "(a tempo)"
    s1*5 |
    \bar "|."
}


mvtVtenor = <<
\relative c' {
    \autoBeamOff

    R1 | % bar 1
    r2 r4 a4 | % bar 2
    a4 g8[ f8] g4 a4 | % bar 3
    f4 e4 d8 r16 d'16 d8 a8 | % bar 4
    fis'8 fis8 a8 d,8 g8 g8 r16 g,16 g16 g16 | % bar 5
    es'8 es8 es8 d8 bes8 bes8 r4 | % bar 6
    r2 r4 a4 | % bar 7
    a4 g4 c4 a4 | % bar 8
    f4 g4 a4 r8 e'8 | % bar 9
    r8 g,16 a16 bes8 g8 fis'4 r8 a,8 | % bar 10
    a'8 fis8 dis8. e16 fis8 a,8 c8 b8 | % bar 11
    g8 r16 b16 e8 fis8 g8 d8 b8 d8 | % bar 12
    e8 e8 r16 e16 e16 b16 gis8 gis8 f'8 e8 | % bar 13
    c8 c8 r4 r2 | % bar 14
    r4 a4 c4 d8[ e8] | % bar 15
    f4 e4 d4 cis4 | % bar 16
    d4 r4 r4 d4 | % bar 17
    e4 d4 c4 b4 | % bar 18
    a4 gis8[( a16 b16)] a4 r8 cis8 | % bar 19
    a8 a8 gis8 \once \set suggestAccidentals = ##t fis8 dis'8 dis8 fis8 b,8 | % bar 20
    e4 r8 b8 f'8 f8 f8 d8 | % bar 21
    b8 d8 e8 b8 c4 r4 | % bar 22
    r4 d4 c4 b4 | % bar 23
    c8[ bes8] a4 a4 g4 | % bar 24
    f4 r8 c'8 a'8 c,8 es8 d8 | % bar 25
    bes8 bes8 r8 g'8 cis,8 d8 e8 a,8 | % bar 26
    f'8 f8 r4 r2 | % bar 27
    r4 a,4 bes4 a8[ g] | % bar 28
    f4 g4 f4 e4 | % bar 29
    d4 r4 r2 | % bar 30
    R1 |
}
\mvtVtimeLine
>>


mvtVlyrics = \lyricmode {
    Die Sünd hat uns ver -- der -- bet sehr,
    so mü -- ßen auch die Fromm -- sten sa -- gen,
    und mit be -- trän -- ten Au -- gen kla -- gen:
    Der Teu -- fel plagt uns noch viel mehr.
    Ja, die -- ser bö -- se Geist,
    der schon von An -- be -- ginn ein Mör -- der heißt,
    sucht uns um un -- ser Heil zu brin -- gen
    und als ein Lö -- we zu ver -- schlin -- gen.
    Die Welt, auch un -- ser Fleisch und Blut
    uns al -- le -- zeit ver -- füh -- ren __ tut.
    Wir tref -- fen hier auf die -- ser schma -- len Bahn
    sehr vie -- le Hin -- der -- nis im Gu -- ten an.
    Solch E -- lend kennst du, Herr, al -- lein:
    hilf, Hel -- fer, hilf uns Schwa -- chen,
    du kannst uns stär -- ker ma -- chen!
    Ach, laß uns dir be -- foh -- len sein! 
}


mvtVbc = <<
\relative c' {
    \clef F
    \overrideTimeSignatureSettings
	#'(4 . 4)         % timeSignatureFraction
	#'(1 . 2)         % baseMomentFraction
	#'(1 1)           % beatStructure
	#'()
            %{
	    (end .
	     (
	      ((1 . 8) . (4 4))
	      ((1 . 16) . (4 4 4 4))
	      ((1 . 24) . (3 3 3 3 3 3 3 3))
	      ((1 . 32) . (4 4 4 4 4 4 4 4))
	     ))
	  )               % beamExceptions
          %}

    r8 a8 f8 g16 a16 bes8 g8 e8 f16 g16 | % bar 1
    a8 f8 d8 e16 f16 g8 e8 cis8 d16 e16 | % bar 2
    f8 d8 b8 cis16 d16 e8 cis8 a8 b16 cis16 | % bar 3
    d8 bes8 g8 a16 bes16 c2~ | % bar 4
    c2 bes2 | % bar 5
    a2 g8 g'8 e8 f16 g16 | % bar 6
    a8 f8 d8 e16 f16 g8 e8 cis8 d16 e16 | % bar 7
    f8 d8 b8 cis16 d16 e8 a8 f8 g16 a16 | % bar 8
    bes8 g8 e8 f16 g16 cis,2~ | % bar 9
    cis2 c2~ | % bar 10
    c2 <\tag CELLO dis,2 \tag ORGAN dis'2 > | % bar 11
    <\tag CELLO e \tag ORGAN e'>2 b'2 | % bar 12
    gis1 | % bar 13
    a8 e'8 c8 d16 e16 f8 d8 b8 c16 d16 | % bar 14
    e8 c8 a8 r8 r8 a8 f8 g16 a16 | % bar 15
    d,8 a''8 f8 g16 a16 bes8 g8 e8 fis16 g16 | % bar 16
    fis8 c'8 a8 b16 c16 d8 b8 g8 a16 b16 | % bar 17
    c8 gis8 e8 fis16 gis16 a8 e8 cis8 dis16 eis16 | % bar 18
    f8 d8 b8 cis16 d16 fis,2~ | % bar 19
    fis1 | % bar 20
    gis1~ | % bar 21
    gis2 a8 a'8 fis8 gis16 a16 | % bar 22
    bes8 gis8 e8 fis16 gis16 a8 f8 d8 e16 f16 | % bar 23
    e8 g8 c,8 d16 e16 f8 d8 bes8 c16 d16 | % bar 24
    es4 fis,2. | % bar 25
    g1 | % bar 26
    d8 a''8 f8 g16 a16 bes8 g8 e8 f16 g16 | % bar 27
    a8 f8 d8 e16 f16 g8 e8 cis8 d16 e16 | % bar 28
    d8 bes'8 e,8 f16 g16 a8 f8 cis8 d16 e16 | % bar 29
    fis8 d8 a8 bes16 c16 d8 bes8 g8 a16 bes16 | % bar 30
    d,2 r2 | % bar 31
}
\mvtVtimeLine
>>


mvtVfigs = \figuremode {
    s8 <_+> s2. | %1
    s1*2 | %3
    s2 <6 4\+ 2> | %4
    s <6> | %5
    <6\\ 5-> s | %6
    s1*2 | %8
    s2. <7- 5>4 | %9
    s2 <6 4\+ 2> | %10
    <[4\+ 2]> <7- 5> | %11
    <5\+> <6> | %12
    <6>2. <5>4 | %13
    s1*4 | %17
    s2. <7 5\+ _+>4 | %18
    <5\+> <6\\ 4\+ 2\+> <5\+>2 | %19
    <5\+> <6\\> | %20
    <6> <7- 5> | %21
    s4 <[6]> s2 | %22
    s1 | %23
    s2. <6 5>8 <[5 3]> | %24
    <6 4 2>4 <7- 5>2. | %25
    s2 <4\+ 2> | %26
    s1*5 |
}
