\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Oboe II"
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \mvtIobII
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \mvtIVobII
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIVpiece
    }
}

\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \new Staff = staffE <<
        \mvtVIIalto
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
