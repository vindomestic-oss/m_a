\version "2.19.15"

% transpChorton = d

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"
\pageBreak
\middleBackPage
\pageBreak

\header {
    instrument = "Continuo Beziffert"
}

\paper {
    % ragged-bottom = ##t
    ragged-last-bottom = ##f
    % page-count = #14
}

%{
\layout {
    \context {
        \FiguredBass {
            \override BassFigure #'font-size = #-1.0
        }
    }
    \context {
        \Staff {
            \override BassFigureAlignmentPositioning.direction = #UP
        }
    }
}
%}

#(set-global-staff-size 18)
mvtIbreaksAutograph = {
    <>^"Autograph breaks left in"

    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak } s2 \bar ""
    \break\noPageBreak
    s2 \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 11 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 13 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 12 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 7 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \bar "||"
}


\score {
    \transpose \transpChorton c <<
        % \new Dynamics \mvtIbreaksAutograph

        \new Staff = staffL <<
            \keepWithTag #'( PARTS ORGAN ) { \mvtIbc }
            \mvtIfigs
        >>
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}


\score {
    \new Staff = staffC \transpose \transpChorton c <<
        \keepWithTag #'( PARTS ORGAN ) { \mvtIIbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIpiece
    }
}

\markup\null
\pageBreak
\blankPage

\score {
    \new StaffGroup \transpose \transpChorton c <<
        \new Staff = mvtIIIsoprano \with { \staffSize #-3 } <<
            \set Staff.instrumentName = \markup\bold{\normalsize "Soprano"}

            \new Voice = mvtIIIsoprano \clefSoprano \mvtIIIsoprano
            \new Lyrics \with {
                alignBelowContext = "mvtIIIsoprano"
                \override LyricText #'font-size = #-1
            } {
                \lyricsto mvtIIIsoprano \mvtIIIlyrics
            }
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \keepWithTag #'( PARTS ORGAN ) { \mvtIIIbc }
            \mvtIIIfigs
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIIpiece
    }

    \layout {
        indent = #20
    }
}


\score {
    \new Staff = staffE \transpose \transpChorton c <<
        \keepWithTag #'( PARTS ORGAN ) { \mvtIVbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIVpiece
    }
}


\score {
    \new StaffGroup \transpose \transpChorton c <<
        \new Staff = mvtVtenor \with { \staffSize #-3 } <<
            \set Staff.instrumentName = \markup\bold{\normalsize "Tenore"}

            \new Voice = mvtVtenor \clefTenor \mvtVtenor
            \new Lyrics \with {
                alignBelowContext = "mvtVtenor"
                \override LyricText #'font-size = #-1
            } {
                \lyricsto mvtVtenor \mvtVlyrics
            }
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \keepWithTag #'( PARTS ORGAN ) { \mvtVbc }
            \mvtVfigs
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVpiece
    }

    \layout {
        indent = #20
    }
}


\score {
    \new Staff = staffE \transpose \transpChorton c <<
        \horizontalSpacingLoose
        \keepWithTag #'( PARTS ORGAN ) { \mvtVIbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVIpiece
    }
}


\score {
    \new Staff = staffE \transpose \transpChorton c <<
        \keepWithTag #'( PARTS ORGAN ) { \mvtVIIbc }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
