\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = \markup{\center-column{\line{Trombone III} \line{\transpInstr}}}
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
}


\addQuote mvtIobI { \keepWithTag SCORE \mvtIobI }
\addQuote mvtIalto { \keepWithTag SCORE \mvtIalto }
\addQuote mvtItenor { \keepWithTag SCORE \mvtItenor }
mvtIcues = \new CueVoice {
    s1*24 | %24
    \cueDuringWithClef mvtIobI #UP #"treble" { s1*5^"Ob.I,Vln.I" | } | %29
    s1*34 | %63
    s2 \cueDuringWithClef mvtItenor #DOWN #"tenor" { s2^"Trom.II" | s1*4 | } | %68
    s1*31 | %99
    s2 \cueDuringWithClef mvtItenor #UP #"tenor" { s2^"Trom.II" | s1*10 } | %110
    s1*22 | %132
    \cueDuringWithClef mvtIobI #UP #"treble" { s1*8^"Ob.I" } | %140
    s1*37 | %177
    s2 \cueDuringWithClef mvtItenor #UP #"tenor" { s2^"Trom.II" | s1*3 | } | %181
    s1*30 | %211
    s2 \cueDuringWithClef mvtIalto #UP #"alto" { s2^"Trom.I" | s1*2 | } | %214
}

\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffL <<
        \mvtIbass
        \mvtIcues
        { s1*177 | \pageBreak }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffE <<
        \mvtVIIbass
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
