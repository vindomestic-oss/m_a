\version "2.19.11"

\include "common.ly"


mvtVIItimeLine = {
    \time 4/4
    \partial 4
    \key d \minor

    s4 |
    s1*11 |
    s2. \bar "|."
}


mvtVIIsoprano = <<
\relative c'' {
    a4 | % bar 0
    a4 f4 g4 a4 | % bar 1
    f4 e4 d4\fermata a'4 | % bar 2
    a4 g4 c4 a4 | % bar 3
    f4 g4 a4\fermata a4 | % bar 4
    c4 d8[ e8] f4 e4 | % bar 5
    d4 cis4 d4\fermata d4 | % bar 6
    e4 d4 c4 b4 | % bar 7
    a4 \tag INSTR { <>-\trill } b4 a4\fermata d4 | % bar 8
    c4 b4 c4 a4 | % bar 9
    a4 g4 f4\fermata a4 | % bar 10
    bes4 a8[ g8] f4 g4 | % bar 11
    f4 e4 d4\fermata % bar 12
}
\mvtVIItimeLine
>>

mvtVIIsopranoLyrics = \lyricmode {
    Leit4 uns mit dei -- ner rech -- ten Hand
    und seg -- ne un -- ser Stadt und Land;
    gib uns all8 -- _ zeit4 dein heil -- ges Wort,
    Be -- hüt fürs Teu -- fels List und Mord;
    ver -- leih ein sel -- ges Stün -- de -- lein,
    auf daß wir8 _ e4 -- wig bei dir sein!
}


mvtVIIalto = <<
\relative c' {
    f4 | % bar 0
    e4 d4 d4 d4 | % bar 1
    d4 cis4 a4\fermata f'4 | % bar 2
    f4 g8[ f8] e4 f4 | % bar 3
    d4 d4 cis4\fermata d4 | % bar 4
    e4 g4 a4 g4 | % bar 5
    f8[ g8] a4 a4\fermata g4 | % bar 6
    g4 fis8[( gis8)] a4 e4 | % bar 7
    e8[( a8)] a8[( gis8)] e4\fermata d4 | % bar 8
    e4 f4 g4 f4 | % bar 9
    f4 e4 c4\fermata d4 | % bar 10
    d4 cis4 d4 e4 | % bar 11
    cis8( d4) cis8 a4\fermata % bar 12
}
\mvtVIItimeLine
>>

mvtVIIaltoLyrics = \lyricmode {
    Leit4 uns mit dei -- ner rech -- ten Hand
    und seg -- ne un -- ser Stadt und Land;
    gib uns all -- zeit dein heil8 -- _ ges4 Wort,
    Be -- hüt fürs8 _ Teu4 -- fels List8 _ und _ Mord;4
    ver -- leih ein sel -- ges Stün -- de -- lein,
    auf daß wir e -- wig bei8 _4 dir8 sein!
}


mvtVIIobII = <<
\relative c' {
    f4 | % bar 0
    e4 d4 d4 d4 | % bar 1
    d4 cis4 \partcombineApartOnce d\fermata f4 | % bar 2
    f4 g8[ f8] e4 f4 | % bar 3
    d \partcombineApartOnce g \partcombineApartOnce e\fermata d | % bar 4
    e4 g4 a4 g4 | % bar 5
    f8[ g8] a4 a4\fermata g4 | % bar 6
    g4 fis8[( gis8)] a4 e4~ | % bar 7
    e8 a4 gis8 e4\fermata d4 | % bar 8
    e4 f4 g4 f4 | % bar 9
    f4 e4 c4\fermata d4 | % bar 10
    d4 cis4 d4 e4~ | % bar 11
    e8 \partcombineApartOnce d4 cis8 \partcombineApartOnce d4\fermata % bar 12
}
\mvtVIItimeLine
>>


mvtVIItenor = <<
\relative c' {
    d4 | % bar 0
    a4 a4 bes4 a4 | % bar 1
    \partcombineApartOnce bes4 \partcombineApartOnce e,4 f4\fermata d'4 | % bar 2
    c4 c4 c4 c4 | % bar 3
    bes4 d,4 e4\fermata f4 | % bar 4
    a4 bes4 c4 bes8[ c8] | % bar 5
    d4 e4 f4\fermata b,4 | % bar 6
    c8[ b8] a4 d4 d4 | % bar 7
    c4 d4 c4\fermata g4 | % bar 8
    g4 d'4 c4 c4 | % bar 9
    d4 g,4 a4\fermata a4 | % bar 10
    g8[ f8] e4 bes'2~ | % bar 11
    bes8 a8 g8 a8 fis4\fermata % bar 12
}
\mvtVIItimeLine
>>

mvtVIItenorLyrics = \lyricmode {
    Leit4 uns mit dei -- ner rech8 -- _ ten4 Hand
    und seg -- ne un -- ser Stadt und Land;
    gib uns all -- zeit dein8 _ heil4 -- ges Wort,
    Be -- hüt8 _ fürs4 Teu -- fels List und Mord;
    ver -- leih ein sel -- ges Stün -- de -- lein,
    auf daß8 _ wir4 e2 -- _8 wig bei dir sein!4
}

mvtVIItaille = <<
\relative c' {
    d4 | % bar 0
    a4 a4 bes4 a4 | % bar 1
    bes8 a g4 f4\fermata d'4 | % bar 2
    c4 c4 c4 c4 | % bar 3
    bes4 \partcombineApartOnce d4 \partcombineApartOnce cis4\fermata f,4 | % bar 4
    a4 bes4 c4 bes8[ c8] | % bar 5
    d4 e4 f4\fermata b,4 | % bar 6
    c8[ b8] a4 d4 d4 | % bar 7
    c4 d4 c4\fermata g4 | % bar 8
    g4 d'4 c4 c4 | % bar 9
    d4 g,4 a4\fermata a4 | % bar 10
    d \partcombineApartOnce a d8 c bes4~ | % bar 11
    bes8 a8 g8 a8 \partcombineApartOnce a4\fermata % bar 12
}
\mvtVIItimeLine
>>


mvtVIIbass = <<
\relative c {
    \clef F

    d4 | % bar 0
    cis4 d4 bes'4 f4 | % bar 1
    g4 a4 d,4\fermata d8[ e] | % bar 2
    f4 e4 a4 f4 | % bar 3
    bes4 bes,4 a4\fermata d4 | % bar 4
    a'4 g4 f4 g8[ a8] | % bar 5
    bes4 a4 d,4\fermata g4 | % bar 6
    c,4 d8[ e8] fis4 gis4 | % bar 7
    a4 e4 a,4\fermata b4 | % bar 8
    c4 d4 e4 f4 | % bar 9
    bes,4 c4 f,4\fermata fis4 | % bar 10
    g4 a4 bes4 a8[ g8] | % bar 11
    a4 a4 d4\fermata % bar 12
}
\mvtVIItimeLine
>>

mvtVIIbassLyrics = \lyricmode {
    Leit uns mit dei -- ner rech -- ten Hand
    und8 _ seg4 -- ne un -- ser Stadt und Land;
    gib uns all -- zeit dein8 _ heil4 -- ges Wort,
    Be -- hüt fürs8 _ Teu4 -- fels List und Mord;
    ver -- leih ein sel -- ges Stün -- de -- lein,
    auf daß wir e -- wig8 _ bei4 dir sein!
}


mvtVIIbc = <<
\relative c {
    \clef F
    d4 | % bar 0
    cis4 d4 bes'4 f4 | % bar 1
    g4 a4 d,4\fermata d8 e8 | % bar 2
    f4 e4 a4 f4 | % bar 3
    bes4 bes,4 a4\fermata d4 | % bar 4
    a'4 g4 f4 g8 a8 | % bar 5
    bes4 a4 d,4\fermata g4 | % bar 6
    c,4 d8 e8 fis4 gis4 | % bar 7
    a4 e4 a,4\fermata b4 | % bar 8
    c4 d4 e4 f4 | % bar 9
    bes,4 c4 f,4\fermata fis4 | % bar 10
    g4 a4 bes4 a8 g8 | % bar 11
    a4 a4 d4\fermata % bar 12
}
\mvtVIItimeLine
>>
