\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Basso Continuo"
}

\paper {
    % ragged-bottom = ##t
    ragged-last-bottom = ##f
    % page-count = #12
}


\score {
    \new Staff = staffL <<
        \keepWithTag #'( PARTS CELLO ) { \mvtIbc }
        % \new Voice { \partLstaffAvoiceB }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}


\score {
    \new Staff = staffC <<
        \keepWithTag #'( PARTS CELLO ) { \mvtIIbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIpiece
    }
}

\markup\null\pageBreak
\blankPage

\score {
    \new StaffGroup <<
        \new Staff = mvtIIIsoprano \with { \staffSize #-3 } <<
            \set Staff.instrumentName = \markup\bold{\normalsize "Soprano"}

            \new Voice = mvtIIIsoprano \clefSoprano \mvtIIIsoprano
            \new Lyrics \with {
                alignBelowContext = "mvtIIIsoprano"
                \override LyricText #'font-size = #-1
            } {
                \lyricsto mvtIIIsoprano \mvtIIIlyrics
            }
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \keepWithTag #'( PARTS CELLO ) { \mvtIIIbc }
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIIpiece
    }

    \layout {
        indent = #20
    }
}


\score {
    \new Staff = staffE <<
        \keepWithTag #'( PARTS CELLO ) { \mvtIVbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIVpiece
    }
}


\score {
    \new StaffGroup <<
        \new Staff = mvtVtenor \with { \staffSize #-3 } <<
            \set Staff.instrumentName = \markup\bold{\normalsize "Tenore"}

            \new Voice = mvtVtenor \clefTenor \mvtVtenor
            \new Lyrics \with {
                alignBelowContext = "mvtVtenor"
                \override LyricText #'font-size = #-1
            } {
                \lyricsto mvtVtenor \mvtVlyrics
            }
        >>
        \new Staff = staffB <<
            \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}

            \keepWithTag #'( PARTS CELLO ) { \mvtVbc }
        >>
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVpiece
    }

    \layout {
        indent = #20
    }
}


\score {
    \new Staff = staffE <<
        \horizontalSpacingLoose
        \keepWithTag #'( PARTS CELLO ) { \mvtVIbc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVIpiece
    }
}


\score {
    \new Staff = staffE <<
        \keepWithTag #'( PARTS CELLO ) { \mvtVIIbc }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
