\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Oboe I (Oboe da Caccia)"
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
    indent = #16
}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \set Staff.instrumentName = \markup{"Oboe I"}

        \mvtIobI
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \set Staff.instrumentName = \markup{"Oboe I"}

        \mvtIVobI
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIVpiece
    }
}

\markup\Tacet{\mvtVpiece}


\score {
    \keepWithTag PARTS \new Staff = staffB <<
        \set Staff.instrumentName = \markup\center-column{"Oboe da" "Caccia"}

        \transpose \transpObDaC c { \clefObDaC \mvtVIobdc }
    >>

    \header {
        breakbefore = ##t
        piece = \mvtVIpiece
    }
}


\score {
    \keepWithTag PARTS \new Staff = staffE <<
        \set Staff.instrumentName = \markup{"Oboe I"}

        \mvtVIIsoprano
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
