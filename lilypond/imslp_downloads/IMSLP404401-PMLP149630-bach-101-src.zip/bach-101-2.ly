\version "2.19.11"

\include "common.ly"


mvtIItimeLine = {
    \time 3/4
    \key g \minor

    s2. | %1
    \segno
    s2.*73 |
    \dalSegno
    \bar "||"
}


% %{
% violin urtext
vdot = -.
vso = (
vsc = )
vTrill = -\trill
vP = \Pia
vTransp = c,
% %}
%{
% flute urtext
vdot = -\markup\null
vso = -\markup\null
vsc = -\markup\null
vTrill = -\markup\null
vP = -\markup\null
vTransp = c
%}


mvtIIfl = <<
\relative c'' {
    g16( a16 bes16) d16\vdot g16\vdot fis16\vdot g16\vdot d16\vdot bes16\vdot a16 bes16 g16 | % bar 1
    fis16( g16 a16) c16\vdot a'16 g16 a16 fis16 c16 bes16 c16 a16 | % bar 2
    % \slurDashed
        g16\vso a16 bes16\vsc d16\vdot bes'16 a16 bes16 g16 es16 d16 es16 c16 | % bar 3
    f,16\vso g16 a16\vsc c16\vdot a'16 g16 a16 f16 d16 c16 d16 bes16 | % bar 4
    es,16\vso f16 g16\vsc bes16\vdot g'16 f16 g16 es16 c16 bes16 c16 a16 | % bar 5
    d,16\vso e16 fis16\vsc a16 \slurSolid d16( e16 fis16) a16 d4 | % bar 6
    r16 % \slurDashed
        f,32\vso g32 as16\vsc f16\vdot d16 f16 b,16 f'16 g,16 f'16 es16 d16 | % bar 7
    es32\vso c32 d32 es32 f32 g32 a32 b32 c16\vsc g16\vdot es16\vdot c16\vdot bes8.\vTrill a32 g32 | % bar 8
    \slurSolid a16( c32 bes32 a16) c16\vdot fis16 c16 g'16 c,16 a'16 es16 d16 c16 | % bar 9
    % \slurDashed
       bes32\vso g'32 f32 es32 d32 c32 bes32 a32 g16\vsc bes16 d16 g16 bes16 fis16 g16 d16 | % bar 10
    es16\vso \once \set suggestAccidentals = ##t fis16 g16\vsc c16\vdot g16 es16 g16 d16 c16 fis!16 g16 a16 | % bar 11
    d,16\vso fis16 g16\vsc bes16\vdot g16 d16 g16 c,16 bes16 g'16 a16 bes16 | % bar 12
    c,16\vso d16 es16\vsc a16\vdot es16 c16 es16 bes16 a16 a'16 bes16 c16 | % bar 13
    fis,16\vso es16 d16\vsc a'16\vdot c,16 es16 a,16 es'16 fis,16 es'16 d16 c16 | % bar 14
    bes16\vso a16 g16\vsc a16\vdot bes16 g16 b16 g16 c16 g16 d'16 g,16 | % bar 15
    es'16 g,16 e'16 g,16 cis16 fis16 g16 bes,16 a8.\vTrill g16 | % bar 16
    g16\vso a16 bes16\vsc d16\vdot g16\vso a16 bes16\vsc d16\vdot g4\fermata | % bar 17
    R2.*7 | % bar 18
    g,,16\vP\vso a16 bes16\vsc d16\vdot g16 fis16 g16 d16 bes16 a16 bes16 g16 | % bar 25
    fis16\vso g16 a16\vsc c16\vdot a'16 g16 a16 fis16 c16 bes16 c16 a16 | % bar 26
    g16\vso a16 bes16\vsc d16\vdot bes'4 r4 | % bar 27
    c,16\vso d16 es16\vsc g16\vdot c16 bes16 c16 g16 es16 d16 es16 c16 | % bar 28
    f,16\vso g16 a16\vsc c16\vdot es4 r4 | % bar 29
    bes16\vP\vso c16 d16\vsc f16\vdot bes16 a16 bes16 f16 d16 c16 d16 bes16 | % bar 30
    es,16\vso f16 g16\vsc bes16\vdot d4 r4 | % bar 31
    a16\vP\vso bes16 c16\vsc fis16\vdot a16 g16 a16 fis16 c16 bes16 c16 a16 | % bar 32
    d,16\vso e16 fis16\vsc a16\vdot c4 r4 | % bar 33
    R2. | % bar 34
    d16\vP\vso es16 f16\vsc bes16\vdot f16 d16 f16 c16 bes16 e16 f16 g16 | % bar 35
    c,16\vso e16 f16\vsc a16\vdot f16 c16 f16 bes,16 a16 f'16 g16 a16 | % bar 36
    bes,16\vso c16 d16\vsc g16\vdot d16 bes16 d16 a16 g16 g'16 a16 bes16 | % bar 37
    a16\vso g16 f16\vsc c'16\vdot es,16 g16 c,16 g'16 a,16 g'16 f16 es16 | % bar 38
    d16\vso c16 bes16\vsc c16\vdot d16 bes16 es16 bes16 f'16 bes,16 g'16 bes,16 | % bar 39
    a'16 f16 bes16 f16 c'16 es,16 d16 bes'16 c,16 f16 bes16 a16 | % bar 40
    bes4 r4 r4 | % bar 41
    g,16\vP\vso as16 bes16\vsc es16\vdot bes16 g16 bes16 f16 es16 g16 f16 es16 | % bar 42
    f16\vso a16 bes16\vsc d16\vdot bes16 f16 bes16 es,16 d16 f16 es16 d16 | % bar 43
    es16\vso f16 g16\vsc bes16\vdot c16 g16 d'16 g,16 es'16 c16 e16 bes16 | % bar 44
    a16\vso bes16 c16\vsc e16\vdot f16 c16 g'16 c,16 as'16 f16 a16 f16 | % bar 45
    bes16 f16 c'16 f,16 d'16 bes16 g16 c16 f,16 bes16 c16 a16 | % bar 46
    bes4 r4 r4 | % bar 47
    g16\vP\vso a16 b16\vsc d16\vdot \transpose c \vTransp \relative c'' { f'16 es16 f16 d16 } b16 a16 b16 g16 | % bar 48
    c,16\vso d16 es16\vsc g16\vdot es'4 r4 | % bar 49
    a,,16\vso bes16 c16\vsc fis16\vdot a16 g16 a16 fis16 c16 bes16 c16 a16 | % bar 50
    fis16\vso g16 a16\vsc c16 a'2~ | % bar 51
    a8 d,,16 es16 f16 d16 fis16 d16 g16 d16 a'16 d,16 | % bar 52
    bes'16\vso a16 g16\vsc a16\vdot bes16 g16 b16 g16 c16 g16 d'16 g,16 | % bar 53
    es'16\vso d16 c16\vsc d16\vdot es16 c16 e16 c16 fis16 c16 g'16 c,16 | % bar 54
    a'16\vso g16 fis16\vsc g16\vdot a16 d, bes'16 d,16 c'16 d,16 bes'16 d,16 | % bar 55
    e16\vso f16 g16\vsc bes16\vdot cis16 g16 d'16 g,16 e'16 g,16 a16 e16 | % bar 56
    fis16\vso g16 a16\vsc d16\vdot d,4 r4 | % bar 57
    r8 g,16\vP a16 bes16 g16 b16 g16 c16 g16 d'16 g,16 | % bar 58
    es'16 d16 c16 d16 es16 c16 e16 c16 fis16 c16 g'16 c,16 | % bar 59
    a'16 g16 fis16 g16 a16 d,16 bes'16 d,16 c'16 bes16 c16 a16 | % bar 60
    fis16\vso g16 a16\vsc c16\vdot es8 r8 r4 | % bar 61
    g,,16\vP\vso a16 bes16\vsc d16\vdot g16 fis16 g16 d16 bes16 a16 bes16 g16 | % bar 62
    fis16\vso g16 a16\vsc c16\vdot a'16 g16 a16 fis16 c16 bes16 c16 a16 | % bar 63
    g16\vso a16 bes16\vsc d16\vdot bes'16 a16 bes16 g16 es16 d16 es16 c16 | % bar 64
    f,16\vso g16 as16\vsc c16\vdot as'16 g16 as16 f16 d16 c16 d16 bes16 | % bar 65
    es,16\vso f16 g16\vsc bes16\vdot g'16 f16 g16 es16 c16 bes16 c16 a16 | % bar 66
    d,16\vso e16 fis16\vsc a16\vdot d16\vso e16 fis16\vsc a16\vdot d4 | % bar 67
    R2. | % bar 68
    g,,16\vso a16 b16\vsc d16\vdot g16 f16 g16 e16 cis16 b16 cis16 g16 | % bar 69
    a16\vso b16 cis16\vsc e16\vdot a16 g16 a16 fis16 es16 d16 es16 c16 | % bar 70
    d4~ d16 c16\vso bes16 a16\vsc g'16\vso fis16 e16\vsc d16\vdot | % bar 71
    d'2 r4 | % bar 72
    R2. | % bar 73
    g,,16\vso a16 bes16\vsc d16\vdot g16\vdot fis16\vdot g16\vdot d16\vdot bes16\vdot a16 bes16 g16 | % bar 74
}
\mvtIItimeLine
>>


mvtIItenor = <<
\relative c' {
    \autoBeamOff

    R2.*16 | % bar 1
    r4\fermata d8.[ es32 f32] es8[ d8] | % bar 17
    c4 a4.\trill( g16[ a16]) | % bar 18
    bes8[( d8] g8[ f8)] a,8[( bes8)] | % bar 19
    \appoggiatura f'8 es2\trill d4 | % bar 20
    r4 c4 a4 | % bar 21
    fis4( es'2)~ | % bar 22
    es8 d8 fis8[( g8)] es?8[( d8)] | % bar 23
    \appoggiatura c8 bes2\trill a4 | % bar 24
    bes16[( c16 d8)] d8[( bes8)] g4 | % bar 25
    c16[( d16 es8)] es8[( c8)] a4 | % bar 26
    bes4 a8[ g8] fis[ g] | % bar 27
    es'2.~ | % bar 28
    es8[ g8] g8 f8 bes,8[( a8)] | % bar 29
    d2.~ | % bar 30
    d8 g,8 g'8[( es8)] d8[( c8)] | % bar 31
    c2.~ | % bar 32
    c8 a8 fis8 es'8 es8 d8 | % bar 33
    \autoBeamOn bes16 \melisma d16 g,16 a16 bes16 c16 d16 es16 f16[ es16] \melismaEnd \autoBeamOff g16[ f16] | % bar 34
    f2.~ | % bar 35
    f2.~ | % bar 36
    f2.~ | % bar 37
    f4 r4 r4 | % bar 38
    f8 d8 bes8 c8 d8 g,8 | % bar 39
    es'4. g16[( f16)] es16[( d16)] c16[( bes16)] | % bar 40
    bes2.~ | % bar 41
    bes2.~ | % bar 42
    bes2. | % bar 43
    R2.*3 | % bar 44
    r4 bes16[( a16 bes16 d16 f8)] d8 | % bar 47
    b8[ as'8] g4 r4 | % bar 48
    r4 c,16[( b16 c16 es16 g8)] c,8 | % bar 49
    fis8 a,8 a16[( bes16)] c16[( d16)] \autoBeamOn es4~ \melisma | % bar 50
    es8 d8 d8 c8 c8 bes8 | % bar 51
    bes16 g16 cis16 d16 \melismaEnd \autoBeamOff \appoggiatura bes8 a4 r4 | % bar 52
    r4 d8.[( es32 f32)] es8[( d8)] | % bar 53
    c4 a4.( bes16[ c16]) | % bar 54
    fis,8[ es'8]~ es8[ d8] fis8[ g8] | % bar 55
    \appoggiatura d8 cis4 e8 cis8 a8 cis8 | % bar 56
    d4 a8 g16[ fis16] g8 a8 | % bar 57
    bes8 g8 \autoBeamOn g'4. \melisma f8 | % bar 58
    es8 d8 c4. bes8 | % bar 59
    a8 g8 fis8 e8 d4~ | % bar 60
    d16 e16 fis16 g16 a16 bes16 c16 a16 fis8. g16 | % bar 61
    \melismaEnd \autoBeamOff g4 bes16[( a16 bes16 d16 g8)] es8 | % bar 62
    es8[( d8]) d2 | % bar 63
    r4 d8[( bes8)] a8[( g8)] | % bar 64
    as8[ \melisma c8] es8[ d8]~ d8[ as8] | % bar 65
    g8[ bes8] d8[ c8]~ c8[ g8] | % bar 66
    fis8[ a8] \melismaEnd c2 | % bar 67
    r4 bes8 c8 d8 es8 | % bar 68
    f8 d8 \appoggiatura d8 e4. g,8 | % bar 69
    g'8 e8 fis4 r4 | % bar 70
    g8 f8 es8 d8 c4~ | % bar 71
    c8 bes8 \autoBeamOn a8[ \melisma g8] fis8 es'8~ | % bar 72
    es8 d8 bes4 a8 g8 \melismaEnd \autoBeamOff | % bar 73
    g2 r4 | % bar 74
}
\mvtIItimeLine
>>


mvtIIbc = <<
\relative c' {
    \clef F
    r4 bes4^"Pizzicato" g4 | % bar 1
    r4 fis4 d4 | % bar 2
    r4 g4 c,4 | % bar 3
    r4 f4 bes,4 | % bar 4
    r4 es4 es,4 | % bar 5
    r4 d8 d'8 d8 c8 | % bar 6
    b4 r4 r4 | % bar 7
    r4 c8 d8 d8 es8 | % bar 8
    fis,4 r4 r4 | % bar 9
    r4 g8 a8 a8 bes8 | % bar 10
    c8 c'8 c8 bes8 a4 | % bar 11
    bes,8 bes'8 bes8 a8 g4 | % bar 12
    a,8 a'8 a8 g8 fis8 e8 | % bar 13
    d8 d'8 d8 c8 bes8 a8 | % bar 14
    g,8 g'8 g8 f8 es8 d8 | % bar 15
    c8 bes8 a8 g8 d' d, | % bar 16
    g4\fermata bes'4 g4 | % bar 17
    r4 fis4 d4 | % bar 18
    g8 f8 es8 d8 c8 bes8 | % bar 19
    a8 g8 a8 f8 bes8 a8 | % bar 20
    g8 es'8 es8 d8 c8 bes8 | % bar 21
    a8 c'8 c8 bes8 a8 g8 | % bar 22
    fis4 es4 c4 | % bar 23
    cis8 d8 d8 e8 e8 fis8 | % bar 24
    g,4 r4 g'4 | % bar 25
    a,4 r4 d4 | % bar 26
    g8 f8 f8 es8 es8 d8 | % bar 27
    c8 c'8 c8 bes8 bes8 a8 | % bar 28
    a4 r4 f4 | % bar 29
    bes,8 bes'8 bes8 a8 a8 g8 | % bar 30
    g4 r4 es4 | % bar 31
    a,8 a'8 a8 g8 g8 fis8 | % bar 32
    fis4 r4 d4 | % bar 33
    g,8 g'8 g8 f8 f8 es8 | % bar 34
    d4 bes4 g4 | % bar 35
    r4 a4 f4 | % bar 36
    r8 bes8 bes8 a8 a8 g8 | % bar 37
    f8 f'8 f8 es8 d8 c8 | % bar 38
    bes4 r4 r4 | % bar 39
    c8 bes8 a8 bes8 f'8[ f,8] | % bar 40
    bes8 bes'8 bes8 as8 g8 f8 | % bar 41
    es,8 es' es8 d8 c4 | % bar 42
    d,8 d'8 d8 c8 bes4 | % bar 43
    c,8 es' es8 d8 c4 | % bar 44
    f,8 a'8 a8 g8 f8 es8 | % bar 45
    d8 c8 bes8 es8 f8 f,8 | % bar 46
    bes8 bes'8 bes8 as8 as8 g8 | % bar 47
    g,8 g'8 g8 f8 f8 es8 | % bar 48
    es8 a,8 a8 bes8 bes8 c8 | % bar 49
    d,4 r4 r4 | % bar 50
    r4 fis'4 d4 | % bar 51
    g,8 d'8 d8 c8 bes8 a8 | % bar 52
    g4 g'4 r4 | % bar 53
    r4 c,4 a4 | % bar 54
    d,2.~ | % bar 55
    d2.~ | % bar 56
    d8 d''8 d8 c8 bes8 a8 | % bar 57
    g4. f8 es8 d8 | % bar 58
    c4. bes8 a8 g8 | % bar 59
    fis4. g8 a8 bes8 | % bar 60
    c8 a8 fis8 g8 d'8 d,8 | % bar 61
    g4 r4 g'4 | % bar 62
    a4 r4 fis4 | % bar 63
    g4 r4 c,4 | % bar 64
    f,4 r4 bes4 | % bar 65
    es,4 r8 es'8 es8 c8 | % bar 66
    c8 a8 a8 fis8 fis8 d8 | % bar 67
    g4 r4 g'4 | % bar 68
    b,4 bes8 bes'8 g8 e8 | % bar 69
    cis4 c8 c'8 a8 fis8 | % bar 70
    bes,8 g8 c8 d8 es8 e8 | % bar 71
    fis8 g8 a8 bes8 c8 a8 | % bar 72
    fis8 g8 d4 d,4 | % bar 73
    g4 bes'4 g4 | % bar 74
}
\mvtIItimeLine
>>


mvtIIlyrics = \lyricmode {
    Han -- dle nicht nach __ dei -- nen Rech -- ten
    mit uns bö -- sen Sün -- den -- knech -- ten,
    han -- dle nicht, han -- dle nicht nach dei -- nen Rech -- ten
    mit uns bö -- sen Sün -- den -- knech -- ten,
    laß das Schwert der Fein -- de ruhn, __
    laß das Schwert der Fein -- de ruhn,
    der Fein -- de ruhn! __

    Höch -- ster, hö -- re, Höch -- ster, hö -- re un -- ser Fle -- hen,
    daß __ wir nicht durch __ sünd -- lich Tun,
    nicht durch sünd -- lich Tun,
    wie Je -- ru -- sa -- lem ver -- ge -- hen,
    Höch -- ster, hö -- re un -- ser Fle -- hen,
    daß __ wir nicht durch sünd -- lich Tun,
    durch sünd -- lich Tun,
    wie Je -- ru -- sa -- lem ver -- ge -- hen.
}
