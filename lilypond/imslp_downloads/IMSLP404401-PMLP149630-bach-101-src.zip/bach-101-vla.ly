\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Viola"
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
    page-count = #3
}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \mvtIvla
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece - \mvtIVpiece}
\markup\Tacet{\mvtVpiece - \mvtVIpiece}

\score {
    \keepWithTag PARTS \new Staff = staffE <<
        \clef alto \mvtVIItenor
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
