\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = "Cornetto"
}

\paper {
    % ragged-bottom = ##t
    ragged-last-bottom = ##f
}


\addQuote mvtIalto { \keepWithTag SCORE \mvtIalto }
\addQuote mvtIbass { \keepWithTag SCORE \mvtIbass }
mvtIcues = \new CueVoice {
    s1*35 | %35
    s2 \cueDuring mvtIalto #DOWN { s2^"Trom.I" | s1*2 } | %38
    s1*30 | %68
    s2 \cueDuringWithClef mvtIbass #UP #"bass" { s2^"Trom.III" | s1*3 } | %72
    s1*29 | %101
    s2 \cueDuring mvtIalto #DOWN { s2^"Trom.I" | s1*7 } | %109
    s1*34 | %143
    s2 \cueDuring mvtIalto #DOWN { s2^"Trom.I" | s1*4 } | %148
    s1*33 | %181
    s2 \cueDuringWithClef mvtIbass #UP #"bass" { s2^"Trom.III" | s1*4 } | %186
    s1*28 | %214
    s2 \cueDuringWithClef mvtIbass #UP #"bass" { s2^"Trom.III" | s1*4 } | %219
}

\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \mvtIsoprano
        \mvtIcues
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \new Staff = staffE <<
        \mvtVIIsoprano
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
