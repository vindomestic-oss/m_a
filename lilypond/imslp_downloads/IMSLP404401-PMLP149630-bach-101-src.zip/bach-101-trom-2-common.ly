\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = \markup{\center-column{\line{Trombone II} \line{\transpInstr}}}
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
}


\addQuote mvtIobI { \keepWithTag SCORE \mvtIobI }
\addQuote mvtIalto { \keepWithTag SCORE \mvtIalto }
\addQuote mvtIbass { \keepWithTag SCORE \mvtIbass }
mvtIcues = \new CueVoice {
    s1*24 | %24
    \cueDuringWithClef mvtIobI #UP #"treble" { s1*5^"Ob.I,Vln.I" | } | %29
    s2 \cueDuringWithClef mvtIbass #DOWN #"bass" { s2^"Trom.III" | s2 } s2 | %31
    s1*27 | %58
    \cueDuringWithClef mvtIobI #UP "treble" { s1*5^"Ob.I,Vln.I" | } | %63
    s1*30 | %93
    \cueDuringWithClef mvtIobI #UP "treble" { s1*6^"Ob.I,Vln.I" | } | %99
    s1*33 | %132
    \cueDuringWithClef mvtIobI #UP "treble" { s1*8^"Ob.I,Vln.I" | } | %140
    s1*31 | %171
    \cueDuringWithClef mvtIobI #UP "treble" { s1*6^"Ob.I,Vln.I" } | %177
    s1*34 | %211
    s2 \cueDuring mvtIalto #UP { s2^"Trom.I" | s2 } s2 | %213
}

\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffL <<
        \clefTromII \mvtItenor
        \mvtIcues
        { s1*171 | \pageBreak }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffE <<
        \clefTromII \mvtVIItenor
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
