\version "2.19.15"

\include "common-clefs-orig.ly"

\include "bach-101-score-common.ly"
