\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
% \include "bach-paged-title.ly"

\header {
    instrument = \markup{\center-column{\line{Trombone I} \line{\transpInstr}}}
}

\paper {
    % ragged-bottom = ##t
    % ragged-last-bottom = ##f
}

\addQuote mvtIobI { \keepWithTag SCORE \mvtIobI }
\addQuote mvtItenor { \keepWithTag SCORE \mvtItenor }
\addQuote mvtIbass { \keepWithTag SCORE \mvtIbass }
mvtIcues = \new CueVoice {
    s1*30 | %30
    s2 \cueDuring mvtItenor #DOWN { s2^"Trom.II" | s1*4 | } | %36
    s1*28 | %63
    s2 \cueDuring mvtItenor #DOWN { s2^"Trom.II" | s1*1 | } | %66
    s1*34 | %99
    s2 \cueDuring mvtItenor #DOWN { s2^"Trom.II" | s1*1 | } | %102
    s1*39 | %140
    s2 \cueDuring mvtItenor #DOWN { s2^"Trom.II" | s1*2 | } | %144
    s1*34 | %177
    s2 \cueDuring mvtItenor #DOWN { s2^"Trom.II" | s1*1 | } | %180
    s1*20 | %199
    \cueDuringWithClef mvtIobI #UP "treble" { s1*12^"Ob.I" | } | %213
}


\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffL <<
        \clefTromI \mvtIalto
        \mvtIcues
        { s1*199 | \pageBreak }
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}

% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece}
\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \transpose c \transpTrom \new Staff = staffE <<
        \clefTromI \mvtVIIalto
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
