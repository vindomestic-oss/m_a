\version "2.19.15"

\include "bach-101-1.ly"
\include "bach-101-2.ly"
\include "bach-101-3.ly"
\include "bach-101-4.ly"
\include "bach-101-5.ly"
\include "bach-101-6.ly"
\include "bach-101-7.ly"

\include "bach-101-title.ly"
\include "bach-paged-title.ly"

\header {
    instrument = "Violino I"
}

\paper {
    % ragged-bottom = ##t
    ragged-last-bottom = ##f
}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \mvtIvlnI
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtIpiece
    }
}


\score {
    \keepWithTag PARTS \new Staff = staffL <<
        \set Staff.instrumentName = \markup\center-column{"Flauto Traverso"
                                                          "o"
                                                          "Violino solo" }

        \mvtIIfl
    >>

    \header {
        breakbefore = ##t
        piece = \mvtIIpiece
    }

    \layout {
        indent = #32
    }
}

\markup\Tacet{\mvtIIIpiece}
\markup\Tacet{\mvtIVpiece}
\markup\Tacet{\mvtVpiece}
\markup\Tacet{\mvtVIpiece}


\score {
    \keepWithTag PARTS \new Staff = staffE <<
        \mvtVIIsoprano
    >>

    \header {
        % breakbefore = ##t
        piece = \mvtVIIpiece
    }
}
