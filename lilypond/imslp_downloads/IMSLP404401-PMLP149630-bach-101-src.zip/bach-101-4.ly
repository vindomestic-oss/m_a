\version "2.19.11"

\include "common.ly"


mvtIVtimeLine = {
    \key c \major

    \tempo "Vivace"
    s1 | %1
    \segno
    s1*7 | %8
    \tempo "Andante"
    s1*2 | %10
    \tempo "Vivace"
    s1*6 | %16
    \tempo "Andante"
    s1*2 | %18
    \tempo "Adagio" s1 | %19
    s2 s4. \tempo "Vivace" s8 | %20
    s1*17 | %37
    \tempo "Andante"
    s1*20 | %57
    s2 \tempo "Adagio" s2 | %58
    \tempo "Vivace"
    s1*8 | %66
    \dalSegno
    \bar "||"
}


mvtIVbreaks = {
    <>^"BGA breaks left in"

    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 3 { s1\noBreak }
    \break
    \repeat unfold 4 { s1\noBreak }
    \bar "|."
}


mvtIVobI = <<
\relative c'' {
    c16 a16 e'8~ e16 c16 a'16 gis16 \once \slurDotted a16( g16)( f16 e16 d16 c16 b16 a16) | % bar 1
    b16 g16 d'8~ d16 b16 g'16 fis16 \once \slurDotted g16( f16)( e16 d16 c16 b16 a16 g16) | % bar 2
    a16 f16 d'8~ d16 b16 f'16 e16 f16 d16 b'8~ b16 e,16 c'16 b16 | % bar 3
    \once \slurDotted c16( b16)( a16 g16 f16 e16 d16 c16) b16 e16 dis16 e16 e,4~ | % bar 4
    e16 fis16( gis16 a16 b8.) a16 gis16( a16 b16 c16 d8.) c16 | % bar 5
    b16( c16 d16 e16 f8) e16 d16 cis16 d16 e8-. a,16( b16 cis16 d16 | % bar 6
    e8.) d16 cis16( d16 e16 f16 g8.) f16 e16( f16 g16 a16 | % bar 7
    bes16 a16) d16( c16) b16( a16) gis16( a16) d,16 f16( e16 d16) c16( b16 a16 gis16) | % bar 8
    a8\fermata c8\Pia( b8 a8) r8 b8( a8 gis8) | % bar 9
    r8 d'8( c8 b8) r8 f'8( e8 d8) | % bar 10
    c16\Pia a16 e'8~ e16 c16 a'16 gis16 \once \slurDotted a16( g16)( f16 e16 d16 c16 b16 a16) | % bar 11
    d16 b16 gis'8~ gis16 d16 b'16 a16 \once \slurDotted b16( a16)( gis16 fis16 e16 d16 c16 b16) | % bar 12
    a16( b16 c16 d16 e8.) d16 cis16( d16 e16 f16 g8.) f16 | % bar 13
    e16( f16 g16 a16 bes8) a16 g16 f8 r8 r4 | % bar 14
    b,16( cis16 dis16 e16 fis8.) e16 dis16( e16 fis16 g16 a8.) g16 | % bar 15
    fis16( g16 a16 b16 c8) b16 a16 g8 r8 r4 | % bar 16
    r8 g8( fis8 e8) r8 fis8( e8 dis8) | % bar 17
    r8 a'8( g8 fis8) r8 c8( b8 a8) | % bar 18
    g1~\PPia | % bar 19
    g4 fis4 g4 r4\fermata | % bar 20
    r8 g'8\Pia-. e8-. c8-. r8 e16( fis16 g16 a16 b16 c16) | % bar 21
    d,8 g8-. d8-. b8-. r8 d16( e16 fis16 g16 a16 b16) | % bar 22
    c,8 g'8-. e8-. c8-. r8 fis16( e16 d16 c16 b16 a16) | % bar 23
    g16( a16 b16 c16 d8.) c16 b16( c16 d16 e16 f8.) e16 | % bar 24
    d16( e16 f16 g16 a8) g16 f16 e16 f16 g8-. c,16( d16 e16 f16 | % bar 25
    g8.) f16 e16( f16 g16 a16 bes8) r8 r4 | % bar 26
    r8 a8-. a8-. f8-. r8 a8-. a8-. f8-. | % bar 40
    r8 g8-. g8-. e8-. r8 g8-. g8-. e8-. | % bar 41
    r8 f8-. f8-. d8-. r8 f8-. f8-. d8-. | % bar 42
    r8 e8-. e8-. c8-. r8 fis,16( g16 a16 bes16) c8~ | % bar 43
    c16 bes16( a16 bes16 c16 d16 es8)~ es16 d16( c16 d16 es16 d16 es16) c16 | % bar 44
    \once \slurDotted g'16( f16)( e16 d16 c16 b16 a16 g16) r2 | % bar 45
    R1 | % bar 46
    e'16\For c16 g'8~ g16 e16 c'16 b16 \once \slurDotted c16( b16)( a16 g16 f16 e16 d16 c16) | % bar 47
    d16 b16 g'8~ g16 d16 b'16 a16 \once \slurDotted b16( a16)( g16 \once \set suggestAccidentals = ##t fis16 e16 d16 c16 b16) | % bar 48
    c16 a16 f'8~ f16 d16 b'16 a16 b16 g16 d'8~ d16 f, g d | % bar 49
    e8. f16 d8.\trill c16 c8 d16( e16 f16 g16 a16 b16) | % bar 50
    c8 r8 r4 r2 | % bar 51
    r8 bes,8\Pia( a8 g8) r4 e'4 | % bar 52
    e4 c4 d4 e4 | % bar 53
    c4 b4 a4 r4 | % bar 54
    r2 r4 e'4 | % bar 55
    e4 d4 g4 e4 | % bar 56
    c4 d4 e4 r4 | % bar 57
    r2 r4 e8( fis) | % bar 58
    g8( gis8) a8( b8) c4 b4 | % bar 59
    a4 gis4 a4 r4 | % bar 60
    r2 r4 a4 | % bar 61
    b4 a4 g4 fis4 | % bar 62
    e8. fis16 dis4\trill e4 r4 | % bar 63
    r2 r4 a4 | % bar 64
    g4 fis4 g4 e4 | % bar 65
    e8 f16( g16) d4\trill c4 r4 | % bar 66
    r2 r4 e4 | % bar 67
    f4 e8 d8 c4 d4 | % bar 68
    c4 b4 a2~ | % bar 69
    a2. d4~ | % bar 70
    d8 b8 c8 a8 d,4.\trill e8 | % bar 71
    e16( fis16 gis16 a16 b8.) a16 gis16( a16 b16 c16 d8.) c16 | % bar 72
    b16( c16 d16 e16 f8) e16 d16 cis16( d16) e8-. a,16( b16 cis16 d16 | % bar 73
    e8.) d16 cis16( d16 e16 f16 g8.) f16 e16( f16 g16 a16 | % bar 74
    bes8) r8 r4 r2 | % bar 75
    R1*3 | % bar 76
    c,16\For a16 e'8~ e16 d16 a'16 gis16 \once \slurDotted a16( g16)( f16 e16 d16 c16 b16 a16) | % bar 79
}
\mvtIVtimeLine
>>


mvtIVobII = <<
\relative c'' {
    r8 c16 b16 c8-. d8-. \once \slurDotted e16( d16)( c16 b16 a16 g16 f16 e16) | % bar 1
    r8 b'16 a16 b8-. c8-. \once \slurDotted d16( c16)( b16 a16 g16 f16 e16 d16) | % bar 2
    r8 a'16 gis16 a8-. d8-. r8 f16 e16 f8-. e8-. | % bar 3
    \once \slurDotted e16( g16)( f16 e16 d16 c16 b16 a16) gis8 a8 b8 c8 | % bar 4
    b8 e,16( fis16 gis16 a16 b8)~ b16 a16( gis16 a16 b16 c16 d8)~ | % bar 5
    d16 c16( b16 a16 gis8) b8 a16( b16 cis16 d16 e8.) d16 | % bar 6
    cis16( d16 e16 f16 g8.) f16 e16( f16 g16 a16 bes8) a16( g16) | % bar 7
    f8. g16 f16( e16 d16 c16) b16 d16( c16 b16) a8 e8 | % bar 8
    e8\fermata a\Pia( gis8 e8) r8 gis( a8 e8) | % bar 9
    r8 b'8( a8 e8) r8 d'8( gis,8 b8) | % bar 10
    r8 c16\Pia b16 c8-. d-. \once \slurDotted e16( d16)( c16 b16 a16 g16 f16 e16) | % bar 11
    r8 d'16 c16 d8-. e8-. \once \slurDotted f16( e16)( d16 c16 b16 a16 gis16 fis16) | % bar 12
    e8 a16( b16 c16 d16 e8)~ e16 d16( cis16 d16 e16 f16 g8)~ | % bar 13
    g16 f16( e16 d16 cis8) e8-. d8 r8 r4 | % bar 14
    r8 b16( cis16 dis16 e16 fis8)~ fis16 e16( dis16 e16 fis16 g16 a8)~ | % bar 15
    a16 g16( fis16 e16 dis8) fis8-. e8 r8 r4 | % bar 16
    r8 e8( dis8 b8) r8 dis8( e8 b8) | % bar 17
    r8 fis'8( e8 b8) r8 a8( dis,8 dis8) | % bar 18
    e2\PPia  es2~ | % bar 19
    es4 d8 c8 d4 r4\fermata | % bar 20
    r4 r8 e'8\Pia-. c8-. g8-. r4 | % bar 21
    r4 r8 d'8-. b8-. g8-. r4 | % bar 22
    r4 r8 e'8-. c8-. c,16( d16 e16 fis16 g16 a16) | % bar 23
    b16( a16 g16 a16) b16 c16 d8~ d16 c16( b16 c16 d16 e16 f8)~ | % bar 24
    f16 e16( d16 c16 b8) d8 c16( d16 e16 f16 g8.) f16 | % bar 25
    e16( f16 g16 a16 bes8) r8 r2 | % bar 26
    r8 f8-. f8-. c8-. r8 d8-. d8-. a8-. | % bar 40
    r8 d8-. d8-. b8-. r8 c8-. c8-. g8-. | % bar 41
    r8 c8-. c8-. a8-. r8 b8-. b8-. b8-. | % bar 42
    r8 c8-. c8-. c,8 r4 r8 fis16( g16 | % bar 43
    a16 bes16) c8~ c16 bes16( a16 bes16 c16 d16 es8) a,8-. c8-. | % bar 44
    d16( c16 b16 a16 g8) r8 r2 | % bar 45
    R1 | % bar 46
    r8 e'16\For d16 e8-. f8-. \once \slurDotted g16( f16)( e16 d16 c16 b16 a16 g16) | % bar 47
    r8 d'16 c16 d8-. fis8-. \once \slurDotted g16( fis16)( e16 d16 c16 b16 a16 g16) | % bar 48
    r8 c16 b16 c8-. f8-. r8 g16 f16 g8-. d8-. | % bar 49
    c8. d16 b8.\trill g16 g8 a16( b16 c16 d16 e16 f16 | % bar 50
    g8) r8 r4 r2 | % bar 51
    r8 g,8\Pia( fis8 d8) r4 b'4 | % bar 52
    c4 a4 b4 b4 | % bar 53
    a4 e4 e4 r4 | % bar 54
    r2 r4 b'4 | % bar 55
    a4 a4 d4 c4 | % bar 56
    c4 b8 a8 b4 r4 | % bar 57
    r2 r4 c4 | % bar 58
    e2 r8 c8( d8 e8) | % bar 59
    f8 d8 e4 e4 r4 | % bar 60
    r2 r4 r8 d8 | % bar 61
    d8( c8) r8 e8 e8( dis8) r8 a8 | % bar 62
    b8 c8 fis,8 a8 g4 r4 | % bar 63
    r2 r4 fis'4~ | % bar 64
    fis8 e8~ e8[ dis8] b4 b4~ | % bar 65
    b8 c8~ c8[ b8] g4 r4 | % bar 66
    r2 r4 cis8 e8~ | % bar 67
    e8 d16 c16 b4~ b8 a8~ a8[ gis8] | % bar 68
    e8 a8~ a8[ gis8] e2 | % bar 69
    f4 g4 f4 r4 | % bar 70
    r2 r2 | % bar 71
    r8 e16( f16 gis16 a16 b8)~ b16 a16 gis16( a16 b16 c16 d8)~ | % bar 72
    d16 \once \slurDashed c16( b16 a16) gis8-. b8-. a16( b16 cis16 d16 e8.) d16 | % bar 73
    cis16( d16 e16 f16 g8.) f16 e16( f16 g16 a16 bes8) r8 | % bar 74
    R1*4 | % bar 75
    r8 c,16\For b16 c8-. d8-. \once \slurDotted e16( d16)( c16 b16 a16 g16 f16 e16) | % bar 79
}
\mvtIVtimeLine
>>


mvtIVtaille = <<
\relative c'' {
    r8 a16 gis16 a8-. b8-. \once \slurDotted c16( b16)( a16 g16 f16 e16 d16 c16) | % bar 1
    r8 g'16 fis16 g8-. a8-. \once \slurDotted b16( a16)( g16 f16 e16 d16 c16 b16) | % bar 2
    r8 f'16 e16 f8-. a8-. r8 d16 c16 d8-. gis,8-. | % bar 3
    a8 a,16( b16 c16 d16 e16 fis16) gis8 fis8 gis8 a8 | % bar 4
    gis4 e16( fis16 gis16 a16 b8.) a16 gis16( a16 b16 c16 | % bar 5
    d8.) c16 b16( a16 gis16 b16) e,8-. a,16( b16 cis16 d16 e8)~ | % bar 6
    e16 d16 cis16( d16 e16 f16 g8)~ g16 f16( e16 f16 g16 f16 e8) | % bar 7
    d16( cis16 d16 e16) f4~ f16 b,16( c16 d16 e16 d16 c16 b16) | % bar 8
    c8\fermata e8\Pia( d8 c8) r8 d8( e8 c8) | % bar 9
    r8 f8( e8 d8) r8 a'8( e8 gis8) | % bar 10
    r8 a16\Pia gis16 a8-. b8-. \once \slurDotted c16( b16)( a16 g16 f16 e16 d16 c16) | % bar 11
    r8 b'16 a16 b8-. c8-. \once \slurDotted d16( c16)( b16 a16 gis16 fis16 e16 d16) | % bar 12
    c4 a16( b16 c16 d16 e8.) d16 cis16( d16 e16 f16 | % bar 13
    g8.) f16( e16 d16 cis16 e16) a,8 r8 r4 | % bar 14
    r4 b16( cis16 dis16 e16 fis8.) e16 dis16( e16 fis16 g16 | % bar 15
    a8.) g16( fis16 e16 dis16 fis16) b,8 r8 r4 | % bar 16
    r8 b'8( a8 g8) r8 a8( b8 g8) | % bar 17
    r8 c8( b8 a8) r8 e8( b8 b8) | % bar 18
    b2\PPia c2~ | % bar 19
    c2 b4 r4\fermata | % bar 20
    r2 r8 c'8\Pia-. g8-. e8-. | % bar 21
    r2 r8 g8-. d8-. b8-. | % bar 22
    r2 r8 c'16( b16 a16 g16 fis16 e16) | % bar 23
    d4 g,16( a16 b16 c16 d8.) c16 b16( c16 d16 e16 | % bar 24
    f8.) e16 d16( c16 b16 d16) g,8 c16( d16 e16 f16 g8)~ | % bar 25
    g16 f16( e16 f16 g16 a16 bes8) r2 | % bar 26
    r8 c8-. c8-. a8-. r8 f8-. f8-. a8-. | % bar 40
    r8 b8-. b8-. g8-. r8 e8-. e8-. g8-. | % bar 41
    r8 a8-. a8-. f8-. r8 d8-. d8-. f8 | % bar 42
    r8 g8-. g8-. c8-. r2 | % bar 43
    r4 r8 fis,16( g16 a16 bes16 c8) fis,8-. a8-. | % bar 44
    b16( a16 g16 f16) g8 r8 r2 | % bar 45
    R1 | % bar 46
    r8 c,16\For b16 c8-. d8-. e16 d'16( c16 b16 a16 g16 f16 e16) | % bar 47
    r8 b16 a16 b8-. c8-. \once \slurDotted d16( c'16)( b16 a16 g16 fis16 e16 d16) | % bar 48
    r8 a'16 g16 a8-. d8-. r8 b16 a16 b8-. g8-. | % bar 49
    g8. a16 g8 f e8 f16( g a16 b16 c16 d16 | % bar 50
    e8) r8 r4 r2 | % bar 51
    r8 d,8\Pia( c8 bes8) r4 gis'4 | % bar 52
    a4 e4 gis4 gis4 | % bar 53
    e4 b4 c4 r4 | % bar 54
    r2 r4 e4 | % bar 55
    e4 f4 g4 g4 | % bar 56
    f4 f4 e4 r4 | % bar 57
    r2 r4 g8( a8) | % bar 58
    b8( e,8) fis8( gis8) a4 gis4 | % bar 59
    r8 b8( c8 d8) c4 r4 | % bar 60
    r2 r4 r8 fis,8 | % bar 61
    fis8( e8) r8 c'8 g8( b8) r8 a8 | % bar 62
    g8( e8) b4 b4 r4 | % bar 63
    r2 r4 d'8( a8) | % bar 64
    b4 c8( b8) g4 r8 gis8~ | % bar 65
    gis8 a8~ a8[ d,8] e4 r4 | % bar 66
    r2 r4 a4 | % bar 67
    a4 gis8 e8~ e8 f8~ f8 e16 d16 | % bar 68
    a'8 f8 b,8 e8 c4 cis8 a8 | % bar 69
    d4 cis4 d4 r4 | % bar 70
    r2 r2 | % bar 71
    r4 e16\Pia( fis16 gis16 a16 b8.) a16 gis16( a16 b16 c16 | % bar 72
    d8.) c16 b16( a16 gis16 b16) e,8 a,16( b16 cis16 d16 e8)~ | % bar 73
    e16 d16( cis16 d16 e16 f16 g8)~ g16 f16 e16( f16 g16 a16 bes8) | % bar 74
    R1*4 | % bar 75
    r8 a16\For gis16 a8-. b8-. \once \slurDotted c16( b16)( a16 g16 f16 e16 d16 c16) | % bar 79
}
\mvtIVtimeLine
>>


mvtIVbass = <<
\relative c {
    \clef F

    \autoBeamOff

    R1*8 | % bar 1
    r4\fermata e4 e4 c4 | % bar 9
    d4 e4 c4 b4 | % bar 10
    a4 r8 e'8 a8 a,8 c8 e8 | % bar 11
    \autoBeamOn gis16 \melisma a16 b16 c16 b16 a16 gis16 a16 \autoBeamOff d,8 \melismaEnd b'16 c16 d8 e,8 | % bar 12
    c'4 r8 a,8 g'8 e8 e8 cis8 | % bar 13
    \autoBeamOn bes'8. \melisma a16 g16 f16 g16 cis16 \autoBeamOff d8 \melismaEnd a16 g16 f8 a8 | % bar 14
    a8[( dis,8)] r8 b8 a'8 fis8 fis8 dis8 | % bar 15
    \autoBeamOn c'8. \melisma b16 a16 g16 a16 dis16 \autoBeamOff e8 \melismaEnd b16 a16 g8 e8 | % bar 16
    b'4 b4 b4 g4 | % bar 17
    a4 b4 g4 fis4 | % bar 18
    e4 r8 g8 es'8 r8 r8 b?8 | % bar 19
    c8 c8 c16\trill[ b16] c8 d4 r8\fermata g,8 | % bar 20
    e8 c8 g'8 e8 \autoBeamOn c'16 \melisma b16 a16 g16 \once \set suggestAccidentals = ##t fis16 e16 d16 c16 | % bar 21
    b16 d16 g8~ g16[ d16] \melismaEnd \autoBeamOff b'16[ a16] \autoBeamOn b16 \melisma c16 b16 a16 g16 \once \set suggestAccidentals = ##t fis16 e16 d16 | % bar 22
    c16 a16 e'8~ e16 c16 a'16 g16 a16 b16 a16 g16 fis16 e16 d16 c16 | % bar 23
    \autoBeamOff b8 \melismaEnd g8 r8 d'8 g8 a8 b8 c8 | % bar 24
    d4 r8 g,8 c8 g8 e8 c8 | % bar 25
    bes'8. a16 \autoBeamOn g16 \melisma f16 e16 f16 g16 a16 bes16 c16 d8. c16 | % bar 26
    \autoBeamOff bes16[ a16] \melismaEnd g16[ f16] r8 a d a f d | % bar 27
    \autoBeamOn g8. \melisma e16 f16 g16 a16 b16 c16 d16 c16 b16 a16[ g16] \melismaEnd \autoBeamOff f16[ e16] | % bar 41
    \autoBeamOn f8. \melisma d16 e16 f16 g16 a16 b16 c16 b16 a16 g f e d | % bar 42
    \autoBeamOff e8 \melismaEnd d16 c16 d16[ e16] fis16[ g16] a8. g16 fis16[( g16 a16 bes16] | % bar 43
    c8.) bes16 \autoBeamOn a16 \melisma bes16 c16 d16 es8. d16 c16 \once \set suggestAccidentals = ##t b16 c16 a16 | % bar 44
    \autoBeamOff d8 \melismaEnd g,8 r8 c8 a16[( bes16 a16)] g16 f16[ e16] d16[ c16] | % bar 45
    \autoBeamOn b \melisma c d e f g a b \autoBeamOff c8. \melismaEnd f,16 d8.[ c16] | % bar 46
    c4 r4 r2 | % bar 47
    R1*3 | % bar 48
    r8 c'8 c8 a8 fis8 b,8 es8 d8 | % bar 51
    bes8 r8 r8 d'16 bes16 gis8. a16 b8 d,8 | % bar 52
    c8 r8 r4 f4 r8 d'16 b16 | % bar 53
    c8 d8 e8 e,8 a8 b8 c4~ | % bar 54
    c8[ a8] b8 f8 f8[ \melisma e8] d'4~ | % bar 55
    d8 \melismaEnd c8 r8 b16 c16 d8 g,8 bes4~ | % bar 56
    bes8[ a8] gis8[ a8] e8 d'16 b16 c8 f,8 | % bar 57
    e4 d16[ c16 d8] c4 r4 | % bar 58
    R1 | % bar 59
    r2 r8 a'8 b8 c8 | % bar 60
    d8 e16[ d16] c16[ b16] a16[ g16] fis4 r8 a8 | % bar 61
    a8[( g8)] fis8[( e8)] c'8[ b8] a8[ fis8] | % bar 62
    g8.[ a16] fis4\trill e4 bes'4 | % bar 63
    r8 a8 a8 e f a c16[ b16] c8 | % bar 64
    b4 r8 fis8 \autoBeamOn fis8[ \melisma e8] d'4~ | % bar 65
    d8 \melismaEnd \autoBeamOff c8 r8 g8 \autoBeamOn e8 \melisma g8 bes4~ | % bar 66
    \autoBeamOff bes8[ a8] \melismaEnd g8 bes16 a16 g16[ f16] e16[ d16] a8 cis8 | % bar 67
    d4 r8 b'8 b8[ e,8] r8 gis8 | % bar 68
    a8 b16[ c16] d8 c16[ b16] c4 r8 cis8 | % bar 69
    d8 a8 g8 f16[ e16] f8 r16 a16 f8 e8 | % bar 70
    f8[( e8)] a8[( gis8)] a8[( gis8)] a8[( b8)] | % bar 71
    gis4 r8 e8 e2~ | % bar 72
    e1~ | % bar 73
    e1~ | % bar 74
    e8 bes'8 a8 g8 f8 e16[ d16] d'8 b8 | % bar 75
    gis8. e16 fis16[ gis16] a16[ b16] c8 b16[ c32 d32] c8 b16[ a16] | % bar 76
    a8 f8 d4~ d8 c16[ b16] c8 d8 | % bar 77
    e8[ c'] gis[ a] c,4 b8[ a] | % bar 78
    a4 r4 r2 | % bar 79
}
\mvtIVtimeLine
>>


mvtIVlyrics = \lyricmode {
    Wa -- rum willst du so zor -- nig sein,
    wa -- rum willst du so zor -- nig, so zor -- nig sein,
    wa -- rum willst du so zor -- nig, so zor -- nig sein,
    wa -- rum willst du so zor -- nig, so zor -- nig sein,
    wa -- rum willst du so zor -- nig sein,
    wa -- rum willst du so zor -- nig sein?

    Es schla -- gen dei -- nes Ei -- fers Flam -- men
    schon ü -- ber un -- serm Haupt,
    schon ü -- ber un -- serm Haupt zu -- sam -- men,
    es schla -- gen dei -- nes Ei -- fers Flam -- men
    schon ü -- ber un -- serm Haupt zu -- sam -- men,
    schon ü -- ber un -- serm Haupt __ zu -- sam -- men.

    Ach, stel -- le doch die Stra -- fen ein,
    stel -- le doch die Stra -- fen ein,
    ach, stel -- le doch die Stra -- fen ein,
    die Stra -- fen, die Stra -- fen,
    stel -- le doch die Stra -- fen ein,
    stel -- le doch die Stra -- fen ein,

    und trag aus vä -- ter -- li -- cher Huld
    mit un -- serm schwa -- chen Fleisch Ge -- duld,
    ach!  ach, stel -- le doch die Stra -- fen ein,
    die Stra -- fen, die Stra -- fen, stel -- le doch die Stra -- fen ein,
    und trag aus vä -- ter -- li -- cher Huld
    aus vä -- ter -- li -- cher Huld
    mit un -- serm schwa -- chen Fleisch Ge -- duld, Ge -- duld, __
    und trag aus vä -- ter -- li -- cher Huld
    mit un -- serm schwa -- chen Fleisch Ge -- duld, Ge -- duld,
    mit un -- serm schwa -- chen Fleisch Ge -- duld.
}

mvtIVbc = <<
\relative c {
    \clef F
    a4 a'4 r8 a,16 b16 c16 d16 e16 f16 | % bar 1
    g,4 g'4 r8 g,16 a16 b16 c16 d16 e16 | % bar 2
    f,8 f'8 f8 d8 gis, gis'8 gis e8 | % bar 3
    a,16 e'16 f16 g16 a16 b16 c16 d16 e4~ e16 e,16 dis16 e16 | % bar 4
    e,8 e'8 e8 e,8 e8 e'8 e8 e,8 | % bar 5
    e8 e'8 e8 e,8 g8 g'8 g8 g,8 | % bar 6
    e8 e'8 e8 e,8 cis8 cis'8 cis8 cis,8 | % bar 7
    d8 f'16 e16 d16 c16 b16 a16 gis8 a8 e'8 e,8 | % bar 8
    a4\fermata r8\Pia a'8 gis8 e8 r8 a8 | % bar 9
    f8 d8 r8 gis8 a8 d,8 e8 e,8 | % bar 10
    b'4\p a'4 r8 a,16 b16 c16 d16 e16 f16 | % bar 11
    b,4 b'4 r8 b,16 c16 d16 e16 fis16 gis16 | % bar 12
    a,8 a'8 a8 a,8 a8 a'8 a8 a,8 | % bar 13
    a8 a'8 a8 a,8 d16 e16 f16 e16 d16 c16 b16 a16 | % bar 14
    b8 b'8 b8 b,8 b8 b'8 b8 b,8 | % bar 15
    b8 b'8 b8 b,8 e8 d16 c16 b16 a16 g16 fis16 | % bar 16
    e4 r8 e' dis8 b8 r8 e | % bar 17
    c8 a8 r8 dis8 e8 a8 b8 b,8 | % bar 18
    e,8\PPia e'8 e8 e,8 <\tag CELLO c \tag ORGAN c'>8 <\tag CELLO c' \tag ORGAN c'>8 <\tag CELLO c \tag ORGAN c'>8 <\tag CELLO c, \tag ORGAN c'>8 | % bar 19
    a'2 g4 r4\fermata | % bar 20
    c4\p c'4 r8 c,16 d16 e16 fis16 g16 a16 | % bar 21
    b,4 b'4 r8 b,16 c16 d16 e16 fis16 g16 | % bar 22
    a,4 a'4 r8 a,16 b16 c16 d16 e16 fis16 | % bar 23
    g,8 g'8 g8 g,8 g8 g'8 g8 g,8 | % bar 24
    g8 g'8 g8 g,8 bes8 bes'8 bes8 bes,8 | % bar 25
    g8 g'8 g8 g,8 e16 f16 g16 a16 bes16 c16 d16 e16 | % bar 26
    f,4 f'4 r8 f,16 g16 a16 b16 c16 d16 | % bar 40
    e,4 e'4 r8 e,16 f16 g16 a16 b16 c16 | % bar 41
    d,4 d'4 r8 d,16 e16 f g a b | % bar 42
    c,8 c'16 d16 c16 bes16 a16 g16 fis8 fis'8 fis8 fis,8 | % bar 43
    fis8 fis'8 fis8 fis,8 fis8 fis'8 fis8 fis,8 | % bar 44
    f8 f'8 e8 c8 f8 g8 a8 f8 | % bar 45
    g8. f16 e d c b a8 f' g g, | % bar 46
    c4\For c'4 r8 c,16 d16 e16 f16 g16 a16 | % bar 47
    b,4 b'4 r8 b,16 c16 d16 e16 fis16 g16 | % bar 48
    a,8 a'8 a8 g,8 f8 f'8 f8 b,8 | % bar 49
    c8 f8 g8 g,8 c8 b16 a g16 f16 e16 d16 | % bar 50
    c4\Pia c'4 r8 a16( bes16 c16 d16 e16 fis16) | % bar 51
    g,4 g'4 r8 e16( f16 e16 d16 c16 b16) | % bar 52
    a8 a'8 a8 a,8 a8 a'8 a8 a,8 | % bar 53
    a8 a'8 g8 g,8 fis8 fis'8 fis8 fis,8 | % bar 54
    g8 g'8 g8 g,8 gis8 gis'8 gis8 gis,8 | % bar 55
    a8 a'16( g16 f16 e16 d16 c16) b16 g16( a16 b16 c16 d16 e16) c16 | % bar 56
    f16 g16( f16 e16 d16 c16 b16 a16) g8 gis'8 a8 f8 | % bar 57
    g8 f8 g8 g,8 c8 c'8 c8 c,8 | % bar 58
    b4 b'4 r8 a16 g16 f16 e16 d16 c16 | % bar 59
    d8 b8 e8 e,8 a8 a'~ a[ g8] | % bar 60
    fis8 d8 g8 c,8 d8 a16( b c16 d16 e16 fis16) | % bar 61
    g,8 g'8 a8 a,8 b8 b'8 c8 c,8 | % bar 62
    b8 a8 b8 b'8 e,8 g16( f16 e16 d16 cis16 d16) | % bar 63
    cis4 r8 a8 d8 d,8 d8 d'8 | % bar 64
    g,8 g'8 a8 b8 e,8 e,8 fis16 gis16 a16 b16 | % bar 65
    c8 a8 fis8 g8 c,8 e'16 d16 c16 bes16 a16 g16 | % bar 66
    f8. g'16 f16 e16 d16 cis16 d8 g8 a8 a,8 | % bar 67
    d16 c16 b16 c16 d16 e16 fis16 gis16 a8 a,8 b8 b'8 | % bar 68
    c8 d,8 e8 e,8 a8 a'8 g8 g,8 | % bar 69
    f8 f'8 e8 e,8 d8 f'16 e16 d16 c16 b16 a16 | % bar 70
    gis8 gis'8 a8 a,8 f2 | % bar 71
    e8 e' e e, e8 e'8 e8 e,8 | % bar 72
    e8 e'8 e8 e,8 g8 g'8 g8 g,8 | % bar 73
    e8 e' e e, cis8 cis'8 cis8 cis,8 | % bar 74
    g'4 r8 a8 d8. c16 b16 a16 gis16 fis16 | % bar 75
    e8 d'8 c8 b8 a8 d8 e8 e,8 | % bar 76
    f8 f'8 f8 f,8 e e'16 f e d c b | % bar 77
    c16 b16 a16 b16 c16 d16 e16 f16 e8 d8 e8 e,8 | % bar 78
    a4\f a'4 r8 a,16 b16 c16 d16 e16 f16 | % bar 79
}
\mvtIVtimeLine
>>
