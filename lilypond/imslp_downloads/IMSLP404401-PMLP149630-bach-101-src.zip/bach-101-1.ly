\version "2.19.11"

\include "common.ly"


mvtItimeLine = {
    \time 2/2
    \key d \minor

    s1*5 | %5
    \segno
    s1*231 | %236
    \dalSegno
    \bar "||"
}


mvtIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \pageBreak

    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \pageBreak

    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \pageBreak

    \repeat unfold 7 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak }
    \pageBreak

    \repeat unfold 7 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 8 { s1\noBreak }
    \pageBreak

    \repeat unfold 11 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \pageBreak

    \repeat unfold 10 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \pageBreak

    \repeat unfold 11 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 10 { s1\noBreak }
    \pageBreak

    \repeat unfold 8 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 9 { s1\noBreak }
    \bar "|."
}


mvtIfl = <<
\relative c''' {
    R1*30 | % bar 30
    R1\fermataMarkup | % bar 31
    R1*7 | % bar 38
    a1 | % bar 39
    a1 | % bar 40
    f1 | % bar 41
    g1 | % bar 42
    a1 | % bar 43
    f1 | % bar 44
    e1 | % bar 45
    d1~ | % bar 46
    d1~ | % bar 47
    d2 r2 | % bar 48
    \tag SCORE {
        R1*24 | % bar 49
    }
    \tag PARTS {
        R1*20 | % bar 49
        \voiceTwo R1*4 \oneVoice | % bar 49
    }
    a'1 | % bar 73
    a1 | % bar 74
    g1 | % bar 75
    c1 | % bar 76
    a1 | % bar 77
    f1 | % bar 78
    g1 | % bar 79
    a1~ | % bar 80
    a1~ | % bar 81
    a2 r2 | % bar 82
    R1*27 | % bar 83
    a1 | % bar 110
    c1 | % bar 111
    d2 e2 | % bar 112
    f1 | % bar 113
    e1 | % bar 114
    d1 | % bar 115
    cis1 | % bar 116
    d1~ | % bar 117
    d1~ | % bar 118
    d2 r2 | % bar 119
    R1*29 | % bar 120
    d1 | % bar 149
    e1 | % bar 150
    d1 | % bar 151
    c1 | % bar 152
    b1 | % bar 153
    a1 | % bar 154
    b1 | % bar 155
    a1~ | % bar 156
    a1~ | % bar 157
    a4 a4 gis4 a4 | % bar 158
    b4 e,4 e'4 d4 | % bar 159
    c2 r2 | % bar 160
    \tag SCORE {
        R1*26 | % bar 161
    }
    \tag PARTS {
        R1*21 | % bar 161
        \voiceTwo R1*5 \oneVoice | % bar 161
    }
    d1 | % bar 187
    c1 | % bar 188
    b1 | % bar 189
    c1 | % bar 190
    a1 | % bar 191
    a1 | % bar 192
    g1 | % bar 193
    f1 | % bar 194
    \tag SCORE {
        R1*25 | % bar 195
    }
    \tag PARTS {
        R1*20 | % bar 195
        \voiceTwo R1*5 \oneVoice | % bar 195
    }
    a1 | % bar 220
    bes1 | % bar 221
    a2( g2) | % bar 222
    f1 | % bar 223
    g1 | % bar 224
    g1 | % bar 225
    e1 | % bar 226
    d1~ | % bar 227
    d1~ | % bar 228
    d1~ | % bar 229
    d1~ | % bar 230
    d1~ | % bar 231
    d1~ | % bar 232
    d1~ | % bar 233
    d1~ | % bar 234
    d1~ | % bar 235
    d2 r2 | % bar 236
}
\mvtItimeLine
>>


mvtIobI = <<
\relative c'' {
    d1~ | % bar 1
    d2 cis4 b4 | % bar 2
    cis2 bes'2~ | % bar 3
    bes2 a4 g4 | % bar 4
    f4 a,4 a4 a4 | % bar 5
    b4 b8 a8 b4 c4 | % bar 6
    d4 c4 b4 a4 | % bar 7
    gis2 gis'2 | % bar 8
    a2 g2 | % bar 9
    fis1\trill | % bar 10
    g1~ | % bar 11
    g4 bes4 a4 g4 | % bar 12
    f1 | % bar 13
    es2 d4 c4 | % bar 14
    d1~ | % bar 15
    d4 f4 e?4 d4 | % bar 16
    cis2 e2~ | % bar 17
    e4 d8 cis8 d4 e4 | % bar 18
    f d d d | % bar 19
    e4 e8 d8 e4 f4 | % bar 20
    g4 f4 e4 d4 | % bar 21
    cis2 f2~ | % bar 22
    f2 e2~ | % bar 23
    e2 d2~ | % bar 24
    d4 es4 cis4( d4) | % bar 25
    a4 es'4 cis4( d4) | % bar 26
    g,4 a4 bes2~ | % bar 27
    bes4 e?4 cis4 g4 | % bar 28
    f4-. bes4-. a4-. g4-. | % bar 29
    f2 e2 | % bar 30
    \onceCenterNoteColumn #0 d1\fermata | % bar 31
    r2 r4 f'4 | % bar 32
    cis4( d4) r2 | % bar 33
    r4 c4 gis4( a4) | % bar 34
    r2 r4 g'4 | % bar 35
    e4( f4) r2 | % bar 36
    r4 f4 gis,4( a4) | % bar 37
    R1 | % bar 38
    r4 f'4 cis4( d4) | % bar 39
    R1 | % bar 40
    r4 f4 cis4( d4) | % bar 41
    r4 f4 cis4( d4) | % bar 42
    R1*3 | % bar 43
    r4 a4 a4 a4 | % bar 46
    bes4 bes8 a8 bes4 c4 | % bar 47
    d4 c4 bes4 a4 | % bar 48
    gis2 gis'2\trill | % bar 49
    a2 c,2~ | % bar 50
    c2 bes2~ | % bar 51
    bes2 a4 g4 | % bar 52
    fis4 g4 a4 bes4 | % bar 53
    c4 d4 es2 | % bar 54
    d1 | % bar 55
    e?4 f4 g2~ | % bar 56
    g4 c,4 f2~ | % bar 57
    f4 g4-. e4( f4) | % bar 58
    c4 g'4^"CHECK: dot?" e4( f4) | % bar 59
    bes,4 c4 des2~ | % bar 60
    des4 g4 e4 bes4 | % bar 61
    a4 d4 c4 bes4 | % bar 62
    a2 g2 | % bar 63
    f2 r2 | % bar 64
    r4 es'4 cis4( d4) | % bar 65
    r2 r4 a'4 | % bar 66
    cis,4( d4) r2 | % bar 67
    r4 f4 cis4( d4) | % bar 68
    r2 r4 f4 | % bar 69
    bes,4( d4) r2 | % bar 70
    r4 f4 a,4( c4) | % bar 71
    R1 | % bar 72
    r4 f4 cis4( d4) | % bar 73
    r4 a'4 dis,4( fis4) | % bar 74
    R1*3 | % bar 75
    r4 d4 d4 d4 | % bar 78
    e4 e8 d8 e4 f4 | % bar 79
    g4 f4 e4 d4 | % bar 80
    cis2 d2~ | % bar 81
    d2 cis4 b4 | % bar 82
    cis2 bes'2~ | % bar 83
    bes2 a4 g4 | % bar 84
    f4 f,4 f4 f4 | % bar 85
    g4 g8 f8 g4 a4 | % bar 86
    bes4 a4 g4 f4 | % bar 87
    e2 e'2 | % bar 88
    f4 c4 f2~ | % bar 89
    f2 e2~ | % bar 90
    e2 d~ | % bar 91
    d4 d4 b'2~ | % bar 92
    b2 a4 g4 | % bar 93
    f4-. bes4-. gis4( a4) | % bar 94
    e4-. bes'4-. gis4( a4) | % bar 95
    d,4 e4 f2~ | % bar 96
    f4 b4 gis4 d4 | % bar 97
    c4 f4 e4 d4 | % bar 98
    c2 b2 | % bar 99
    a2 r2 | % bar 100
    r4 a4 a4 a4 | % bar 101
    b4 b8 a8 b4 cis4 | % bar 102
    d4 c4 bes4 a4 | % bar 103
    g2 g'2~ | % bar 104
    g4 a4 bes2~ | % bar 105
    bes4 a8 g8 a4 fis4 | % bar 106
    d2 g4 f4 | % bar 107
    e4 a2 g8 f8 | % bar 108
    g4 g2 f8 e8 | % bar 109
    f4 f4 cis4( d4) | % bar 110
    r4 c4 gis4( a4) | % bar 111
    R1 | % bar 112
    r4 a4 a4 a4 | % bar 113
    bes4 bes8 a8 b4 cis4 | % bar 114
    d4 c4 bes4 a4 | % bar 115
    g2 g'2~ | % bar 116
    g2 fis2 | % bar 117
    g2 a2~ | % bar 118
    a4 d,4 g2~ | % bar 119
    g4 bes4 a4 g4 | % bar 120
    f2 r2 | % bar 121
    fis2 r2 | % bar 122
    g2 r2 | % bar 123
    a2 r2 | % bar 124
    bes4-. bes,4-. fis4( g4) | % bar 125
    d'4\PdO b4\PdS g4( as4) | % bar 126
    g4\PdO e'4\PdS b4( c4) | % bar 127
    f,4-. d'4-. b4( c4) | % bar 128
    e,2 r2 | % bar 129
    e'2 r2 | % bar 130
    f2 r2 | % bar 131
    g2 r2 | % bar 132
    a4-. c,4-. e,4( f4) | % bar 133
    c'4\PdO a4\PdS f4( ges4) | % bar 134
    f4\PdO d'4\PdS a4( bes4) | % bar 135
    es,4\PdO c'4\PdS a4( bes4) | % bar 136
    d,4 d'4 d4 d4 | % bar 137
    e4 e8 d8 e4 fis4 | % bar 138
    g4 f4 e4 d4 | % bar 139
    cis2 cis'2 | % bar 140
    d2 r2 | % bar 141
    R1*7 | % bar 142
    r4 f,4-. b,4( d4) | % bar 149
    e,4-. e'4-. gis,4( a4) | % bar 150
    e4\PdO d'4\PdS gis,4( a4) | % bar 151
    e2 e'2 | % bar 152
    d4 f2 e4~ | % bar 153
    e4 a,4 f'2~ | % bar 154
    f4 d4 b4 e4~ | % bar 155
    e4 a,4 a4 a4 | % bar 156
    b4 b8 a8 b4 c4 | % bar 157
    d4 c4 b4 a4 | % bar 158
    gis2 gis'2 | % bar 159
    a2 e2~ | % bar 160
    e2 dis4 cis4 | % bar 161
    dis2 c'2~ | % bar 162
    c2 b4 a4 | % bar 163
    g1~ | % bar 164
    g4 bes4 a4 g4 | % bar 165
    f2 d'2 | % bar 166
    b1~ | % bar 167
    b2 a2 | % bar 168
    g1~ | % bar 169
    g4 f8 e8 d4 c4 | % bar 170
    b1~ | % bar 171
    b4 f'4 f4 f4 | % bar 172
    e4 e8 f8 e4 d4 | % bar 173
    c4 d4 e4 fis4 | % bar 174
    gis4 e4 d4 c4 | % bar 175
    b4 c4 d4 e4 | % bar 176
    f2 e2 | % bar 177
    d2. e8 f8 | % bar 178
    e4 a2 gis4 | % bar 179
    a2 r2 | % bar 180
    r4 d,4 bes'4( a4) | % bar 181
    r2 r4 bes,4 | % bar 182
    g'4( f4) r2 | % bar 183
    r4 c4 as'4( g4) | % bar 184
    r2 r4 a,?4 | % bar 185
    a'?4( g4) r2 | % bar 186
    r4 a,4 f'4( e4) | % bar 187
    R1*4 | % bar 188
    r4 a,4 a4 a4 | % bar 192
    b4 b8 a8 b4 cis4 | % bar 193
    d4 c4 bes4 a4 | % bar 194
    g2 g'2 | % bar 195
    a2 r2 | % bar 196
    cis,2 r2 | % bar 197
    d2 r2 | % bar 198
    e2 r2 | % bar 199
    f4-. a4-. cis,4( d4) | % bar 200
    a'4-. fis4-. d4( es4) | % bar 201
    d4-. bes'4-. fis4( g4) | % bar 202
    c,4-. a'4-. fis4( g4) | % bar 203
    bes,2 r2 | % bar 204
    b2 r2 | % bar 205
    c2 r2 | % bar 206
    d2 r2 | % bar 207
    e4-. g4-. b,4( c4) | % bar 208
    g'4-. e4-. c4( des4) | % bar 209
    c4-. a'4-. e4( f4) | % bar 210
    bes,4-. g'4-. e4( f4) | % bar 211
    a,2 a2~ | % bar 212
    a4 g4 f4 e4 | % bar 213
    d4 bes'2 a8 g8 | % bar 214
    a4 c2 bes8 a8 | % bar 215
    bes4 d2 c8 b8 | % bar 216
    c4 f2 es8 d8 | % bar 217
    es4 g2 f8 e8 | % bar 218
    a4 e,4 bes'4( a4) | % bar 219
    r2 r4 d4 | % bar 220
    g4( f4) r2 | % bar 221
    r4 d4 bes'4( a4) | % bar 222
    r2 r4 f4 | % bar 223
    cis4( d4) r2 | % bar 224
    r4 a4 d2~ | % bar 225
    d8 cis8 d8 e8 cis2\trill | % bar 226
    d4 es4 es4 es4 | % bar 227
    d4 d8 es8 d4 c4 | % bar 228
    bes4 c4 d4 e4 | % bar 229
    fis4 d4 c4 bes4 | % bar 230
    a4 bes4 c4 d4 | % bar 231
    es2 d2~ | % bar 232
    d2 cis4 b4 | % bar 233
    cis2 bes'2~ | % bar 234
    bes2 a4 g4 | % bar 235
    f4 a,4 a4 a4 | % bar 236
}
\mvtItimeLine
>>


mvtIobII = <<
\relative c'' {
    a1 | % bar 1
    g1~ | % bar 2
    g2 g'2~ | % bar 3
    g4 f4 e2 | % bar 4
    d4 f,4 f4 f4 | % bar 5
    f4 f8 e8 d4 e4 | % bar 6
    d4 e4 f4 d4 | % bar 7
    e2 e'2~ | % bar 8
    e2 es2~ | % bar 9
    es4 a,4 d2~ | % bar 10
    d4 d,4 g4 a4 | % bar 11
    bes2 e,2 | % bar 12
    a2. bes4 | % bar 13
    c4 bes4 a4 g4 | % bar 14
    fis2 g4 a4 | % bar 15
    b4 a4 b2 | % bar 16
    e,2 cis'2~ | % bar 17
    cis4 a8 g8 a4 cis4 | % bar 18
    d2 a~ | % bar 19
    a4 cis8 b8 cis4 d4 | % bar 20
    e4 d4 cis4 d4 | % bar 21
    a2 cis2 | % bar 22
    d2 a2~ | % bar 23
    a4 bes8 c8 d4 c4 | % bar 24
    bes2 r2 | % bar 25
    a2 r2 | % bar 26
    r4 d4 cis4( d4) | % bar 27
    e2 r4 e4~ | % bar 28
    e4 d8 cis8 d4 bes4 | % bar 29
    a2 g2 | % bar 30
    \onceCenterNoteColumn #0 f1\fermata | % bar 31
    r4 bes4 gis4( a4) | % bar 32
    r2 r4 d4 | % bar 33
    gis,4( a4) r2 | % bar 34
    r4 d4 bes4( c4) | % bar 35
    r2 r4 f4 | % bar 36
    gis,4( a4) r2 | % bar 37
    R1 | % bar 38
    r4 d4 g,4( a4))) | % bar 39
    R1 | % bar 40
    r4 d4 g,4( a4) | % bar 41
    r4 d4 g,4( bes4) | % bar 42
    R1*3 | % bar 43
    r4 d,4 d4 d4 | % bar 46
    d2 g2 | % bar 47
    a2 f'2~ | % bar 48
    f2. e8 d8 | % bar 49
    cis2 a2 | % bar 50
    d,2 g2~ | % bar 51
    g2 f4 e4 | % bar 52
    d4 e4 fis4 g4 | % bar 53
    a1 | % bar 54
    bes4 d,4 g2~ | % bar 55
    g2 c2~ | % bar 56
    c4 es4 des4 c4 | % bar 57
    des2 r2 | % bar 58
    c2 r2 | % bar 59
    r4 f4 e4( f4) | % bar 60
    g2 r4 g4~ | % bar 61
    g4 f8 e8 f4 g,4~ | % bar 62
    g4 f2 e4 | % bar 63
    c2 r2 | % bar 64
    r2 r4 d'4 | % bar 65
    fis,4( g4) r2 | % bar 66
    r4 bes4 fis4( g4) | % bar 67
    r2 r4 f4 | % bar 68
    e4( g4) r2 | % bar 69
    r4 d'4 a4( c4) | % bar 70
    r2 r4 c4 | % bar 71
    fis,4( g4) r2 | % bar 72
    r4 d'4 g,4( a4) | % bar 73
    r4 e'4 b4( c4) | % bar 74
    R1*3 | % bar 75
    r4 a4 a4 d4~ | % bar 78
    d4 cis4 e2~ | % bar 79
    e4 d4 cis4 d4 | % bar 80
    a1~ | % bar 81
    a2 g4 f4 | % bar 82
    e2 g'2~ | % bar 83
    g4 f8 e8 a2~ | % bar 84
    a4 d,,4 d4 d4 | % bar 85
    d4 e8 d8 e4 f4 | % bar 86
    g2 d2 | % bar 87
    c2 c'2 | % bar 88
    c2 c2 | % bar 89
    d2 a2~ | % bar 90
    a4 bes8 c d4 c | % bar 91
    b2 e2 | % bar 92
    e1 | % bar 93
    f2 r2 | % bar 94
    e2 r2 | % bar 95
    r4 a,4 gis4( a4) | % bar 96
    b2 r4 b'4~ | % bar 97
    b4 a8 gis8 a4 b,4~ | % bar 98
    b4 a2 gis4 | % bar 99
    e2 r2 | % bar 100
    R1*9 | % bar 101
    r4 d'4 g,4( a4) | % bar 110
    r4 c4 gis4( a4) | % bar 111
    R1 | % bar 112
    r4 f4 f4 f4 | % bar 113
    g4 g8 f8 g4 e4 | % bar 114
    a4 g4 f2 | % bar 115
    e2 e'2 | % bar 116
    d2 c2 | % bar 117
    bes2 a2 | % bar 118
    d2. c8 bes8 | % bar 119
    a2 e'2 | % bar 120
    d2 r2 | % bar 121
    d2 r2 | % bar 122
    d2 r2 | % bar 123
    fis2 r2 | % bar 124
    g2 r2 | % bar 125
    g,2 r2 | % bar 126
    c,2 r2 | % bar 127
    f2 r2 | % bar 128
    c'2 r2 | % bar 129
    c2 r2 | % bar 130
    c2 r2 | % bar 131
    e2 r2 | % bar 132
    f2 r2 | % bar 133
    f,2 r2 | % bar 134
    bes2 r2 | % bar 135
    a2 r2 | % bar 136
    f4 bes4 bes4 bes4 | % bar 137
    c4 c8 bes8 c4 a4 | % bar 138
    g4 a4 g4 f4 | % bar 139
    e2 e'2 | % bar 140
    f2 r2 | % bar 141
    R1*14 | % bar 142
    r4 e,4 e4 e4 | % bar 156
    f4 f8 e8 f4 e4 | % bar 157
    d4 e4 f4 e4 | % bar 158
    d2 d'2 | % bar 159
    e2 a,2 | % bar 160
    a1~ | % bar 161
    a2 a'2~ | % bar 162
    a4 g4 fis2 | % bar 163
    e1~ | % bar 164
    e4 cis4 d4 e4 | % bar 165
    a,2 bes4 c4 | % bar 166
    d4 c4 b2 | % bar 167
    c4 e,4 a4 b4 | % bar 168
    cis4 d4 e2~ | % bar 169
    e4 a,2 c4 | % bar 170
    fis1 | % bar 171
    e4 d4 d4 d4 | % bar 172
    b4 c8 d8 c4 b4 | % bar 173
    a4 b4 c2 | % bar 174
    b2. a4 | % bar 175
    gis4 a4 b4 c4 | % bar 176
    d2 c4 b4 | % bar 177
    a2 b2 | % bar 178
    c2 d2 | % bar 179
    c2 r2 | % bar 180
    r2 r4 a4 | % bar 181
    e'4( d4) r2 | % bar 182
    r4 d,4 a'4( g4) | % bar 183
    r2 r4 f4 | % bar 184
    d'4( cis4) r2 | % bar 185
    r4 g4 d'4( cis4) | % bar 186
    r2 r4 d4 | % bar 187
    gis4( a4) r2 | % bar 188
    R1*3 | % bar 189
    r4 a,4 a4 a4 | % bar 192
    b4 b8 a8 b4 cis4 | % bar 193
    d4 c4 bes4 a4 | % bar 194
    g4 g'4 cis,4( d4) | % bar 195
    e2 r2 | % bar 196
    a,2 r2 | % bar 197
    a2 r2 | % bar 198
    cis2 r2 | % bar 199
    d2 r2 | % bar 200
    d2 r2 | % bar 201
    g,2 r2 | % bar 202
    c2 r2 | % bar 203
    g'2 r2 | % bar 204
    g,2 r2 | % bar 205
    g2 r2 | % bar 206
    b2 r2 | % bar 207
    c2 r2 | % bar 208
    c2 r2 | % bar 209
    f,2 r2 | % bar 210
    bes2 r2 | % bar 211
    f'2 r2 | % bar 212
    R1*6 | % bar 213
    r2 r4 a,4 | % bar 219
    e'4( d4) r2 | % bar 220
    r4 g,4 d'4( cis4) | % bar 221
    r2 r4 e,4 | % bar 222
    as4( g4) r2 | % bar 223
    r4 d'4 g,4( a4) | % bar 224
    r4 f4 bes2~ | % bar 225
    bes4 e,4 a2~ | % bar 226
    a4 c4 c4 c4 | % bar 227
    a4 bes8 c8 bes4 a4 | % bar 228
    g4 a4 bes2 | % bar 229
    a2. g4 | % bar 230
    fis4 g4 a4 bes4 | % bar 231
    c2 bes4 a4 | % bar 232
    g1~ | % bar 233
    g2 g'2~ | % bar 234
    g4 f4 e2 | % bar 235
    d4 f,4 f4 f4 | % bar 236
}
\mvtItimeLine
>>


mvtItaille = <<
\relative c' {
    f1 | % bar 1
    e1~ | % bar 2
    e1~ | % bar 3
    e1 | % bar 4
    a,4 d4 d4 d4 | % bar 5
    d4 d8 e8 f4 a4 | % bar 6
    f4 e4 d4 f4 | % bar 7
    b,2 b'2 | % bar 8
    c2. bes4 | % bar 9
    a1 | % bar 10
    bes4 a4 g4 f4 | % bar 11
    e2 a2 | % bar 12
    d,2 d'2 | % bar 13
    a2 d,4 e4 | % bar 14
    a,2 d2~ | % bar 15
    d4 c8 b8 e2 | % bar 16
    a2 g2~ | % bar 17
    g4 f8 e8 f4 g4 | % bar 18
    a2 f | % bar 19
    cis4 g'8 f g4 a4 | % bar 20
    bes4 a4 g4 f4 | % bar 21
    e2 a2 | % bar 22
    d,4 e8 f8 g4 e4 | % bar 23
    f1 | % bar 24
    g2 r2 | % bar 25
    a2 r2 | % bar 26
    r4 a4 g4 f4 | % bar 27
    g2 r4 cis,4 | % bar 28
    a4 g'4 f4 e4~ | % bar 29
    e4 d2 cis4 | % bar 30
    \onceCenterNoteColumn #0 a1\fermata | % bar 31
    R1 | % bar 32
    r4 bes'4 gis4( a4) | % bar 33
    r2 r4 a4 | % bar 34
    fis4( g4) r2 | % bar 35
    r4 a4 e4( f4) | % bar 36
    r2 r4 a4 | % bar 37
    e4( f4) r2 | % bar 38
    r4 a4 e4( f4) | % bar 39
    R1 | % bar 40
    r4 a4 e4( f4) | % bar 41
    r4 a4 e4( f4) | % bar 42
    R1*3 | % bar 43
    r4 a,4 a4 a4 | % bar 46
    g2 d'2~ | % bar 47
    d2. a'4 | % bar 48
    b1 | % bar 49
    e,2. d8 c8 | % bar 50
    g'2. f4 | % bar 51
    e4 d4 cis4 e4 | % bar 52
    a,4 bes4 c4 d4 | % bar 53
    c4 bes4 a2 | % bar 54
    d2 bes'2 | % bar 55
    c2. bes4 | % bar 56
    as2 f2 | % bar 57
    bes2 r2 | % bar 58
    c2 r2 | % bar 59
    r4 c4 bes4( as4) | % bar 60
    bes2 r4 e,4 | % bar 61
    c4 bes'4 a4 d,4 | % bar 62
    c2 bes2 | % bar 63
    a2 r2 | % bar 64
    R1 | % bar 65
    r4 bes'4 cis,4( d4) | % bar 66
    r2 r4 g4 | % bar 67
    cis,4( d4) r2 | % bar 68
    r4 g4 cis,4( d4) | % bar 69
    r2 r4 f4 | % bar 70
    a,4( c4) r2 | % bar 71
    r4 d4 a4( bes4) | % bar 72
    r4 a'4 e4( f4) | % bar 73
    r4 c'4 fis,4( a4) | % bar 74
    R1*3 | % bar 75
    r4 f4 f4 f4 | % bar 78
    g2. bes4 | % bar 79
    e,4 f4 g4 a4 | % bar 80
    e2 f2 | % bar 81
    e2. d4 | % bar 82
    e1~ | % bar 83
    e2. f8 g8 | % bar 84
    a4 a,4 a4 a4 | % bar 85
    bes4 bes8 a8 bes4 c4 | % bar 86
    d4 c4 bes4 a4 | % bar 87
    g2 g'2 | % bar 88
    a2 a2 | % bar 89
    d,4 e8 f8 g4 e4 | % bar 90
    f2. g8 a | % bar 91
    e2. b'4 | % bar 92
    c2 c,2 | % bar 93
    d2 r2 | % bar 94
    e2 r2 | % bar 95
    r4 e4 d4( c4) | % bar 96
    d2 r4 gis4 | % bar 97
    e4( d4) c4 f4 | % bar 98
    e2 d2 | % bar 99
    c2 r2 | % bar 100
    R1*9 | % bar 101
    r4 a'4 e4( f4) | % bar 110
    r4 c'4 gis4( a4) | % bar 111
    R1 | % bar 112
    r4 d,4 d4 d4 | % bar 113
    bes4 g4 e'2 | % bar 114
    f2. e8 f8 | % bar 115
    g2. f8 e8 | % bar 116
    bes'2 a2 | % bar 117
    e4 g4 c,4 d4 | % bar 118
    g,4 g'2 a8 bes8 | % bar 119
    e,2 a2 | % bar 120
    a2 r2 | % bar 121
    a2 r2 | % bar 122
    bes2 r2 | % bar 123
    c2 r2 | % bar 124
    d2 r2 | % bar 125
    b2 r2 | % bar 126
    e,2 r2 | % bar 127
    b2 r2 | % bar 128
    g2 r2 | % bar 129
    g'2 r2 | % bar 130
    a2 r2 | % bar 131
    bes2 r2 | % bar 132
    c2 r2 | % bar 133
    a2 r2 | % bar 134
    f2 r2 | % bar 135
    c2 r2 | % bar 136
    f,4 bes4 d4 g4 | % bar 137
    g4 e4 a,4 d4~ | % bar 138
    d4 d'8 c8 bes2 | % bar 139
    a2 a2 | % bar 140
    a2 r2 | % bar 141
    R1*14 | % bar 142
    r4 c,4 c4 c4 | % bar 156
    d4 d8 c8 d4 c4 | % bar 157
    b4 c4 d4 c4 | % bar 158
    b2 b'2 | % bar 159
    c2 c2 | % bar 160
    fis,1~ | % bar 161
    fis2 fis2~ | % bar 162
    fis4 e4 dis2 | % bar 163
    b4 g'4 a4 bes4 | % bar 164
    e,2 f4 g4 | % bar 165
    a1 | % bar 166
    b2 gis2 | % bar 167
    e2. d4 | % bar 168
    cis2. d4 | % bar 169
    e4 cis4 a4 e'4 | % bar 170
    b'2 dis,2 | % bar 171
    gis4 gis4 gis4 gis4 | % bar 172
    gis4 a4 a4 fis4 | % bar 173
    e2 a2 | % bar 174
    e2 gis4 e4 | % bar 175
    b'4 e,4 gis4 e4 | % bar 176
    gis1 | % bar 177
    fis2 b,4 e4~ | % bar 178
    e4 a,4 f'4 e4 | % bar 179
    e2 r2 | % bar 180
    R1 | % bar 181
    r4 d4 a'4( g4) | % bar 182
    r2 r4 c,4 | % bar 183
    f4( es4) r2 | % bar 184
    r4 g4 bes4( a4) | % bar 185
    r2 r4 g4 | % bar 186
    cis4( d4) r2 | % bar 187
    r4 e,4 gis4( a4) | % bar 188
    R1*3 | % bar 189
    r4 a4 a4 a4 | % bar 192
    b4 b8 a8 b4 cis4 | % bar 193
    d4 c4 bes4 a4 | % bar 194
    g2 bes2 | % bar 195
    cis,2 r2 | % bar 196
    e2 r2 | % bar 197
    f2 r2 | % bar 198
    g2 r2 | % bar 199
    a2 r2 | % bar 200
    fis2 r2 | % bar 201
    bes2 r2 | % bar 202
    fis2 r2 | % bar 203
    d2 r2 | % bar 204
    d2 r2 | % bar 205
    e2 r2 | % bar 206
    f2 r2 | % bar 207
    g2 r2 | % bar 208
    e2 r2 | % bar 209
    a2 r2 | % bar 210
    e2 r2 | % bar 211
    c2 r2 | % bar 212
    R1*7 | % bar 213
    r4 a4 e'4( d4) | % bar 220
    r2 r4 g,4 | % bar 221
    e'4( d4) r2 | % bar 222
    r4 f,4 bes4( as4) | % bar 223
    r2 r4 e'4 | % bar 224
    cis4( d4) f2 | % bar 225
    e1 | % bar 226
    d4 fis4 fis4 fis4 | % bar 227
    fis4 g4 g4 fis4 | % bar 228
    d2 g2 | % bar 229
    d'2 fis,4 d4 | % bar 230
    a4 d4 fis4 d4 | % bar 231
    a'4 fis4 g4 f4 | % bar 232
    e1~ | % bar 233
    e1~ | % bar 234
    e1 | % bar 235
    a,4 d4 d4 d4 | % bar 236
}
\mvtItimeLine
>>


mvtIvlnI = <<
\relative c' {
    r4 d4 d4 d4 | % bar 1
    e4 e8 d8 e4 f4 | % bar 2
    g4 f4 e4 d4 | % bar 3
    cis2 cis'2 | % bar 4
    d2 a2~ | % bar 5
    a2 gis4 fis4 | % bar 6
    gis2 f'2~ | % bar 7
    f2 e4 d4 | % bar 8
    c1~ | % bar 9
    c4 es4 d4 c4 | % bar 10
    bes2 bes'2 | % bar 11
    e,1~ | % bar 12
    e2 d2 | % bar 13
    c1~ | % bar 14
    c4 bes8 a8 g4 f4 | % bar 15
    e1~ | % bar 16
    e4 bes'4 bes4 bes4 | % bar 17
    a4 a8 bes8 a4 g4 | % bar 18
    f4 g a b | % bar 19
    cis4 a'4 g4 f4 | % bar 20
    e4 f4 g4 a4 | % bar 21
    bes2 a2 | % bar 22
    g1 | % bar 23
    f1~ | % bar 24
    f4 es4 cis4( d4) | % bar 25
    a4 es'4 cis4( d4) | % bar 26
    g,4 a4 bes2~ | % bar 27
    bes4 e4 cis4 g4 | % bar 28
    f4 bes4 a4 g4 | % bar 29
    f2 e2 | % bar 30
    \onceCenterNoteColumn #0 d1\fermata | % bar 31
    r2 r4 f'4 | % bar 32
    cis4( d4) r2 | % bar 33
    r4 c4 gis4( a4) | % bar 34
    r2 r4 g'4 | % bar 35
    e4( f4) r2 | % bar 36
    r4 f4 gis,4( a4) | % bar 37
    R1 | % bar 38
    r2 r4 d4 | % bar 39
    gis,4( a4) r2 | % bar 40
    r2 r4 f'4 | % bar 41
    cis4( d4) r4 bes4 | % bar 42
    e,4( f4) r2 | % bar 43
    R1 | % bar 44
    r4 d'4 gis,4( a4) | % bar 45
    d,2 a'2~ | % bar 46
    a2 g2~ | % bar 47
    g2 f4 e4 | % bar 48
    d4 d'4 d4 d4 | % bar 49
    e4 e8 d8 e4 fis4 | % bar 50
    g4 f4 es4 d4 | % bar 51
    cis2 cis'2 | % bar 52
    d1~ | % bar 53
    d2 c2~ | % bar 54
    c2 bes2~ | % bar 55
    bes2 as4 g4 | % bar 56
    as1~ | % bar 57
    as4 g4 e4( f4) | % bar 58
    c4 g'4 e4( f4) | % bar 59
    bes,4 c4 des2~ | % bar 60
    des4 g4 e4 bes4 | % bar 61
    a4 d4 c4 bes4 | % bar 62
    a2 g2 | % bar 63
    f2 r2 | % bar 64
    r4 es'4 cis4( d4) | % bar 65
    r2 r4 a'4 | % bar 66
    cis,4( d4) r2 | % bar 67
    r4 f4 cis4( d4) | % bar 68
    r2 r4 f4 | % bar 69
    bes,4( d4) r2 | % bar 70
    r4 f4 a,4( c4) | % bar 71
    R1 | % bar 72
    r2 r4 d4 | % bar 73
    gis,4( a4) r2 | % bar 74
    r4 g4 g4 g4 | % bar 75
    a4 a8 g8 a4 bes4 | % bar 76
    c4 bes4 a4 g4 | % bar 77
    f2 f'2 | % bar 78
    e4 f4 g2 | % bar 79
    cis,4 a4 a'2~ | % bar 80
    a4 bes8 a8 g4 f4 | % bar 81
    e4 e8 d8 e4 f4 | % bar 82
    g4 f4 e4 d4 | % bar 83
    cis2 cis'2 | % bar 84
    d1~ | % bar 85
    d1~ | % bar 86
    d1~ | % bar 87
    d2 c4 bes4 | % bar 88
    a1 | % bar 89
    g1 | % bar 90
    f1~ | % bar 91
    f2 e4 d4 | % bar 92
    c4 e4 c'2~ | % bar 93
    c4 bes4-\parenthesize-. gis4( a4) | % bar 94
    e4\PdO bes'4\PdS gis4( a4) | % bar 95
    d,4 e4 f2~ | % bar 96
    f4 b4 gis4 d4 | % bar 97
    c4 f4 e4 d4 | % bar 98
    c2 b2 | % bar 99
    a4 e'4 b4( c4) | % bar 100
    R1*2 | % bar 101
    r4 d4 d4 d4 | % bar 103
    e4 e8 d8 e4 f4 | % bar 104
    g4 f4 es4 d4 | % bar 105
    c2 c'2~ | % bar 106
    c4 bes8 a8 bes2 | % bar 107
    a4 a,,4 a4 a4 | % bar 108
    bes4 bes8 a8 bes4 cis4 | % bar 109
    d4 r4 r4 d4 | % bar 110
    gis,4( a4) r2 | % bar 111
    r2 e''2~ | % bar 112
    e2 d2~ | % bar 113
    d4 cis8 d8 e4 cis4 | % bar 114
    a'4 d,4 d4 d4 | % bar 115
    e4 e8 d e4 f4 | % bar 116
    g4 f4 es4 d4~ | % bar 117
    d4 c4 c'2 | % bar 118
    bes2. e,4 | % bar 119
    a1~ | % bar 120
    a4 f4-. cis4( d4) | % bar 121
    a'4-. fis4-. d4( es4) | % bar 122
    d4-. bes'4-. fis4( g4) | % bar 123
    c,4-. a'4-. fis4( g4) | % bar 124
    bes,2 r2 | % bar 125
    b2 r2 | % bar 126
    c2 r2 | % bar 127
    d2 r2 | % bar 128
    e4-. g4-. b,4( c4) | % bar 129
    g'4-. e4-. c4( des4) | % bar 130
    c4-. a'4-. e4( f4) | % bar 131
    bes,4-. g'4-. e4( f4) | % bar 132
    a,2 r2 | % bar 133
    a'2 r2 | % bar 134
    bes2 r2 | % bar 135
    c2 r2 | % bar 136
    d1~ | % bar 137
    d2 c2~ | % bar 138
    c4 bes8 a8 bes2~ | % bar 139
    bes4 bes4 a4 g4 | % bar 140
    f2 r2 | % bar 141
    R1*10 | % bar 142
    r4 e4-\parenthesize-. gis,4( a4) | % bar 152
    d,4-. d'4-. gis,4( a4) | % bar 153
    f4-. c'4-. gis4( a4) | % bar 154
    f'2 e4 d4 | % bar 155
    c2 a2~ | % bar 156
    a2 gis4 fis4 | % bar 157
    gis2 f'2~ | % bar 158
    f2 e4 d4 | % bar 159
    c4 e,4 e4 e4 | % bar 160
    fis4 fis8 e8 fis4 g4 | % bar 161
    a4 g4 fis4 e4 | % bar 162
    dis2 dis'2 | % bar 163
    e2 d2 | % bar 164
    cis1 | % bar 165
    d1~ | % bar 166
    d4 f4 e4 d4 | % bar 167
    c1 | % bar 168
    bes2 a4 g4 | % bar 169
    a1~ | % bar 170
    a4 c4 b4 a4 | % bar 171
    gis2 b2~ | % bar 172
    b4 a8 gis8 a4 b4 | % bar 173
    c4 a4 a4 a4 | % bar 174
    b4 b8 a8 b4 c4 | % bar 175
    d4 c4 b4 a4 | % bar 176
    gis2 c2~ | % bar 177
    c2 b2~ | % bar 178
    b4 a8 b8 b4.\trill a8 | % bar 179
    a2 r2 | % bar 180
    r4 d4 bes'4( a4) | % bar 181
    r2 r4 bes,4 | % bar 182
    g'4( f4) r2 | % bar 183
    r4 c4 as'4( g4) | % bar 184
    r2 r4 a,4 | % bar 185
    a'?4( g4) r2 | % bar 186
    r4 a,4 f'4( e4) | % bar 187
    r4 e,4 e4 e4 | % bar 188
    fis4 fis8 e8 fis4 gis4 | % bar 189
    a4 g4 f4 e4 | % bar 190
    d2 d'2~ | % bar 191
    d4 a'8 g8 a2 | % bar 192
    r4 g8 f8 g2 | % bar 193
    r4 f8 e8 f2~ | % bar 194
    f4 e8 d8 e8 f8 e8 d8 | % bar 195
    cis4-. e4-. gis,4( a4) | % bar 196
    e'4-. cis4-. a4( bes4) | % bar 197
    a4-. f'4-. cis4( d4) | % bar 198
    g,4-. e'4-. cis4( d4) | % bar 199
    f,2 r2 | % bar 200
    fis2 r2 | % bar 201
    g2 r2 | % bar 202
    a2 r2 | % bar 203
    bes4-. d4-. fis,4( g4) | % bar 204
    d'4-. b4-. g4( as4) | % bar 205
    g4-. e'4-. b4( c4) | % bar 206
    f,4-. d'4-. b4( c4) | % bar 207
    e,2 r2 | % bar 208
    e'2 r2 | % bar 209
    f2 r2 | % bar 210
    g2 r2 | % bar 211
    a2 r4 a,4 | % bar 212
    f'4( e4) r4 g4 | % bar 213
    cis,4( d4) r4 c4 | % bar 214
    f4( es4) r4 es4 | % bar 215
    fis,4( g4) r4 g4 | % bar 216
    g'4( f4) r4 as4 | % bar 217
    b,4( c4) r4 g4 | % bar 218
    f'4( e4) bes4( a4) | % bar 219
    r2 r4 d4 | % bar 220
    g4( f4) r2 | % bar 221
    r4 d4 bes'4( a4) | % bar 222
    r2 r4 f4 | % bar 223
    cis4( d4) r2 | % bar 224
    r2 r4 f4 | % bar 225
    bes2 e,2 | % bar 226
    fis2 a2~ | % bar 227
    a4 g8 fis8 g4 a4 | % bar 228
    bes4 g4 g4 g4 | % bar 229
    a4 a8 g8 a4 bes4 | % bar 230
    c4 bes4 a4 g4 | % bar 231
    fis4 d,4 d4 d4 | % bar 232
    e4 e8 d8 e4 f4 | % bar 233
    g4 f4 e4 d4 | % bar 234
    cis2 cis'2 | % bar 235
    d2 a2\laissezVibrer | % bar 236
}
\mvtItimeLine
>>


mvtIvlnII = <<
\relative c' {
    r4 a4 a4 a4 | % bar 1
    bes4 bes8 a8 bes4 a4 | % bar 2
    g4 a4 bes4 a4 | % bar 3
    g2 g'2 | % bar 4
    a2 d,2 | % bar 5
    d1~ | % bar 6
    d2 d'2~ | % bar 7
    d4 c4 b2\trill | % bar 8
    a1~ | % bar 9
    a4 fis4 g4 a4 | % bar 10
    d,2 es4 f4 | % bar 11
    g4 f4 e2 | % bar 12
    f4 a4 d4 e4 | % bar 13
    fis4 g4 a2~ | % bar 14
    a4 d,2 f4 | % bar 15
    b,1\trill | % bar 16
    a4 g4 g4 g4 | % bar 17
    e4 f8 g8 f4 e4 | % bar 18
    d e f2 | % bar 19
    e2 e'4 d4 | % bar 20
    cis4 d4 e4 f4 | % bar 21
    g2 f4 e4 | % bar 22
    d2 e2 | % bar 23
    a,1 | % bar 24
    bes2 r2 | % bar 25
    a2 r2 | % bar 26
    r4 d4 cis4( d4) | % bar 27
    e2 r4 e4~ | % bar 28
    e4 d8 cis8 d4 e,4~ | % bar 29
    e4 d2 cis4 | % bar 30
    \onceCenterNoteColumn #0 d1\fermata | % bar 31
    r4 bes'4 gis4( a4) | % bar 32
    r2 r4 d4 | % bar 33
    gis,4( a4) r2 | % bar 34
    r4 d4 bes4( c4) | % bar 35
    r2 r4 f4 | % bar 36
    gis,4( a4) r2 | % bar 37
    R1 | % bar 38
    r2 r4 a4 | % bar 39
    d,4( e4) r2 | % bar 40
    r2 r4 d'4 | % bar 41
    g,4( a4) r4 g4 | % bar 42
    cis,4( d4) r2 | % bar 43
    R1 | % bar 44
    r4 b'4 e,4 cis4 | % bar 45
    a2 d2 | % bar 46
    d1~ | % bar 47
    d2. e4 | % bar 48
    f4 d4 b'4 b4 | % bar 49
    cis2 c2 | % bar 50
    d2 g,2~ | % bar 51
    g4 e4 f4 g4 | % bar 52
    a4 g'4 fis4 e4 | % bar 53
    d2 a'2~ | % bar 54
    a2 g2~ | % bar 55
    g4 f4 e2\trill | % bar 56
    c1 | % bar 57
    des2 r2 | % bar 58
    c2 r2 | % bar 59
    r4 f4 e4( f4) | % bar 60
    g2 r4 g4~ | % bar 61
    g4 f8 e8 f4 g,4~ | % bar 62
    g4 f2 e4 | % bar 63
    c2 r2 | % bar 64
    r2 r4 d'4 | % bar 65
    fis,4( g4) r2 | % bar 66
    r4 bes4 fis4( g4) | % bar 67
    r2 r4 f4 | % bar 68
    e4( g4) r2 | % bar 69
    r4 d'4 a4( c4))) | % bar 70
    r2 r4 c4 | % bar 71
    fis,4( g4) r2 | % bar 72
    r2 r4 a4 | % bar 73
    d,4( e4) r2 | % bar 74
    r4 e4 e4 e4 | % bar 75
    es4 f8 es8 f4 g4 | % bar 76
    a4 g8 f8 e2~ | % bar 77
    e4 d8 cis8 d2 | % bar 78
    g4 a4 bes2 | % bar 79
    e,2 r4 d'4 | % bar 80
    e4 cis4 a2~ | % bar 81
    a4 b4 cis4 d4 | % bar 82
    e4 d4 cis4 d4 | % bar 83
    a2 e'2 | % bar 84
    f1~ | % bar 85
    f1~ | % bar 86
    f4 g8 a8 bes2~ | % bar 87
    bes4 a4 g2 | % bar 88
    f2. e4 | % bar 89
    d2 e2 | % bar 90
    a,1 | % bar 91
    b1 | % bar 92
    a2. b8 c8 | % bar 93
    d2 r2 | % bar 94
    e2 r2 | % bar 95
    r4 a,4 gis4( a4) | % bar 96
    b2 r4 b'4~ | % bar 97
    b4 a8 gis8 a4 b,4~ | % bar 98
    b4 a2 gis4 | % bar 99
    e4 c'4 gis4( a4) | % bar 100
    R1*7 | % bar 101
    r4 a,4 a4 a4 | % bar 108
    bes4 bes8 a8 bes4 cis4 | % bar 109
    d4 r4 r4 d4 | % bar 110
    gis,4( a4) r2 | % bar 111
    r2 a'2 | % bar 112
    a1 | % bar 113
    e2. f8 g8 | % bar 114
    a4 a4 a4 a4 | % bar 115
    bes4 bes8 a8 bes4 a4 | % bar 116
    d,2 fis2 | % bar 117
    e4 e'2 d4~ | % bar 118
    d4 bes4 g4 g'4~ | % bar 119
    g4 f4 e2 | % bar 120
    f2 r2 | % bar 121
    d2 r2 | % bar 122
    g,2 r2 | % bar 123
    c2 r2 | % bar 124
    g'2 r2 | % bar 125
    g,2 r2 | % bar 126
    g2 r2 | % bar 127
    b2 r2 | % bar 128
    c2 r2 | % bar 129
    c2 r2 | % bar 130
    f,2 r2 | % bar 131
    bes2 r2 | % bar 132
    f'2 r2 | % bar 133
    f2 r2 | % bar 134
    f2 r2 | % bar 135
    a2 r2 | % bar 136
    bes1~ | % bar 137
    bes2 a2~ | % bar 138
    a4 g8 f8 g2~ | % bar 139
    g4 f4 e2 | % bar 140
    d2 r2 | % bar 141
    R1*14 | % bar 142
    r2 e,2 | % bar 156
    d1~ | % bar 157
    d2 d'2 | % bar 158
    d4 c4 b2 | % bar 159
    a4 c,4 c4 c4 | % bar 160
    c4 c8 b8 a4 b4 | % bar 161
    a4 b4 c4 a4 | % bar 162
    b2 b'2~ | % bar 163
    b2 bes2~ | % bar 164
    bes4 e,4 a2~ | % bar 165
    a4 a,4 d4 e4 | % bar 166
    f2 b,2 | % bar 167
    e2. f4 | % bar 168
    g4 f4 e4 d4 | % bar 169
    cis2 d4 e4 | % bar 170
    fis4 e4 fis2 | % bar 171
    b,2 gis'2~ | % bar 172
    gis4 e8 d8 e4 gis4 | % bar 173
    a2 e2~ | % bar 174
    e4 gis8 fis8 gis4 a4 | % bar 175
    b4 a4 gis4 a4 | % bar 176
    e2 gis2 | % bar 177
    a2 e2~ | % bar 178
    e4 f2 e4 | % bar 179
    e2 r2 | % bar 180
    r2 r4 a4 | % bar 181
    e'4( d4) r2 | % bar 182
    r4 d,4 a'4( g4) | % bar 183
    r2 r4 f4 | % bar 184
    d'4( cis4) r2 | % bar 185
    r4 g4 d'4( cis4) | % bar 186
    R1 | % bar 187
    r4 e,4 e4 e4 | % bar 188
    fis4 fis8 e fis4 gis4 | % bar 189
    a4 g4 f4 e4 | % bar 190
    d4 bes'4 a4 g4 | % bar 191
    f4 e4 d2~ | % bar 192
    d4 d4 g4 e4 | % bar 193
    d2 r4 a'4 | % bar 194
    d2 r4 g,4 | % bar 195
    e2 r2 | % bar 196
    a2 r2 | % bar 197
    d,2 r2 | % bar 198
    g2 r2 | % bar 199
    d'2 r2 | % bar 200
    d,2 r2 | % bar 201
    d2 r2 | % bar 202
    fis2 r2 | % bar 203
    g2 r2 | % bar 204
    g2 r2 | % bar 205
    c,2 r2 | % bar 206
    f2 r2 | % bar 207
    c'2 r2 | % bar 208
    c2 r2 | % bar 209
    c2 r2 | % bar 210
    e2 r2 | % bar 211
    f2 r2 | % bar 212
    R1*6 | % bar 213
    r2 r4 a,4 | % bar 219
    e'4( d4) r2 | % bar 220
    r4 g,4 d'4( cis4) | % bar 221
    r2 r4 e,4 | % bar 222
    as4( g4) r2 | % bar 223
    r4 d'4 g,4( a4) | % bar 224
    r2 r4 d4 | % bar 225
    d2 cis2 | % bar 226
    a2 fis'2~ | % bar 227
    fis4 d8 c8 d4 fis4 | % bar 228
    g2 d2~ | % bar 229
    d4 fis8 e8 fis4 g4 | % bar 230
    a4 g4 fis4 g4 | % bar 231
    c,4 c,4 bes4 bes4 | % bar 232
    bes4 bes8 a8 bes4 a4 | % bar 233
    g4 a4 bes4 a4 | % bar 234
    g2 g'2 | % bar 235
    a2 d,2 | % bar 236
}
\mvtItimeLine
>>


mvtIvla = <<
\relative c {
    \clef C
    r4 f4 f4 f4 | % bar 1
    g4 g8 f g4 f4 | % bar 2
    e4 f4 g4 f4 | % bar 3
    e2 e'2 | % bar 4
    f2 f2 | % bar 5
    b,1~ | % bar 6
    b2 b'2~ | % bar 7
    b4 a4 gis2 | % bar 8
    e4 c4 d4 es4 | % bar 9
    a,2 bes4 c4 | % bar 10
    d1 | % bar 11
    e2 cis2 | % bar 12
    a2 a'4 g4 | % bar 13
    fis2. g4 | % bar 14
    a4 fis4 d4 a4 | % bar 15
    e'2 gis2 | % bar 16
    cis,4 cis4 cis4 cis4 | % bar 17
    cis4 d4 d4 cis4 | % bar 18
    a2 d | % bar 19
    a'2 cis,4 a4 | % bar 20
    e'4 a4 cis,4 a4 | % bar 21
    cis1 | % bar 22
    b4 b'4 e,4 a,4 | % bar 23
    d2. e8 f8 | % bar 24
    g2 r2 | % bar 25
    a2 r2 | % bar 26
    r4 a4 g4( f4) | % bar 27
    g2 r4 cis,4 | % bar 28
    a4 g'4 f4 bes4 | % bar 29
    a2 g2 | % bar 30
    \onceCenterNoteColumn #0 f1\fermata | % bar 31
    R1 | % bar 32
    r4 bes4 gis4( a4) | % bar 33
    r2 r4 a4 | % bar 34
    fis4( g4) r2 | % bar 35
    r4 a4 e4( f4) | % bar 36
    r2 r4 a4 | % bar 37
    e4( f4) r2 | % bar 38
    r2 r4 f4 | % bar 39
    b,4( cis4) r2 | % bar 40
    r2 r4 a'4 | % bar 41
    e4( f4) r4 d4 | % bar 42
    e4( d4) r2 | % bar 43
    R1 | % bar 44
    r4 e4 cis4 e,4 | % bar 45
    fis2 c'2 | % bar 46
    bes1 | % bar 47
    a2 bes4 c4 | % bar 48
    d4 b'4 gis4 d4 | % bar 49
    a'2 e4 a,4 | % bar 50
    bes4 c8 d8 es4 bes'4 | % bar 51
    e,2 a2~ | % bar 52
    a4 d4 c4 bes4 | % bar 53
    a4 g4 fis4 a4 | % bar 54
    d,1 | % bar 55
    c2. d8 e8 | % bar 56
    f2. g8 as8 | % bar 57
    bes2 r2 | % bar 58
    c2 r2 | % bar 59
    r4 c4 \once \slurDashed bes4( as4) | % bar 60
    bes2 r4 e,4 | % bar 61
    c4 bes'4 a4 d,4 | % bar 62
    c2 bes2 | % bar 63
    a2 r2 | % bar 64
    R1 | % bar 65
    r4 bes'4 cis,4( d4) | % bar 66
    r2 r4 g4 | % bar 67
    cis,4( d4) r2 | % bar 68
    r4 g4 cis,4( d4) | % bar 69
    r2 r4 f4 | % bar 70
    a,4( c4) r2 | % bar 71
    r4 d4 a4( bes4) | % bar 72
    r2 r4 f'4 | % bar 73
    b,4( c4) r2 | % bar 74
    r4 b4 b4 b4 | % bar 75
    c4 c8 bes8 c2~ | % bar 76
    c4 d4 e2 | % bar 77
    a,2 r4 f4 | % bar 78
    bes4 f'4 e4 d4 | % bar 79
    a'2 r4 f4 | % bar 80
    cis4 d8 e8 a,4 d4 | % bar 81
    e4 g8 f8 g4 a4 | % bar 82
    bes4 a4 g4 f4 | % bar 83
    e4 f8 g8 a2 | % bar 84
    a1 | % bar 85
    g1~ | % bar 86
    g1~ | % bar 87
    g4 f4 e4 d4 | % bar 88
    c1 | % bar 89
    b4 b'4 e,4 a,4 | % bar 90
    d2. e8 f | % bar 91
    b,4 b'4 gis4 e4~ | % bar 92
    e4 f8 g8 a4 c,4 | % bar 93
    f2 r2 | % bar 94
    a2 r2 | % bar 95
    r4 e4 d4 c4 | % bar 96
    d2 r4 gis4 | % bar 97
    e4( d4) c4 f4 | % bar 98
    e2 d2 | % bar 99
    c4 a'4 d,4( e4) | % bar 100
    R1*7 | % bar 101
    r4 a,4 a4 a4 | % bar 108
    bes4 bes8 a8 bes4 cis4 | % bar 109
    d4 r4 r4 d4 | % bar 110
    gis,4( a4) r2 | % bar 111
    r2 g'2 | % bar 112
    f1 | % bar 113
    bes2 g4 a8 bes8 | % bar 114
    d,4 f8 e8 f4 f4 | % bar 115
    g4 g8 f8 g4 cis,4 | % bar 116
    g'2 a2 | % bar 117
    g4 g8 f8 e4 a4 | % bar 118
    d,2 es4 f8 g8 | % bar 119
    a4 b,4 cis4 a4 | % bar 120
    d2 r2 | % bar 121
    fis2 r2 | % bar 122
    bes2 r2 | % bar 123
    fis2 r2 | % bar 124
    d2 r2 | % bar 125
    d2 r2 | % bar 126
    e2 r2 | % bar 127
    f2 r2 | % bar 128
    g2 r2 | % bar 129
    e2 r2 | % bar 130
    a2 r2 | % bar 131
    e2 r2 | % bar 132
    c2 r2 | % bar 133
    c2 r2 | % bar 134
    d2 r2 | % bar 135
    es2 r2 | % bar 136
    f2 g2 | % bar 137
    e2 a4 fis4 | % bar 138
    d2 e2~ | % bar 139
    e4 d4 cis2 | % bar 140
    a2 r2 | % bar 141
    R1*14 | % bar 142
    r2 c2 | % bar 156
    b1~ | % bar 157
    b1~ | % bar 158
    b1 | % bar 159
    e,4 a4 a4 a4 | % bar 160
    a4 a8 b8 c4 e4 | % bar 161
    c4 b4 a4 c4 | % bar 162
    fis,2 fis'2 | % bar 163
    g2. f4 | % bar 164
    e1 | % bar 165
    f4 e4 d4 c4 | % bar 166
    b2 e2 | % bar 167
    a,2 a'2 | % bar 168
    e2 a,4 b4 | % bar 169
    e,2 a2~ | % bar 170
    a4 g8 fis8 b2 | % bar 171
    e2 d2~ | % bar 172
    d4 c8 b8 c4 d4 | % bar 173
    e2 c2 | % bar 174
    gis4 d'8 c8 d4 e4 | % bar 175
    f4 e4 d4 c4 | % bar 176
    b2 e2 | % bar 177
    a,4 b8 c8 d4 b4 | % bar 178
    e,4 c'4 b2 | % bar 179
    c2 r2 | % bar 180
    R1 | % bar 181
    r4 d4 a'4( g4) | % bar 182
    r2 r4 c,4 | % bar 183
    f4( es4) r2 | % bar 184
    r4 g4 bes4( a4) | % bar 185
    r2 r4 g4 | % bar 186
    cis4( d4) r2 | % bar 187
    r4 e,4 e4 e4 | % bar 188
    fis4 fis8 e8 fis4 gis4 | % bar 189
    a4 g4 f4 e4 | % bar 190
    d4 e4 f4 g4 | % bar 191
    a4 a,4 d4 c4 | % bar 192
    b4 a4 g4 a4 | % bar 193
    a2 r4 f'4 | % bar 194
    g2 r4 d4 | % bar 195
    a'2 r2 | % bar 196
    cis,2 r2 | % bar 197
    f2 r2 | % bar 198
    cis2 r2 | % bar 199
    a2 r2 | % bar 200
    a2 r2 | % bar 201
    bes2 r2 | % bar 202
    c2 r2 | % bar 203
    d2 r2 | % bar 204
    b2 r2 | % bar 205
    e2 r2 | % bar 206
    b2 r2 | % bar 207
    g2 r2 | % bar 208
    g'2 r2 | % bar 209
    a2 r2 | % bar 210
    bes2 r2 | % bar 211
    c2 r2 | % bar 212
    R1*7 | % bar 213
    r4 a,4 e'4( d4) | % bar 220
    r2 r4 g,4 | % bar 221
    e'4( d4) r2 | % bar 222
    r4 f,4 bes4( as4) | % bar 223
    r2 r4 e'4 | % bar 224
    cis4( d4) r4 a'4 | % bar 225
    bes2 a4 e4 | % bar 226
    d2 c'2~ | % bar 227
    c4 bes8 a8 bes4 c4 | % bar 228
    d2 bes2 | % bar 229
    fis4 c'8 bes8 c4 d4 | % bar 230
    es4 d4 c4 bes4 | % bar 231
    a4 a,4 g4 g4 | % bar 232
    g4 g8 f8 g4 f4 | % bar 233
    e4 f4 g4 f4 | % bar 234
    e2 e'2 | % bar 235
    f2 f2 | % bar 236
}
\mvtItimeLine
>>


mvtIsoprano = <<
\relative c'' {
    \autoBeamOff

    R1*30 | % bar 30
    R1\fermataMarkup | % bar 31
    R1*7 | % bar 38
    a1 | % bar 39
    a1 | % bar 40
    f1 | % bar 41
    g1 | % bar 42
    a1 | % bar 43
    f1 | % bar 44
    e1 | % bar 45
    d1~ | % bar 46
    d1~ | % bar 47
    d2 r2 | % bar 48
    \tag SCORE {
        R1*24 | % bar 49
    }
    \tag PARTS {
        R1*20 | % bar 49
        \voiceTwo R1*4 \oneVoice | % bar 49
    }
    a'1 | % bar 73
    a1 | % bar 74
    g1 | % bar 75
    c1 | % bar 76
    a1 | % bar 77
    f1 | % bar 78
    g1 | % bar 79
    a1~ | % bar 80
    a1~ | % bar 81
    a2 r2 | % bar 82
    R1*27 | % bar 83
    a1 | % bar 110
    c1 | % bar 111
    d2( e2) | % bar 112
    f1 | % bar 113
    e1 | % bar 114
    d1 | % bar 115
    cis1 | % bar 116
    d1~ | % bar 117
    d1~ | % bar 118
    d2 r2 | % bar 119
    R1*29 | % bar 120
    d1 | % bar 149
    e1 | % bar 150
    d1 | % bar 151
    c1 | % bar 152
    b1 | % bar 153
    a1 | % bar 154
    b1 | % bar 155
    a1~ | % bar 156
    a1~ | % bar 157
    a4 a4 gis4 a4 | % bar 158
    b4 e,4 e'4 d4 | % bar 159
    c2 r2 | % bar 160
    \tag SCORE {
        R1*26 | % bar 161
    }
    \tag PARTS {
        R1*21 | % bar 161
        \voiceTwo R1*5 \oneVoice | % bar 161
    }
    d1 | % bar 187
    c1 | % bar 188
    b1 | % bar 189
    c1 | % bar 190
    a1 | % bar 191
    a1 | % bar 192
    g1 | % bar 193
    f1 | % bar 194
    \tag SCORE {
        R1*25 | % bar 195
    }
    \tag PARTS {
        R1*20 | % bar 195
        \voiceTwo R1*5 \oneVoice | % bar 195
    }
    a1 | % bar 220
    bes1 | % bar 221
    a2( g2) | % bar 222
    f1 | % bar 223
    g1 | % bar 224
    f1 | % bar 225
    e1 | % bar 226
    d1~ | % bar 227
    d1~ | % bar 228
    d1~ | % bar 229
    d1~ | % bar 230
    d1~ | % bar 231
    d1~ | % bar 232
    d1~ | % bar 233
    d1~ | % bar 234
    d1~ | % bar 235
    d2 r2 | % bar 236
}
\mvtItimeLine
>>

mvtIsopranoLyrics = \lyricmode {
    Nimm von uns, Herr, du treu -- er Gott __

    die schwe -- re Straf und gro -- ße Not __

    die wir mit __ Sün -- den oh -- ne Zahl __

    ver -- die -- net ha -- ben all -- zu -- mal, __
    ver -- die -- net ha -- ben all -- zu -- mal.

    Be -- hüt vor Krieg und teu -- rer Zeit,
    vor Seu -- chen, __ Feur und gro -- ßem Leid. __
}


mvtIalto = <<
\relative c'' {
    \autoBeamOff

    R1*30 | % bar 30
    \tag SCORE {
        R1\fermataMarkup | % bar 31
        R1*4 | % bar 35
    }
    \tag PARTS {
        \voiceOne R1\fermataMarkup | % bar 31
        R1*4 | \oneVoice % bar 35
    }
    r2 a2 | % bar 36
    a2 f2 | % bar 37
    g2 a2 | % bar 38
    f2.( e8[ d8]) | % bar 39
    e1 | % bar 40
    d4 f4 bes2~ \melisma | % bar 41
    bes4 a4 \melismaEnd g4( f4) | % bar 42
    e4 d4 e4 d8[ cis8] | % bar 43
    f4 e4 d2~ | % bar 44
    d2 cis2 | % bar 45
    d2 c2 | % bar 46
    bes2 bes2 | % bar 47
    a2 r2 | % bar 48
    \tag SCORE {
        R1*17 | % bar 49
    }
    \tag PARTS {
        R1*15 | % bar 49
        \voiceOne R1*2 | \oneVoice % bar 49
    }
    r2 d2 | % bar 66
    d2 c2 | % bar 67
    g'4( f4) e4( d4) | % bar 68
    cis2 d2 | % bar 69
    e2 es2 | % bar 70
    es4( c4) f4( es4) | % bar 71
    d2 e2 | % bar 72
    e4( d4) e4( f4) | % bar 73
    e2 dis2 | % bar 74
    e2 e2 | % bar 75
    es1~ | % bar 76
    es4 d4 e2~ | % bar 77
    e4 d8[ cis8] d2~ | % bar 78
    d4 f4 e4 d4 | % bar 79
    cis2 r4 d4 | % bar 80
    e2 f2 | % bar 81
    e2 r2 | % bar 82
    \tag SCORE {
        R1*19 | % bar 83
    }
    \tag PARTS {
        R1*17 | % bar 83
        \voiceOne R1*2 | \oneVoice % bar 83
    }
    r2 e2 | % bar 102
    f2 g4( a4) | % bar 103
    bes2 a2 | % bar 104
    g1~ | % bar 105
    g2 fis2 | % bar 106
    g1~ | % bar 107
    g4 f4 e4 d4 | % bar 108
    cis4( bes'2) a4 | % bar 109
    f4 a4 g4 f4 | % bar 110
    e2 \melisma a2~ | % bar 111
    a2 \melismaEnd g2 | % bar 112
    f2. \melisma g8[ a8] | % bar 113
    bes2 \melismaEnd e,2 | % bar 114
    a4 c4 bes4 a4 | % bar 115
    g4( bes2) a4 | % bar 116
    g4 a4 a4 a4 | % bar 117
    g4 g8[ f8] e4 a4 | % bar 118
    d,4 g4 bes4 bes4 | % bar 119
    a2. e4 | % bar 120
    f2 r2 | % bar 121
    \tag SCORE {
        R1*22 | % bar 122
    }
    \tag PARTS {
        R1*19 | % bar 122
        \voiceOne R1*3 | \oneVoice % bar 122
    }
    r2 gis2 | % bar 144
    a2 g2 | % bar 145
    f2 e2 | % bar 146
    d2 e2 | % bar 147
    d4 d4 c'2~ | % bar 148
    c4( b4) b4( a4) | % bar 149
    b2 e,2 | % bar 150
    r4 e4 b'2~ | % bar 151
    b4 a4 a2~ | % bar 152
    a2 gis4 e4 | % bar 153
    f?4( e4) d4( c4) | % bar 154
    d4 b4 e4 e4 | % bar 155
    e1 | % bar 156
    r2 f4 e4 | % bar 157
    d2 r2 | % bar 158
    r2 gis4 b4 | % bar 159
    a2 r2 | % bar 160
    \tag SCORE {
        R1*19 | % bar 161
    }
    \tag PARTS {
        R1*17 | % bar 161
        \voiceOne R1*2 | \oneVoice % bar 161
    }
    r2 g2 | % bar 180
    f2 e2 | % bar 181
    f2 d2 | % bar 182
    d2( c4 bes4) | % bar 183
    c1 | % bar 184
    b2 \melisma cis2 | % bar 185
    d2 \melismaEnd r4 bes'4 | % bar 186
    a2 gis2 | % bar 187
    a4 e4 a2~ %{^"FIXME: BGA and Friedemann have a, Kuhnau has g in alto and trom I; but trom I next note is (also) wrong"%} | % bar 188
    a4 b4 a4 gis4 | % bar 189
    e4 e4 f4 g4 | % bar 190
    a4 bes4 a4 g4 | % bar 191
    f4 e4 d2~ | % bar 192
    d4 d4 g4 e4 | % bar 193
    d2 r2 | % bar 194
    \tag SCORE {
        R1*17 | r2 % bar 195
    }
    \tag PARTS {
        R1*5 | % bar 195
        \voiceTwo R1*12 | r2 \oneVoice % bar 195
    }
    a'2 | % bar 212
    bes2 a4( g4) | % bar 213
    f2 g2 | % bar 214
    f2 es2 | % bar 215
    d1~ | % bar 216
    d2 b2 | % bar 217
    c2 d2 | % bar 218
    e2 e2 | % bar 219
    f2 e4( d4) | % bar 220
    cis2 e2~ | % bar 221
    e4 d2 cis4 | % bar 222
    d4 \melisma es4 f2~ | % bar 223
    f2 e2~ | % bar 224
    e2 d4 \melismaEnd a'4 | % bar 225
    bes2 a4( g4) | % bar 226
    fis2 a2~ | % bar 227
    a4 g8[( fis8] g4) a4 | % bar 228
    bes4 g4 g4 g4 | % bar 229
    a2. bes4 | % bar 230
    c4( bes4) a4( g4) | % bar 231
    fis4 a4 bes2~ \melisma | % bar 232
    bes2. a4 | % bar 233
    g2. f4 | % bar 234
    e4 f4 \melismaEnd g2 | % bar 235
    a2 r2 | % bar 236
}
\mvtItimeLine
>>

mvtIaltoLyrics = \lyricmode {
    Nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,
    nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,

    die schwe -- re Straf und gro -- ße Not,
    die schwe -- re Straf und gro -- ße __ Not,
    und gro -- ße __ Not, __
    die schwe -- re Straf __ und gro -- ße __ Not,
    und gro -- ße Not,

    die wir mit Sün -- den oh -- ne Zahl, __
    mit Sün -- den oh -- ne Zahl,
    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl,
    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl

    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben,
    ver -- die -- net ha -- ben,
    ver -- die -- net ha -- ben all -- zu -- mal,
    all -- zu -- mal,
    all -- zu -- mal.

    Be -- hüt vor Krieg und teu -- rer Zeit, __
    be -- hüt vor Krieg, vor Krieg __ und teu -- rer Zeit,
    be -- hüt vor Krieg und teu -- rer Zeit,
    vor Krieg __ und teu -- rer Zeit,

    vor Seu -- chen, __ Feur und gro -- ßem Leid, __
    und gro -- ßem Leid,
    vor Seu -- chen, Feur und __ gro -- ßem Leid, __
    vor Seu -- chen, Feur und __ gro -- ßem Leid, __
    vor Seu -- chen, Feur und gro -- ßem Leid, __
    und gro -- ßem Leid.
}


mvtItenor = <<
\relative c' {
    \autoBeamOff

    \tag SCORE {
        R1*30 | % bar 1
        r2\fermata
    }
    \tag PARTS {
        R1*24 | % bar 1
        \voiceTwo R1*6 | % bar 1
        r2\fermata
        \oneVoice
    }
    d2 | % bar 31
    d2 c2 | % bar 32
    d2 e2 | % bar 33
    c2( b4 a4) | % bar 34
    bes1 | % bar 35
    a4 a4 d2~ | % bar 36
    d2 cis2 | % bar 37
    d4 g,4 e'4 e4 | % bar 38
    e4 a,4 d2~ \melisma | % bar 39
    d4 cis8[ b8] \melismaEnd cis2 | % bar 40
    d2 r2 | % bar 41
    r4 d4 g2~ | % bar 42
    g4 f4 e2~ | % bar 43
    e4 a,4 d4 c4 | % bar 44
    b4 e,4 a2~ \melisma | % bar 45
    a8[ g8 fis8 g8] a4 \melismaEnd fis4 | % bar 46
    d4 g4 d'4 d4 | % bar 47
    d2 r2 | % bar 48
    \tag SCORE {
        R1*15 | % bar 49
    }
    \tag PARTS {
        R1*10 | % bar 49
        \voiceTwo R1*5 \oneVoice | % bar 49
    }
    r2 a2 | % bar 64
    a2 g2 | % bar 65
    c4( bes4) a4( g4) | % bar 66
    f2 g2 | % bar 67
    a2 bes2 | % bar 68
    bes2 a2 | % bar 69
    gis2 a2 | % bar 70
    a1~ \melisma | % bar 71
    a4 g4 \melismaEnd g2 | % bar 72
    f8([ g8] a2) d4 | % bar 73
    d4( c4) b4( a4) | % bar 74
    b2 b2 | % bar 75
    c1~ \melisma | % bar 76
    c4 d4 \melismaEnd a2 | % bar 77
    a2 r4 f4 | % bar 78
    bes4 a4 g2~ | % bar 79
    g4 a4 g4 \melisma f4 | % bar 80
    e4 f8[ g8] a4 \melismaEnd a4 | % bar 81
    a2 r2 | % bar 82
    \tag SCORE {
        R1*17 | % bar 83
    }
    \tag PARTS {
        R1*11 | % bar 83
        \voiceTwo R1*6 \oneVoice | % bar 83
    }
    r2 a2 | % bar 100
    c2 d4( e4) | % bar 101
    f2 e2 | % bar 102
    d1~ | % bar 103
    d2 cis2 | % bar 104
    d4 c4 bes4 a4 | % bar 105
    g4( es'2) d4 | % bar 106
    d4 g4 cis,4 d4 | % bar 107
    a2 f'2 | % bar 108
    e4 d2 cis4 | % bar 109
    a4 f'4 e4 d4 | % bar 110
    c2 \melisma f2~ | % bar 111
    f2 \melismaEnd e2 | % bar 112
    a,2 \melisma d2~ | % bar 113
    d4 e8[ f8] g4 \melismaEnd cis,4 | % bar 114
    a4 g'4 f2 | % bar 115
    e4 g2 f8[ e8] | % bar 116
    d4 d4 fis4 fis4 | % bar 117
    g4 e4 c4 a4 | % bar 118
    bes2 r4 g4 | % bar 119
    e'4 d4 e4 cis4 | % bar 120
    a2 r2 | % bar 121
    \tag SCORE {
        R1*19 | % bar 122
    }
    \tag PARTS {
        R1*11 | % bar 122
        \voiceTwo R1*8 \oneVoice | % bar 122
    }
    r2 d2 | % bar 141
    e2 d2 | % bar 142
    c2 b2 | % bar 143
    a2 b2 | % bar 144
    a4 a4 e'2~ \melisma | % bar 145
    e4 d4 \melismaEnd d4( cis4) | % bar 146
    d2. c4 | % bar 147
    bes4( a8[ g8]) a2 | % bar 148
    g4 g4 d'2~ \melisma | % bar 149
    d4 c4 \melismaEnd c4( b4) | % bar 150
    b2. a4 | % bar 151
    gis4 e4 c'2 | % bar 152
    r4 c4 d4 e4 | % bar 153
    a,2 b4( c4) | % bar 154
    b4( d2) c8[( b]) | % bar 155
    c1 | % bar 156
    r2 d4 c4 | % bar 157
    b2 r2 | % bar 158
    r2 b4 gis4 | % bar 159
    e'2 r2 | % bar 160
    R1*17 | % bar 161
    r2 d2 | % bar 178
    c2 b2 | % bar 179
    c2 a2 | % bar 180
    a2 g2 | % bar 181
    f2. g4 | % bar 182
    a4 bes4 c4 c4 | % bar 183
    f2. es4 | % bar 184
    d2 g2 | % bar 185
    f2 e2 | % bar 186
    f2 d2 | % bar 187
    e2 e2 | % bar 188
    d4 b4 e4 d4 | % bar 189
    c4 c4 d4 e4 | % bar 190
    f4 e4 f4 g4 | % bar 191
    a4 a,4 d4 c4 | % bar 192
    b4( a4) g4( a4) | % bar 193
    a2 r2 | % bar 194
    R1*18 | % bar 195
    r2 cis2 | % bar 213
    d2 c4( bes4) | % bar 214
    a2 c2 | % bar 215
    bes2 as2 | % bar 216
    g1~ | % bar 217
    g2 bes2 | % bar 218
    a2 g2 | % bar 219
    f4( g4) a4( f4) | % bar 220
    g4( a4) bes4( g4) | % bar 221
    a2 r4 a4 | % bar 222
    d4( c4) bes4( as4) | % bar 223
    g4 a4 bes4 a4 | % bar 224
    a2 d2 | % bar 225
    d2 cis2 | % bar 226
    a2 c2 | % bar 227
    c4( bes8[ a8] bes4) fis4 | % bar 228
    g2 r4 g'4 | % bar 229
    fis2. \melisma g4 | % bar 230
    a4( g4) \melismaEnd fis4( g4) | % bar 231
    a4 d,4 d4 d4 | % bar 232
    e2. f4 | % bar 233
    g4( f4 e4 d4 | % bar 234
    cis4 d4) e2 | % bar 235
    f2 r2 | % bar 236
}
\mvtItimeLine
>>

mvtItenorLyrics = \lyricmode {
    Nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,
    nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,
    nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,

    die schwe -- re Straf und gro -- ße Not,
    die schwe -- re Straf und gro -- ße Not,
    die schwe -- re __ Straf und gro -- ße Not,
    die schwe -- re Straf __ und gro -- ße Not,
    die wir mit Sün -- den oh -- ne Zahl,

    mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl,
    oh -- ne Zahl,
    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl,
    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl

    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    all -- zu -- mal,
    all -- zu -- mal.

    Be -- hüt vor Krieg und teu -- rer Zeit,
    be -- hüt vor Krieg und teu -- rer Zeit,
    be -- hüt vor Krieg,
    be -- hüt vor Krieg und teu -- rer Zeit,
    be -- hüt vor Krieg und teu -- rer Zeit,
    vor Krieg und teu -- rer Zeit,

    vor Seu -- chen, Feur und gro -- ßem Leid, __
    vor Seu -- chen, Feur und gro -- ßem Leid,
    vor Seu -- chen, Feur und gro -- ßem Leid,
    und gro -- ßem Leid,
    vor Seu -- chen, Feur und gro -- ßem Leid,
    vor Seu -- chen, Feur und gro -- ßem Leid.
}


mvtIbass = <<
\relative c' {
    \autoBeamOff

    \clef F
    \tag SCORE {
        R1*29 | % bar 1
    }
    \tag PARTS {
        R1*24 | % bar 1
        \voiceTwo R1*5 \oneVoice | % bar 1
    }
    r2 a2^\markup\right-align\right-column{"Prima" "volta"} | % bar 30
    a2_\fermata f2 | % bar 31
    g2 a2 | % bar 32
    f2( e4 d4) | % bar 33
    e1 | % bar 34
    d4 d4 g2~ | % bar 35
    g2 f2 | % bar 36
    e4 a,4 a'4 a4 | % bar 37
    b2 cis2 | % bar 38
    d2.( c8[ bes8] | % bar 39
    a2) a2 | % bar 40
    bes2 r4 a4 | % bar 41
    g4( f4) e4( d4) | % bar 42
    cis2. \melisma b8[ a8] | % bar 43
    d4 c4 \melismaEnd bes4( a4) | % bar 44
    gis2 a2 | % bar 45
    fis2 r4 fis'4 | % bar 46
    g2 g,2 | % bar 47
    d'2 r2 | % bar 48
    \tag SCORE {
        R1*20 | % bar 49
    }
    \tag PARTS {
        R1*15 | % bar 49
        \voiceOne R1*5 \oneVoice | % bar 49
    }
    r2 d2 | % bar 69
    d2 c2 | % bar 70
    f4( es4) d4( c4) | % bar 71
    b2 cis2 | % bar 72
    d4 f4 e4 d4 | % bar 73
    a'2 r4 a,4 | % bar 74
    e'4( f4) e4( d4) | % bar 75
    c2 r4 c4 | % bar 76
    f2 cis2 | % bar 77
    d4 d'4 a4 bes4 | % bar 78
    bes,2 bes'2 | % bar 79
    a2. \melisma bes8[ a8] | % bar 80
    g4 f4 \melismaEnd e4( d4) | % bar 81
    a'2 r2 | % bar 82
    \tag SCORE {
        R1*28 | % bar 83
    }
    \tag PARTS {
        R1*17 | % bar 83
        \voiceTwo R1*11 \oneVoice | % bar 83
    }
    r4 a,4 a4 a4 | % bar 111
    b4 b8[ a8] b4 cis4 | % bar 112
    d4 c4 bes4 a4 | % bar 113
    g2 g'2 | % bar 114
    f4 e4 d4 c4 | % bar 115
    bes4( a4) g4( a4) | % bar 116
    bes4 d4 d4 d4 | % bar 117
    e4 e8[ d8] e4 fis4 | % bar 118
    g4 f4 es4 d4 | % bar 119
    cis2 cis'2 | % bar 120
    d2 r2 | % bar 121
    \tag SCORE {
        R1*19 | % bar 122
    }
    \tag PARTS {
        R1*11 | % bar 122
        \voiceTwo R1*8 \oneVoice | % bar 122
    }
    r4 d,4 b'2~ \melisma | % bar 141
    b4 a4 \melismaEnd a4( gis4) | % bar 142
    a2. g4 | % bar 143
    f4( e4) d4( e4) | % bar 144
    cis2 r4 a'4 | % bar 145
    d4( bes4) g4( a4) | % bar 146
    bes4( g4) e4( fis4) | % bar 147
    g2. fis4 | % bar 148
    g1 | % bar 149
    r4 e4 a2~ | % bar 150
    a4 g4 f4 d4 | % bar 151
    e4 a,4 a4 a4 | % bar 152
    b4( a4) b4( c4) | % bar 153
    d4( c4) b4( a4) | % bar 154
    gis2 gis'2 | % bar 155
    a1 | % bar 156
    r2 a4 a4 | % bar 157
    a2 r2 | % bar 158
    r2 a4 a4 | % bar 159
    a2 r2 | % bar 160
    \tag SCORE {
        R1*21 | % bar 161
    }
    \tag PARTS {
        R1*17 | % bar 161
        \voiceTwo R1*4 \oneVoice | % bar 161
    }
    r2 bes2 | % bar 182
    a2 g2 | % bar 183
    a2 f2 | % bar 184
    f2 e2 | % bar 185
    d2 r4 cis4 | % bar 186
    d4( c4) b2 | % bar 187
    a2 r4 c4 | % bar 188
    d2 e2 | % bar 189
    a,4 a'4 a4 g4 | % bar 190
    f4 g4 f4 e4 | % bar 191
    d4 e4 f4 fis4 | % bar 192
    g4( f4) e4( a4) | % bar 193
    d,2 r2 | % bar 194
    \tag SCORE {
        R1*20 | % bar 195
    }
    \tag PARTS {
        R1*17 | % bar 195
        \voiceTwo R1*3 \oneVoice | % bar 195
    }
    r2 fis2 | % bar 215
    g2 f4( es4) | % bar 216
    d2 f2 | % bar 217
    es2 d2 | % bar 218
    cis2 r4 cis4 | % bar 219
    d4( e4) f2 | % bar 220
    e4( f4) g2 | % bar 221
    f4( g4) a2 | % bar 222
    bes,2 d2 | % bar 223
    es4( d4) cis2 | % bar 224
    d4( c4) bes4( a4) | % bar 225
    gis2 a2 | % bar 226
    d1~ | % bar 227
    d1~ | % bar 228
    d1~ | % bar 229
    d1~ | % bar 230
    d1~ | % bar 231
    d1~ | % bar 232
    d1~ | % bar 233
    d1~ | % bar 234
    d1~ | % bar 235
    d2 r2 | % bar 236
}
\mvtItimeLine
>>

mvtIbassLyrics = \lyricmode {
    Nimm von uns, Herr, du treu -- er Gott,
    du treu -- er Gott,
    nimm von uns, Herr, du treu -- er Gott,
    nimm von uns, Herr, __ du treu -- er Gott,
    du treu -- er Gott,

    die schwe -- re Straf und gro -- ße Not,
    die schwe -- re Straf,
    die schwe -- re __ Straf und gro -- ße Not,
    die schwe -- re Straf und gro -- ße Not,

    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl,
    die wir mit Sün -- den oh -- ne Zahl,
    mit Sün -- den oh -- ne Zahl

    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    ver -- die -- net ha -- ben all -- zu -- mal,
    all -- zu -- mal,
    all -- zu -- mal.

    Be -- hüt vor Krieg und teu -- rer Zeit,
    be -- hüt vor Krieg und teu -- rer Zeit,
    be -- hüt vor Krieg und teu -- rer Zeit,
    vor Krieg und teu -- rer Zeit,

    vor Seu -- chen, Feur und gro -- ßem Leid,
    vor Seu -- chen, Feur und gro -- ßem Leid,
    und gro -- ßem Leid,
    und gro -- ßem Leid. __
}


mvtIbc = <<
\relative c {
    \clef F
    d1~^"Tasto solo" | % bar 1
    d1~ | % bar 2
    d1~ | % bar 3
    d1~ | % bar 4
    d4 e4 f4 e4 | % bar 5
    d4 c4 b4 a4 | % bar 6
    b4 c4 d4 b4 | % bar 7
    e2 e,2 | % bar 8
    a4 a'4 bes4 c4 | % bar 9
    d4 c4 bes4 a4 | % bar 10
    g4 f4 es4 d4 | % bar 11
    cis2 cis'2 | % bar 12
    d4 d,8 e8 f4 g4 | % bar 13
    a4 g4 fis4 e4 | % bar 14
    d4 c4 bes4 a4 | % bar 15
    gis2 gis'2 | % bar 16
    a,1~^"tasto solo" | % bar 17
    a1~ | % bar 18
    a1~ | % bar 19
    a1~ | % bar 20
    a1~ | % bar 21
    a4 a'4 a4 a4 | % bar 22
    b4 b8 a8 b4 cis4 | % bar 23
    d4 c4 bes4 a4 | % bar 24
    g2 r2 | % bar 25
    f2 r2 | % bar 26
    r4 f4 e4 d4 | % bar 27
    cis2 r4 a4 | % bar 28
    d4 e4 f4 g4 | % bar 29
    a2 a,2 | % bar 30
    d4\fermata f4 cis4( d4) | % bar 31
    bes2 a2 | % bar 32
    b2 c2~ | % bar 33
    c4 a'4 e4( f4) | % bar 34
    g,4 g'4 d4( e4) | % bar 35
    f,4 f'4 cis4( d4) | % bar 36
    a1 | % bar 37
    b2 cis2 | % bar 38
    d4 f4 e4 d4 | % bar 39
    a'2 a,2 | % bar 40
    bes4 c4 bes4 a4 | % bar 41
    g4 f'4 e4 d4 | % bar 42
    cis4 bes'4 gis4( a4) | % bar 43
    d,4 f4 cis4( d4) | % bar 44
    gis,2 a2 | % bar 45
    fis2 fis'2 | % bar 46
    g2 g,2 | % bar 47
    d4 a'4 d4 c4 | % bar 48
    b1 | % bar 49
    a2 a'2 | % bar 50
    g4 g,4 g4 g4 | % bar 51
    a4 a8 g8 a4 bes4 | % bar 52
    c4 bes4 a4 g4 | % bar 53
    fis2 fis'2 | % bar 54
    g4-. as4-. fis4( g4) | % bar 55
    c,4-. des'4-. b4( c4) | % bar 56
    f,4-. ges4-. e?4( f4) | % bar 57
    bes,2 r2 | % bar 58
    as2 r2 | % bar 59
    r4 as'4 g4 f4 | % bar 60
    e2 r4 c4 | % bar 61
    f,4 g4 a4 bes4 | % bar 62
    c2 <\tag CELLO c \tag ORGAN c,>2  | % bar 63
    f,4-. f'4-. cis4( d4) | % bar 64
    bes2 bes'2 | % bar 65
    a4 g4 f4 e4 | % bar 66
    d2 es2~ | % bar 67
    es4 d4 g,4 gis4 | % bar 68
    a4 e4 f4 d4 | % bar 69
    d'4 b4 c4 a4 | % bar 70
    f'4 es4 d4 c4 | % bar 71
    b2 cis2 | % bar 72
    d4 f4 e4 d4 | % bar 73
    a'2 a,2 | % bar 74
    e'4 f4 e4 d4 | % bar 75
    c4 bes4 a4 g4 | % bar 76
    f4 f'4 cis4( d4) | % bar 77
    d,4-. d''4-. a4( bes4) | % bar 78
    bes,2 bes'2 | % bar 79
    a2. bes8 a8 | % bar 80
    g4 f4 e4 d4 | % bar 81
    a'1~ | % bar 82
    a1~ | % bar 83
    a4 g4 f4 e4 | % bar 84
    d4 e4 d4 c4 | % bar 85
    bes4 c4 bes4 a4 | % bar 86
    g2. a8 bes8 | % bar 87
    c2 <\tag CELLO c \tag ORGAN c,>2  | % bar 88
    f,4 a4 a4 a4 | % bar 89
    b4 b8 a8 b4 cis4 | % bar 90
    d4 c bes a | % bar 91
    gis2 gis'2 | % bar 92
    a4 g4 f4 e4 | % bar 93
    d2 r2 | % bar 94
    c2 r2 | % bar 95
    r4 c'4 b4 a4 | % bar 96
    gis2 r4 e4 | % bar 97
    a,4 b4 c4 d4 | % bar 98
    e2 e,2 | % bar 99
    a2 r4 a'4 | % bar 100
    e4( f4) r4 cis4 | % bar 101
    d4 d'4 gis,4( a4) | % bar 102
    d,2 e4 fis4 | % bar 103
    g4 e4 a4 a,4 | % bar 104
    bes4 d4 g4 f4 | % bar 105
    es4 c4 a4 d4 | % bar 106
    g,4 f'4 e4 d4 | % bar 107
    cis2 d2 | % bar 108
    g,2 a2 | % bar 109
    d,2 r2 | % bar 110
    r4 a'4 a4 a4 | % bar 111
    b4 b8 a8 b4 cis4 | % bar 112
    d4 c4 bes4 a4 | % bar 113
    g2 g'2 | % bar 114
    f4 e4 d4 c4 | % bar 115
    bes4 a4 g4 a4 | % bar 116
    bes4 d,4 d4 d4 | % bar 117
    e4 e8 d e4 fis4 | % bar 118
    g4 f4 es4 d4 | % bar 119
    <\tag CELLO cis \tag ORGAN cis'>2  cis'2 | % bar 120
    d2 r2 | % bar 121
    c2 r2 | % bar 122
    bes2 r2 | % bar 123
    a2 r2 | % bar 124
    g2 r2 | % bar 125
    f2 r2 | % bar 126
    e2 r2 | % bar 127
    d2 r2 | % bar 128
    c'2 r2 | % bar 129
    bes2 r2 | % bar 130
    a2 r2 | % bar 131
    g2 r2 | % bar 132
    f'2 r2 | % bar 133
    es2 r2 | % bar 134
    d2 r2 | % bar 135
    c2 r2 | % bar 136
    bes4-. bes'4-. fis4( g4) | % bar 137
    c,2 d2 | % bar 138
    g,2 g'2 | % bar 139
    a2 a,2 | % bar 140
    d4 d'4 gis,4 b4 | % bar 141
    c,4 f4 b,4 e4 | % bar 142
    a,4 c4 d4 e4 | % bar 143
    f4 e4 d4 e4 | % bar 144
    cis2 r4 a4 | % bar 145
    d4 bes4 g4 a4 | % bar 146
    bes4 g4 e4 fis4 | % bar 147
    g2. fis4 | % bar 148
    g2 g'2 | % bar 149
    gis2 a2~ | % bar 150
    a4 g4 f4 e8 d8 | % bar 151
    e4 a,4 a4 a4 | % bar 152
    b4 b8 a8 b4 c4 | % bar 153
    d4 c4 b4 a4 | % bar 154
    gis2 gis'2 | % bar 155
    a,1^"tasto solo"~ | % bar 156
    a1~ | % bar 157
    a1~ | % bar 158
    a1~ | % bar 159
    a4 b4 c4 b4 | % bar 160
    a4 g4 fis4 e4 | % bar 161
    fis4 g4 a4 fis4 | % bar 162
    b2 b2 | % bar 163
    e,4 e'4 f4 g4 | % bar 164
    a4 g4 f4 e4 | % bar 165
    d4 c4 bes4 a4 | % bar 166
    gis2 gis'2 | % bar 167
    a4 a,8 b8 c4 d4 | % bar 168
    e4 d4 cis4 b4 | % bar 169
    a4 g4 f4 e4 | % bar 170
    <\tag CELLO dis \tag ORGAN dis'>2  dis'2 | % bar 171
    e,1^"tasto solo"~ | % bar 172
    e1~ | % bar 173
    e1~ | % bar 174
    e1~ | % bar 175
    e1~ | % bar 176
    e4 e'4 e4 e4 | % bar 177
    fis4 fis8 e8 fis4 gis4 | % bar 178
    a4 f4 d4 e4 | % bar 179
    a,4 b4 cis4 a4 | % bar 180
    d2. cis4 | % bar 181
    d2. e4 | % bar 182
    f2 e2 | % bar 183
    es2 d2 | % bar 184
    g,4 a4 a4 a4 | % bar 185
    b4 b8 a8 b4 cis4 | % bar 186
    d4 c4 b2 | % bar 187
    a2 c2 | % bar 188
    d2 e2 | % bar 189
    a,4 a'4 a4 g4 | % bar 190
    f4 f8 g8 f4 e4 | % bar 191
    d4 e4 f4 fis4 | % bar 192
    g4 f4 e4 a4 | % bar 193
    d,4 a'4 d4 c4 | % bar 194
    bes2 bes,2 | % bar 195
    a2 r2 | % bar 196
    g'2 r2 | % bar 197
    f2 r2 | % bar 198
    e2 r2 | % bar 199
    d2 r2 | % bar 200
    c2 r2 | % bar 201
    bes2 r2 | % bar 202
    a2 r2 | % bar 203
    g2 r2 | % bar 204
    f'2 r2 | % bar 205
    e2 r2 | % bar 206
    d2 r2 | % bar 207
    c2 r2 | % bar 208
    bes2 r2 | % bar 209
    a2 r2 | % bar 210
    g2 r2 | % bar 211
    f4-. f'4-. cis4( d4) | % bar 212
    r4 g4-. a,4( bes4) | % bar 213
    r4 bes'4-. es,4( e4) | % bar 214
    r4 c'4-. fis,4( g4) | % bar 215
    r4 g4-. b,4( c4) | % bar 216
    r4 b4-. d,4( es4) | % bar 217
    r4 es'4-. cis4( d4) | % bar 218
    c1\trill | % bar 219
    d4 e4 f2 | % bar 220
    e4 f4 g2 | % bar 221
    f4 g4 a2 | % bar 222
    bes,4 c4 d2 | % bar 223
    <\tag CELLO es, \tag ORGAN es'>4 <\tag CELLO d \tag ORGAN d'>4 <\tag CELLO cis \tag ORGAN cis'>2 | % bar 224
    <\tag CELLO d \tag ORGAN d'>4 c'?4 bes4 a4 | % bar 225
    gis2 a2 | % bar 226
    d,1^"tasto solo"~ | % bar 227
    d1~ | % bar 228
    d1~ | % bar 229
    d1~ | % bar 230
    d1~ | % bar 231
    d1~ | % bar 232
    d1~ | % bar 233
    d1~ | % bar 234
    d1~ | % bar 235
    d4 d'8 e f4 e | % bar 236
}
\mvtItimeLine
>>


mvtIfigs = \figuremode {
    s1*4 | %4
    s2 <6> |
    <6\\ 5> <6\\> <6\\ 5> <6\\>4 <7> |
    <9 _+>2 <8>4 <7> |
    s2 <6 4- 2> | %9
    <9- 7 _+> <5\+ 3>4 <6\\> |
    s2 <5> |
    <7- 5> <6>4 <5> |
    <9>2 <6> |
    <6\\ 5-> <6> |
    <_+> <6>4 <6\\> |
    <6 5>2 \once \bassFigureExtendersOn <6 5> |
    <_+>1 |
    s1*4 |

    <_+>2 <6 _+> | %22
    <6 5> <6 4> |
    <9> <3> |
    <7>4 <6-> s2 |
    <6> s |
    <6 4 2> <6\\ 5> |
    <7- 5> s4 <7 _+> |

    s <6\\> <6> <6> | %29
    <6 5> <4> \once \bassFigureExtendersOn <5 4> <_+> |
    s2 <6 4 2> |
    <6> s |
    <[3] 6\\> <[9] 5\+> |
    <[8 \FBx]> <5\+> |
    <_-> <6 4> |
    <9>4 <8> <6>2 |
    <5 4> <6 _+> |

    <6> <6> | %38
    <9>4 <6>2 \once \bassFigureExtendersOn <6>4 |
    <4>2 <_+> |
    <5>2. \once \bassFigureExtendersOn <5>4 |
    s2 <5-> |
    <6> <6 4\+ 2> |
    <9>4 <6>2 \once \bassFigureExtendersOn <6>4 |
    <6 5>2 <_+> |

    <6> <6 5> | %46
    <9> <8> |
    <4> <6- 3>4 <6> |
    <6\\ 5>2. <4>8  <3> |
    <_+>2 <5 _->4 <6\\> |
    <4>2 <6- 3>4 <5> |
    <9>2 <8 _+> |       % auto has: <4>2 <_>2 |
    <6 4\+ 2>2. \once \bassFigureExtendersOn <6 4\+ 2>4 |
    <[6]>2 <7- 5> |

    <9 5> <6 4 2> | %55
    <7> <7->4 <5> |
    <9 _->2 <6 4- 2> |
    <7- _->4 <6> <4\+> <5> |
    <6>2 s |
    <6 4- 2>2 <6\\> |
    <7->4 <6> s <7> |
    <9>2 <6>4 <6> |
    <6 5>4 <5 4> <\FBx> <3> |
    s2 <6 5> |

    <7>2 <6> | %65
    s <6> |
    s <6> |
    <6\\ 4 3>4 <3> <6 _-> \once \bassFigureExtendersOn <5 _-> |
    <9 _+>2 <6> |
    <6\\ 4\+ 2> <6 _-> |
    <7->2. \once \bassFigureExtendersOn <7->4 |
    <7>4 <6> <6 5>2 |
    <9>4 <6>2 \once \bassFigureExtendersOn <6>4 |

    <4>4 <3> <6\\ 4\+ 3>2 | %74
    <5\+>4 s s2 |
    <_->2. \once \bassFigureExtendersOn <_->4 |
    <7-> <6> <6> s |
    <9> <8> <6 4> <3> |
    <6>2 s |
    <7 _+>2. <5>4 |

    <6 4\+ 2>2 <7 4 2> | %81
    <4> <_+> |
    <7 9 _+>1 |
    <9 _+>2 <7 5\+>4 <3> |
    s1 |
    <6 5> |
    <7>4 <6> s <4> |
    <9>2 <8>4 <7> |
    s <6> s2 |
    <6 5> <6 4> |

    <9> <3> | %91
    <7-> <6>4 <5> |
    <9\\>2 <3> |
    <7>4 <6-> <4\+> <5> |
    <6>2 s |
    s4 <6> <6\\ 5> s |
    <7- 5>2 s4 <7 _+> |
    <9\\> s <6> <6\\> |
    <6 5\+> <\markup{ } 4> \once \bassFigureExtendersOn <5\+ 4> <_+> |
    s1 |

    <6>2 s4 <6> | %101
    <6\\> s <6> <_+> |
    s2 <7> |
    <6 5> <5 _+> |
    <6> <6->4 <6 4> |
    <6 5> s <6\\> <[_+]> |
    <4>2 <5> |
    <6 5> <9>4 <8> |

    <6 4\+> <7 5> <5 4> <_+> | %109
    s1 |
    s4 <5> <6> s |
    <7 5>2 <6 4> |
    <9> <5> |
    <6 5> <\FBx>4 <4\+> |
    <6>2 <6>4 <6> |

    <6 4 2\+>2. \once \bassFigureExtendersOn <6 4 2\+>4 | %116
    <6>2 <_+> |
    <7>2. \once \bassFigureExtendersOn <7>4 |
    s2 <5> |
    <6 5> s |
    s1 |
    <6 4\+ 2>2 s |
    <6> s |

    <6\\>1 | %124
    s1 |
    <6 4\+ 2> |
    <6> |
    <6\\> |
    s |
    <6 4 2> |
    <6> |
    <6> |
    s |
    <6 4 2> |

    <6> | %135
    <6 _-> |
    <5>2 <6 4 2> |
    <9 7> <7 _+> |
    <4>4 <3> <6> <5> |
    <9 _+>2 <8>4 <7> |
    s2  <5 3> |
    <7\\>4 <7> <7> <7 _+> |
    s2 <6\\ 5>4 <3> |
    <5>2 <6\\ 4\+ 2> |

    <6> <5> | %145
    <9>4 <3> <6 5> <_+> |
    s2 <7>4 <7 5> |
    <_->2 <5 4 2> |
    <4>4 <_!> s2 |
    <6 5> s
    <6 4 2\+> <6 4\+> |
    <6 5\+ _+> <3> |

    <7> <6\\>4 <7\\ 3> | %153
    <5>2 <7> |
    <7 5> <6> |
    s1*4 |
    s2 <6> |
    <6\\ 5> <6\\>4 <6\\> |

    <6\\>2 <6\\ 4\+ 3> | %162
    <9 _+> <8>4 <7> |
    <5\+>2 <6 4- 2> |
    <7 _+>2. \once \bassFigureExtendersOn <7 _+>4 |
    s2 <5> |
    <7-> <6>4 <5> |
    <9\\>2 <6> |
    <6\\ 5> <5>4 <6> |
    <7 _+> <6 4\+ 2> <6> <6 4> |
    <6\\ 5>2 s |

    <_+>1 | %172
    s1*4 |
    s2 <6 _+> |
    <6 5> <6 4\+> |
    <9\\>4 <3> <6\\ 5> <_+> |
    s2 <6 5> |
    <5 3> <6 4 2>4 <6 5> |

    <5>2 <6> | %182
    <6> <6>4 <5> |
    <4 2>2 <[7 5-]> |
    <7 5 _!> <7 _+> |
    <7 5> <6 4> |
    s <6\\> |
    s <6> |
    <6\\ 5> <_+> |

    s1 | %190
    <6> |
    s2 <6>4 <6 5> |
    <_!>2 <5\+>4 <_+> |
    s1 |
    <6 5>2 <6 4 2\+>4 <3> |
    <_+>1 |
    <6 4\+ 2> |
    <6> |

    <6\\> | %199
    s |
    <6 4\+ 2> |
    <6> |
    <6\\> |
    s |
    <6 4\+ 2> |
    <6> |
    <6\\> |
    s |
    <6 4 2> |

    <6> | %210
    <6> |
    s2 <6 5> |
    s <_+>4 <6 4 2\+> |
    s <5> <6> <5> |
    s <6 4> <7- 5> s |
    s <5> <7- 5> s |
    s <6> s <5\+> |
    s <6> <7 5> s |
    <6>2 <5> |

    s <7>4 <6> | %220
    <6\\ 5>2 <6> |
    <7>4 <5> <7 4> <_+> |
    <5>2 <6>4 <5-> |
    <9>2 <7- 5> |
    <9> <3> |
    <6 5\+ 3-> <_+> |
    <_+>1 |

    s1*8 | %228
    s2 <[6]> |
}
