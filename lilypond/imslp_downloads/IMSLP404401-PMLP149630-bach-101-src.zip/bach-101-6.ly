\version "2.19.11"

\include "common.ly"


mvtVItimeLine = {
    \time 12/8
    \key d \minor

    s1.*1 |
    \segno
    s1.*54 | %55
    \dalSegno
    \bar "||"
}


mvtVIbreaks = {
    <>^"BGA breaks left in"
    \repeat unfold 2 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \pageBreak

    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 2 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \pageBreak

    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \pageBreak

    \repeat unfold 2 { s1.\noBreak }
    \break
    \repeat unfold 2 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \pageBreak

    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \break
    \repeat unfold 2 { s1.\noBreak }
    \break
    \repeat unfold 3 { s1.\noBreak }
    \pageBreak
}


mvtVIfl = <<
\relative c'' {
    r4. r8 r8 d16( e32 f32) \appoggiatura f8 e8. f16-. d8-. d8( cis8) e16( f32 g32) | % bar 1
    \appoggiatura g8 f8. g16-. e8-. e8( d8) a'16( bes32 c32) \appoggiatura c8 bes8. a16-. g8-. cis8.( d16) e8 | % bar 2
    a,8.( d16) d,8-. g8 a16( g16 f16 e16) f16-. d16( cis16 d16) f16-. g16-. a16-. d,16( cis16 d16) a'16-. b16-. | % bar 3
    c16-. a16( gis16 a16) c16 d16 e4.~ e2. | % bar 4
    e4. c4. d4. e4. | % bar 5
    c4. b4.\trill a4. r8 r8 a16( bes32 c32) | % bar 6
    \appoggiatura c8 bes8. c16-. a8-. a8( g8) g16( a32 bes32) \appoggiatura bes8 a8. bes16-. g8-. g8( f8) bes8-. | % bar 7
    \appoggiatura a8 g4.~ g8.( e16) a8 \appoggiatura g8 f4. e4.~ | % bar 8
    e4. d4.~ d4 d8 \appoggiatura d8 cis8. d16-. e8-. | % bar 9
    a,8.( cis16) e8-. g4.~ g8. a16 f8-. f8.( g16) e8-. | % bar 10
    d16-. g,16( fis16 g16) bes16-. cis16-. \appoggiatura cis8 d4.~ d16 f,16( e16 f16) a16-. cis16-. \appoggiatura cis8 d4.~ | % bar 11
    d16 cis16( b16 cis16) e16-. f16-. g16-. e16( d16 e16) g16-. a16-. \appoggiatura a8 bes8. g16-. a8-. d,8.( e16) cis8-. | % bar 12
    \appoggiatura cis8 d4.\fermata~ d4 r8 r8 r8 e16\Pia( f32 g) g4 r8 | % bar 13
    r8 r8 f16( g32 a32) a4 r8 r8 r8 e16( f32 g32) g4 r8 | % bar 14
    r8 r16 a,16-. d8-. d8.( e16) cis8-. \appoggiatura cis8 d4. r4. | % bar 15
    r4. r8 r8 a16\For( b32 c32) \acciaccatura c8 b8. c16\PdO a8\PdS a8( gis8) b16( c32 d32) | % bar 16
    \appoggiatura d8 c8. d16-. b8-. b8( a8) e'16( f32 g32) f8.\trill e16 d8 gis8.( a16) b8 | % bar 17
    e,8. a16 a,8-. d8 e16( d16 c16 b16) c16-. a16( gis16 a16) c16-. d16-. e16-. a,16( gis16 a16) e'16-. f16-. | % bar 18
    \appoggiatura f8 g4 r8 r4. r2. | % bar 19
    R1.*5 | % bar 20
    f4.\For~ f16 d16( cis16 d16) f16-. g16-. a4.~ a16 c,16( bes16 c16) f16-. a16-. | % bar 25
    bes2.~ bes8. g16-. a8-. a8.( bes16) g8\trill | % bar 26
    f16\Pia-. f,16( e16 f16) a16-. bes16-. c16-. f,16( e16 f16) c'16-. d16-. e4 r8 r4. | % bar 27
    a8.( d16) d,8-. g8 a16( g16 f16 e16) \appoggiatura e8 f8. a,16 bes8~ bes8 a8-. g8-. | % bar 28
    f16-. f16( e16 f16) bes16-. c16-. d16-. g,16( f16 g16) c16-. d16-. e4 r8 r4. | % bar 29
    e8.( a16) a,8-. d8 e16( d16 c16 b16) \appoggiatura b8 c8. d16 b8 b4\trill a8 | % bar 30
    a4 r8 a4\For( b8) c4( cis8) d4( e8) | % bar 31
    f4. e4. d4. cis4. | % bar 32
    d4. r8 r8 c16\Pia( d32 es32) \appoggiatura es8 d4( c8) bes4( a8) | % bar 33
    g4.~ g8 fis8 c'8~ c8 bes8 es8~ es8 d8 c8 | % bar 34
    bes16-. g16( fis16 g16) bes16-. c16-. d16-. g,16( fis16 g16) d'16-. e16-. f16-. d16( cis16 d16) f16-. g16-. a4.\For~ | % bar 35
    a2. a4. f4. | % bar 36
    g4. a4. f4. e4. | % bar 37
    d4. r4. r2. | % bar 38
    R1.*6 | % bar 39
    r4. r8 r8 a16\For( bes32 c32) \appoggiatura c8 bes8. c16\PdO a8\PdS a8( g8) g16( a32 bes32) | % bar 45
    \appoggiatura bes8 a8. bes16-. g8-. g8( fis8) fis'8 g8. es16 f8 \appoggiatura f8 es4.~ | % bar 46
    es4. d4.~ d8 c8( b8) \appoggiatura b8 c4.~ | % bar 47
    c8 b8( a8) b4.\trill c4. r4. | % bar 48
    r4. r8 r8 g16\Pia( a32 bes32) \appoggiatura bes8 a8. bes16-. g8-. g8( fis8) a16( bes32 c32) | % bar 49
    \appoggiatura c8 bes8. c16-. a8-. a8( g8) d'16( es32 f32) \appoggiatura f8 es8. d16-. c8-. fis8.( g16) a8-. | % bar 50
    d,8.( g16) g,8-. c8 d16( c16 bes16 a16) bes16-. g16( fis16 g16) bes16-. c16-. d16-. g,16( fis16 g16) d'16-. e16-. | % bar 51
    f16-. d16( cis16 d16) f16-. g16-. a4. r8 r8 e16( f32 g32) g4. | % bar 52
    r8 r8 f16( g32 a32) a4. r8 r8 e16( f32 g32) g4. | % bar 53
    r8 r8 bes,8 c8 bes16( a16 g16 f16) f'4 r8 r4. | % bar 54
    r4. r8 r8 d16( e32 f32) \appoggiatura g8 e8. f16-. d8-. d8( cis8) e16( f32 g32) | % bar 55
}
\mvtVItimeLine
>>


mvtVIobdc = <<
\relative c'' {
    r4. r8 r8 a8 a2.~ | % bar 1
    a4. f4. g4. a4. | % bar 2
    f4. e4. d4. r4. | % bar 3
    r4. r8 r8 a16( b32 c32) b8. c16 a8 a8( gis8) b16( c32 d32) | % bar 4
    c8.( d16) b8 b8( a8) e'16( f32 g) f8.( e16) d8 gis8.\trill( a16) b8 | % bar 5
    e,8.( a16) a,8 d8 e16( d16 c16 b16) c16 a16( gis16 a16) c16 d16 e16 a,16( gis16 a16) e'16 f16 | % bar 6
    g4. r8 r8 e16( f32 g32) f8.( g16) e8 e8( d8) d16( e32 f32) | % bar 7
    e8.( f16) d8 d8( cis8) cis'8 d2. | % bar 8
    c4.~ c4 a16( bes32 c) bes8.( c16) a8 g4.~ | % bar 9
    g8. a16( bes8) e,4.~ e8.( f16) d8 d8.( e16) cis8 | % bar 10
    d4.~ d16 bes16( a16 bes16 d16) e16 f4.~ f16 a,16( g16 a16 d16) f16 | % bar 11
    g2.~ g8. e16 f8 f8.( g16) e8 | % bar 12
    d4.\fermata r8 r8 d16\Pia( e32 f) e8.( f16) d8 d8( cis8) e16( f32 g32) | % bar 13
    f8.( g16) e8 e8( d8) a'16( bes32 c32) bes8.( a16) g8 cis8.( d16) e8 | % bar 14
    a,8.( d16) d,8 g8 a16( g16 f16 e16) f16 d16( cis16 d16 f16) g16 a16 d,16( cis16 d16 a'16) b16 | % bar 15
    c16 a,16( gis16 a16) c16 d16 e4. r8 r8 b16( c32 d) d4 r8 | % bar 16
    r8 r8 c16( d32 e32) e4 r8 r8 r8 b16( c32 d32) d4 r8 | % bar 17
    r8 r16 e16-. a8-. a8.( b16) gis8 a4. r4. | % bar 18
    R1.*6 | % bar 19
    r16 bes,16\f( a16 bes16 d16 e16) f4.~ f16 a,16( g16 a16 c16) e16 f4.~ | % bar 25
    f16 e16( d16 e16 g16) a16 bes16 \once \slurDashed e,16( d16 e16 bes'16) c16 d8.( bes16) c8 f,8.( g16) e8 | % bar 26
    f4. r4. g16\p c,16( b16 c16) g'16 a16 bes16 d,16( cis16 d16) b'16 cis16 | % bar 27
    d4 r8 r4. a8.( d16) d,8 g8 a16( g16 f16 e16) | % bar 28
    d4 r8 r4. c16 g16( f16 g16) c16 d16 e16 a,16( gis16 a16) fis'16 gis16 | % bar 29
    a4 r8 r4. d,8.( a'16) a,8 d8 e16( d16 c16 b16) | % bar 30
    c4. r4. r2. | % bar 31
    R1. | % bar 32
    r4. d4( es8) f4( fis8) g4( a8) | % bar 33
    bes4. a4. g4. fis4. | % bar 34
    g4. r4. r4. r8 r8 d16( e32 f32) | % bar 35
    e8.( f16) d8 d8( cis8) e16( f32 g32) f8.( g16) e8 e8( d8) a'16( bes32 c32) | % bar 36
    bes8. a16 g8 cis8.( d16) e8 \once \slurDashed a,8.( d16) d,8 g8 a16( g16 f16 e16) | % bar 37
    f16 d16( cis16 d16 f16) g16 a16 d,16( cis16 d16 a'16) bes16 c4 r8 r4. | % bar 38
    R1.*5 | % bar 39
    r2. r4. r8 r8 d,16\f( es32 f) | % bar 44
    es8.( f16) d8 d8( c8) c16( d32 es32) d8.( es16) c8 c8( bes8) es8 | % bar 45
    \grace d8 c4.~ c8. a16 d8 bes8.\trill a16 g8 c4.~ | % bar 46
    c4. bes4.~ bes8 as8 g8 as4.~ | % bar 47
    as8 g8 f8 g4. g4. r4. | % bar 48
    r2. r8 r8 a'16\p( bes32 c32) c4 r8 | % bar 49
    r8 r8 bes16( c32 d32) d4 r8 r8 r8 a16( bes32 c32) c4 r8 | % bar 50
    r8 r16 d,16-. g8-. g8.( a16) fis8 g4. r4. | % bar 51
    r4. r8 r8 d16( e32 f32) e8.( f16) d8 d8( cis8) e16( f32 g32) | % bar 52
    f8.( g16) e8 e8( d8) a'16( bes32 c32) bes8.\trill a16 g8 \once \set suggestAccidentals = ##t cis8.( d16) e8 | % bar 53
    a,8. d16 d,8 f8 g16( f16 e16 d16) bes'4 r8 r4. | % bar 54
    r4. r8 r8 a8 a2. | % bar 55
}
\mvtVItimeLine
>>


mvtVIsoprano = <<
\relative c'' {
    \autoBeamOff

    R1.*15 | % bar 1
    r4. r8 r8 e8 e2.~ | % bar 16
    e4. c4. d4. e4. | % bar 17
    c4. b4. a4 e'8 a4 f8 | % bar 18
    d8[( e8)] f8 e8[( d8)] e8 f4( e8) e8[( d8)] d16[( e32 f32)] | % bar 19
    \grace f8 e4 d8 cis8[ \once \set suggestAccidentals = ##t b8] cis8 d2. | % bar 20
    \melisma cis4. c4. b4. bes4. | % bar 21
    a4 \melismaEnd a8 d4 d8 g,4 g8 c4.~  | % bar 22
    c4 bes8 \autoBeamOn es4.~ \melisma es8 c8 d8 g4.~ | % bar 23
    g8[ e] \melismaEnd \autoBeamOff f bes,4 bes8 bes8[ g8] a8 a8[ bes8] g8 | % bar 24
    f4 f8 r4. r2. | % bar 25
    R1. | % bar 26
    r4. a4. c4( cis8) d4( e8) | % bar 27
    f4. e4. d4. cis4. | % bar 28
    d4. r8 r8 d16[( e32 f32)] e4 d8 c4 b8 | % bar 29
    \autoBeamOn a4.~ \melisma a8 gis8 d'8~ d8 c8 f8~ f8[ e8] \melismaEnd \autoBeamOff d8 | % bar 30
    c4 bes?8 a4 g8 f4 g8 a8[( d8)] cis | % bar 31
    d8[ e8] f8 g8[ e8] cis8 d8[( e8)] f8 e8[( d8)] e8 | % bar 32
    d4. r8 r8 a8 bes[( f)] a8 bes4 c8 | % bar 33
    bes8[ a8] g8 g'4. r8 g8 es8 c8[( bes8)] a8 | % bar 34
    bes4 d8 g4 bes,8 a4 a8 d8[( cis8)] d8 | % bar 35
    cis4 d8 e4.~ e8[ d8] cis8 d8[ e8] f8 | % bar 36
    f8[ e16 d16] e8 e4.~ e4 a,8 bes8[ a8] g8 | % bar 37
    f4 r8 r8 r8 d'16[( es32 f32)] es4 d8 c4 c16[( d32 es32)] | % bar 38
    d4 c8 c8[( bes8)] es8 \grace d8 c4.~ c8[ a8] d8 | % bar 39
    bes8[ a] bes8 a4.~ a4 a8 d8[ c8] d8 | % bar 40
    g,4 g8 c4 c8 b4.( bes4. | % bar 41
    a4.) as4. g4.~ g4 f8 | % bar 42
    bes4.~ bes8[ g8] a8 d4 d8 c4 c8 | % bar 43
    c8[( a8)] bes8 bes8[( c8)] a8 bes4 r8 r4. | % bar 44
    R1.*2 | % bar 45
    r4. r8 r8 d16[( es32 f32)] es8.[ f16] d8 d8[( c8)] c16[( d32 es32)] | % bar 47
    d8.[( es16 c8]) c8[( b16 a16 b8)] c4. r8 r8 c8 | % bar 48
    a'4 fis8 d4 d8 d2.~ | % bar 49
    d4. bes4. c4. d4. | % bar 50
    bes4. a4. g4 d'8 g4 bes,8 | % bar 51
    a4 a8 d8[ cis8] d8 cis4 d8 e4.~ | % bar 52
    e8[ d8] cis8 d8[ e8] f8 f8[ e16 d16] e8 e4.~ | % bar 53
    e4 d8 es8[ cis8] d8 d4. cis4. | % bar 54
    d4. r4. r2. | % bar 55
}
\mvtVItimeLine
>>


mvtVIlyricsSoprano = \lyricmode {
    Ge -- denk __ an Je -- su bit -- tern Tod,
    nimm Va -- ter, dei -- nes Soh -- nes Schmer -- zen
    und sei -- ner Wun -- den Pein, __
    und sei -- ner Wun -- den Pein, __
    zu Her -- zen, sei -- ner Wun -- den Pein zu Her -- zen.

    sie sind __ ja __ für die gan -- ze Welt
    die Zah -- lung und das Lö -- se -- geld,
    sie sind __ ja __ für die gan -- ze Welt
    die Zah -- lung und das Lö -- se -- geld,
    die Zah -- lung und das Lö -- se -- geld,
    und das Lö -- se -- geld;

    er -- zeig auch mir zu al -- ler Zeit,
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit. __
    Barm -- her -- zig -- keit;
    er -- zeig auch mir zu al -- ler Zeit,
    barm -- herz -- ger Gott,
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit,
    barm -- herz -- ger Gott, __ zu al -- ler Zeit,
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit.

    Ich seuf -- ze stets in mei -- ner __ Not, ich seuf -- ze stets:
    ge -- denk __ an Je -- su bit -- tern Tod,
    ge -- denk __ an Je -- su bit -- tern Tod,
    ge -- denk __ an Je -- su bit -- tern Tod,
    an Je -- su bit -- tern Tod!
}


mvtVIalto = <<
\relative c'' {
    \autoBeamOff

    R1.*12 | % bar 1
    r4. r8 r8 a8 a2.~ | % bar 13
    a4. f4. g4. a4. | % bar 14
    f4. e4.\trill d4 a'8 d4 f,8 | % bar 15
    e4 e8 a8[( gis8)] a8 gis4 \melisma a8 b4.~ | % bar 16
    b8 \melismaEnd a8 gis8 a8[ b8] c8 c8[ b8] a8 b4.~ | % bar 17
    b4 e,8 f8[( e8 d8)] c4 r8 r8 r8 a'16[( bes32 c32)] | % bar 18
    bes4 a8 g4 g16[( a32 bes32)] a4 g8 g8 f8 bes8 | % bar 19
    g4.~ g8[ e8] a f[ e] f8 e4.~ | % bar 20
    e4 e8 a8[ g8] a8 d,4 d8 g4. | % bar 21
    \melisma fis4. f4. e4. es4. | % bar 22
    d4.~ d4 \melismaEnd c8 \autoBeamOn f4.~ \melisma f8 d8 e8 | % bar 23
    a4 \melismaEnd \autoBeamOff a8 g4 g8 g8[ e8] f8 f8[ g8] e8 | % bar 24
    f4 f8 r4. r2. | % bar 25
    R1.*3 | % bar 26
    r4. d4. g4( gis8) a4( b8) | % bar 29
    c4. b4. a4. gis4. | % bar 30
    a4. r8 r8 g16[ a32 bes32] a4 g8 f4 e8 | % bar 31
    \autoBeamOn d4.~ \melisma d8 cis8 g'8~ g8 f8 bes8~ bes8[ a8] \melismaEnd \autoBeamOff g8 | % bar 32
    f4 es8 d4 c8 bes4 c8 d8[( g8)] fis8 | % bar 33
    g8[ a8] bes8 c8[ a8] fis8 g8[ a8] bes8 a8[ g8] a8 | % bar 34
    g4 r8 r4. r2. | % bar 35
    r8 r8 e16[( f32 g32]) g4. r8 r8 f16[( g32 a32)] a4 r8 | % bar 36
    r8 r8 e16[( f32 g32)] g4 r8 r8 r8 d8 d8.[( e16)] cis8 | % bar 37
    d4 a'8 d4 bes8 g8[( a8)] bes8 a8[( g8)] a8 | % bar 38
    bes4 a8 a8[( g8)] g16[( a32 bes32)] a4 g8 fis8[ e8] fis8 | % bar 39
    g4. g4. fis4. \melisma f4. | % bar 40
    e4. es4. d4 \melismaEnd d8 g8[ f8] g8 | % bar 41
    c,4 c8 f4.~ f4 es8 as4.~ | % bar 42
    as8[ f8] g8 c4.~ c8[ a8] bes8 es,4 es8 | % bar 43
    es8[ c8] d8 d8[ es8] c8 bes4 r8 r4. | % bar 44
    R1. | % bar 45
    r2. r4. r8 r8 g'16[( as32 bes32)] | % bar 46
    as8.[( bes16)] g8 g8[ f8] f16[( g32 as32)] g8.[ as16] f8 f8[( es8)] as8 | % bar 47
    \grace g8 f4.~ f8.[ d16] g8 es4 g8 a16[ bes16 c8] a8 | % bar 48
    fis4 r8 r4. r2. | % bar 49
    R1.*2 | % bar 50
    r4. r8 r8 a8 a2.~ | % bar 52
    a4. f4. g4. a4. | % bar 53
    fis4. \melisma f4.~ f8[ bes8 a8] f8\trill[ e8] \melismaEnd d8 | % bar 54
    d4. r4. r2. | % bar 55
}
\mvtVItimeLine
>>


mvtVIlyricsAlto = \lyricmode {
    Ge -- denk __ an Je -- su bit -- tern Tod,
    nimm Va -- ter, dei -- nes Soh -- nes Schmer -- zen
    und sei -- ner Wun -- den Pein, __
    zu Her -- zen,
    nimm Va -- ter, dei -- nes Soh -- nes Schmer -- zen
    und sei -- ner Wun -- den Pein __
    und sei -- ner Wun -- den Pein __ zu Her -- zen,
    sei -- ner Wun -- den Pein __ zu Her -- zen.

    sie sind __ ja __ für die gan -- ze Welt
    die Zah -- lung und das Lö -- se -- geld,
    sie sind __ ja __ für die gan -- ze Welt
    die Zah -- lung und das Lö -- se -- geld;

    er -- zeig auch mir, auch mir zu al -- ler Zeit,
    er -- zeig auch mir zu al -- ler Zeit,
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit,
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit, __
    zu al -- ler Zeit, __
    barm -- herz -- ger Gott, Barm -- her -- zig -- keit.

    Ich seuf -- ze stets in mei -- ner __ Not, in mei -- ner Not,
    ich seuf -- ze stets:
    ge -- denk __ an Je -- su bit -- tern Tod!
}


mvtVIbc = <<
\relative c {
    \clef F
    d4 e8 f4 d8 cis4 e8 a,4 cis8 | % bar 1
    d4 a'8 d4.~ d4 bes8 g4 cis,8 | % bar 2
    d4 bes8 g4 a8 d,4 e8 f4 d8 | % bar 3
    a'4 b8 c4 a8 gis4 b8 e,4 gis8 | % bar 4
    a4 e'8 a4.~ a4 f8 d4 gis,8 | % bar 5
    a4 f8 d4 e8 a4 b8 c4 a8 | % bar 6
    e'4 f8 bes,4 c8 f,4 a8 bes4 g8 | % bar 7
    e4 g8 a4 a'16( bes32 c32) bes8.( c16) a8 a8( g8) g16( a32 bes) | % bar 8
    a8.( bes16) g8 g8( fis8) fis16( g32 a32) g8.( a16) f8 e8.( f16) d8 | % bar 9
    cis4.~ cis8. d16( e8) f,4 bes8 g4 a8 | % bar 10
    bes4. r8 r8 bes'8 a4. r8 r8 bes8 | % bar 11
    e,4 g8 cis,4 e8 f,4 d8 a'4 a8 | % bar 12
    d4\fermata e8\Pia f4 d8 cis4 e8 a,4 cis8 | % bar 13
    d4 a'8 d4.~ d4 cis8 a4 cis8 | % bar 14
    d4 bes8 g4 a8 d,4 e8 f4 d8 | % bar 15
    a4 b8 c4 a8 e'4 r8 r8 r8 gis8 | % bar 16
    a4 r8 r8 r8 a,8 a'( gis8 fis8) e4 gis8 | % bar 17
    a4 c,8 d4 e8 a,4 b8 c4 d8 | % bar 18
    g,4. r8 r8 c8 f,4. r8 r8 g'8 | % bar 19
    cis,4 e8 a,4 a'16( bes32 c32) bes8.( c16) a8 a8( g8) g16( a32 bes32) | % bar 20
    a8.( bes16) g8 g8( fis8) fis16( g32 a32) g4. r8 r8 g,8 | % bar 21
    d'8.( e16) c8 c8( b8) b16( c32 d32) c8.( d16) bes8 bes8( a8) a16( bes32 c32) | % bar 22
    bes8.( c16) a8 g8( bes8) a8 bes4 g8 e4 c8 | % bar 23
    f4 f'8 e8.( f16) g8 a,4 f8 c'4 c,8 | % bar 24
    d4. r8 r8 d''8 c4. r8 r8 d8 | % bar 25
    g,4 bes8 e,4 g8 a,4 f8 c'4 c,8 | % bar 26
    f4. r8 r8 f'8 c8( bes8) a8 g8( f8) e8 | % bar 27
    d4 d'8~ d8 cis4\trill d8.( e16) f8 g8 a8 a,8 | % bar 28
    bes4 bes'8 b4 b,8 c4 b8 a4.~ | % bar 29
    a4 g8 f4.~ f4 d8 e4 e'8 | % bar 30
    a4 g8 f4.~ f4 e8 d4.~ | % bar 31
    d4 c8 bes4.~ bes4 g8 a4 a'8 | % bar 32
    d4 c8 bes4.~ bes4 a8 g4.~ | % bar 33
    g4 f8 es4.~ es4 c8 d4 d,8 | % bar 34
    g4 a8 bes4 g8 d'4 e8 f4 d8 | % bar 35
    a'4 r8 r8 r8 cis,8 d4. r8 r8 d,8 | % bar 36
    d'8( cis8) b8 a4 cis8 d4 f8 g4 a8 | % bar 37
    d,4 e8 f4 g8 c,4. r8 r8 f8 | % bar 38
    bes,4. r8 r8 c8 fis,4 a8 d,4 d'16( es32 f32) | % bar 39
    es8.( f16) d8 d8( c8) c16( d32 es32) d8.( es16) c8 c8( b8) b16( c32 d32) | % bar 40
    c4. r8 r8 c8 g'8.( as16) f8 f8( e8) e16( f32 g32) | % bar 41
    f8.( g16) es8 es8( d8) d16( es32 f32) es8.( f16) d8 c8( es8) d8 | % bar 42
    es4 c8 a4 f8 bes4 bes'8 a8.( bes16) c8 | % bar 43
    d,4 bes8 f'4 f,8 bes4 a8 bes4 g8 | % bar 44
    c4 es8 f4 f,8 bes4 d8 es4 bes8 | % bar 45
    c4 a8 d4 d,8 g4 g'8 as4 es8 | % bar 46
    f4. r8 r8 bes,8 es4. r8 r8 as,8 | % bar 47
    d,4. r8 r8 g8 c,4. r8 r8 c'8 | % bar 48
    c4. r8 r8 bes8 fis4 a8 d,4 fis8 | % bar 49
    g4 d'8 g4.~ g4 fis8 d4 fis8 | % bar 50
    g4 es8 c4 d8 g,4 a8 bes4 g8 | % bar 51
    d'4 e8 f4 d8 a'4. r8 r8 cis,8 | % bar 52
    d4. r8 r8 d,8 d'8 cis8 b8 a4 cis8 | % bar 53
    d4 bes8 a4 bes8 gis4. a4. | % bar 54
    d4 e8 f4 d8 cis4 e8 a,4 cis8 | % bar 55
}
\mvtVItimeLine
>>
