\version "2.19.15"

\include "bach-101-score-common.ly"
