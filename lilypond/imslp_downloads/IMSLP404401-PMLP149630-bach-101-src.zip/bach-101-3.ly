\version "2.19.11"

\include "common.ly"


mvtIIItimeLine = {
    \key d \minor

    \time 3/4
    \tempo "a tempo"
    s2.*8 | %8
    \bar "||"
    \time 4/4
    \tempo "Recit."
    s1*4 | %12
    s2 \tempo "(a tempo)" s2 | %13
    \bar "||"
    \time 3/4
    s2.*3 | %16
    \bar "||"
    \tempo "(Recit.)"
    \time 4/4
    s1*2 | %18
    \bar "||"
    \tempo "(a tempo)"
    \time 3/4
    s2.*10 | %28
    \bar "||"
    \tempo "(Recit.)"
    \time 4/4
    s1*2 | %30
    \bar "||"
    \tempo "(a tempo)"
    \time 3/4
    s2.*4 | %34
    \bar "||"
    \tempo "(Recit.)"
    \time 4/4
    s1*3 | %37
    \bar "||"
    \tempo "(a tempo)"
    \time 3/4
    s2.*9 | %48
    \bar "|."
}

mvtIIIsoprano = <<
\relative c'' {
    \autoBeamOff

    R2.*4 | % bar 1
    r4 r4 a4 | % bar 5
    a4 f4 g4~ | % bar 6
    g16[ a16 bes8] a4 cis4~ | % bar 7
    cis8[ d8] f,4( e4)\trill | % bar 8
    d4 r8 e8 f8 f8 g8 a8 | % bar 9
    bes8 bes8 \grace a8 g8. c16 a4 r16 a16 a16 a16 | % bar 10
    es'8 es8 es8 d8 \grace c8 b4 r8 d8 | % bar 11
    g8 g8 g8 r16 e16 \grace d8 cis8 d8 e8 a,8 | % bar 12
    f'8 r16 d16 bes8 d8 gis,4 a4 | % bar 13
    a4( g4) r8 g8 | % bar 14
    c8.[( bes16] a4) g4 | % bar 15
    f8[ d8] \grace a'8 g4.\trill( a8) | % bar 16
    a8 r16 e'16 e8 a,8 bes8. bes16 a8 g8 | % bar 17
    des'8 des8 r16 g,16 c16 e16 g8 g,8 bes8 a8 | % bar 18
    f8 f8 r4 r4 | % bar 19
    r4 r4 a4 | % bar 20
    c4 d4( e4) | % bar 21
    f4 e2~ | % bar 22
    e8 f8 \grace d8 cis4. d8 | % bar 23
    d2 r4 | % bar 24
    r4 r4 d8[ e16 f16] | % bar 25
    e4 gis,8[( b8)] d4 | % bar 26
    r4 c8. a16 f'4 | % bar 27
    r8 e8 \grace d8 c4 b8[( a8)] | % bar 28
    a4 r16 a16 a16 bes16 c8 c8 a8 c8 | % bar 29
    fis,8 fis8 r16 fis16 g16 a16 es8 d8 c'8 a8 | % bar 30
    bes8 bes8 r4 d4 | % bar 31
    c4( a4) b4 | % bar 32
    c4 g4 a4~ | % bar 33
    a8[ bes16 c] g4.( f8) | % bar 34
    f4 r8 c'8 f8 f8 f8 d8 | % bar 35
    b8 c8 d8 g,8 cis8 cis8 r16 e16 e16 cis16 | % bar 36
    a4 r8 a8 cis8 e8 g8 e8 | % bar 37
    f8 f8 r4 a,4 | % bar 38
    bes8. g16 cis4 e4 | % bar 39
    e8[( g,8)] f4 es'4 | % bar 40
    cis8[ d8] \grace f,8 e4.\trill( d8) | % bar 41
    d2 r4 | % bar 42
    R2.*3 |
    R2.\fermataMarkup |
}
\mvtIIItimeLine
>>


mvtIIIlyrics = \lyricmode {
    Ach! Herr Gott, durch __ die Treu -- e __ dein
    wird un -- ser Land in Fried und Ru -- he sein.
    Wenn uns ein Un -- glücks -- wet -- ter droht,
    so ru -- fen wir,
    barm -- herz -- ger Gott, zu dir
    in sol -- cher Not:
    mit Trost und Ret -- tung uns er -- schein!
    Du kannst dem feind -- li -- chen Zer -- stö -- ren
    durch dei -- ne Macht und Hül -- fe weh -- ren.
    Be -- weis an uns dei -- ne gro -- ße Gnad,
    und straf uns nicht, straf uns nicht auf fri -- scher Tat,
    wenn un -- sre Fü -- ße wan -- ken woll -- ten,
    und wir aus Schwach -- heit strau -- cheln soll -- ten.
    Wohn uns __ mit dei -- ner Gü -- te __ bei
    und gib, daß wir
    nur nach dem Gu -- ten stre -- ben,
    da -- mit all -- hier
    und auch in je -- nem Le -- ben
    dein Zorn und Grimm fern von uns, fern von uns sei!
}


mvtIIIbc = <<
\relative c' {
    \clef F

    \overrideTimeSignatureSettings
        #'(3 . 4)         % timeSignatureFraction
        #'(1 . 4)         % baseMomentFraction
        #'(1 1 1)           % beatStructure
        #'(
            (end .
             (
              ((1 . 8) . (6))
              ((1 . 16) . (12))
             ))
          )               % beamExceptions

    r4 r8 a8 g8. a16 | % bar 1
    f4 r8 f8 e8.\trill d16 | % bar 2
    bes'4 r8 cis,8 b8.\trill a16 | % bar 3
    d8. g16 a4 a,4 | % bar 4
    <\tag CELLO d, \tag ORGAN d'>4 r8 a''8\Pia g8. a16 | % bar 5
    f4 r8 f8 e8.\trill d16 | % bar 6
    bes'4 r8 cis,8 b8. a16 | % bar 7
    d8. g16 a4 a,4 | % bar 8
    bes1 | % bar 9
    g2 f2 | % bar 10
    fis2 f2 | % bar 11
    e2. cis'4 | % bar 12
    d2~ d8. d16 c8. d16 | % bar 13
    bes4 r8 bes8 a8.\trill g16 | % bar 14
    e'4 r8 cis8 b8.\trill a16 | % bar 15
    d8. f16 bes4 bes,4 | % bar 16
    a2 cis2 | % bar 17
    bes1 | % bar 18
    a4. a'8 g8. a16 | % bar 19
    f4 r8 f8 e8. d16 | % bar 20
    a'4 r8 f8 e8. f16 | % bar 21
    d4 r8 d8 c8. bes16 | % bar 22
    g'8. e16 a4 a,4 | % bar 23
    d4 r8 d'8 c8. d16 | % bar 24
    b4 r8 b8 a8.\trill g16 | % bar 25
    c4 r8 gis8 fis8.\trill e16 | % bar 26
    a4 r8 c,8 b8.\trill a16 | % bar 27
    gis8. a16 e'4 e,4 | % bar 28
    a2 es'2 | % bar 29
    a,2 fis2 | % bar 30
    g4 r8 g'8 f8. g16 | % bar 31
    e4 r8 f8 e8.\trill d16 | % bar 32
    c4 r8 bes8 a8.\trill g16 | % bar 33
    f8. bes16 c4 <\tag CELLO c, \tag ORGAN c'>4 | % bar 34
    f1~ | % bar 35
    f2 e2 | % bar 36
    cis'1 | % bar 37
    d4 r8 d8 cis8. d16 | % bar 38
    g,4 r8 bes8 a8.\trill g16 | % bar 39
    cis4 r8 d8 c8. d16 | % bar 40
    bes8. g16 a4 a4 | % bar 41
    d,4 r8 a''8 g8. a16 | % bar 42
    f4 r8 f8 e8.\trill d16 | % bar 43
    bes'4 r8 cis,8 b8.\trill a16 | % bar 44
    d8. g16 a4 a,4 | % bar 45
    \onceCenterNoteColumn #0 d,2.\fermata | % bar 46
}
\mvtIIItimeLine
>>


mvtIIIfigs = \figuremode {
    s4. <_+> | %1
    <6>2. |
    s2.*6 | %8
    s1 |
    <7>4 <6> s2 | %10
    <7- 5>2 <6 4\+ 2> |
    <7> <6\\> |
    <5>4 <6-> <4\+ \markup{\number\smaller{3}(2)}> <6> | %13
    <7> <6> s |
    <6>4. <6> |
    s4 <6> s |

    <_+>2 <7-> | %17
    <6 4\+ 3->4 \once \bassFigureExtendersOn <6 4\+ 2> s2 | %19
    <6>2. |
    s2 <7 4 2>4 |
    s4. <6>8 <6\\>4 |
    s4. <6 4 2> |
    s4 <_+> s |
    s2. | %26
    <6> | %27
    s2.*3 | %30
    s2 <6 4 2\+> | %31
    <6\\> <7->4 <6> |
    s4 s <6 4\+ 2> |
    <6>2. |
    s2.*2 |
    s1 |
    <6 4\+ 2>2 <6\\> | %36
    <6> <5> |
    s2.*9 |
}
