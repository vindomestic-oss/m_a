\version "2.21.0"

\header {
    title = \markup{ Was Gott tut, das ist wohlgetan }
    subtitle = \markup{ Zweite Composition }
    % source = \markup\center-column{
        % \line{Quellen:  D-LEb Thomana 99 \italic{Bach-Archiv Leipzig}}
        % "D-B Mus. ms. Bach P 647"
        % \line\italic{Biblioteka Jagiellonska & Staatsb. zu Berlin – Preuß. Kulturbesitz}}
    opus = \markup{ BWV 99 }
    composer = "J.S. Bach"
    copyright = \markup{\abs-fontsize #10 \center-column{
		    "© 2020 Rutger Hofman"
		    "Creative Commons Attribution Attribution ShareAlike 4.0"}}
}

\layout {
}

mvtIpiece = "I. (Coro)"
mvtIIpiece = \markup{II. Recit. \medium (Basso)}
mvtIIIpiece = \markup{III. Aria \medium (Tenore)}
mvtIVpiece = \markup{IV. Recit. \medium (Alto)}
mvtVpiece = \markup{V. Aria \smallCaps Duetto \medium{(Soprano, Alto)}}
mvtVIpiece = "VI. Chorale"
