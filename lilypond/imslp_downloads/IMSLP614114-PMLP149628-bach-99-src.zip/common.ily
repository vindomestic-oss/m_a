\version "2.21.0"

\include "include-once.ily"
\includeOnce "common-defs.ily"
\includeOnce "common-settings.ily"
