\version "2.21.0"

\include "common.ily"

mvtVItimeline = {
    \time 4/4
    \partial 4
    \key g \major

    \repeat volta 2 {
	s4 |
	s1*3 |
	s2.
    }
    s4 |
    s1*5 |
    s2.
    \bar "|."
}

mvtVIsopr = <<
\mvtVItimeline
\relative c' {
    \autoBeamOff

    d4 | % bar 0
    g4 a4 b4 c4 | % bar 1
    d4. c8 b4\fermata e4 | % bar 2
    d4 c4 b8[ a8] b4 | % bar 3
    a2 g4 % bar 4

    d'4 | % bar 4
    e4 e4 a,4\fermata a4 | % bar 5
    d4 d4 g,4\fermata b4 | % bar 6
    a4 g4 fis8[ e8] fis4 | % bar 7
    e2 d4\fermata d'4 | % bar 8
    c4 b4 a4 b8[ c8] | % bar 9
    a2 g4\fermata % bar 10
}
>>


mvtVIalto = <<
\mvtVItimeline
\relative c' {
    \autoBeamOff

    b8[ c8] | % bar 0
    d4 d4 g4 g4 | % bar 1
    g4 fis4 g4\fermata g4 | % bar 2
    fis4 e4 d4 g4 | % bar 3
    g4( fis4) d4 % bar 4

    g4 | % bar 4
    g4 a8[ g8] fis4\fermata fis4 | % bar 5
    fis4 fis4 e4\fermata e4 | % bar 6
    e4 e4 e4 d4 | % bar 7
    d4( cis4) a4\fermata fis'4 | % bar 8
    g8[ a8] d,[ e] fis4 g4 | % bar 9
    g8[( fis16 e16] fis4) d4\fermata % bar 10
}
>>


mvtVIten = <<
\mvtVItimeline
\relative c' {
    \autoBeamOff

    g8[ a8] | % bar 0
    b4 a4 e'4 e4 | % bar 1
    d8[( c16 b16 a8]) d8 d4\fermata c8[ b8] | % bar 2
    a4 g8[ a8] b8[ c8] d4 | % bar 3
    d8[( c16 b16] c8[ a8]) b4 % bar 4

    b4 | % bar 4
    c8[ d8] e4 d4\fermata cis4 | % bar 5
    cis8[( ais8]) b4 b4\fermata g4 | % bar 6
    a8[ b8] cis4 a4 b4 | % bar 7
    b4( a8[ g8]) fis4\fermata b4 | % bar 8
    b8[ a8] b8[ c8] d4 d4 | % bar 9
    d8[( a16 b16] c4) b4\fermata % bar 10
}
>>


mvtVIbasso = <<
\mvtVItimeline
\relative c {
    \clef F
    \autoBeamOff

    g4 | % bar 0
    g'4 fis4 e4 d8[ c8] | % bar 1
    b8[ c8] d4 g,4\fermata c4 | % bar 2
    d4 e8[ fis8] g4 b,8[ c8] % bar 3
    d2 g,4 % bar 4

    g'4 | % bar 4
    c,4 cis4 d4\fermata fis4 | % bar 5
    b,8[ cis8] d8[ b8] e4\fermata e8[ d8] | % bar 6
    cis4 b8[ a8] d8[ cis8] b8[ a8] | % bar 7
    g4( a4) d4\fermata b4 | % bar 8
    e8[ fis8] g4 d8[ c8] b8[ g8] | % bar 9
    d'2 g,4\fermata % bar 10
}
>>


mvtVIbc = <<
\mvtVItimeline
\relative c {
    \clef F
    g4 | % bar 0
    g'4 fis4 e4 d8 c8 | % bar 1
    b8 c8 d4 g,4\fermata c4 | % bar 2
    d4 e8 fis8 g4 b,8 c8 | % bar 3
    d2 g,4 % bar 4

    g'4 | % bar 4
    c,4 cis4 d4\fermata fis4 | % bar 5
    b,8 cis8 d8 b8 e4\fermata e8 d8 | % bar 6
    cis4 b8 a8 d8 cis8 b8 a8 | % bar 7
    g4 a4 d4\fermata b4 | % bar 8
    e8 fis8 g4 d8 c8 b8 g8 | % bar 9
    d'2 g,4\fermata % bar 10
}
>>

mvtVIfigs = <<
\mvtVItimeline
\figuremode {
    s4 |
    s2. <7 4 2>4 |
    <6> s2. |
    s1 |
    s2.

    s4 |
    s1*5
    s2.
}
>>

mvtVIlyrics = \lyricmode {
    Was4 Gott tut, das ist wohl -- ge -- tan,
    da -- bei will ich ver -- blei2 -- ben;4
    so wird Gott mich ganz vä -- ter -- lich
    in sei -- nen Ar -- men hal2 -- ten:4
    drum laß ich ihn nur wal2 -- ten.4
}

mvtVIlyricsII = \lyricmode {
    es4 mag mich auf die rau -- he Bahn
    Not, Tod und E -- lend trei2 -- ben,4
}
