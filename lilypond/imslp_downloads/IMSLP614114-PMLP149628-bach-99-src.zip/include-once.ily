\version "2.21.0"

%%http://lsr.di.unimi.it/LSR/Item?id=894

% includeOnce: include a file only if it hasn't already been included.
% Usage: \includeOnce "my_file.ily"
% By Marnen Laibow-Koser <marnen@marnen.org>
% Based on http://lsr.dsi.unimi.it/LSR/Snippet?id=657
% and 
% http://lilypond.1069038.n5.nabble.com/conditional-include-td140471.html

includeOnce =
#(define-void-function (filename) (string?)
   (if
     (not (defined? (string->symbol filename)))
     (begin
       (ly:parser-include-string
         (string-concatenate
          (list "\\include \"" filename "\"")))
       (primitive-eval (list 'define (string->symbol filename) #t)))))

% \markup { "Dummy output so that the database doesn't complain." }
