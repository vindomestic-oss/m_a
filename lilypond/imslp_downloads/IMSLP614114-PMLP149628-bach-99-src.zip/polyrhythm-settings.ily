\version "2.21.0"

%
% This file to be included in \layout blocks
%

\context {
    \Score
        \remove Timing_translator
        \remove Default_bar_line_engraver
        \remove Staff_collecting_engraver
}

\context {
    \Staff
        \consists Timing_translator
        \consists Default_bar_line_engraver
        \consists Staff_collecting_engraver
}

\context {
    \RhythmicStaff
        \consists Timing_translator
        \consists Default_bar_line_engraver
        \consists Staff_collecting_engraver
}

\context {
    \Dynamics
        \consists Timing_translator
        \consists Default_bar_line_engraver
        \consists Staff_collecting_engraver
}

\context {
    \MarkLine
        \consists Timing_translator
        \consists Default_bar_line_engraver
        \consists Staff_collecting_engraver
}
