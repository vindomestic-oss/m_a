\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-2.ily"
\include "bach-99-3.ily"
\include "bach-99-4.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"


\paper {
    % page-breaking = #ly:page-turn-breaking
    ragged-last-bottom = ##f
    page-count = 7
}

\header {
    instrument = "Basso Continuo"
}

\include "bach-99-title.ily"
\include "bach-paged-title.ily"


% %{
\score { 
    \keepWithTag #'( PARTS cIC KEEPKEYS ) \new Staff = mvtIbc << 
	\mvtIbc
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}


% %{
\score {
   \new StaffGroup = mvtII <<
        \new Staff = mvtIIbasso \with { \staffSize #-3 } <<
	    \new Voice = mvtIIbasso {
		\mvtIIbasso
	    }
	    \new Lyrics \with {
                alignBelowContext = "mvtIIbasso"
		\override LyricText.font-size = #-0.5
	    } {
		\lyricsto mvtIIbasso \mvtIIbassLyrics
	    }

	    \set Staff.instrumentName = \markup\bold{\normalsize Basso}
        >>
        \new Staff = mvtIIbc \with {
	    instrumentName = \markup\center-column{"Basso" "Continuo"}
        } <<
	    \mvtIIbc
        >>
   >>

    \header {
	piece = \mvtIIpiece
	breakbefore = ##t
	page-count = #2
    }

    \layout {
	indent = 18
    }
}
% %}


\score {
   \new Staff = mvtIIIbc <<
       \mvtIIIbc
   >>

    \header {
	piece = \mvtIIIpiece
	breakbefore = ##t
    }
}


% %{
\score {
   \new StaffGroup = mvtIV <<
        \new Staff = mvtIValto \with { \staffSize #-3 } <<
	    \new Voice = mvtIValto {
		\clef alto \mvtIValto
	    }
	    \new Lyrics \with {
                alignBelowContext = "mvtIValto"
		\override LyricText.font-size = #-0.5
	    } {
		\lyricsto mvtIValto \mvtIVlyrics
	    }

	    \set Staff.instrumentName = \markup\bold{\normalsize Alto.}
        >>
        \new Staff = mvtIVbc \with {
	    instrumentName = \markup\center-column{"Basso" "Continuo"}
        } <<
            \mvtIVbc
        >>
   >>

    \header {
	piece = \mvtIVpiece
	breakbefore = ##t
    }

    \layout {
	indent = 18
    }
}
% %}


% %{
\score {
    \new Staff = mvtVbc <<
       \mvtVbc
    >>

    \header {
	piece = \mvtVpiece
	% breakbefore = ##t
    }
}
% %}


% %{
\score {
    \new Staff = mvtVIbc <<
	\new Voice = mvtVIinstr \mvtVIbc
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
