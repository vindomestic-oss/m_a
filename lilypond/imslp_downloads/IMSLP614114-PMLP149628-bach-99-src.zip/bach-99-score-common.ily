\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-2.ily"
\include "bach-99-3.ily"
\include "bach-99-4.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"

\include "bach-99-title.ily"
\include "bach-paged-title.ily"

\include "common-grand-score.ily"

\markup\null
\pageBreak


#(set-global-staff-size 15)

\paper {
    indent = 18
    short-indent = 7
    ragged-last-bottom = ##f
}


% %{
\score {
    \keepWithTag #'( cIC SCORE KEEPKEYS ) << 
        % \new Staff = ACTptpartA << 
	    % \set Staff.instrumentName = "Tromba in C"
	    % \set Staff.shortInstrumentName = "Trp"

            % \clef treble \mvtIsop
        % >>

        % \new Dynamics { \mvtIbreaksBGA }
        % \new Dynamics { \mvtIbreaksNBA }

        \new StaffGroup <<
            \new Staff = mvtIfl << 
                \set Staff.instrumentName = \markup{\center-column{"Flauto" "traverso"}}
                \set Staff.shortInstrumentName = "Fl."

                \mvtIfl
            >>

            \new Staff = mvtIob << 
                \set Staff.instrumentName = \markup{\center-column{"Oboe" "d’Amore"}}
                \set Staff.shortInstrumentName = \markup\center-column{"Ob." "d’A."}

                { \transpose \transpObDAm c \mvtIob }
            >>
        >>

	\new StaffGroup = mvtIstr <<

	    \new GrandStaff = mvtIvln <<
		\set GrandStaff.instrumentName = "Violini"
		\set GrandStaff.shortInstrumentName = "Vln."

		\new Staff = mvtIvlnI << 
		    \set Staff.instrumentName = "I"
		    \set Staff.shortInstrumentName = "I"

		    \mvtIvlnI
		>>

		\new Staff = mvtIvlnII << 
		    \set Staff.instrumentName = "II"
		    \set Staff.shortInstrumentName = "II"

		    \mvtIvlnII
		>>
	    >>

	    \new Staff = mvtIvla << 
		\set Staff.instrumentName = "Viola"
		\set Staff.shortInstrumentName = "Vla."

		\mvtIvla
	    >>
	>>

	\new ChoirStaff = mvtIchoir \with {
            \consists Keep_alive_together_engraver
            \RemoveEmptyStaves
        } <<
	    \new Staff = mvtIsop \with {
		instrumentName = \markup\center-column{\line\bold{Soprano} "Corno"}
		shortInstrumentName = \markup\center-column{\line\bold{S.} "Cor."}
            } << 
		\new Voice = mvtIsop {
		    \clefSoprano \mvtIsop
		}
		\new Lyrics \lyricsto mvtIsop {
		    \mvtIsopranoLyrics
		}
	    >>

	    \new Staff = mvtIalto << 
		\set Staff.instrumentName = \markup\bold{Alto}
		\set Staff.shortInstrumentName = \markup\bold{A.}

		\new Voice = mvtIalto {
		    \clefAlto \mvtIalto
		}
		\new Lyrics \lyricsto mvtIalto {
		    \mvtIaltoLyrics
		}
	    >>

	    \new Staff = mvtIten << 
		\set Staff.instrumentName = \markup\bold{Tenore}
		\set Staff.shortInstrumentName = \markup\bold{T.}

		\new Voice = mvtIten {
		    \clefTenor \mvtIten
		}
		\new Lyrics \lyricsto mvtIten {
		    \mvtItenorLyrics
		}
	    >>

	    \new Staff = mvtIbasso << 
		\set Staff.instrumentName = \markup\bold{Basso}
		\set Staff.shortInstrumentName = \markup\bold{B.}

		\new Voice = mvtIbasso {
		    \mvtIbasso
		}
		\new Lyrics \lyricsto mvtIbasso {
		    \mvtIbassLyrics
		}
	    >>
	>>

        \new StaffGroup <<
            \new Staff = mvtIbc << 
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                { \dynamicUp \mvtIbc }
                \mvtIfigs
            >>
        >>
    >>

    \header {
	piece = \mvtIpiece
    }

    \layout {
        \context {
            \Staff
            % \RemoveEmptyStaves
        }
    }
}
% %}


% %{
\score {
   \keepWithTag #'( SCORE KEEPKEYS ) \new StaffGroup = mvtII <<
        \new Staff = mvtIIbasso <<
	    \set Staff.instrumentName = \markup\bold{Basso}
	    \set Staff.shortInstrumentName = \markup\bold{B.}

	    \new Voice = mvtIIbasso {
		\mvtIIbasso
	    }
	    \new Lyrics \lyricsto mvtIIbasso \mvtIIbassLyrics
        >>
        \new Staff = mvtIIbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
	    \set Staff.shortInstrumentName = \markup{B.C.}

	    \mvtIIbc
	    \mvtIIfigs
        >>
    >>

    \header {
	piece = \mvtIIpiece
	breakbefore = ##t
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE KEEPKEYS ) \new StaffGroup = mvtIII <<
       % \new Dynamics { \mvtIIIbreaksBGA }
       % \new Dynamics { \mvtIIIbreaksNBA }

       \new Staff = mvtIIIfl \with {
	   instrumentName = \markup{\center-column{"Flauto" "traverso"}}
	   shortInstrumentName = "Fl."
       } <<
           \mvtIIIfl
       >>
       \new Staff = mvtIIItenor \with {
	   instrumentName = \markup\bold{Tenore}
	   shortInstrumentName = \markup\bold{T.}
       } <<
	   \new Voice = mvtIIItenor \clefTenor \mvtIIItenor
           \new Lyrics \lyricsto mvtIIItenor \mvtIIIlyrics
       >>
       \new Staff = mvtIIIbc <<
	   \set Staff.instrumentName = \markup{\center-column{"Basso" "Continuo"}}
	   \set Staff.shortInstrumentName = "B.C."

           \mvtIIIbc
            \mvtIIIfigs
       >>
    >>

    \header {
	piece = \mvtIIIpiece
	% breakbefore = ##t
    }
}
% %}


% %{
\score {
   \keepWithTag #'( SCORE KEEPKEYS ) \new StaffGroup = mvtIV <<
        % \new Dynamics { \mvtIVbreaksNBA }

        \new Staff = mvtIValto <<
	    \set Staff.instrumentName = \markup\bold{Alto}
	    \set Staff.shortInstrumentName = \markup\bold{A.}

	    \new Voice = mvtIValto {
		\clefAlto \mvtIValto
	    }
	    \new Lyrics \lyricsto mvtIValto \mvtIVlyrics
        >>
        \new Staff = mvtIVbc <<
	    \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
	    \set Staff.shortInstrumentName = \markup{B.C.}

            \mvtIVbc
            \mvtIVfigs
        >>
    >>

    \header {
	piece = \mvtIVpiece
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE KEEPKEYS ) <<
        % \new Dynamics { \mvtVbreaks }
        % \new Dynamics { \mvtVbreaksNBA }

        \new StaffGroup = mvtV <<
            \new Staff = mvtVfl <<
               \set Staff.instrumentName = \markup{\center-column{"Flauto" "traverso"}}
               \set Staff.shortInstrumentName = \markup{Fl.}

               \mvtVfl
            >>
            \new Staff = mvtVob <<
               \set Staff.instrumentName = \markup{\center-column{"Oboe" "d’Amore"}}
               \set Staff.shortInstrumentName = \markup{\center-column{"Ob." "d’A."}}

               \transpose \transpObDAm c { \mvtVob }
            >>
        >>

	\new ChoirStaff = mvtVchoir <<
	    \new Staff = mvtVsoprano <<
	        \set Staff.instrumentName = \markup\bold{Soprano}
	        \set Staff.shortInstrumentName = \markup\bold{S.}

		\new Voice = mvtVsoprano { \clefSoprano \mvtVsoprano }
                \new Lyrics \lyricsto mvtVsoprano \mvtVsopranoLyrics
	    >>
	    \new Staff = mvtValto <<
	        \set Staff.instrumentName = \markup\bold{Alto}
	        \set Staff.shortInstrumentName = \markup\bold{A.}

		\new Voice = mvtValto { \clefAlto \mvtValto }
                \new Lyrics \lyricsto mvtValto \mvtValtoLyrics
	    >>
	>>

        \new StaffGroup <<
            \new Staff = mvtVbc <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = \markup{B.C.}

                \mvtVbc
                \mvtVfigs
            >>
        >>
    >>

    \header {
	piece = \mvtVpiece
	breakbefore = ##t
    }
}
% %}


% %{
\score {
    \keepWithTag #'( SCORE KEEPKEYS ) <<
        % \new Dynamics { s4 | s1*3 | s2. \break }

	\new ChoirStaff = mvtVI <<
	    \new Staff = mvtVIsopr <<
		\set Staff.instrumentName = \markup\center-column{
                                                \bold{Soprano}
                                                \line{Fl. in \concat{8 \raise #0.8 \smaller va ,} Ob.d’A.}
                                                \line{Corno, V.I}
                                            }
		\set Staff.shortInstrumentName = \markup\bold{S.}

		\new Voice = mvtVIsopr {
                    % \horizontalSpacingLoose
                    \stretchHorizontalSpacing #2.0
		    \clefSoprano
		    \mvtVIsopr
		}

		\new Lyrics \lyricsto mvtVIsopr \mvtVIlyrics
		\new Lyrics \lyricsto mvtVIsopr \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIalto <<
		\set Staff.instrumentName = \markup\center-column{
                                                \bold{Alto}
                                                \line{V.II}
                                            }
		\set Staff.shortInstrumentName = \markup\bold{A.}

		\new Voice = mvtVIalto {
		    \clefAlto
		    \mvtVIalto
		}

		\new Lyrics \lyricsto mvtVIalto \mvtVIlyrics
		\new Lyrics \lyricsto mvtVIalto \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIten <<
		\set Staff.instrumentName = \markup\center-column{
                                                \bold{Tenore}
                                                \line{Vla.}
                                            }
		\set Staff.shortInstrumentName = \markup\bold{T.}

		\new Voice = mvtVIten {
		    \clefTenor
		    \mvtVIten
		}

		\new Lyrics \lyricsto mvtVIten \mvtVIlyrics
		\new Lyrics \lyricsto mvtVIten \mvtVIlyricsII
	    >>
	    \new Staff = mvtVIbasso <<
		\set Staff.instrumentName = \markup\bold{Basso}
		\set Staff.shortInstrumentName = \markup\bold{B.}

		\new Voice = mvtVIbasso {
		    \mvtVIbasso
		}

		\new Lyrics \lyricsto mvtVIbasso \mvtVIlyrics
		\new Lyrics \lyricsto mvtVIbasso \mvtVIlyricsII
	    >>
	>>

        \new StaffGroup <<
            \new Staff = mvtVIbc <<
                \set Staff.instrumentName = \markup\center-column{"Basso" "Continuo"}
                \set Staff.shortInstrumentName = "B.C."

                \mvtVIbc
                \mvtVIfigs
            >>
       >>
    >>

    \header {
	piece = \mvtVIpiece
	breakbefore = ##t
    }

    \layout {
        indent = #26
    }
}
% %}
