\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-2.ily"
\include "bach-99-3.ily"
\include "bach-99-4.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"


\paper {
    % page-breaking = #ly:page-turn-breaking
    page-count = #14
    % ragged-last-bottom = ##f
}

\header {
    instrument = "Continuo Beziffert"
}

\include "bach-99-title.ily"
\include "bach-paged-title.ily"

breaksIcic = <<
\mvtItimeline
{
    s8 |
    s1*72 |
    \pageTurn
}
>>

% %{
\score { 
    \keepWithTag #'( PARTS cIC KEEPKEYS ) <<
        \new Dynamics \breaksIcic

        \new Staff = mvtIbc << 
            { \dynamicUp \mvtIbc }
            \mvtIfigs
        >>
    >>

    \header {
	piece = \markup{\mvtIpiece Bezifferung aus BWV 99}
    }
}
% %}


breaksIcc = <<
\mvtItimeline
{
    s8 |
    s1*36 |
    \barNumberCheck # 37
    \pageTurn
}
>>

% %{
\score { 
    <<
        \new Dynamics \breaksIcc

        \new Staff = mvtIbc << 
            \keepWithTag #'( PARTS cIC KEEPKEYS ) { \dynamicUp \mvtIbc }
            \keepWithTag #'( PARTS cC KEEPKEYS ) { \mvtIfigs }
        >>
    >>

    \header {
	piece = \markup{\mvtIpiece Bezifferung aus BWV 100}
        breakbefore = ##t
    }
}
% %}

breaksIcccic = <<
\mvtItimeline
{
    s8 |
    s1*72 |
    \barNumberCheck # 73
    \pageTurn
    \autoPageBreaksOff
}
>>

% %{
\score { 
    <<
        \new Dynamics \breaksIcccic

        \new Staff = mvtIbc << 
            \keepWithTag #'( PARTS cIC KEEPKEYS ) { \dynamicUp \mvtIbc }
        >>
        \context Staff = mvtIbc <<
            \keepWithTag #'( PARTS cC KEEPKEYS ) { \bassFigureStaffAlignmentUp \mvtIfigs }
        >>
        \new FiguredBass \keepWithTag #'( PARTS cIC KEEPKEYS ) { \mvtIfigs }
    >>

    \header {
	piece = \markup{\mvtIpiece Bezifferung aus BWV 100 (oben) und 99 (unten) }
        breakbefore = ##t
    }
}
% %}


% %{
\score {
   \new StaffGroup = mvtII <<
        \new Staff = mvtIIbasso \with { \staffSize #-3 } <<
	    \new Voice = mvtIIbasso {
		\mvtIIbasso
	    }
	    \new Lyrics \with {
                alignBelowContext = "mvtIIbasso"
		\override LyricText.font-size = #-0.5
	    } {
		\lyricsto mvtIIbasso \mvtIIbassLyrics
	    }

	    \set Staff.instrumentName = \markup\bold{\normalsize Basso}
        >>
        \new Staff = mvtIIbc \with {
	    instrumentName = \markup\center-column{"Basso" "Continuo"}
        } <<
	    \mvtIIbc
	    \mvtIIfigs
        >>
   >>

    \header {
	piece = \mvtIIpiece
	breakbefore = ##t
	page-count = #2
    }

    \layout {
	indent = 18
    }
}
% %}


\score {
   \new Staff = mvtIIIbc <<
       \mvtIIIbc
        \mvtIIIfigs
   >>

    \header {
	piece = \mvtIIIpiece
	breakbefore = ##t
    }
}


% %{
\score {
   \new StaffGroup = mvtIV <<
        \new Staff = mvtIValto \with { \staffSize #-3 } <<
	    \new Voice = mvtIValto {
		\clef alto \mvtIValto
	    }
	    \new Lyrics \with {
                alignBelowContext = "mvtIValto"
		\override LyricText.font-size = #-0.5
	    } {
		\lyricsto mvtIValto \mvtIVlyrics
	    }

	    \set Staff.instrumentName = \markup\bold{\normalsize Alto}
        >>
        \new Staff = mvtIVbc \with {
	    instrumentName = \markup\center-column{"Basso" "Continuo"}
        } <<
            \mvtIVbc
            \mvtIVfigs
        >>
   >>

    \header {
	piece = \mvtIVpiece
	breakbefore = ##t
    }

    \layout {
	indent = 18
    }
}
% %}


% %{
\score {
    \new Staff = mvtVbc <<
       \mvtVbc
        \mvtVfigs
    >>

    \header {
	piece = \mvtVpiece
	breakbefore = ##t
    }
}
% %}


% %{
\score {
    <<
        \new Lyrics = mvtVIaboveI \with {
            \override LyricText.font-size = #-0.5
        } { s4 }
        \new Lyrics = mvtVIaboveII \with {
            \override LyricText.font-size = #-0.5
        } { s4 }
        \new Staff = mvtVIbc <<
            \new Voice = mvtVIinstr \mvtVIbc
            \mvtVIfigs
            { s4 | s1*3 | s2. \break }
            \context Lyrics = mvtVIaboveI \mvtVIlyrics
            \context Lyrics = mvtVIaboveII \mvtVIlyricsII
        >>
    >>

    \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
