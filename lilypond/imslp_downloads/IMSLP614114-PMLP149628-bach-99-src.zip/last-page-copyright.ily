\version "2.21.0"

% If desired on page X, replace #last-page with #(on-page X)

\paper {
    oddFooterMarkup = \markup {
        \column {
            \mm-feed #4
            \fill-line {
                \on-the-fly #last-page \fromproperty #'header:copyright
            }
            \mm-feed #2
            \fill-line {
                \abs-fontsize #10 \on-the-fly #last-page \fromproperty #'header:tagline
            }
        }
    }
}
