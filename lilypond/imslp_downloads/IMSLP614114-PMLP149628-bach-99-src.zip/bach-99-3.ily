\version "2.21.0"

\include "common.ily"

mvtIIItimeline = {
    % \set subdivideBeams = ##t 
    \set baseMoment = #(ly:make-moment 1/8)
    \overrideTimeSignatureSettings
        #'(3 . 8)        % timeSignatureFraction
        #'(1 . 8)        % baseMomentFraction
        1,1,1            % beatStructure
        #'(
            (end .
             (
              ((1 . 8) . (3))
              ((1 . 16) . (6))
              ((1 . 24) . (3 3 3))
              ((1 . 32) . (4 4 4))
             ))
          )              % beamExceptions

    \time 3/8
    \key g \major

    s4.*120
    \barNumberCheck # 121
    \daCapo
    \bar "|."
}

mvtIIIfl = <<
\mvtIIItimeline
\relative c'' {
    b8 e16( dis16) e16( dis16) | % bar 1
    e16 g32 fis32 e16 b16 b'8~ | % bar 2
    b8 ais16 a16 gis16 g16 | % bar 3
    fis16 dis32 e32 fis16 b16 b,8~ | % bar 4
    b32 d32 c32 d32 f32 d32 c32 d32 gis32 d32 c32 d32 | % bar 5
    c32 e32 d32 e32 a32 e32 d32 e32 c'32 e,32 d32 e32 | % bar 6
    cis32 e32 d32 e32 g32 e32 d32 e32 ais32 e32 d32 e32 | % bar 7
    dis32 fis32 e32 fis32 b32 fis32 e32 fis32 dis'32 b32 a32 b32 | % bar 8
    c32 a32 g32 a32 b32 g32 fis32 g32 a32 fis32 e32 fis32 | % bar 9
    g32 e32 dis32 e32 fis32 dis32 cis32 dis32 e8~ | % bar 10
    e16 fis32 g32 a16 ais16 b16 dis,16 | % bar 11
    e32 g32 fis32 g32 b32 g32 fis32 g32 e'8 | % bar 12
    R4.*3 | % bar 13
    r8 r8 b8~ | % bar 16
    b32 g32 fis32 g32 e32 g32 fis32 g32 cis,32 g'32 fis32 g32 | % bar 17
    a32 fis32 e32 fis32 dis32 fis32 e32 fis32 b,32 fis'32 e32 fis32 | % bar 18
    g16 b,16 c16 cis16 d!16 dis16 | % bar 19
    e32 g32 fis32 g32 b32 g32 fis32 g32 e'8 | % bar 20
    R4. | % bar 21
    b4.~ | % bar 22
    b8 ais16 a16 gis16 g16 | % bar 23
    fis16 dis32 e32 fis16 b16 b,8~ | % bar 24
    b32 c32 d32 e32 f16 fis16 g16 gis16 | % bar 25
    a8 r8 cis,8~ | % bar 26
    cis32 d32 e32 fis32 g16 gis16 a16 ais16 | % bar 27
    b4 r8 | % bar 28
    fis,8 b16 ais16 b16 ais16 | % bar 29
    b16 d32 cis32 b16 fis16 fis'8~ | % bar 30
    fis8 eis16 e16 dis16 d16 | % bar 31
    cis16 ais32 b32 cis16 fis16 fis,8~ | % bar 32
    fis32 a32 g32 a32 c32 a32 g32 a32 dis32 a32 g32 a32 | % bar 33
    g32 b32 a32 b32 e32 b32 a32 b32 g'32 b,32 a32 b32 | % bar 34
    gis32 b32 a32 b32 d32 b32 a32 b32 gis'32 b,32 a32 b32 | % bar 35
    ais32 cis32 b32 cis32 fis32 cis32 b32 cis32 ais'32 fis32 e32 fis32 | % bar 36
    g32 e32 d32 e32 fis32 d32 cis32 d32 e32 cis32 b32 cis32 | % bar 37
    d32 b32 ais32 b32 cis32 ais32 gis32 ais32 b8~ | % bar 38
    b16 cis32 d32 e16 eis16 fis8~ | % bar 39
    fis16 b,32 \once \set suggestAccidentals = ##t cis32 d16 dis16 e16 fis16 | % bar 40
    g32 e32 d32 e32 fis32 d32 cis32 d32 e32 cis32( b32 cis32) | % bar 41
    d32 b32 ais32 b32 cis32 ais32 gis32 ais32 b8~ | % bar 42
    b16 cis32 d32 e16 eis16 fis16 ais,16 | % bar 43
    b32 d32 cis32 d32 fis32 d32 cis32 d32 b'8 | % bar 44
    R4.*2 | % bar 45
    f32 d32 c32 d32 e32 c32 b32 c32 d32 b32 a32 b32 | % bar 47
    c16 e32 d32 c16 a16 a'8~ | % bar 48
    a4.~ | % bar 49
    a32 fis32( e32 fis32) b,32 fis'32 e32 fis32 a32 fis32 e32 fis32 | % bar 50
    g32 e32 dis32 e32 fis32 dis32 \once \set suggestAccidentals = ##t cis32 dis32 e32 cis!32 b32 cis32 | % bar 51
    dis16 fis32 e32 dis16 b16 b'8~ | % bar 52
    b4.~ | % bar 53
    b4.~ | % bar 54
    b8 ais16 a16 gis16 g16 | % bar 55
    fis16 dis32 e32 fis16 b16 b,8~ | % bar 56
    b32 d32 c32 d32 f32 d32 c32 d32 gis32 d32 c32 d32 | % bar 57
    c32 e32 d32 e32 a32 e32 d32 e32 c'32 e,32 d32 e32 | % bar 58
    cis32 e32 d32 e32 g32 e32 d32 e32 cis'32 e,32 d32 e32 | % bar 59
    dis32 fis32 e32 fis32 b32 fis32 e32 fis32 dis'32 b32 a32 b32 | % bar 60
    c32 a32 g32 a32 b32 g32 fis32 g32 a32 fis32 e32 fis32 | % bar 61
    g32 e32 dis32 e32 fis32 dis32 cis32 dis32 e8 | % bar 62
    c'8.\noBeam b16 ais16 a16 | % bar 63
    g16 e,32 fis32 g16 gis16 a16 ais16 | % bar 64
    b8 e16( dis16) e16( dis16) | % bar 65
    e16 g32 fis32 e16 b16 b'8~ | % bar 66
    b8 ais16 a16 gis16 g16 | % bar 67
    fis16 dis32 e32 fis16 b16 b,8~ | % bar 68
    b32 d32 c32 d32 f32 d32 c32 d32 gis32 d32 c32 d32 | % bar 69
    c32 e32 d32 e32 a32 e32 d32 e32 c'32 e,32 d32 e32 | % bar 70
    cis32 e32 d32 e32 g32 e32 d32 e32 ais32 e32 d32 e32 | % bar 71
    dis32 fis32 e32 fis32 b32 fis32 e32 fis32 dis'32 b32 a32 b32 | % bar 72
    c32 a32 g32 a32 b32 g32 fis32 g32 a32 fis32 e32 fis32 | % bar 73
    g32 e32 dis32 e32 fis32 dis32 cis32 dis32 e8~ | % bar 74
    e16 fis32 g32 a16 ais16 b16 dis,16 | % bar 75
    e32 g32 fis32 g32 b32 g32 fis32 g32 e'8\fermata | % bar 76
    R4.*3 | % bar 77
    a,,8 d16( cis16) d16( cis16) | % bar 80
    d16 fis32 e32 d16 a16 a'8~ | % bar 81
    a8 g16 fis16 g16 e16 | % bar 82
    fis16 dis32 e32 fis16 b16 b,8~ | % bar 83
    b16 g32 a32 b16 e16 e,8~ | % bar 84
    e16 e'16 a16( gis16) a16( gis16) | % bar 85
    a16 c32 b32 a16 e16 e'8~ | % bar 86
    e16 d16 cis16 c16 b16 bes16 | % bar 87
    a16 gis32 a32 b16 e16 e,8~ | % bar 88
    e32 g,32 fis32 g32 bes32 g32 fis32 g32 cis32 g32 fis32 g32 | % bar 89
    f32 a32 g32 a32 d32 a32 g32 a32 f'32 a,32 g32 a32 | % bar 90
    fis32 a32 g32 a32 c32 a32 g32 a32 fis'32 a,32 g32 a32 | % bar 91
    gis32 b32 a32 b32 e32 b32 a32 b32 gis'32 e32 d32 e32 | % bar 92
    f32 d32 c32 d32 e32 c32 b32 c32 d32 b32 a32 b32 | % bar 93
    c32 a32 gis32 a32 b32 gis32 fis32 gis32 a8~ | % bar 94
    a16 b32 c32 d16 dis16 e8~ | % bar 95
    e16 fis32 gis32 a16 b16 c8~ | % bar 96
    c32 a32 \once \set suggestAccidentals = ##t gis32 a32 f32 a32 \once \set suggestAccidentals = ##t gis!32 a32 d,32 a'32 gis!32 a32 | % bar 97
    b32 gis32 fis32 gis32 e32 gis32 fis32 gis32 c,32 gis'32 fis32 gis32 | % bar 98
    a16 g32( f32 e16) d16 c16 b16 | % bar 99
    a32 c32 b32 c32 e32 c32 b32 c32 a'32 e32 d32 e32 | % bar 100
    c'32 b32 a32 b32 c32 a32 g32 a32 c32 g32 fis32 g32 | % bar 101
    c32 fis,32 e32 fis32 c'32 e,32 d32 e32 c'32 d,32 c32 d32 | % bar 102
    b'32 a32 g32 a32 b32 g32 fis32 g32 b32 fis32 e32 fis32 | % bar 103
    b32 e,32 d32 e32 b'32 d,32 c32 d32 b'32 c,32 b32 c32 | % bar 104
    a'32 g32 fis32 g32 a32 fis32 e32 fis32 a32 e32 \once \set suggestAccidentals = ##t dis32 e32 | % bar 105
    a32 dis,32 cis32 dis32 a'32 cis,32 b32 cis32 a'32 b,32 a32 b32 | % bar 106
    g'32 fis32 e32 fis32 g32 e32 d32 e32 g32 d32 cis32 d32 | % bar 107
    g32 cis,32 b32 cis32 fis4~ | % bar 108
    fis32 e32 d32 e32 fis32 d32 cis32 d32 fis32 cis32 b32 cis32 | % bar 109
    fis32 b,32 a32 b32 e4~ | % bar 110
    e32 c32 b32 c32 g32 c32 b32 c32 e32 c32 b32 c32 | % bar 111
    g'32 e32 d32 e32 c32 e32 d32 e32 g32 e32 d32 e32 | % bar 112
    c'32 g32 f32 g32 e32 g32 f32 g32 c32 g32 f32 g32 | % bar 113
    e'4.~ | % bar 114
    e4.~ | % bar 115
    e32 e,32( d32 e32) fis32 d32( \once \set suggestAccidentals = ##t cis32 d32) e32 cis!32( b32 cis32) | % bar 116
    d32 b32( ais32 b32) \stemDown \once \set suggestAccidentals = ##t cis32 ais32( \once \set suggestAccidentals = ##t gis32 ais32) \stemNeutral b8~ | % bar 117
    b8. \once \set suggestAccidentals = ##t cis16 d16 dis16 | % bar 118
    e16 fis32 g32 ais,8. b16 | % bar 119
    b4. | % bar 120
    \barNumberCheck # 121
}
>>


mvtIIItenor = <<
\mvtIIItimeline
\relative c' {
    \autoBeamOff
    R4.*12 | % bar 1
    b8 e16[ dis16] e16[ dis16] | % bar 13
    e8 r16 b16 a'8 | % bar 14
    g8 fis16[ e16] dis16[ e16] | % bar 15
    fis16[ dis16 e16 cis16] b8 | % bar 16
    R4.*4 | % bar 17
    b8 e16[ dis16] e16[ dis16] | % bar 21
    e8 r16 b16 a'8 | % bar 22
    g8 fis8 e8 | % bar 23
    dis8[ e16 cis16] \set melismaBusyProperties = #'() \schleiferVH b8 #0.2 #1.5 | % bar 24
    f'8 e8 d8 | % bar 25
    \set melismaBusyProperties = #'( melismaBusy slurMelismaBusy tieMelismaBusy beamMelismaBusy )
    c16[ cis16 d16] dis16 e16 fis16 | % bar 26
    g8[ fis8] e8 | % bar 27
    d4 fis8 | % bar 28
    d16[ cis] d[ cis] d8~ | % bar 29
    d16 e16 fis8 fis,8 | % bar 30
    g16[ gis16 a16 ais16] b16[ gis16] | % bar 31
    ais8\trill gis16[ fis16] cis'8 | % bar 32
    d8[( dis16 e16]) fis16[ b,16] | % bar 33
    g'8 e8 d8 | % bar 34
    cis8 b32[( cis32 d16]) cis16[( b16]) | % bar 35
    e4.~ | % bar 36
    e8 cis8 fis8~ | % bar 37
    fis16 d16 e16 cis16 d8 | % bar 38
    cis16[ b16] ais8. b16 | % bar 39
    b4 r8 | % bar 40
    R4.*4 | % bar 41
    e,8 d'16[ c16] d16[ b16] | % bar 45
    c8. d16 e8 | % bar 46
    R4.*2 | % bar 47
    fis,8 e'16[ dis16] e16[ cis16] | % bar 49
    dis8. e16 fis8 | % bar 50
    R4.*2 | % bar 51
    b,8 e16[ dis16] e16[ dis16] | % bar 53
    e8 r16 b16 a'8 | % bar 54
    g8 fis8 e8 | % bar 55
    dis8 cis16[ b16] fis'8 | % bar 56
    g,8[ gis16 a16] b16[ e,16] | % bar 57
    c'16[ cis16] d16[ dis16] e16[ fis16] | % bar 58
    g8 g16[ fis16] g8 | % bar 59
    fis8( a,4)~ | % bar 60
    a8 fis8 b8~ | % bar 61
    b16 g16 a16 fis16 g16[ g'16] | % bar 62
    fis16[ e16] dis8. e16 | % bar 63
    e4 r8 | % bar 64
    R4.*11 |
    R4.\fermata | % bar 65
    g8 b,16[ a16] b16[ g16] | % bar 77
    d'8. e16 fis8 | % bar 78
    g8 fis16[ e16] fis16[ g32 a32] | % bar 79
    fis4 r8 | % bar 80
    a8 c,?16[ b16] c16[ a16] | % bar 81
    b8 e16[ dis16] e8 | % bar 82
    a,8 c8 b8 | % bar 83
    g4 gis8 | % bar 84
    a16[ b16] b8.[\trill a32 b32] | % bar 85
    c8 cis4 | % bar 86
    d8[ e8] f8 | % bar 87
    \autoBeamOn f8 \melisma e16 d16 c16 b16 | % bar 88
    cis16 d16 cis16 d16 e8~ | % bar 89
    e8 d16 c16 b16 a16 | % bar 90
    b8 c16 b16 \melismaEnd \autoBeamOff c16[( a16]) | % bar 91
    e'4 r8 | % bar 92
    d8 c16 b16 f'8~ | % bar 93
    f16[ e16] d16[ b16] c8 | % bar 94
    b16[ a16] gis8. a16 | % bar 95
    a4 r8 | % bar 96
    R4.*4 | % bar 97
    e'8 c8 b8 | % bar 101
    a8 fis'16[ e16] fis8 | % bar 102
    d8 \appoggiatura c16 b8 \appoggiatura a16 g8 | % bar 103
    e4. | % bar 104
    c'8 a8 g8 | % bar 105
    fis8 e'16[( cis16]) dis16 b16 | % bar 106
    \autoBeamOn e4.~ \melisma | % bar 107
    e16 fis16 e16 d16 e16 cis16 | % bar 108
    d4.~ | % bar 109
    d16 e16 d16 \once \set suggestAccidentals = ##t cis16 d16 b16 | % bar 110
    \once \set suggestAccidentals = ##t c!4.~ | % bar 111
    c4.~ | % bar 112
    c16 f16 e16 d16 e16 c16 | % bar 113
    b16 e16 d16 cis16 d16 b16 | % bar 114
    ais16 d16 \once \set suggestAccidentals = ##t cis16 b16 \melismaEnd \autoBeamOff \once \set suggestAccidentals = ##t cis!16[( ais16]) | % bar 115
    fis4.~ | % bar 116
    fis16 gis16 ais16[ b16] cis16[ d16] | % bar 117
    e16[ fis16] g16[ e16] fis8 | % bar 118
    r16 b,16 \appoggiatura a16 g8 fis16[ g32 e32] | % bar 119
    dis4\trill r8 | % bar 120
    \barNumberCheck # 121
}
>>


mvtIIIlyrics = \lyricmode {
    Er schütt -- re dich nur nicht, ver -- zag -- te See -- le,
    er schütt -- re dich nur nicht, ver -- zag -- te See -- le,
    wenn dir der Kreu -- zes -- kelch so bit -- ter schmeckt,
    er schütt -- re dich nur nicht, ver -- zag -- te See -- le,
    wenn dir __ der Kreu -- zes -- kelch so bit -- ter schmeckt, __
    wenn dir __ der Kreu -- zes -- kelch so bit -- ter schmeckt,

    Er schütt -- re dich nur nicht,
    er schütt -- re dich nur nicht,
    er schütt -- re dich nur nicht, ver -- zag -- te See -- le,
    wenn dir __ der Kreu -- zes -- kelch so bit -- ter schmeckt, __
    wenn dir __ der Kreu -- zes -- kelch so bit -- ter schmeckt.

    Gott ist dein wei -- ser Arzt und Wun -- der -- mann,
    Gott ist dein wei -- ser Arzt und Wun -- der -- mann,
    so dir kein __ töd -- lich Gift ein -- schen -- ken kann,
    so dir kein __ töd -- lich Gift ein -- schen -- ken kann,

    ob -- gleich -- die Sü -- ßig -- keit ver -- bor -- gen steckt,
    ob -- gleich -- die Sü -- ßig -- keit ver -- bor -- gen steckt, __
    ob -- gleich -- die Sü -- ßig -- keit ver -- bor -- gen __ steckt.
}


mvtIIIbc = <<
\mvtIIItimeline
\relative c {
    \clef F

    e8^\Pia r8 fis8 | % bar 1
    g8 r8 e8 | % bar 2
    c8 r8 a8 | % bar 3
    b8 r8 a8 | % bar 4
    gis8 r8 e8 | % bar 5
    a8 r8 r8 | % bar 6
    ais8 r8 fis8 | % bar 7
    b8 r8 r8 | % bar 8
    dis8( dis8 dis8) | % bar 9
    e8 b8 c8 | % bar 10
    a8 fis8 b8 | % bar 11
    e,4 r8 | % bar 12
    e'8 r8 fis8 | % bar 13
    g16( fis16) e16( dis16) e16( dis16) | % bar 14
    e8 a,8 c8 | % bar 15
    b8 b'8 a8 | % bar 16
    g8 r8 e8 | % bar 17
    fis r dis | % bar 18
    e8 a,8 b8 | % bar 19
    e,8 e'16( dis16) e16( dis16) | % bar 20
    e8 r8 fis8 | % bar 21
    g16( fis16) e16( dis16) e16( dis16) | % bar 22
    e8 r8 ais,8 | % bar 23
    b8 r8 a8 | % bar 24
    gis8 r8 e8 | % bar 25
    a8 r8 g8 | % bar 26
    fis8 r8 fis'8 | % bar 27
    b,16 fis'16 g16( gis16) a16( ais16) | % bar 28
    b8 r8 fis8 | % bar 29
    d8 r8 dis8 | % bar 30
    e8 r8 eis8 | % bar 31
    fis8 r8 ais8 | % bar 32
    b8 r8 b,8 | % bar 33
    e8 r8 e,8 | % bar 34
    eis r8 eis' | % bar 35
    fis8 ais8 fis8 | % bar 36
    ais,8( ais8 ais8) | % bar 37
    b8 g'8 fis8 | % bar 38
    e8 fis8 fis,8 | % bar 39
    b8 r8 b'8 | % bar 40
    ais8( ais8 ais8) | % bar 41
    b8 fis8 g8 | % bar 42
    e8 cis8 fis8 | % bar 43
    b,8 b'8( a8) | % bar 44
    gis8 r8 e8 | % bar 45
    a16 gis16 a16( b16) c16( a16) | % bar 46
    gis8( gis8 gis8) | % bar 47
    a8 r8 g8 | % bar 48
    fis8 a8 fis8 | % bar 49
    b16 ais16 b16( cis16) dis16( b16) | % bar 50
    ais8( ais8 ais8) | % bar 51
    b8 r16 a16 g16 fis16 | % bar 52
    e8 r8 fis8 | % bar 53
    \once \slurDashed g16( fis16) e16( dis16) e16( dis16) | % bar 54
    e8 r8 ais,8 | % bar 55
    b8 r8 dis8 | % bar 56
    e8 r8 e,8 | % bar 57
    a8 r8 a'8 | % bar 58
    ais8 r8 ais,8 | % bar 59
    b8 dis8 b8 | % bar 60
    dis,8( dis8 dis8) | % bar 61
    e8 c'8 b8 | % bar 62
    a8 b8 b8 | % bar 63
    e,4 fis8 | % bar 64
    g8 g'16( fis16) g16( fis16) | % bar 65
    g8 r8 e8 | % bar 66
    c8 r8 a8 | % bar 67
    b8 r8 a8 | % bar 68
    gis8 r8 e8 | % bar 69
    a8 r8 r8 | % bar 70
    ais8 r8 fis8 | % bar 71
    b8 r8 r8 | % bar 72
    dis8( dis8 dis8) | % bar 73
    e8 b8 c8 | % bar 74
    a8 fis8 b8 | % bar 75
    e,4\fermata r8 | % bar 76
    e'8 r8 r8 | % bar 77
    b'8 d,16( cis16) d16( b16) | % bar 78
    e8 a8 a,8 | % bar 79
    d4 e8 | % bar 80
    fis8 r8 d8 | % bar 81
    g8 r8 c8~ | % bar 82
    c8 dis,16 cis16 dis16 b16 | % bar 83
    e8 d16 c16 d16 b16 | % bar 84
    c8 d8 e8 | % bar 85
    a,8 a'8 g8 | % bar 86
    f8 e8 d8 | % bar 87
    e8 fis8 gis8 | % bar 88
    a8 r8 a,8 | % bar 89
    d8 r8 d,8 | % bar 90
    dis8 r8 dis'8 | % bar 91
    e8 d16( c16) d16( b16) | % bar 92
    gis8( gis8 gis8) | % bar 93
    a8 f'8 e8 | % bar 94
    d8 e8 e,8 | % bar 95
    a8 c8 a8 | % bar 96
    d8 r8 b8 | % bar 97
    gis8 r8 a8 | % bar 98
    f'8 c8 e8 | % bar 99
    a,8 c8 e8 | % bar 100
    a4 r8 | % bar 101
    d,8 a8 d,8 | % bar 102
    g4 r8 | % bar 103
    c8 g8 c,8 | % bar 104
    fis4 r8 | % bar 105
    b8 fis'8 b8 | % bar 106
    e,8 cis8 b8 | % bar 107
    ais4 r8 | % bar 108
    b8 b'8 a8 | % bar 109
    g4 r8 | % bar 110
    e,8( e8 e8) | % bar 111
    e8( e8 e8) | % bar 112
    e8( e8 e8) | % bar 113
    d8 g'8 e8 | % bar 114
    cis8 e8 cis8 | % bar 115
    ais8( ais8 ais8) | % bar 116
    b8 r8 r8 | % bar 117
    g'8 ais,8 b8 | % bar 118
    g16( e16) fis16( e16) fis8 | % bar 119
    b4. | % bar 120
    \barNumberCheck # 121
}
>>

mvtIIIfigs = <<
\mvtIIItimeline
\figuremode {
}
>>


mvtIIIbreaksBGA = <<
\mvtIIItimeline
{
    % p267
    <>^"BGA breaks left in"
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak }
    \pageBreak

    % p268
    \repeat unfold 6 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \pageBreak

    % p269
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 7 { s4.\noBreak }
    \pageBreak

    % p270
    \repeat unfold 7 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak }
    \pageBreak

    % p271
    \repeat unfold 6 { s4.\noBreak }
    \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak }
    \barNumberCheck # 121
}
>>


mvtIIIbreaksNBA = <<
% \mvtIIItimeline
{
    <>^"NBA breaks left in"
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    % cannot follow NBA because schleifer breaks the breaks
    \repeat unfold 6 { s4.\noBreak } \break
    \barNumberCheck # 30
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break
    \barNumberCheck # 59
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 6 { s4.\noBreak } \break
    \barNumberCheck # 90
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 4 { s4.\noBreak } \break\noPageBreak
    \repeat unfold 5 { s4.\noBreak } \break
    \barNumberCheck # 116
    \repeat unfold 5 { s4.\noBreak }
    \barNumberCheck # 121
}
>>
