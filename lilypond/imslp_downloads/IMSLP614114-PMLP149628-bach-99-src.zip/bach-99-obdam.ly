\version "2.21.0"

#(define instrument (if (defined? 'instrument) instrument #{ \markup{Oboe d’Amore} #}))
#(define pInstr (if (defined? 'pInstr) pInstr #{ \markup\center-column{"(Oboe)"} #}))

\include "bach-99-1.ily"
\include "bach-99-3.ily"
\include "bach-99-4.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"

\include "bach-99-title.ily"
\include "bach-paged-title.ily"


\paper {
    % page-breaking = #ly:page-turn-breaking
    ragged-right = ##f
    page-count = #6
    ragged-last-bottom = ##f
}

\layout {
    \context {
        \StaffGroup {
            \revert StaffGroup.SystemStartBracket.collapse-height
        }
    }
}

\header {
    instrument = \instrument
}


% %{

\addQuote mvtIvlnI { \keepWithTag #'( PARTS cIC KEEPKEYS ) \mvtIvlnI }

breaksI = <<
{
    \autoPageBreaksOff
    s8 |
    s1*69 |
    \barNumberCheck # 70
    \pageTurn
    s1*47 |
    \barNumberCheck # 117
}
>>

mvtIcues = <<
\removeWithTag KEEPKEYS \mvtItimeline
{
    \transposition \transpObDAm
    <>^"Violino I" \cueDuring #"mvtIvlnI" #UP { s8 | s1 | }
    s1*12
    \cueDuring #"mvtIvlnI" #DOWN { s1*2 | s2. }
        <>^\pInstr
        s4 |
    s1*30 |
    <>^"Violino I" \cueDuring #"mvtIvlnI" #DOWN { s1*4 | s2. }
    <>^\pInstr
}
>>


\score { 
    \keepWithTag #'( PARTS cIC KEEPKEYS ) <<
        \new Dynamics \breaksI

        \new Staff = mvtIob \with {
        } \context Bottom << 
            \stretchHorizontalSpacing #-0.5
            \transpose \transpObDAm c \mvtIob
            \mvtIcues
        >>
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}

\markup\null\pageBreak

\markup\Tacet{\mvtIIpiece \endash \mvtIIIpiece}

% \markup\Tacet{\mvtIVpiece}

\score {
    \new Staff = mvtIVbc \with {
        instrumentName = \markup\center-column{"Basso" "Continuo"}
        \staffSize #-3
    } <<
        \mvtIVtimeline
        {
            \clef bass
            R1*11 |
            \quoteDuring mvtIVbc { s1*3 | }
            \bar "|."
        }
    >>

    \header {
        piece = \markup\TacetPiece{\mvtIVpiece}
        % breakbefore = ##t
    }
    \layout {
        indent = #18
    }
}

breaksV = <<
\mvtVtimeline
{
    s1*33 |
    \barNumberCheck # 34
    \pageTurn
    s1*18 |
    \barNumberCheck # 52
}
>>


% %{
\score {
    \keepWithTag #'( PARTS KEEPKEYS ) <<
        \new Dynamics \breaksV

        \new StaffGroup <<
            \new Staff = mvtVobDam <<
                \transpose \transpObDAm c \mvtVob
            >>
            \new Staff = mvtValto \with {
                instrumentName = \markup\bold{\normalsize "Alto"}
                \RemoveAllEmptyStaves
                \staffSize #-3
            } <<
                \new Voice = mvtValto { \clefAlto \mvtValto }
                { s1*4 | <>^\markup\normalsize{Alto} }
                \new Lyrics \with {
                    alignBelowContext = "mvtValto"
                    \override LyricText.font-size = #-0.5
                } {
                    \lyricsto mvtValto \mvtValtoLyrics
                }
            >>
        >>
    >>

    \header {
	piece = \mvtVpiece
	% breakbefore = ##t
    }
}
% %}


% %{
\score {
    \new Staff = mvtVIsopr <<
	\new Voice = mvtVIinstr { \transpose \transpObDAm c \mvtVIsopr }
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
