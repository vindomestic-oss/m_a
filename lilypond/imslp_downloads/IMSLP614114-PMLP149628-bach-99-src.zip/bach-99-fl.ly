\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-2.ily"
\include "bach-99-3.ily"
\include "bach-99-4.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"

instrument = "Flauto traverso"
pInstr = "(Flauto)"

\header {
    instrument = "Flauto traverso"
}

\include "bach-99-title.ily"
\include "bach-paged-title.ily"


\paper {
    % page-breaking = #ly:page-turn-breaking
    ragged-right = ##f
    ragged-last-bottom = ##f
}

\layout {
    \context {
        \StaffGroup {
            \revert SystemStartBracket.collapse-height
        }
    }
    \context {
        \GrandStaff {
            \revert SystemStartBrace.collapse-height
        }
    }
}


% %{

\addQuote mvtIvlnI { \keepWithTag #'cIC \mvtIvlnI }

breaksI = <<
\mvtItimeline
{
    \autoPageBreaksOff
    s8 |
    s1*68 |
    \barNumberCheck # 69
    \pageBreak
    s1*48 |
    \barNumberCheck # 117
    \noPageBreak
}
>>


mvtIcues = <<
\mvtItimeline
{
    \transposition c
    <>^"Violino I" \cueDuring #"mvtIvlnI" #UP { s8 s1 }
    s1*12
    \cueDuring #"mvtIvlnI" #UP { s1*2 s2. }
        <>^\pInstr
        s4 |
    s1*30
    <>^"Violino I" \cueDuring #"mvtIvlnI" #DOWN { s1*4 s2. }
        <>^\pInstr
}
>>

\score {
    \keepWithTag #'( PARTS cIC KEEPKEYS ) <<
        \new Dynamics \breaksI

        \new Staff \with {
        } \context Bottom <<
            \stretchHorizontalSpacing #-1.0
            \mvtIfl
            \mvtIcues
        >>
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}


\score {
    \new Staff = mvtIIbc \with {
        instrumentName = \markup\center-column{"Basso" "Continuo"}
        \staffSize #-3
    } <<
        \mvtIItimeline
        {
            \clef bass
            R1*11 |
            \quoteDuring mvtIIbc { s1*4 | }
            \barNumberCheck # 16
        }
    >>

    \header {
        piece = \markup\TacetPiece{\mvtIIpiece}
        % breakbefore = ##t
    }
    \layout {
        indent = #18
    }
}

\markup\null\pageBreak

%{ % BEGIN OF DUPLEX-ONLY SECTION
\markup\wordwrap{\bold{Note:} Movements \mvtIIIpiece and \mvtVpiece both
spread over three pages. The page order in this document allows
double-sided printing with pages 6 and 7 on a fold-out sheet.}\noPageBreak
\markup{\vspace #0.0 }\noPageBreak
%} % END OF DUPLEX-ONLY SECTION

breaksIII = <<
\mvtIIItimeline
{
    \autoPageBreaksOff
    s4.*16 |
    \barNumberCheck # 17
    \break
    s4.*4 |
    \barNumberCheck # 21
    \break
    s4.*20 |
    \barNumberCheck # 41
    \break
    s4.*4 |
    \barNumberCheck # 45
    \break
    \pageBreak
    s4.*20 |
    \barNumberCheck # 65
    \break
    s4.*21 |
    \barNumberCheck # 86
    \pageTurn
    s4.*11 |
    \barNumberCheck # 97
    \break
    s4.*24 |
    \barNumberCheck # 121
}
>>

\score {
    \keepWithTag #'( PARTS KEEPKEYS ) <<
        \new Dynamics \breaksIII

        \new StaffGroup <<
            \new Staff \with {
                % instrumentName = \markup\center-column{"Flauto" "Traverso"}
            } <<
                \stretchHorizontalSpacing #-1.1
                \mvtIIIfl
            >>
            % %{
            \new Staff = mvtIIItenor \with {
                instrumentName = \markup\bold{\normalsize "Tenore"}
                \RemoveAllEmptyStaves
                \staffSize #-3
            } <<
                \new Voice = mvtIIItenor { \clefTenor \mvtIIItenor }
                { s4.*12 | <>^\markup\normalsize{Tenore} }
                \new Lyrics \with {
                    alignBelowContext = "mvtIIItenor"
                    \override LyricText.font-size = #-0.5
                } {
                    \lyricsto mvtIIItenor \mvtIIIlyrics
                }
            >>
            % %}
        >>
    >>

    \header {
        piece = \mvtIIIpiece
        % breakbefore = ##t
    }
    \layout {
        % indent = #20
    }
}


\markup\null\pageBreak
% \markup\Tacet{\mvtIVpiece}


\score {
    \new Staff = mvtIVbc \with {
        instrumentName = \markup\center-column{"Basso" "Continuo"}
        \staffSize #-3
    } <<
        \mvtIVtimeline
        {
            \clef bass
            R1*11 |
            \quoteDuring mvtIVbc { s1*3 | }
            \bar "|."
        }
    >>

    \header {
        piece = \markup\TacetPiece{\mvtIVpiece}
        % breakbefore = ##t
    }
    \layout {
        indent = #18
    }
}


% %{
\score {
    \new StaffGroup <<
        \new Staff = mvtVfl <<
           \mvtVfl
        >>
	\new Staff = mvtValto \with {
	    instrumentName = \markup\bold{\normalsize "Alto"}
            \RemoveAllEmptyStaves
            \staffSize #-3
        } <<
            \new Voice = mvtValto { \clefAlto \mvtValto }
            { s1*4 | <>^\markup\normalsize{Alto} }
	    \new Lyrics \with {
		alignBelowContext = "mvtValto"
		\override LyricText.font-size = #-0.5
	    } {
                \lyricsto mvtValto \mvtValtoLyrics
            }
        >>
    >>

    \header {
	piece = \mvtVpiece
	% breakbefore = ##t
    }
}
% %}


% %{
\score {
    \new Staff = mvtVIsopr <<
	\new Voice = mvtVIinstr { \transpose c c' \mvtVIsopr }
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
