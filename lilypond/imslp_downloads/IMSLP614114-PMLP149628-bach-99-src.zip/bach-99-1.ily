\version "2.21.0"

\include "common.ily"
\include "bach-C-IC-common.ily"

mvtItimeline = {
    \time 2/2 
    \tag KEEPKEYS \key g \major
        \overrideTimeSignatureSettings
        #'(2 . 2)         % timeSignatureFraction
        #'(1 . 2)         % baseMomentFraction
        1,1               % beatStructure
        #'(
            (end .
             (
              ; ((1 . 8) . (2 2 2 2))
              ((1 . 8) . (4 4))
              ((1 . 16) . (4 4 4 4))
              ((1 . 24) . (6 6 6 6))
              ((1 . 32) . (8 8 8 8))
             ))
          )               % beamExceptions

    \partial 8*1
    \tag cC {
	\tempo \markup{\bold\large Vivace.}
    }

    s8 |
    s1*115 |
    \barNumberCheck # 116
    s2 s4.
    \tag cIC {
	s8 |
        \barNumberCheck # 117
    }
    \bar "|."
}


mvtIcorI = <<
\removeWithTag KEEPKEYS \mvtItimeline
\relative c'''{
    \clef treble
    \transposition g,

    g8 |
    e( f) f( g) g r r g | % 1
    e( f) f( g) g r r g | % 2
    g r r g g r r e | % 3
    c d16 e f8 e d g,16 g g8 r | % 4
    r8 g16 g g8 r r g16 g g8 r | % 5
    r8 g16 g g8 r r g16 g g8 g' | % 6
    g( a) r f f( g) r e | % 7
    e( f) r f f2~\trill | % 8
    f4. g16 g e8( d) d( c) | % 9
    c4 r8 e f8( e) e( d) | % 10
    d4 r8 f g8( f) f( e) | % 11
    e1~ | % 12
    e8 f r f f( g) r g | % 13
    c, d16 e f e d e c2~\startTrillSpan | % 14
    << c2 { s4 s4\stopTrillSpan } >> d4.\trill c16 d | % 15
    e f g8~ g16 e f8-. e4 r | % 16
    R1*6 | % 22
    r2 r4 r8 g | % 23
    e8( f) f( g) g r r4 | % 24
    r2 r4 r8 g | % 25
    d( e) e( f) f r r4 | % 26
    R1 | % 27
    r2 r4 r8 g | % 28
    a1~ | % 29
    a8 r f r e r a r | % 30
    e r b' r e, r c' r | % 31
    bes r bes r a r a r | % 32
    g r g r f r f r | % 33
    e8 r e r e16 d e f e f g a | % 34
    d,8 r d r d16 c d e f g f g | % 35
    e8( f) f( g) g r r4 | % 36
    r2 r4 r8 g | % 37
    g r r g g r r e | % 38
    c d16 e f8 e d g,16 g g8 r | % 39
    r g16 g g8 r r g16 g g8 r | % 40
    r g16 g g8 r r g16 g g8 g' | % 41
    g( a) r f f( g) r e | % 42
    e( f) r f f2~\trill | % 43
    f4. g16 f e8( d) d( c) | % 44
    c4 r8 e f( e) e( d) | % 45
    d4 r8 f g( f) f( e) | % 46
    e1~ | % 47
    e8 f r f f( g) r g | % 48
    c, d16 e f e d e c2~\startTrillSpan | % 49
    << c2 { s4 s4\stopTrillSpan } >> d4.\trill c16 d | % 50
    e f g8~ g16 e f8-. e4 r | % 51
    R1*6 | % 57
    r2 r4 r8 g | % 58
    e( f) f( g) g r r4 | % 59
    r2 r4 r8 g | % 60
    d( e) e( f) f r r4 | % 61
    R1 | % 62
    r2 r4 r8 g | % 63
    a1~ | % 64
    a8 r f r e r a r | % 65
    e r b' r e, r c' r | % 66
    bes r bes r a r a r | % 67
    g r g r f r f r | % 68
    e r e r e16 d e f e f g a | % 69
    d,8 r d r d16 c d e f g f g | % 70
    e8( f) f( g) g r r4 | % 71
    R1*4 | % 75
    r2 r4 r8 e | % 76
    f( g) g( a) a r r f | % 77
    f( e) e( d) d r8 r4 | % 78
    r2 r4 r8 g | % 79
    e( f) f( g) g r r c,,16 c | % 80
    c8 r r c16 c c8 r r4 | % 81
    r2 r4 a''8 r | % 82
    a r g r a r a r | % 83
    g r g r b r b r | % 84
    c r c r a r a r | % 85
    b( a) a( g) g r r4 | % 86
    r2 r4 r8 g | % 87
    a( g) g( fis) fis r r4 | % 88
    r2 r4 r8 a | % 89
    b1~ | % 90
    b8 r g r a r e r | % 91
    a1~ | % 92
    a8 r a r g r g r | % 93
    f r g r g r g r | % 94
    f r f r e r e r | % 95
    d r d r e r e r | % 96
    d r d r d r d r | % 97
    c r r g' a2~| % 98
    a1 | % 99
    g2 f4. g16 f | % 100
    e8( f) f( g) g r r4 | % 101
    r2 r4 r8 g | % 102
    g r r g g r r g | % 103
    a( b) b( c16 a) b8 g,16 g g8 r | % 104
    r g16 g g8 r r g16 g g8 r | % 105
    r2 r4 r8 g' | % 106
    g( a) r f f( g) r e | % 107
    e( f) r f f2~\trill | % 108
    f4. g16 f e8( d) d( c) | % 109
    c4 r8 e f( e) e( d) | % 110
    d4 r8 f g( f) f( e) | % 111
    e1~ | % 112
    e8 f r f f( g) r g | % 113
    c, d16 e f e d e c2~\startTrillSpan | % 114
    << c2 { s4 s4\stopTrillSpan } >> d8 g,( g g) | % 115
    g c16 d e g f8 
        \tag cC {
            e4.\fermata
        }
        \tag cIC {
            e2\fermata
        }
}
>>


mvtIcorII = <<
\removeWithTag KEEPKEYS \mvtItimeline
\relative c''{
    \clef treble
    \transposition g,
    
    e8 |
    c( d) d( e) e r r e | % 1
    c( d) d( e) e r r e | % 2
    d r r d e r r c | % 3
    c, g' r g g4 r8 g16 g | % 4
    g8 r r g16 g g8 r r g16 g | % 5
    g8 r r g16 g g8 r r e' | % 6
    e( f) r c d( e) r g, | % 7
    c( d) r d d2~\trill | % 8
    d4. e16 d c8 e,( e e) | % 9
    e4 r8 c' d g, c g | % 10
    g4 r8 d' e g,( g g) | % 11
    c1~ | % 12
    c8 d r d d( e) r e | % 13
    e( d) r g, e g g e | % 14
    c8 r e r g d'16 e f d g8 | % 15
    g, c16 d e c d8 c4 r | % 16
    R1*6 | % 
    r2 r4 r8 d | % 23
    c( d) d( e) e r r4 | % 24
    r2 r4 r8 e | % 25
    b( c) c( d) d r r4 | % 26
    r2 r4 r8 d | % 27
    e1~ | % 28
    e8 r g r f e e r |
    d1~ | % 30
    d8 r d r c r d r | % 31
    d r c r c r d r | % 32
    g, r c r c r g r | % 33
    g r g r c, r c' r | % 34
    c8 r c r g g16 g g8 d' | % 35
    c( d) d( e) e r r4 | % 36
    r2 r4 r8 e | % 37
    d r r d e r r c | % 38
    c, g' r g g4 r8 g16 g | % 39
    g8 r r g16 g g8 r r g16 g | % 40
    g8 r r g16 g g8 r r e' | % 41
    e( f) r c d( e) r g, | % 42
    c( d) r d d2~\trill| % 43
    d4. e16 d c8 e,( e e) | % 44
    e4 r8 c' d g, c g | % 45
    g4 r8 d' e g,( g g) | % 46
    c1~ | % 47
    c8 d r d d( e) r e | % 48
    e( d) r g, d g g e | % 49
    c r d r g d'16 e r d g8 | % 50
    g, c16 d e c d8 c4 r | % 51
    R1*6 | % 
    r2 r4 r8 d | % 58
    c( d) d( e) e r r4 | % 59
    r2 r4 r8 e, | % 60
    g( c) c( d) d r r4 | % 61
    r2 r4 r8 d | % 62
    e1~ | % 63
    e8 r g r f r e r | % 64
    d1~ | % 65
    d8 r d r c r d r | % 66
    d r c r c r d r | % 67
    g,8 r c r c r g r | % 68
    g r g r c, r c' r | % 69
    c r c r g g16 g g8 d' | % 70
    c( d) d( e) e r8 r4 | % 71
    R1*4 | % 
    r2 r4 r8 c | % 76
    c( bes) bes( c) c r r d | % 77
    d( c) c( g) g r r4 | % 78
    r2 r4 r8 d' | % 79
    c( d) d( e) e r r4 | % 80
    r8 c,16 c c8 r r c16 c c8 r | % 81
    r2 r4 e'8 r | % 82
    d r d r c r d r | % 83
    d r d r g, r g' r | % 84
    e r a r d, r fis r | % 85
    d( c) c( g) g r r4 | % 86
    r2 r4 r8 d' | % 87
    fis( d) d d d r r4 | % 88
    R1 | % 89
    r2 r4 r8 d | % 90
    e1~ | % 91
    e8 r c r fis r r4 | % 92
    r b8 r b r a r | % 93
    a r d, r g, r c r | % 94
    d r g, r g r c r | % 95
    c r g r g r c r | % 96
    c r c r g r g r | % 97
    e r r4 r r8 c' | % 98
    d1~ | % 99
    d8 g, c e~ e f16 e d8 e16 d | % 100
    c8( d) d( e) e r r4 | % 101
    r2 r4 r8 c | % 102
    d r r d e r r e | % 103
    c( d) d( e16 f) g8 r r g,16 g | % 104
    g8 r r g16 g g8 r r4 | % 105
    r2 r4 r8 e' | % 106
    e( f) r d d( e) r c | % 107
    c( d) r d d2~\trill | % 108
    d4. e16 d c8 e,( e e) | % 109
    e4 r8 c' d g, c g | % 110
    g4 r8 d' e g,( g g) | % 111
    c1~ | % 112
    c8 d r d d g, r e' | % 113
    e( d) r g, e g g e | % 114
    c r e r g( g g g) | % 115
    g g'16 f e c d8 
        \tag cC {
            c4.\fermata
        }
        \tag cIC {
            c2\fermata
        }
}
>>


mvtItimp = <<
\removeWithTag KEEPKEYS \mvtItimeline
\relative c {
    \transposition c
    \clef F

    % p279
    g8 |
    g8 r g r g r r g |
    g8 r g r g r r g |
    d' r r d g, r r4 |
    r r8 g d'4 r |

    % p280
    d r d r |
    d r d r8 d16 d |
    g,4 r r2 |
    r2 d'4 r |
    d r8 d16 d g,8 r r4 |

    % p281
    g4 r r2 |
    d'4 r r2 |
    g,8 d' d g, g d' d g, |
    g r r4 d'8 r r4 |
    g,8 r r d' g, r r4 |

    % p282
    g8 r r4 d'8 r r4 |
    r8 g, d' d g,4 r |
    R1*6 |

    % p284
    r2 r4 r8 d' |
    g, r g r g r r4 |
    r2 r4 r8 g |
    d' r d r d r r4 |

    % p285
    R1*6 |

    % p286
    r8 g,16 g g8 r r d'16 d d8 r |
    r g,16 g g8 r r g16 g g8 r |

    % 287
    r2 r8 d'16 d d8 d |
    g,8 r g r g r r4 |
    r2 r4 r8 g |
    d' r r d g, r r4 |

    % 288
    r4 r8 g d'4 r |
    d r d r |
    d r d r8 d16 d |
    g,4 r r2 |
    r d'4 r |

    % 289
    d r8 d16 d g,8 r r4 |
    g r r2 |
    d'4 r r2 |
    g,8 d' d g, g d' d g, |

    % 290
    g r r4 d'8 r r4 |
    g,8 r r d' g, r r4 |
    g8 r r4 d'8 r r4 |
    r8 g, d' d g,4 r |

    % 291
    R1*6 |

    % 292
    r2 r4 r8 d' |
    g, r g r g r r4 |

    % 293
    r2 r4 r8 g |
    d' r d r d r r4 |
    R1*6 |
    
    % 295
    r8 g,16 g g8 r r d'16 d d8 r |
    r8 g,16 g g8 r r g16 g g8 r |
    r2 r8 d'16 d d8 d |
    g, r g r g r r4 |

    % 296
    R1*4 |

    % 297
    r2 r4 r8 g
    g r g r g r r4 |
    d'8 r d r d r r4 |
    r2 r4 r8 d |

    % 298
    g, r g r g r r4 |
    R1 |
    r2 r8 g16 g g8 r |
    r d'16 d d8 r r2 |

    % 299
    r8 d16 d d8 r r d16 d d8 r |
    r g,16 g g8 r r2 |
    d'8 r d r d r r4 |
    R1*7 |

    % 301
    r2 r8 g,16 g g8 r |
    r d'16 d d8 r r g,16 g g8 r |

    % 302
    r2 r8 g16 g g8 r |
    r2 r8 d'16 d d8 d |
    g, r r4 r2 |
    R1 |

    % 303
    r2 r4 r8 d' |
    g, r g r g r r4 |
    r2 r4 r8 g |
    d' r r d g, r r4 |

    % 304
    r r8 g d'4 r |
    d r d r |
    r2 r4 r8 d16 d |
    g,4 r r2 |

    % 305
    r2 d'4 r |
    d r8 d16 d g,8 r r4 |
    g r r2 |
    d'4 r r2 |

    % 306
    g,8 d' d g, g d' d g, |
    g r r4 d'8 r r4 |
    g,8 r r d' g, r r4 |
    g8 r r4 d'8 r r4 |
    r8 g, d'16 d d8 
        \tag cC {
            g,4.\fermata
        }
        \tag cIC {
            g,2\fermata
        }
}
>>

 

mvtIfl = <<
\mvtItimeline
\relative c'{
    \transposition c
    \clef treble

    r8 |
    R1*15 | % 13
    \barNumberCheck # 16
    r2 r4 r8 d' | % 16
    g16 a g fis g a g fis g d b( a b) d g fis | % 17
    g a g fis g a g fis g d b( a b) d g b | % 18
    a fis \tag cIC { \once \slurDashed } c( b c) fis a c b g \tag cIC { \once \slurDashed } d( c d) g b d | % 19
    c a \tag cIC { \once \slurDashed } d,( c d) fis g b a g fis e d e d c | % 20
    d b g( fis g) b d e d a fis( e fis) a d e | % 21
    d b \tag cIC { \once \slurDashed } g\cICSO fis g\cICSC b d g g e \tag cIC { \once \slurDashed } c\cICSO b c\cICSC e g a | % 22
    b g d( c d) g b d d a \tag cIC { \once \slurDashed } fis( e fis) a c fis | % 23
    g8 r r4 r r8 d, | % 24
    g16 a g fis g a g fis g d b\cICSO a b\cICSC d g8 | % 25
    r2 r4 r8 d | % 26
    c'16\cCSO d c\cCSC b\cCD b\cCSO c b\cCSC a\cCD a g \tag cIC { \once \slurDashed } fis( e fis) a d8 | % 27
    R1 | % 
    r2 r4 r8 g, | % 29
    a\cCD g16\cCSO fis\cCSC a8 g16 e a8 fis16 dis a'8 fis16 cis | % 30
    a'8 fis16 dis b8 dis16 fis g8 e16 cis a8 cis16 e | % 31
    f8 d16 b g8 b16 d e4 r | % 32
    r2 r4 r8 d\cCT | % 33
    d16 \once \set suggestAccidentals = ##t cis d e d e fis d g fis g a g a b g | % 34
    e' d c b a g fis e fis e d c b a g' fis | % 35
    g1~\trill | % 36
    g16 a g fis g a g fis g d \tag cIC { \once \slurDashed } b( a b) d g8 | % 37
    R1*13 | % 
    r2 r4 r8 d | % 51
    g16 a g fis g a g fis g d b( a b) d g fis | % 52
    g a g fis g a g fis g d b( a b) d g b | % 53
    a fis c( b c) fis a c b g d( c d) g b d | % 54
    c a \tag cIC { \once \slurDashed } d,( c d) fis g b a g fis e
	\tag cC {
	    d c d e | % 55
	}
	\tag cIC {
	    d e d c | % 55
	}
    d b g( fis g) b d e d a fis( e fis) a d e | % 56
    d b \tag cIC { \once \slurDashed } g( fis g) b d g g e \tag cIC { \once \slurDashed } c( b c) e g a | % 57
    b g d( c d) g b d d a \tag cIC { \once \slurDashed } fis( e fis) a c fis | % 58
    g8 r r4 r r8 d, | % 59
    g16 a g fis g a g fis g d b\cICSO a b\cICSC d g8 | % 60
    r2 r4 r8 d | % 61
    c'16\cCSO d c\cCSC b\cCD b\cCSO c b\cCSC a\cCD a g \tag cIC { \once \slurDashed } fis\cICSO e fis\cICSC a d8 | % 62
    R1 | % 
    r2 r4 r8 g, | % 64
    a\cCD g16\cCSO fis\cCSC a8 g16 e a8 fis16 dis a'8 fis16 cis | % 65
    a'8 fis16 dis b8 dis16 fis g8 e16 cis a8 cis16 e | % 66
    f8 d16 b g8 b16 d e4 r | % 67
    r2 r4 r8 d\cCT | % 68
    d16 \once \set suggestAccidentals = ##t cis d e d e fis d g fis g a g a b g | % 69
    e' d c b a g fis e fis e d c b a g' fis | % 70
    g1\trill | % 71
    f\cCTrill | % 72
    e8( f) f( g) g c16 b c8 g | % 73
    e( f) f( g) g c16 b c8 g | % 74
    g d'16 c d8 g, g e'16 d e8 g, | % 75
    a\cCSO b\cCSC b16 d c8 d16 c b a g8 b | % 76
    c16 d c b c d c b c g \tag cIC { \once \slurDashed } e( d e) g c8 | % 77
    r2 r8 d,16( c d) g b d | % 78
    d,\cCSO e d cis\cCSC d\cCSO e d cis\cCSC d a fis( e fis) a d fis | % 79
    g a g fis g a g fis g d \tag cIC { \once \slurDashed } b( a b) d g8 | % 80
    r2 r8 \tag cIC { \once \slurDashed } e16( d e) g c e | % 81
    g, a g fis g a g fis g d b( a b8) e16 g | % 82
    a8 fis16 d b8 d16 fis g8 e16 cis a8 cis16 e | % 83
    fis8 e16 d fis8 e16 cis fis8 d16 b fis'8 d16 a | % 84
    b8 b'16 a b8 g e cis'16 b cis8 a | % 85
    fis( g) g( a) a d16
	\tag cIC { \once \set suggestAccidentals = ##t } cis
	d8 a | % 86
    fis( g) g( a) a d16 cis d8 a | % 87
    e( fis) fis( g) g e'16 d e8 g | % 88
    a,( b) b( cis) cis e16 d e8 r | % 89
    R1 | % 
    r2 r4 r8 d | % 91
    e d16 cis e8 d16 b e8 cis16 ais e'8 cis16 gis | % 92
    e'8 cis16 ais fis8 ais16 cis d8 b16 gis e8 gis16 b | % 93
    c8 a16 fis d8 fis16 a c8( b) b g16 e | % 94
    b'8( a) a fis16 d a'8( g) g d16 b | % 95
    g'8 fis16 e g8 fis16 d g8 d16 b g'8 e16 b | % 96
    g'8 e16 c a8 c16 e fis8 d16 c a8 c16 d | % 97
    f8 d16 b g8 b16 d e8 d16 c e8 d16 b | % 98
    e8 c16 a e'8 c16 g e'8 c16 a fis8 a16 c | % 99
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 100
    b8( c) c( d) d g16 fis g8 d | % 101
    g16 a g\cCSO fis g\cCSC a g fis g d \tag cIC { \once \slurDashed } b( a b) d g b | % 102
    a fis \tag cIC { \once \slurDashed } c( b c) fis a c b g \tag cIC { \once \slurDashed } d( c d) g b d | % 103
    c a \tag cIC { \once \slurDashed } d,( c d) fis g b a g fis e d8 r | % 104
    r2 r4 r8 d | % 105
    \tag cC {
	d16 \once \set suggestAccidentals = ##t cis d e d \once \set suggestAccidentals = ##t cis! d e
    }
    \tag cIC {
	d16 e d c d e d c
    }
    d fis g a b c b c | % 106
    b2\trill a\trill | % 107
    g\trill fis16( e fis\cCSC g\cCD\cICSC g( fis g\cCSC a\cCD\cICSC | % 108
    a\cCSO g a\cCSC c\cCD e8 d
	\tag cC {
	    \appoggiatura c8
	} b4 r | % 109
    r8 b,16( a b) e g b c,4 r | % 110
    r8 c16\cICSO b c\cICSC fis a c d,4 r8 d | % 111
    b' a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 112
    b'8 g16 e c8 e16 g a8 fis16 d b8 d16 fis | % 113
    g8 a d, fis g2~ | % 114
    g r8 d16\cICSO cis d\cICSC fis a c | % 115
    b8[ d] d, fis 
        \tag cC {
            g4.\fermata
        }
        \tag cIC {
            g2\fermata
        }
}
>>

 
mvtIob = <<
\mvtItimeline
\relative c'{
    \transposition c
    \clef treble

    r8 |
    R1*15 | % 
    \barNumberCheck # 16
    r2 r4 r8 d' | % 16
    b( c) c( d) d g16 fis g8 d | % 17
    b( c) c( d) d g16 fis g8 d | % 18
    d a'16 g a8 d, d b'16 a b8 d, | % 19
    e\cCSO fis\cCSC fis16 a g8 \tag cC { \appoggiatura g8 } fis4 r8 a,, | % 20
    b( c) c( d) d a'16 g a8 fis | % 21
    g b16 a b8 g g e'16 d e8 g, | % 22
    g g'16 fis g8 d d a'16 g a8 d, | % 23
    d r r4 r r8 d | % 24
    b( c) c( d) d g16 fis g8 r | % 25
    r2 r4 r8 a | % 26
    a,( b) b( c) c a'16 g a8 r | % 27
    r2 r4 r8 d, | % 28
    e d16 c e8 d16 b e8 c16 a e'8 c16 g | % 29
    fis'1~ | % 30
    fis8 a, fis'4~ fis8 g,8 e'4~ | % 31
    e8 f, d'4~ d8 c16 a fis8 a16 c | % 32
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 33
    b8 a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 34
    e8 e'16 d e8 c a fis'16 e fis8 d | % 35
    b( c) c( d) d g16 fis g8 d\Pia | % 36
    b( c) c( d) d g16 fis16 g8 r | % 37
    R1*13 | % 
    r2 r4 r8 d | % 51
    b( c) c( d) d g16 fis g8 d | % 52
    b( c) c( d) d g16 fis g8 d | % 53
    d a'16 g a8 d, d b'16 a b8 d, | % 54
    e\cCSO fis\cCSC fis16 a g8
	\tag cC {
	    \appoggiatura g8
	}
	fis4 r8 a,, | % 55
    b( c) c( d) d a'16 g a8 fis | % 56
    g b16 a b8 g g e'16 d e8 g, | % 57
    g g'16 fis g8 d d a'16 g a8 d, | % 58
    d r r4 r r8 d | % 59
    b( c) c( d) d g16 fis g8 r | % 60
    r2 r4 r8 a | % 61
    a,( b) b( c) c a'16 g a8 r | % 62
    r2 r4 r8 d, | % 63
    e d16 c e8 d16 b e8 c16 a e'8 c16 g | % 64
    fis'1~ | % 65
    fis8 a, fis'4~ fis8 g,8 e'4~ | % 66
    e8 f, d'4~ d8 c16 a fis8 a16 c | % 67
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 68
    b8 a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 69
    e8 e'16 d e8 c a fis'16 e fis8 \tag cIC { <>\Pia } d | % 70
    b( c) c( d) d g16 fis g8 d | % 71
    g,( a) a( b) b d16 c d8 \tag cIC { <>\For } b | % 72
    c16\cCSO d c b\cCSC c\cCSO d c b\cCSC c g \tag cIC { \once \slurDashed } e( d e) g c b | % 73
    c d c b c d c b c g \tag cIC { \once \slurDashed } e( d e) g c e | % 74
    d b \tag cIC { \once \slurDashed } g( fis g) b d f e c \tag cIC { \once \slurDashed } g( f g) c e g | % 75
    f d \tag cIC { \once \slurDashed } g,( f g) b c e d b g\cCSO fis g8\cCSC g | % 76
    e( f) f( g) g c16 b c8 r | % 77
    r2 r4 r8 g | % 78
    c( b) b( a) a d,16 \once \set suggestAccidentals = ##t cis d8 d' | % 79
    b( c) c( d) d g16 fis g8 r | % 80
    r2 r4 r8 c,, | % 81
    f( e) e( d) d g16 fis g8 r | % 82
    r2 r4 r8 a\cCT | % 83
    a16 \once \set suggestAccidentals = ##t gis a b a b cis a d cis d e d e fis d | % 84
    b' a g fis e d cis b cis b a g fis e d' cis | % 85
    d1~\trill | % 86
    d16 e d cis d e d cis d a \tag cIC { \once \slurDashed } fis( e fis) a d8 | % 87
    r2 r4 r8 a | % 88
    g'16\cCSO a g\cCSC fis\cCD fis\cCSO g fis\cCSC e\cCD e d \tag cIC { \once \slurDashed } cis( b cis) e a8 | % 89
    r2 r4 r8 a | % 90
    b a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 91
    g4 cis,2.~ | % 92
    cis8 e, cis'4~ cis8 d,8 b'4~ | % 93
    b8 c,? a'4~ a8[ b,8] g' e' | % 94
    e c16 a d8 d d b16 g d'8 g\cCT | % 95
    g fis16 e g8 fis16 d g8 d16 b g'8 e16 b | % 96
    g'8 e16 c a8 c16 e fis8 d16 c a8 c16 d | % 97
    f8 d16 b g8 b16 d e8 d16 c e8 d16 b | % 98
    e8 c16 a e'8 c16 g e'8 c16 a fis8 a16 c | % 99
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 100
    b8( c) c( d) d g16 fis g8 d | % 101
    b( c) c( d) d g16 fis g8 d | % 102
    d a'16 g a8 d, d b'16 a b8 d, | % 103
    e( fis) fis( g) a16 g fis e d8 r | % 104
    r2 r4 r8 g16 b, | % 105
    c8( b) b( a) a g16 fis g8 b16 d | % 106
    f8( e) e c16 g e'8( d) d b16 fis | % 107
    d'8( c) c b16 a c8 b16 g c8 a16 fis | % 108
    c'8 g16 e c'8 fis,16 d b'8( a) a( g) | % 109
    g b16 e g8 e16 b c8( b) b( a) | % 110
    a c16 fis a8 fis16 c d8( c) c( b) | % 111
    b4 d g2~ | % 112
    g8 c,4 a'8~ a d,4
	\tag cIC {
	    fis8 | % 113
	}
	\tag cC {
	    fis16 d | % 113
	}
    g16 b, e\cCSO d\cCSC c\cCSO b\cCSC a\cCSO g\cCSC g8 fis16 e g8 f16 d | % 114
    g8 e16 c g'8 d16 b a8 d16 fis a8 c16 a | % 115
    b8[ d] d, fis 
        \tag cC {
            g4.\fermata
        }
        \tag cIC {
            g2\fermata
        }
}
>>

 
mvtIvlnI = <<
\mvtItimeline
\relative c'{
    \transposition c
    \clef treble

    d'8 |
    b( c) c( d) d g16 fis g8 d | % 1
    b( c) c( d) d g16 fis g8 d | % 2
    d a'16 g a8 d, d b'16 a b8 d, | % 3
    e( fis) fis( g) a16 g fis e d8 d | % 4
    c'( b) b( a) a g16 fis g8 b,16 g | % 5
    c8( b) b( a) a g16 fis g8 b16 d | % 6
    f8( e) e c16 g e'8( d) d b16 fis | % 7
    d'8( c) c b16 a c8 b16 g c8 a16 fis | % 8
    c'8 g16 e c'8 fis,16 d b'8( a) a( g) | % 9
    g b16 e g8 e16 b c8( b) b( a) | % 10
    a c16 fis a8 fis16 c d8( c) c( b) | % 11
    b a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 12
    b'8 g16 e c8 e16 g a8 fis16 d b8 d16 fis | % 13
    g8 a d, fis g fis16 e g8 f16 d | % 14
    g8 e16 c g'8 d16 b a8 d16 fis a8 c16 a | % 15
    b8[ d] d, fis g4 r8 g\Pia | % 16
    g,( a) a( b) b d16 c d8 b | % 17
    g( a) a( b) b d16 c d8 b' | % 18
    fis4 r8 fis g4 r8 g | % 19
    g( a) a b16 g d'4 r | % 20
    R1*2 | % 
    r2 r4 r8 d\For | % 23
    b( c) c( d) d g16 fis g8 b,,\Pia | % 24
    g( a) a( b) b d16 c d8 g'\For | % 25
    a,( b) b( c) c a'16 g a8 fis\Pia | % 26
    fis,( g) g( a) a c16 b c8 a\For | % 27
    b a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 28
    c'1~ | % 29
    c8 r c r b r e r | % 30
    dis r r a' g r r g | % 31
    f r r f e c16 a fis8 a16 c | % 32
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 33
    b8 a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 34
    e8 e'16 d e8 c a fis'16 e fis8 d | % 35
    b( c) c( d) d g16 fis g8 b,,\Pia | % 36
    g( a) a( b) b d16 c d8 d'\For | % 37
    d a'16 g a8 d, d b'16 a b8 d, | % 38
    e( fis) fis( g) a16 g fis e d8 d | % 39
    c'( b) b( a) a g16 fis g8 b,16 g | % 40
    c8( b) b( a) a g16 fis g8 b16 d | % 41
    f8( e) e c16 g e'8( d) d b16 fis | % 42
    d'8( c) c b16 a c8 b16 g c8 a16 fis | % 43
    c'8 g16 e c'8 fis,16 d b'8( a) a( g) | % 44
    g b16 e g8 e16 b c8( b) b( a) | % 45
    a c16 fis a8 fis16 c d8( c) c( b) | % 46
    b a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 47
    b'8 g16 e c8 e16 g a8 fis16 d b8 d16 fis | % 48
    g8 a d, fis g fis16 e g8 f16 d | % 49
    g8 e16 c g'8 d16 b a8 d16 fis a8 c16 a | % 50
    b8[ d] d, fis g4 r8 g\Pia | % 51
    g,( a) a( b) b d16 c d8 b | % 52
    g( a) a( b) b d16 c d8 b' | % 53
    fis4 r8 fis g4 r8 g | % 54
    g( a) a b16 g d'4 r | % 55
    R1*2 | % 
    r2 r4 r8 d\For | % 58
    b( c) c( d) d g16 fis g8 b,,\Pia | % 59
    g( a) a( b) b d16 c d8 g'\For | % 60
    a,( b) b( c) c a'16 g a8 fis\Pia | % 61
    fis,( g) g( a) a c16 b c8 a\For | % 62
    b a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 63
    c'1~ | % 64
    c8 r c r b r e r | % 65
    dis r r a' g r r g | % 66
    f r r f e c16 a fis8 a16 c | % 67
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 68
    b8 a16 g b8 a16 fis b8 g16 e b'8 g16 d | % 69
    e8 e'16 d e8 c a fis'16 e fis8 \tag cIC { <>\Pia } d | % 70
    b( c) c( d) d g16 fis g8 \tag cC { <>\Pia } b, | % 71
    b,( c) c( d) d b'16 a b8 g\f | % 72
    c,( d) d( e) e g16 f g8 e | % 73
    c( d) d( e) e g16 f g8 e | % 74
    b4 r8 b c4 r8 c | % 75
    c( d) d e16 c g'4 r8 g\For | % 76
    e( f) f( g) g c16 b c8 c' | % 77
    c( b) b( a) a g16 fis g8 b,\Pia | % 78
    a( g) g( fis) fis a,16 g a8 d'\For | % 79
    b( c) c( d) d g16 fis g8 g, | % 80
    f'( e) e( d) d c16 b c8 e,\Pia | % 81
    d( c) c( b) b d g e'16\For g | % 82
    a8 fis16 d b8 d16 fis g8 e16 cis a8 cis16 e | % 83
    fis8 e16 d fis8 e16 cis fis8 d16 b fis'8 d16 a | % 84
    b8 b'16 a b8 g e cis'16 b cis8 a | % 85
    fis( g) g( a) a d16
	\tag cIC {
	    \once \set suggestAccidentals = ##t cis
	}
	\tag cC {
	    cis
	}
        d8 fis,,\Pia | % 86
    d( e) e( fis) fis a16 g a8 a'\For | % 87
    e( fis) fis( g) g cis16 b cis8 e,,\Pia | % 88
    cis( d) d( e) e g16 fis g8 e'\For | % 89
    fis e16 d fis8 e16 cis fis8 d16 b fis'8 d16 a | % 90
    g'1~ | % 91
    g8 r g r fis r b, r | % 92
    ais r r e' d r r d | % 93
    c r r d d4 g~ | % 94
    g8 fis16 e fis8 a d,4 r8 g~ | % 95
    g fis16 e g8 fis16 d g8 d16 b g'8 e16 b | % 96
    g'8 e16 c a8 c16 e fis8 d16 c a8 c16 d | % 97
    f8 d16 b g8 b16 d e8 d16 c e8 d16 b | % 98
    e8 c16 a e'8 c16 g e'8 c16 a fis8 a16 c | % 99
    d8 b16 g e8 g16 b c8 a16 fis d8 fis16 a | % 100
    b8( c) c( d) d g16 fis g8 d,\Pia | % 101
    g,( a) a( b) b d16 c d8 d'\For | % 102
    a'4 r8 d, b'4 r8 d, | % 103
    e( fis) fis( g) a16 g fis e d8 d | % 104
    c'( b) b( a) a g16 fis g8 b,16\Pia g | % 105
    a8( g) g( fis) fis d16 c d g b\For d | % 106
    f8( e) e c16 g e'8( d) d b16 fis | % 107
    d'8( c) c b16 a c8 b16 g c8 a16 fis | % 108
    c'8 g16 e c'8 fis,16 d b'8( a) a( g) | % 109
    g4 r8 b c( b) b( a) | % 110
    a4 r8 c d( c) c( b) | % 111
    b1~ | % 112
    b4 a2 g8 fis | % 113
    d' e16( d) c( b\cCSC a\cCSO g) g8 fis16 e g8 f16 d | % 114
    g8 e16 c g'8 d16 b a8 d16 fis a8 c16 a | % 115
    b8[ d] d, fis 
        \tag cC {
            g4.\fermata
        }
        \tag cIC {
            g2\fermata
        }
}
>>

 
mvtIvlnII = <<
\mvtItimeline
\relative c'{
    \transposition c
    \clef treble

    b'8 |
    g( a) a( b) b d16 c d8 b | % 1
    g( a) a( b) b d16 c d8 b | % 2
    a c16 b c8 a b d16 c d8 b | % 3
    g( a) a( b) d,4 r8 a' | % 4
    a'( g) g( fis) fis4 r8 g, | % 5
    a( g) g( fis) fis4 r8 d' | % 6
    d( c) c g16 e c'8( b) b fis16 d | % 7
    b'8( a) a e16 c a'8( g) g( fis) | % 8
    fis( e) e( d) d( fis) fis( b,) | % 9
    b4 r8 g' fis( g) g( a) | % 10
    a4 r8 a d,( fis) fis( g) | % 11
    g1~ | % 12
    g8[( c]) c( a) a[( d]) d( fis,) | % 13
    e e d d d4 r8 g | % 14
    e4 r8 g a4 r8 a | % 15
    g[ g] g d d4 r | % 16
    R1*6 | % 
    r2 r4 r8 a'\f | % 23
    g( a) a( b) b d16 c d8 r | % 24
    r2 r4 r8 b\f | % 25
    fis( g) g( a) a fis'16 e fis8 r | % 26
    r2 r4 r8 fis,\f | % 27
    g1~ | % 28
    g8 r g r fis r b r | % 29
    a r c r fis, r a r | % 30
    b r r dis b r r cis | % 31
    a r r b g4 a~ | % 32
    a g2 fis4 | % 33
    g g g r8 g | % 34
    g4 g fis r8 a | % 35
    g( a) a( b) b d16 c d8 r | % 36
    r2 r4 r8 b\f | % 37
    a c16 b c8 a b d16 c d8 b | % 38
    g( a) a( b) d,4 r8 a' | % 39
    a'( g) g( fis) fis4 r8 g, | % 40
    a( g) g( fis) fis4 r8 d' | % 41
    d( c) c g16 e c'8( b) b fis16 d | % 42
    b'8( a) a e16 c a'8( g) g( fis) | % 43
    fis( e) e( d) d( fis) fis( b,) | % 44
    b4 r8 g' fis( g) g( a) | % 45
    a4 r8 a d,( fis) fis( g) | % 46
    g1~ | % 47
    g8[ c] c( a) a[( d]) d( fis,) | % 48
    e e d d d4 r8 g | % 49
    e4 r8 g a4 r8 a | % 50
    g[ g] g d d4 r | % 51
    R1*6 | % 
    r2 r4 r8 a'\f | % 58
    g( a) a( b) b d16 c d8 r | % 59
    r2 r4 r8 b\f | % 60
    fis( g) g( a) a fis'16 e fis8 r | % 61
    r2 r4 r8 fis,\f | % 62
    g1~ | % 63
    g8 r g r fis r b r | % 64
    a r c r fis, r a r | % 65
    b r r dis b r r cis | % 66
    a r r b g4 a~ | % 67
    a g2 fis4 | % 68
    g g g r8 g | % 69
    g4 g fis r8 \tag cIC { <>\Pia } a | % 70
    g( a) a( b) b d16 c d8 \tag cC { <>\Pia } g, | % 71
    g,4 g g r | % 72
    R1*3 | % 
    r2 r4 r8 d'\For | % 76
    c( d) d( e) e g16 \once \set suggestAccidentals = ##t f g8 a' | % 77
    a( g) g( fis) fis4 r | % 78
    r2 r4 r8 b,\f | % 79
    b( a) a( b) b d16 c d8 d, | % 80
    d'( c) c( b) b g g\noBeam r | % 81
    r2 r4 e'\f~ | % 82
    e d2 cis4 | % 83
    d d d r8 d | % 84
    d4 d cis r8 e | % 85
    d( e) e( fis) fis fis16 e fis8 r | % 86
    r2 r4 r8 d\f | % 87
    cis( d) d( e) e g16 fis g8 r | % 88
    r2 r4 r8 cis,\f | % 89
    d1~ | % 90
    d8 r d r cis r fis r | % 91
    e r g r cis, r e r | % 92
    fis r r ais, fis r r gis | % 93
    e r r fis d4 e~ | % 94
    e8 a4 b16 c b4. g8 | % 95
    e fis16 g d8 c d4 e~ | % 96
    e8 d c e d4 c' | % 97
    b d c2~ | % 98
    c1~ | % 99
    c8 b b g16 e b'8( a) a fis16 d | % 100
    g8( a) a( b) b d16 c d8 r | % 101
    r2 r4 r8 b\f | % 102
    d4 r8 a g4 r8 g | % 103
    g( a) a( b) d,4 r8 a' | % 104
    a'( g) g( fis) fis( d) d\noBeam r | % 105
    r2 r4 r8 d\f | % 106
    d( c) c g16 e c'8( b) b fis16 d | % 107
    b'8( a) a e16 c a'8( g) g( fis) | % 108
    fis( e) e( fis) g( dis) dis( e) | % 109
    e4 r8 g fis( g) g( a) | % 110
    a4 r8 a d,( fis) fis( g) | % 111
    g1~ | % 112
    g4 e d4. a'8 | % 113
    b e, fis fis d4 r8 g | % 114
    e4 r8 g a4 r8 a | % 115
    g[ g] g d 
        \tag cC {
            d4.\fermata
        }
        \tag cIC {
            d2\fermata
        }
}
>>

 
mvtIvla = <<
\mvtItimeline
\relative c'{
    \transposition c
    \clef alto

    g'8 |
    d4\cICD d\cICD g8 b16 a b8 g | % 1
    d4\cICD d\cICD g8 b16 a b8 g | % 2
    d4 r8 fis g4 r8 g | % 3
    e\cICSO d\cICSC c\cICSO d\cICSC fis( g) g( a) | % 4
    d,4\cICD d\cICD d\cICD r8 d | % 5
    d4\cICD d\cICD d\cICD r8 b' | % 6
    b4 b a a | % 7
    g g fis8( e) e( d) | % 8
    d( g) g( fis) g( dis) dis( e) | % 9
    e4 r8 b a( d) d( d) | % 10
    d4 r8 d fis( a) a( d,) | % 11
    d4 d e r8 e | % 12
    e4 e d r8 d | % 13
    b c a a b4 r8 d | % 14
    c4 r8 b d4 r8 d | % 15
    \slurDotted d[\cICSO b]\cICSC b\cICSO \slurSolid a\cICSC b4 r | % 16
    R1*6 | % 
    r2 r4 r8 fis'\f | % 23
    d4 d g8 b16 a b8 r | % 24
    r2 r4 r8 d,\f | % 25
    d4 d fis8 c'16 b c8 r | % 26
    r2 r4 r8 d,\f | % 27
    d4 d e r8 b | % 28
    c r g r c r e r | % 29
    fis r a r b r a r | % 30
    fis r r fis e r r e | % 31
    d r r d c4 c~ | % 32
    c b2 a8 d | % 33
    d4 d e r8 e | % 34
    e4 e d r8 d | % 35
    d4 d g8 b16 a b8 r | % 36
    r2 r4 r8 g\f | % 37
    d4 r8 fis g4 r8 g | % 38
    e\cICSO d\cICSC c\cICSO d\cICSC \tag cIC { \once \slurDashed } fis( g) \tag cIC { \once \slurDashed } g( a) | % 39
    d,4\cICD d\cICD d\cICD r8 d | % 40
    d4\cICD d\cICD d\cICD r8 b' | % 41
    b4 b a a | % 42
    g g fis8( e) e( d) | % 43
    d( g) g( fis) g( dis) dis( e) | % 44
    e4 r8 b a( d) d d | % 45
    d4 r8 d fis( a) a( d,) | % 46
    d4 d e r8 e | % 47
    e4 e d r8 d | % 48
    b c a a b4 r8 d | % 49
    c4 r8 b d4 r8 d | % 50
    d[\cICSO b]\cICSC b\cICSO a\cICSC b4 r | % 51
    R1*6 | % 
    r2 r4 r8 fis'\f | % 58
    d4 d \tag cIC d8 \tag cC g8 b16 a b8 r | % 59
    r2 r4 r8 d,\f | % 60
    d4 d fis8 c'16 b c8 r | % 61
    r2 r4 r8 d,\f | % 62
    d4 d e r8 b | % 63
    c r g r c r e r | % 64
    fis r a r b r a r | % 65
    fis r r fis e r r e | % 66
    d r r d c4 c~ | % 67
    c b2 a8 d | % 68
    d4 d e r8 e | % 69
    e4 e d r8 d\Pia | % 70
    d4 d g8 b16 a b8 g | % 71
    g,4 g g r | % 72
    R1*3 | % 
    r2 r4 r8 b\For | % 76
    g4 g c r8 e | % 77
    d4 d d r | % 78
    r2 r4 r8 d\f | % 79
    d4 d g r | % 80
    r r8 f f( e) e\noBeam r | % 81
    r2 r4 g\f~ | % 82
    g fis2 e8 a | % 83
    a4 a b r8 b | % 84
    b4 b a r8 a | % 85
    a4 a a8 a16 g a8 r | % 86
    r2 r4 r8 a\f | % 87
    a4 a a r | % 88
    r2 r4 r8 a\f | % 89
    a4 a b r8 fis | % 90
    g r d r g r b r | % 91
    cis r e r fis, r e r | % 92
    cis r r cis b r r b | % 93
    a r r a g4 b | % 94
    c a b d | % 95
    c8 d16 c d8 fis b, a g a16 b | % 96
    c8 d e c a4 fis' | % 97
    d g g r8 g | % 98
    a1 | % 99
    fis4 g e fis | % 100
    d d g8 b16 a b8 r | % 101
    r2 r4 r8 g\f | % 102
    d4 r8 fis g4 r8 g | % 103
    e\cICSO d\cICSC c\cICSO d\cICSC fis( g) g( a) | % 104
    d,4 d d r | % 105
    r2 r4 r8 g\f | % 106
    g4 g fis fis | % 107
    e e d8( e) e( fis) | % 108
    fis( g) g( a) d,( fis) fis( b,) | % 109
    b4 r8 b a( d) d( d) | % 110
    d4 r8 d fis( a) a( d,) | % 111
    d2 e~ | % 112
    e
	\tag cIC {
	    fis4 g8 a | % 113
	    d,
	}
	\tag cC {
	    fis8 a b a | % 113
	    g8
	}
	c,16 b a8 d b4 r8 d | % 114
    c4 r8 b d4 r8 d | % 115
    d[\cICSO b]\cICSC b\cICSO a\cICSC 
        \tag cC {
            b4.\fermata
        }
        \tag cIC {
            b2\fermata
        }
}
>>


mvtIsop = <<
\mvtItimeline
\relative c'{
    \transposition c

    \autoBeamOff

    r8 |
    R1*19 | % 
    \barNumberCheck # 20
    r2 d | % 20
    g a | % 21
    b c | % 22
    d2. c4 | % 23
    b1 | % 24
    R1*7 | % 
    r2 e | % 32
    d c | % 33
    b b | % 34
    a1 | % 35
    g | % 36
    R1*18 | % 
    r2 d | % 55
    g a | % 56
    b c | % 57
    d2. c4 | % 58
    b1 | % 59
    R1*7 | % 
    r2 e | % 67
    d c | % 68
    b b | % 69
    a1 | % 70
    g | % 71
    R1*4 | % 
    r2 d' | % 76
    e e | % 77
    a, r | % 78
    r a | % 79
    d d | % 80
    g, r | % 81
    r b | % 82
    a g | % 83
    fis fis | % 84
    e1 | % 85
    d | % 86
    R1*7 | % 
    r2 d' | % 94
    c b | % 95
    a b | % 96
    a1 | % 97
    g1 | % 98
    R1*17 | % 
    r2 \tag cC { r4. } \tag cIC { r2\fermata }
}
>>

mvtIsopranoLyrics = \new Lyrics \lyricmode {
    Was Gott tut, das ist wohl -- ge -- tan,
    es bleibt ge -- recht sein Wil -- le;
    wie er fängt mei -- ne Sa -- chen an,
    will ich ihm hal -- ten stil -- le.
    Er ist mein Gott,
    der in der Not
    mich wohl weiß zu er -- hal -- ten;
    drum laß ich ihn nur wal -- ten.
}
 

mvtIalto = <<
\mvtItimeline
\relative c'{
    \transposition c

    \autoBeamOff

    r8     R1*21 | % 
    r4 g' g g | % 22
    g g
	\tag cIC {
	    fis8[( e]) d[ a'8] | % 23
	}
	\tag cC {
	    fis8( d4) a'8 | % 23
	}
    g1 | % 24
    R1*7 | % 
    r2 r4 a~ | % 32
    a g2 fis4 | % 33
    g1~ | % 34
    g4 g fis( d) | % 35
    d1 | % 36
    R1*20 | % 
    r4 g g g | % 57
    g g
	\tag cIC {
	    fis8[ e] d[( a'8]) | % 58
	}
	\tag cC {
	    fis8( d4) a'8 | % 58
	}
    g1 | % 59
    R1*7 | % 
    r2 r4 a~ | % 67
    a g2 fis4 | % 68
    g1~ | % 69
    g4 g fis( d) | % 70
    d1 | % 71
    \tag cIC {
	R1*5 | % 
    }
    \tag cC {
	R1*4 | % 
	r2 r4 b' | % 76
    }
    r4 c g
	\tag cIC {
	    e | % 77
	}
	\tag cC {
	    e8[ a] | % 77
	}
    fis4 r r2 | % 78
    \tag cIC {
	R1 | % 
    }
    \tag cC {
	r2 r4 fis | % 
    }
    r4
	\tag cIC {
	    c'8[( b]) b4
	}
	\tag cC {
	    fis8[( g]) g[( b])
	}
	b8[\cCSO g]\cCSC | % 80
    g2 r | % 81
    r r4 g | % 82
    g fis fis e | % 83
    d1~ \melisma | % 84
    d2 cis4\cICSO a\cICSC \melismaEnd | % 85
    a1 | % 86
    R1*7 | % 
    r2 r4 g' | % 94
    e d d g | % 95
    \autoBeamOn e8 \melisma fis16 g d8 c d4 e~ | % 96
    e8 d c e d2 \melismaEnd | % 97
    d r | % 98
    R1*17 | % 
    r2 \tag cC { r4. } \tag cIC { r2\fermata }
}
>>

mvtIaltoLyrics = \new Lyrics \lyricmode {
    Was Gott tut, das ist wohl -- ge -- tan,
    es __ bleibt ge -- recht __ sein Wil -- le;
    wie er fängt mei -- ne Sa -- chen an,
    will __ ich ihm hal -- ten stil -- le.
    \tag cIC { Er } \tag cC { Er, er } ist mein Gott,
    \tag cC { der, } der in der Not
    mich wohl weiß zu er -- hal -- ten;
    drum laß ich ihn nur wal -- ten.
}
 

mvtIten = <<
\mvtItimeline
\relative c{
    \transposition c

    \autoBeamOff

    r8 |
    R1*21 | % 
    r4 d' c e | % 22
    d b a4. d8 | % 23
    d1 | % 24
    R1*7 | % 
    r2 r4 c~ | % 32
    c b2 b8[( e]) | % 33
    d2 e | % 34
    e \melisma d4. a8 \melismaEnd | % 35
    b1 | % 36
    R1*20 | % 
    r4 d c e | % 57
    d b a4. d8 | % 58
    d1 | % 59
    R1*7 | % 
    r2 r4 c~ | % 67
    c b2 a8[( d]) | % 68
    d2 e | % 69
    e\cICSO \melisma d4. a8\cICSC \melismaEnd | % 70
    b1 | % 71
    \tag cIC {
	R1*5 | % 
    }
    \tag cC {
	R1*4 | % 
	r2 r4 g' | % 76
    }
    r4 g, c
	\tag cIC {
	    g | % 77
	}
	\tag cC {
	    g8[ e'] | % 77
	}
    d4 r r2 | % 78
    \tag cIC {
	R1 | % 
    }
    \tag cC {
	r2 r4 d | % 
    }
    r4 a'8[\cICSO d,]\cICSC g4 d | % 80
    c2 r | % 81
    r r4
	\tag cIC {
	    e~ | % 82
	    e d2 cis4 | % 83
	    a2 b | % 84
	    b \melisma a4. e8 \melismaEnd | % 85
	}
	\tag cC {
	    e'4 | % 82
	    e8 a, d4~ d8[ g,] a4 | % 83
	    a2 \melisma b~ | % 84
	    b a4. e8 \melismaEnd | % 85
	}
    fis1 | % 86
    R1*7 | % 
    r2 r4 b | % 94
    c a b d | % 95
    \autoBeamOn c8 \melisma d16 c d8 fis b, a g a16 b | % 96
    c8 d e c a2 \melismaEnd | % 97
    b r | % 98
    R1*17 | % 
    r2 \tag cC { r4. } \tag cIC { r2\fermata }
}
>>

mvtItenorLyrics = \new Lyrics \lyricmode {
    Was Gott tut, das ist wohl -- ge -- tan,
    es __ bleibt ge -- recht sein Wil -- le;
    wie er fängt mei -- ne Sa -- chen an,
    will __ ich ihm hal -- ten stil -- le.
    \tag cIC { Er } \tag cC { Er, er } ist mein Gott,
    \tag cC { der, } der in der Not
    mich __ wohl weiß zu er -- hal -- ten;
    drum laß ich ihn nur wal --  ten.
}
 

mvtIbasso = <<
\mvtItimeline
\relative c {
    \transposition c
   \clef bass

   \autoBeamOff

    r8 |
    R1*21 | % 
    r4 g' e c | % 22
    \tag cIC {
	b8[ a b] c
    }
    \tag cC {
	b8[( a]) b[( c])
    }
	d4 d | % 23
    g,1 | % 24
    R1*7 | % 
    r2 r4 r8 fis' | % 32
    b[( g]) g[( e]) a[( fis]) fis[( d]) | % 33
    g[\cCSO fis]\cCSC fis e e[\cCSO d]\cCSC d[\cCSO c]\cCSC | % 34
    c4 r8 a d2 | % 35
    g,1 | % 36
    R1*20 | % 
    r4 g' e c | % 57
    b8[\cCSO a]\cCSC b[\cCSO c]\cCSC d4 d | % 58
    g,1 | % 59
    R1*7 | % 
    r2 r4 r8 fis' | % 67
    \tag cIC {
	b2 a | % 68
    }
    \tag cC {
	b4. e,8 a4. d,8 | % 68
    }
    g4( fis) e\cICSO d\cICSC | % 69
    \tag cIC {
	c2
    }
    \tag cC {
	c4. a8
    }
    d2 | % 70
    g,1 | % 71
    \tag cIC {
	R1*5 | % 
    }
    \tag cC {
	R1*4 | % 
	r2 r4 g' | % 76
    }
    r4 g e c | % 77
    d2 r | % 78
    \tag cIC {
	R1 | % 
    }
    \tag cC {
	r2 r4 d | % 
    }
    r4 d b8[\cCSO g]\cCSC g[\cCSO b]\cCSC | % 80
    c2 r | % 81
    r r4 r8 cis | % 82
    \tag cIC {
	fis[( d]) d[ b] e[ cis] cis[ a] | % 83
	\autoBeamOn d \melisma cis cis b b a a g | % 84
	g2 a \autoBeamOff \melismaEnd | % 85
    }
    \tag cC {
	fis'4. b,8 e4. a,8 |
	d4 \melisma cis b a |
	g2 a \melismaEnd | % 85
    }
    d1 | % 86
    R1*7 | % 
    r2 r4 g8[\cCSO e]\cCSC | % 94
    a4 fis8[\cCSO d]\cCSC g4 b, | % 95
    \autoBeamOn c8 \melisma c' b a g fis e d | % 96
    c b c a d c d4 \melismaEnd | % 97
    \tag cIC {
	g,1 | % 98
    }
    \tag cC {
	g2 r | % 98
    }
    R1*17 | % 
    r2 \tag cC { r4. } \tag cIC { r2\fermata }
}
>>

mvtIbassLyrics = \new Lyrics \lyricmode {
    Was Gott tut, das __ ist wohl -- ge -- tan,
    es bleibt ge -- recht sein Wil -- le,
    es bleibt ge -- recht sein Wil -- le;
    wie er fängt mei -- ne Sa -- chen an,
    will ich ihm hal -- ten
	\tag cC {
	    stil --  le,
	    ihm hal -- ten stil --  le.
	}
	\tag cIC {
	    stil -- _ __ le.
	}
    \tag cIC { Er } \tag cC { Er, er } ist mein Gott,
    \tag cC { der, } der in der Not
    mich wohl weiß zu er -- hal -- ten;
    drum laß ich ihn nur wal -- ten.
}
 

mvtIbc = <<
\mvtItimeline
\relative c {
    \transposition c
    \clef bass

    g'8 |
    g,4\cICD g\cICD g\cICD r8 g' | % 1
    g,4\cICD g\cICD g\cICD r8 g' | % 2
    fis4 r8 d g4 r8 g, | % 3
    c\cICSO b\cICSC a\cICSO g\cICSC d'( e) e( fis) | % 4
    \tag cIC {
        fis4 r8 g c( b) b( g) | % 5
        fis4 r8 g, c( b) b( a) | % 6
    }
    \tag cC {
        fis'8 r8 g d c'( b) b( d) | % 5
        fis,8 r8 g c, c( b) b( d) | % 6
    }
    g,4\cICD c\cICD fis,\cICD b\cICD | % 7
    e, a d, d | % 8
    d r8 d' g( fis) fis( e) | % 9
    e4 r8 e a( g) g( fis) | % 10
    fis4 r8 fis b( a) a( g) | % 11
    g( fis) fis( e) e( d) d( c) | % 12
    c\cICSO\cCD a'\cICSC\cCD a\cICSO\cCD fis\cICSC\cCD fis\cICSO\cCD d\cICSC\cCD d\cICSO\cCD b\cICSC\cCD | % 13
    e[\cICSO c]\cICSC d d, g( a) a( b) | % 14
    c( d) d( e) fis,4 r8 fis' | % 15
    g b,16 c d8 d, g4 g\Pia | % 16
    g r8 g' g,4 g | % 17
    g r8 g' g,4 g | % 18
    d r8 d' d,4 d | % 19
    d r8 \tag cIC { <>\For } d' d( c) c( b) | % 20
    b( a) a( g) fis( e) e( d) | % 21
    g( g') g( fis) e( d) d( c) | % 22
    b( a) b( c) d4 r8 \tag cC <>\For \tag cIC <>\f d | % 23
    g,4\cICD g\cICD g\cICD r | % 24
    r2 r4 r8 g\f | % 25
    d'4\cICD d\cICD d\cICD r | % 26
    r2 r4 r8 d\f | % 27
    g( fis) fis( e) e( d) d( c) | % 28
    c( b) b( a) a( g) g( fis) | % 29
    fis'( e) e( dis) dis( cis) cis( b) | % 30
    b\cICSO\cCD dis\cICSC\cCD dis\cICSO\cCD b\cICSC\cCD e\cICSO cis\cICSC cis\cICSO a\cICSC | % 31
    d\cICSO b\cICSC b\cICSO g\cICSC c\cICSO a\cICSC a\cICSO fis\cICSC | % 32
    b\cICSO g\cICSC g\cICSO e\cICSC a\cICSO fis\cICSC fis\cICSO d\cICSC | % 33
    g( fis) fis( e) e( d) d( c) | % 34
    \tag cC {
	c-. c'-. c-. a-.
    }
    \tag cIC {
        <c, \tweak font-size #-3 c'>8( c') c( a)
    }
	d4 r8 d, | % 35
    g4 g g r | % 36
    r2 r4 r8 g'\f | % 37
    fis4 r8 d g4 r8 g, | % 38
    c\cICSO b\cICSC a\cICSO g\cICSC d'( e) e( fis) | % 39
    \tag cIC {
        fis4 r8 g c( b) b( g) | % 40
        fis4 r8 g, c( b) b( a) | % 41
    }
    \tag cC {
        fis'8 r g e c'( b) b( d) | % 40
        fis,8 r g c, c( b) b( d) | % 41
    }
    g,4\cICD c\cICD fis,\cICD b\cICD | % 42
    e, a d, d | % 43
    d r8 d' g( fis) fis( e) | % 44
    e4 r8 e a( g) g( fis) | % 45
    fis4 r8 fis b( a) a( g) | % 46
    g( fis) fis( e) e( d) d( c) | % 47
    c\cICSO\cCD a'\cICSC\cCD a\cICSO\cCD fis\cICSC\cCD fis\cICSO\cCD d\cICSC\cCD d\cICSO\cCD b\cICSC\cCD | % 48
    e[\cICSO c]\cICSC d\cICSO d,\cICSC g( a) a( b) | % 49
    c( d) d( e) fis,4 r8 fis' | % 50
    g b,16 c d8 d, g4 g\Pia | % 51
    g r8 g' g,4 g | % 52
    g r8 g' g,4 g | % 53
    d r8 d' d,4 d | % 54
    d r8 d' d( c) c( b) | % 55
    b( a) a( g) fis( e) e( d) | % 56
    g( g') g( fis) e( d) d( c) | % 57
    b( a) b( c) d4 r8 d\For | % 58
    g,4\cICD g\cICD g\cICD r | % 59
    r2 r4 r8 g | % 60
    d'4\cICD d\cICD d\cICD r | % 61
    r2 r4 r8 d | % 62
    g( fis) fis( e) e( d) d( c) | % 63
    c( b) b( a) a( g) g( fis) | % 64
    fis'( e) e( dis) dis( cis) cis( b) | % 65
    b\cICSO\cCD dis\cICSC\cCD dis\cICSO\cCD b\cICSC\cCD e\cICSO cis\cICSC cis\cICSO a\cICSC | % 66
    d\cICSO b\cICSC b\cICSO g\cICSC c\cICSO a\cICSC a\cICSO fis\cICSC | % 67
    b\cICSO g\cICSC g\cICSO e\cICSC a\cICSO fis\cICSC fis\cICSO d\cICSC | % 68
    g( fis) fis( e) e( d) d( c) | % 69
    \tag cC {
	c\cICSO\cCD c'\cICSC\cCD c\cICSO\cCD a\cICSC\cCD
    }
    \tag cIC {
	<< { \voiceThree c\noBeam } { \oneVoice \normalsize c,[\cICSO\cCD c'\cICSC\cCD c\cICSO\cCD a]\cICSC\cCD } >>
    }
	d4 r8 \tag cIC { <>\Pia } d, | % 70
    g4 g g r | % 71
    R1 | % 
    r4 r8 \tag cC { <>\Pia } c' c,4 c | % 73
    c r8 c' c,4 c | % 74
    g r8 g' g,4 g | % 75
    g r8 \tag cIC { <>\For } g' g,\cICSO b\cICSC b\cICSO \tag cC { <>\For } g\cICSC | % 76
    c4\cICD c\cICD c8( b) b( a) | % 77
    d4 r8 d c( b) b( g) | % 78
    fis r g r d\cICSO\cCD d'\cICSC\cCD d\cICSO\cCD b\cICSC\cCD | % 79
    \tag cIC {
	g4 g g r8 b | % 80
    }
    \tag cC {
	b d d b b g g b | % 80
    }
    c4 c c r8 c | % 81
    b r c r g g' e cis | % 82
    fis\cICSO d\cICSC d\cICSO b\cICSC e\cICSO cis\cICSC cis\cICSO a\cICSC | % 83
    d( cis) cis( b) b( a) a( g) | % 84
    g\cICSO\cCD g'\cICSC\cCD g\cICSO\cCD e\cICSC\cCD a4 r8 a, | % 85
    d4 d d r | % 86
    r2 r4 r8 fis | % 87
    a4 a a r | % 88
    r2 r4 r8 a | % 89
    d( cis) cis( b) b( a) a( g) | % 90
    g( fis) fis( e) e( d) d( cis) | % 91
    cis( b) b( ais) ais( gis) gis( fis) | % 92
    fis\cICSO\cCD ais\cICSC\cCD ais\cICSO\cCD fis\cICSC\cCD b\cICSO\cCD gis\cICSC\cCD gis\cICSO\cCD e\cICSC\cCD | % 93
    a\cICSO fis\cICSC fis\cICSO d\cICSC g4\cICD e'\cICD | % 94
    a,\cICD fis'\cICD b,\cICD g'\cICD | % 95
    c,8( c') b( a) g( fis) e( d) | % 96
    c\cICSO b\cICSC c\cICSO a\cICSC d\cICSO c\cICSC d\cICSO d,\cICSC | % 97
    \tag cIC {
	g4 g c r8 b | % 98
	a( g) g( fis)
    }
    \tag cC {
	g a b g c d c b | % 98
	a b a g
    }
	fis\cICSO a'\cICSC a\cICSO fis\cICSC | % 99
    b\cICSO g\cICSC g\cICSO e\cICSC a\cICSO fis\cICSC fis\cICSO d\cICSC | % 100
    g,4\cICD g\cICD g\cICD r | % 101
    r2 r4 r8 g'\f | % 102
    fis4 r8 d g4 r8 g, | % 103
    c\cICSO b\cICSC a\cICSO g\cICSC d'( e) e( fis) | % 104
    \tag cIC {
	fis4 r8 g c( b) b( g) | % 105
	fis4 r8 g, c( b) b( a) | % 106
    }
    \tag cC {
	fis'8 r g d c'( b) b( d) | % 105
	fis,8 r g c, c( b) b( d) | % 106
    }
    g,4\cICD c\cICD fis,\cICD b\cICD | % 107
    e,\cICD a\cICD d,\cICD d\cICD | % 108
    d r8 d' g( fis) fis( e) | % 109
    e4 r8 e a( g) g( fis) | % 110
    fis4 r8 fis b( a) a( g) | % 111
    g( fis) fis( e) e( d) d( c) | % 112
    c\cICSO\cCD a'\cICSC\cCD a\cICSO\cCD fis\cICSC\cCD fis\cICSO d\cICSC d\cICSO b\cICSC | % 113
    b\cICSO c\cICSC d\cICSO d,\cICSC g( a) a( b) | % 114
    c( d) d( e) fis,4 r8 fis' | % 115
    g b,16 c d8 d, 
        \tag cC {
            g4.\fermata
        }
        \tag cIC {
            g2\fermata
        }
}
>>

mvtIfigs = <<
\mvtItimeline
\figuremode {
    % p279
    s8 |
    s4 <7 4 2> \tag cIC <8 5> \tag cC <5 3> s |
    s <7 4 2> \tag cIC <5 3> \tag cC <8 3> s |
    <6>1 |
    s4 <6> s <7>8 
        \tag cC <[6]>8
        \tag cIC s8
        |

    % p280
    <6 5>4 s <6 4 2> <6> |
    \tag cIC { <6 5>4 s } \tag cC { <6 5>4. <6 5>8 } <4 2>4 <6> |
    <7!> <7> <7> <7> |
    <7> <7>
        \tag cC {
            <7> s |
            <7>
        }
        \tag cIC {
            <7 5 3> <7 4 2> |
            <7 3 8>
        }
        s s8 <6\\> s4 |

    % 281
    s s <6> s |
    <6> s <5> <6> |
    s
        \tag cC {
            <4 2> <5> <6 4 2> |
        }
        \tag cIC {
            <6 4 2> s s |
        }
    <7> <5 3> <6>
        \tag cC <6 5>
        \tag cIC s
        |
    s8 <6>
        \tag cC {
            <8> <7> s4 <7> |
        }
        \tag cIC {
            <5 3>8 s s4 <6!> |
        }

    % 282
    \tag cC {
        s <6 4> <6 5>4. \once \bassFigureExtendersOn 8 |
        s <6>
    }
    \tag cIC {
        s4 <7 4 2>8 <[5 3]> <6 5>4 s |
        s
    }
        <6 4>8 <5 3> s2 |
    s1 |
    s1 |

    % 283
    s2 <6 4> |
    \tag cC {
        <7>4 s8 <6 4> <5 3>4 <4 2> |
        <6> <\FBx> <6> <6 4 2> |
        s s <6> <7> |
    }
    \tag cIC {
        <5 3>4 s s <6 4 2> |
        <6> <7 4 2> <6> <7 4 2> |
        s2 <6>4 <7 4 2> |
    }

    % 284
    <6> s <8> s8 <7> |
    s4 <7 4 2> <8 5 3> s |
    s1 |
    <5 3>4 <6 4> <7 5> s |

    % 285
    s1 |
    s4 <6 4 2>
        \tag cC <5>
        \tag cIC <5 3>
        <6 4 2> |
    \tag cC <5>
    \tag cIC s
        <6 4 2>
        \tag cIC { <6 5> <6 4> }
        \tag cC { <5 3> <6 4 2> } |
    \tag cC <6 5>
    \tag cIC <7>
        <6 4> <6 5> <6 4 3> |

    % 286
    \tag cC {
        <7 _+> <6 5> <5> <6 5> |
        <_!> <6 5!> <5> s |
        \tag cIC <7>
        \tag cC { <7>8 <8> }
            <6 5>4 <7> <6 5> |
        s <6 4 2> <5> <6 4 2> |
    }
    \tag cIC {
        <7 _+>4 s <9> <5> |
        <_! 9> <5!> <5> s |
        <9 7> <[5 3]> <9 7> <5> |
        s2 <5> |
    }

    % 287
    <6 5>4 s s s |
    \tag cC {
        s <8 4 2> <\FBx 5 3> s |
    }
    \tag cIC {
        s1
    }
    s1 |
    <6> |

    % 288
    s4 <6> s
        \tag cIC { <7>8 <[6]> }
        \tag cC <7 5>4 |
    <6 5>4 s
        \tag cIC <6 4 2>
        \tag cC <4 2>
        <6> |
    <6 5> s <6 4 2> <6> |
    <7!> <7> <7> <7> |
    <7> <7>
        \tag cC <7 3>
        \tag cIC <7 5 3>
        <7 4 2> |

    % 289
    <7 5 3> s s <6\\> |
    s s <6> s |
    <6> s <5> <6> |
    s <6 4 2>
        \tag cC {
            <5> <6 4 2> |
        }
        \tag cIC {
            s2 |
        }

    % 290
    <7>4
        \tag cIC <5 3>
        \tag cC s
        <6>
        \tag cC {
            <6 5> |
            s8 <6> <8> <7> s4 <7> |
            s4 <6 4> <6 5>4. <\FBx>8 |
            s <6> <6 4> <5 3> s2 |
        }
        \tag cIC {
            s4 |
            s8 <6> <5 3> s s4 <6!> |
            s4 <7 4 2>8 <[5 3]> <6 5>4 s |
            s4 <6 4>8 <5 3> s2 |
        }

    % 291
    s1 |
    s1 |
    s2 <6 4>4
        \tag cC { \once \bassFigureExtendersOn q }
        \tag cIC s |
    \tag cC {
        <7> s8 <6 4> <5 3>4 <4 2> |
        % 292
        <6>4. \once \bassFigureExtendersOn <6>8 <6>4 <6 4 2> |
    }
    \tag cIC {
        <5 3>4 s s <6 4 2> |
        <6> <7 4 2> <6> <7 4 2> |
    }

    s2 <6>4 <7 4 2> |
    <6> s <8> s8 <7> |
    s4 <7 4 2> <[8] 5 3> s |

    % 293
    s1 |
    <5 3>4 <6 4> <7 5> s |
    s1 |
    s4
        \tag cC { <4 2> <5> }
        \tag cIC { <6 4 2> <5 3> }
        <6 4 2> |

    % 294
    \tag cC {
        <5> <6 4 2> <5> <6 4 2> |
    }
    \tag cIC {
        s <6 4 2> <6 5> <6 4> |
    }
    \tag cC { <[7] 5> <6 4 2> }
    \tag cIC { <7> <6 4> }
        <6 5> <6 4 3> |
    <7 _+> <6 5>
        \tag cC {
            s <6 5> |
            <_!> <6 5!> s s |
            <7> <6 5> <7> <6 5> |
            s <6 4 2> <5> <6 4 2> |
        }
        \tag cIC {
            <9> <5> |
            <_! 9> <5!> <5> s |
            <9 7> <5 3> <9 7> <5> |
            s2 <5> |
        }

    % 295
    <6 5>4 s s s |
    \tag cC {
        s <4 2> <5 3> s |
    }
    \tag cIC {
        s <4 2> <5 3> s |
    }

    % 296
    s1 |
    s1 |
    s1 |
    s2 <6 4>4 s |

    % 297
    \tag cC {
        <5 3> s8 <[6 4]> <[5 3]> s <6>4 |
    }
    \tag cIC {
        <7! 5>4 s8 <6 4> <[5 3]>4 s |
    }
    s4 s s <6 4 2> |
    \tag cC {
        <5 3> s <6 4 2> <6> |
        <6 5> s s s |
        % 298
        <6>4 <[7 5 3]> <6> <7!> |
        <5 4!> <3> <7 4! 2> s8 <5 3> |
        <6 5!>4 s s <5> |
        <9 7> <8 3> <9 7> <6 5> |
        % 299
        s <6 4 2> <5> <6 4 2> |
    }
    \tag cIC {
        s4 s8 <6 4> <6 4 2>4 <[6]> |
        <6 5> s s s8 <7 5> |
        s4 <[4 2]> <[5 3]> s8 <6 5!> |
        <4! 9>4 <3 8> <7 4! 2>8 <8 5 3> s4 |
        <6 5!> s s <6\\ 5> |
        <9>4 <[5] 3> <9> <3> |
        s2 <5> |
    }

    <6 5>4 s <_+> s |
    s <7\\ 4 2>
        \tag cC <5 3>
        \tag cIC <[5 3]>
        s |
    s2 s4 s8 <6> |

    % 300
    \tag cC {
        <_+>4 <6 4> <7 _+> s |
        s2 s4 s8 <_+> |
        s4 <4 2> <5 3> <6 4 2> |
        <5> <6 4 2> <5 3> <6 4> |
        % 301
        <5> <6 4 2\+> <6 5> <6 4\+ 3> |
        <7 _+> <6 5> s <6 5> |
        <_!> <6 5> <4>8 <3> <7>4 |
        <9>8 <8> <6 5>4 <7>8 <6> s4 |
        % 302
        <6 5>8 <6 4> <7 5>4 s <5> |
        <6 5>4. \once \bassFigureExtendersOn <6 5>8 s4 s |
        <7!> <6 5!> <9>8 <7!> <8>4 |
        s s <7 5> <6 5> |
        % 303
        <7> <5> <9> <[6] 5> |
        s <7 4 2> <5 3> s |
        s1 |
        <6>4 s8 <7> s2 |
    }
    \tag cIC {
        <_+>4 <7 4 2> <_+> s |
        s2 s4 s8 <_+> |
        s4 <6 4 2> <5> <6 4 2> |
        %
        s2 <6\\ 5>4 <6 4> |
        <7>4 <6 4> <6 5> <6> |
        <7 _+> <6 5> <9\\> <6 5> |
        <9>4 <6 5> s <7> |
        <9 7> <6 5> <7> s |
        %
        <6 5>4 <7 3> s s |
        <6 5>2 s |
        <7!> <5> |
        <5> <7> |
        <9>4 <6 5> <9> <6 5> |
        %
        s <7 4 2> <8 5 3> s |
        s1 |
        <6>4 s2. |
    }

    % 304
    s4 <6> s <7> |
    <6 5> s <6 4 2> <6> |
    <6 5> s <6 4 2> <6> |
    <7!> <7> <7> <7> |

    % 305
    <7> <7>
        \tag cC <7 3>
        \tag cIC <7 5 3>
        <7 4 2> |
    \tag cC <7 5 3>
    \tag cIC <7 3 8>
        s s <6\\> |
    s s <6> s |
    <6> s <5>
        \tag cC <6 4 3>
        \tag cIC <6>
        |

    % 306
    s <6 4 2>
        \tag cC <5>
        \tag cIC s
        <6 4 2> |
    <7> <5> <6 5> <6 5> |
    <6>8 <6 5> s4 s
        \tag cC {
            <7> |
            <5> <6 4> <6 5>4. \once \bassFigureExtendersOn <6 5>8 |
        }
        \tag cIC {
            <6!>4 |
            s4 <7 4 2>8 <[5 3]> <6 5>4 s |
        }
    \barNumberCheck # 116
    s8 <6> <6 4> <5 3> s4. \tag cIC { s8 | }
}
>>


mvtIbreaksBGA = <<
\mvtItimeline
{
    \tag cC {
	% p279 s1
	s8^"BGA breaks left in"
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p280 s1
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p281 s1
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p282 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p283 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p284 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p285 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p286 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p287 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p288 s1
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p289 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p290 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p291 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p292 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p293 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p294 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p295 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p296 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p297 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p298 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p299 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p300 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p301 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p302 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p303 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p304 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p305 s1
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p306 s1
	\repeat unfold 4 { s1\noBreak } |
	s2 s4.
	\bar "|."
    }

    \tag cIC {
	s8^"BGA breaks left in" |
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	\repeat unfold 5 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p257
	\repeat unfold 5 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p258
	\repeat unfold 5 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p259
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p260
	\repeat unfold 5 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p261
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p262
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p263
	\repeat unfold 5 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 5 { s1\noBreak } | \pageBreak

	% p264
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \pageBreak

	% p265
	\repeat unfold 4 { s1\noBreak } | \break\noPageBreak
	\repeat unfold 4 { s1\noBreak } | \bar "|."
}

}
>>

mvtIbreaksNBA = <<
\mvtItimeline
{
    <>^"NBA Breaks left in"
    \tag cIC {
        s8\noBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 4 { s1\noBreak | } \break
        \barNumberCheck # 12
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 25
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 31
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 4 { s1\noBreak | } \break
        \barNumberCheck # 45
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 4 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 59
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 4 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 70
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 76
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 82
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 91
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \barNumberCheck # 103
        \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 3 { s1\noBreak | } \break
        \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
        \repeat unfold 4 { s1\noBreak | } \break
        \barNumberCheck # 117
    }
    \tag cC {
        s8\noBreak \repeat unfold 3 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 8
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 16
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \barNumberCheck # 23
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 30
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 38
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 46
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 54
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 61
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 69
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \barNumberCheck # 76
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \barNumberCheck # 82
        \repeat unfold 3 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 89
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 97
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 105
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \repeat unfold 4 { s1\noBreak | } \pageBreak
        \barNumberCheck # 113
        \repeat unfold 3 { s1\noBreak | } s2..
        \barNumberCheck # 116
    }
}
>>
