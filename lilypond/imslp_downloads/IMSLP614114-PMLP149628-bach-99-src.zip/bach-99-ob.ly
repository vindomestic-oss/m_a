\version "2.21.0"

instrument = \markup\center-column{"Oboe (statt" "Oboe d’Amore)"}
pInstr = \markup\center-column{"(Oboe)"}
transpObDAm = c

\include "bach-99-obdam.ly"
