\version "2.21.0"

\layout {
    \context {
	\Score {
	    \override Score.BarNumber.font-size = #3
            \override BarNumber.padding = #3.5
	}
    }

    \context {
	\StaffGroup {
	    \override SystemStartBracket.collapse-height = #4
	}
    }

    \context {
	\GrandStaff {
	    \override SystemStartBrace.collapse-height = #4
	}
    }
}


\paper {
    system-separator-markup = \markup {
        \center-align
        \vcenter \combine
        \beam #3.5 #0.4 #0.72
        \raise #1.4 \beam #3.5 #0.4 #0.72
    }
    % system-separator-markup = \slashSeparator
}
