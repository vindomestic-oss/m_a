\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-6.ily"


\paper {
    % page-breaking = #ly:page-turn-breaking
    % ragged-last-bottom = ##f
    % page-count = 7
    % system-system-spacing = #'((basic-distance . 12) (minimum-distance . 8) (padding . 1) (stretchability . 60))
    % % system-system-spacing #'basic-distance = #25
    % system-system-spacing #'minimum-distance = #15
}

\header {
    instrument = "Viola"
}

\include "bach-99-title.ily"
% \include "bach-paged-title.ily"


% %{
\score { 
    \keepWithTag #'( PARTS cIC KEEPKEYS ) \new Staff = mvtIvla << 
	\mvtIvla
        { s8 | s1*75 | \pageBreak }
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}

% \markup\null\pageBreak
\markup\Tacet{\mvtIIpiece \endash \mvtIIIpiece}
\markup\Tacet{\mvtIVpiece \endash \mvtVpiece}


% %{
\score {
    \new Staff = mvtVIten <<
	\new Voice = mvtVIinstr { \clef C \mvtVIten }
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
