\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-6.ily"


% #(set-global-staff-size 14)

\paper {
    % page-count = #4
    % page-breaking = #ly:page-turn-breaking
}

\header {
    instrument = "Violino I"
}

\include "bach-99-title.ily"
\include "bach-paged-title.ily"

breaksI = <<
\mvtItimeline
{
    \autoPageBreaksOff
    s8 |
    s1*59 |
    \barNumberCheck # 60
    \pageBreak
    s1*57 |
    \barNumberCheck # 117
}
>>


% %{
\score { 
    \keepWithTag #'( PARTS cIC KEEPKEYS ) <<
        \new Dynamics \breaksI

        \new Staff = mvtIvlnI << 
            \stretchHorizontalSpacing #-1.0
            \mvtIvlnI
        >>
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}


\markup\null\pageBreak
\markup\Tacet{\mvtIIpiece \endash \mvtIIIpiece}
\markup\Tacet{\mvtIVpiece \endash \mvtVpiece}


% %{
\score {
    \new Staff = mvtVIsopr <<
	\new Voice = mvtVIinstr \mvtVIsopr
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
