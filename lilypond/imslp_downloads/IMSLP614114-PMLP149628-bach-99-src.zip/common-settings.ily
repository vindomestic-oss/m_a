\version "2.21.0"

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Overrides for default settings
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% shared by approx. all works so put it into common.ly
%
\paper {
    two-sided = ##t
    inner-margin = 12\mm
    outer-margin = 8\mm
    indent = 0

    % ragged-right = ##f        Does not work for partial ossia staves
}


% shared by approx. all works so put it into common.ly
%
\paper {
    % annotate-spacing = ##t
    oddHeaderMarkup = \markup{
	\fill-line {
	    \abs-fontsize #11 {
		\on-the-fly #print-page-number-check-first
		    \fromproperty #'header:instrument
		\on-the-fly #print-page-number-check-first
		    \line { \fromproperty #'header:composer — \fromproperty #'header:title " " \fromproperty #'header:opus }
		\on-the-fly #print-page-number-check-first
		    \fromproperty #'page:page-number-string
	    }
	}
    }

    evenHeaderMarkup = \markup{
	\fill-line {
	    \abs-fontsize #11 {
		\on-the-fly #print-page-number-check-first
		    \fromproperty #'page:page-number-string
		\on-the-fly #print-page-number-check-first
		    \line { \fromproperty #'header:composer — \fromproperty #'header:title " " \fromproperty #'header:opus }
		\fromproperty #'header:instrument
	    }
	}
    }

    bookTitleMarkup = \markup {
	\column {
	    \fill-line {
		\large\bold \fromproperty #'header:instrument
		\huge\larger\larger\bold
		\fromproperty #'header:title
		\large\bold \fromproperty #'header:composer
	    }
	    \fill-line {
              ""
	      \large \bold \fromproperty #'header:subtitle
	      \large \bold \fromproperty #'header:opus
	    }
	    \fill-line {
	      \smaller \bold
	      \fromproperty #'header:subsubtitle
	    }
	    \fill-line {
	      \fromproperty #'header:poet
	      \fromproperty #'header:meter
	      \fromproperty #'header:arranger
	    }
	}
    }

    scoreTitleMarkup = \markup {
	\column {
	    \on-the-fly #print-all-headers { \bookTitleMarkup \hspace #1 }
	    % \combine \null \vspace #0.0
	    \huge \larger \bold {
	        \fromproperty #'header:piece
	    }
	    \combine \null \vspace #0.0
	}
    }

}

\layout {

    \context {
        \Score {
            \set quotedCueEventTypes = #'(note-event rest-event tie-event
                                          beam-event tuplet-span-event
                                          dynamic-event articulation-event
                                          slur-event trill-span-event
                                          tremolo-event tremolo-span-event
                                          Override
                                          )

            \override MetronomeMark.font-size = #2.5

            \override BarNumber.font-size = #-0.5
            \override BarNumber.self-alignment-X = #CENTER

            \override BreathingSign.text = \markup\huge\bold{\musicglyph "scripts.rcomma"}
            % \override Score.BreathingSign.text = \markup\huge\bold{,}
            \override BreathingSign.Y-offset = #2.6
        }
    }

    \context GrandStaff {
        % Gould claims a standard GrandStaff is old-fashioned.
        % Bärenreiter and Universal have curly GrandStaff, Sikorski has square.
        % Other publishers?
        % \set systemStartDelimiter = #'SystemStartSquare
    }

    \context {
        \Score
            figuredBassFormatter = #format-bass-figures
	    \accidentalStyle modern-cautionary
    }

    \context {
	\PianoStaff {
	    \accidentalStyle piano-cautionary
	}
    }

    \context {
	\FiguredBass {
	    % \override BassFigure.font-size = #-1.5
	    \set figuredBassAlterationDirection = #RIGHT
	    \set figuredBassPlusDirection = #RIGHT
            \set figuredBassCenterContinuations = ##t
	}
    }
    \context {
	\Staff {
	    % \override BassFigure.font-size = #-1.5
            \bassFigureStaffAlignmentDown
	    \set figuredBassAlterationDirection = #RIGHT
	    \set figuredBassPlusDirection = #RIGHT
            \set figuredBassCenterContinuations = ##t
	}
    }

    \context {
	\Staff {
	    \override TextScript.font-shape = #'italic

	    \set soloText = "1."
	    \set soloIIText = "2."

	    \extendLV #3

            % see below for merge-rests-engraver
	    % \override RestCollision #'positioning-done = #merge-rests-on-positioning

	    \override AccidentalSuggestion.avoid-slur = #'inside
	}
    }

    \context {
        \Staff
            \consists #merge-rests-engraver
            \consists #merge-mmrests-engraver
            \consists #Parenthesis_on_cautionary_accidentals_purger
    }

    \context {
        \RhythmicStaff
            \consists #merge-rests-engraver
            \consists #merge-mmrests-engraver
    }

    \context {
	\RhythmicStaff {
	    \override TextScript.font-shape = #'italic
	}
    }

    \context {
	\Voice {
	    % \set subdivideBeams = ##t

            \override ParenthesesItem.font-size = #-1
        }
    }

    \context {
	\Voice
            \remove #"Text_spanner_engraver"
            \consists \alternateTextSpannerEngraver

            \override TrillPitchAccidental.avoid-slur = #'inside
    }

    \context {
        \StaffGroup
            \accepts MarkLine
    }

    \context {
        \GrandStaff
            \accepts MarkLine
    }

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % By Schneidy (Pierre Perol-Schneider
    % From http://lists.gnu.org/archive/html/lilypond-user/2014-05/msg00025.html
    \context {
        \Staff {
            \set strokeFingerOrientations = #'(left)
        }
    }

    \context {
        \CueVoice {
            \override TextScript.font-size = #3
        }
    }

    \compressFullBarRests
}


\paper {
    markup-system-spacing = #'((basic-distance . 4.0)
                              (min-distance . 3.0)
                              (padding . 1.0)
                              (stretchability . 80))
    score-markup-spacing = #'((basic-distance . 5)
                              (minimum-distance . 3)
                              (padding . 2)
                              (stretchability . 90))
    markup-markup-spacing = #'((basic-distance . 3)
                              (minimum-distance . 2)
                              (padding . 1)
                              (stretchability . 60))
    system-system-spacing = #'((basic-distance . 6)
                              (minimum-distance . 4)
                              (padding . 2)
                              (stretchability . 90))
    top-markup-spacing = #'((basic-distance . 4)
                              (minimum-distance . 2)
                              (padding . 2)
                              (stretchability . 50))
    top-system-spacing = #'((basic-distance . 4)
                              (minimum-distance . 2)
                              (padding . 2)
                              (stretchability . 50))

    % bottom-margin = #5.0
    last-bottom-spacing = #0.0
}

\layout {
    \context {
        \RhythmicStaff
            \override VerticalAxisGroup.staff-staff-spacing =
                        #'((basic-distance . 2)
                           (minimum-distance . 1)
                           (padding . 1)
                           (stretchability . 80))
    }
%    \context {
%        \Staff
%            \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
%                         #'((basic-distance . 1)
%                              (minimum-distance 0)
%                              (padding . 20)
%                              (stretchability . 50))
%    }
    \context {
        \Lyrics
            \override VerticalAxisGroup.nonstaff-relatedstaff-spacing =
                         #'((basic-distance . 0.5)
                              (minimum-distance 0)
                              (padding . 0.5)
                              (stretchability . 50))
    }
    \context {
        \StaffGroup
            \override StaffGrouper.staff-staff-spacing =
                         #'((basic-distance . 2)
                              (minimum-distance . 1)
                              (padding . 1)
                              (stretchability . 40))
            \override StaffGrouper.staffgroup-staff-spacing =
                         #'((basic-distance . 3)
                              (minimum-distance . 1)
                              (padding . 2)
                              (stretchability . 60))
    }
    \context {
        \PianoStaff
            \override StaffGrouper.staff-staff-spacing =
                         #'((basic-distance . 3)
                              (minimum-distance . 1)
                              (padding . 2)
                              (stretchability . 35))
            \override StaffGrouper.staffgroup-staff-spacing =
                         #'((basic-distance . 5)
                              (minimum-distance . 3)
                              (padding . 2)
                              (stretchability . 60))
    }
}

% https://lists.gnu.org/archive/html/lilypond-user/2018-09/msg00084.html
%%%  MWE begins
% \version "2.21.0"

\layout {

    \context {
        \Score {
            \override Glissando.breakable = ##t
            \override Glissando.after-line-breaking = ##t

            \override Beam.breakable = ##t

            \override TextSpanner.springs-and-rods = #ly:spanner::set-spacing-rods
            \override TextSpanner.bound-details.left-broken.text = ##f
            \override TextSpanner.bound-details.right-broken.text = ##f
            \override TextSpanner.bound-details.right.padding = #2.0

            \override TrillSpanner.to-barline = ##t
            \override TrillSpanner.bound-details.right.padding = #2.0

            \override Score.TimedSpanner.springs-and-rods = #ly:spanner::set-spacing-rods
        }
    }

    \context {
        \StaffGroup {
            % Avoid stretching of notes to lyrics in Dynamics
            \override LyricText.extra-spacing-width = #empty-interval
        }
    }
    \context {
        \GrandStaff {
            % Avoid stretching of notes to lyrics in Dynamics
            \override LyricText.extra-spacing-width = #empty-interval
        }
    }

    \context {
        \Voice {
            \override Arpeggio.positions = #widen-arp
        }
    }
    \context {
        \Staff {
            \override Arpeggio.positions = #widen-arp
        }
    }
    \context {
        \PianoStaff {
            \override Arpeggio.positions = #widen-arp
        }
    }

    \context {
        \Voice {
            \override Hairpin.minimum-length = #3.0
            % \override Hairpin.to-barline = ##t
            % \override Hairpin.after-line-breaking = ##t
        }
    }

}

% {
%   \override Arpeggio.positions = #widen-arp
%   <c' e' g'>1\arpeggio
% }
%%%  MWE ends

