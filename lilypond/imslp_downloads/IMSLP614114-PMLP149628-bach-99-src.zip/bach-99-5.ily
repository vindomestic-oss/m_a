\version "2.21.0"

\include "common.ily"


mvtVtimeline = {
    \time 4/4
    \key d \major

    s1*51
    \barNumberCheck # 52
    \bar "|."
}


mvtVbreaks = <<
\mvtVtimeline
{
    % 272
    <>^"BGA breaks left in"
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    % 273
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 4 { s1\noBreak }
    \pageBreak

    % 274
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \pageBreak

    % 275
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 3 { s1\noBreak }
    \break\noPageBreak
    \repeat unfold 5 { s1\noBreak }
    \barNumberCheck # 52
}
>>


mvtVbreaksNBA = <<
\mvtVtimeline
{
    <>^"NBA breaks left in"
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\pageBreak
    \barNumberCheck # 13
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\pageBreak
    \barNumberCheck # 22
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\pageBreak
    \barNumberCheck # 32
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\pageBreak
    \barNumberCheck # 40
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 3 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | } \break\pageBreak
    \barNumberCheck # 52
}
>>


mvtVfl = <<
\mvtVtimeline
\relative c'' {
    r4 fis16( d16 cis16 b16) g'8 g8 g8 g8 | % bar 1
    g8( fis8) fis8 fis8 fis8 eis16( fis16) eis16( fis16) eis16( fis16) | % bar 2
    gis16 a16 b8~ b16 gis16( a16 eis16) fis16( g16) a8~ a16 fis16( g16 dis16) | % bar 3
    e16 fis16 g8~ g16 d16( cis16 d16) e16( fis32 g32 fis16) e16 cis8. b16 | % bar 4
    b4 r4 r8 cis16( d16) e8 e8 | % bar 5
    e8 ais,16( b16) ais16( b16) ais16( cis16) cis16( ais16 b8) r4 | % bar 6
    r4 cis16( b16 cis16 a16) fis'8 fis8 fis16( dis16 cis16 b16) | % bar 7
    g'16( dis16 e8) r4 r2 | % bar 8
    R1 | % bar 9
    r4 fis16( d16 cis16 b16) g'8 g8 g8 g8 | % bar 10
    g8 fis16( g16) fis16( g16) fis16( g16) a8 a8 a8 a8 | % bar 11
    a8 gis16( a16) gis16( a16) gis16( ais16) b16( cis32 d32 cis16) b16 ais8. b16 | % bar 12
    b8 fis8 b8 b8 b8 ais16( b16) ais16( b16) ais16( b16) | % bar 13
    cis16( ais16) b8 r4 r2 | % bar 14
    R1 | % bar 15
    r4 e,16( cis16 b16 a16) f'8 f8 f8 f8 | % bar 16
    f16 d16 e8 fis4~ fis8 e16( fis16 g16 dis16 e16 g16 | % bar 17
     cis8) r8 r4 r2 | % bar 18
    r4 fis,16( e16 fis16 b,16) g'8 g8 g8 g8 | % bar 19
    g8[( fis8]) fis8( e8) e8( dis16 cis16) dis16( e16) dis16( e16) | % bar 20
    fis16 e16 fis16 g16 fis16 g16 fis16 a16 g16( dis16 e8) r4 | % bar 21
    R1*2 | % bar 22
    r4 e16( cis16 b16 a16) fis'8 fis8 fis8 fis8 | % bar 24
    f8( e)  e8 e8 es8( d8) d8 d8 | % bar 25
    d8 cis16( d16) cis16( d16) cis16( d16) e16( fis32 g32 fis16) e16 cis8. d16 | % bar 26
    d4 r4 r2 | % bar 27
    R1*2 | % bar 28
    r4 fis8 fis8 fis8 eis16( gis16) b8 b8 | % bar 30
    b8( a8) a8 a8 a8 gis16( bis16) dis8 dis8 | % bar 31
    dis8( cis8) r4 r2 | % bar 32
    r4 e,8 e8 e8 dis16( fis16) a8 a8 | % bar 33
    a8( g8) g8 g8 g8 fis16( ais16) cis8 cis8 | % bar 34
    cis8( b8) fis8 b8 r8 b8 e,8 g8 | % bar 35
    r8 a8 e8 a8 r8 a8 d,8 fis8 | % bar 36
    r8 g8 d8 g8 r8 g8 cis,8 e8 | % bar 37
    r8 fis8 cis8 fis8 r4 fis16( d16 cis16 b16) | % bar 38
    g'8 g8 g8 g8 e16 d16 e16 fis16 e16 fis16 d16 e16 | % bar 39
    fis16 e16 fis16 g16 fis16 g16 e16 fis16 d16 cis16 d16 e16 d16 e16 cis16 d16 | % bar 40
    e16 d16 e16 fis16 e16 fis16 d16 e16 cis16 b16 cis16 d16 cis16 d16 b16 cis16 | % bar 41
    d16 cis16 d16 e16 d16 e16 cis16 d16 e8 fis16 e16 fis8 fis,8 | % bar 42
    r8 b'16 ais16 b8 b,8 r8 ais'16 \once \set suggestAccidentals = ##t gis16 ais8 fis8 | % bar 43
    r2 r8 d16( cis16) e16( dis16) g16( fis16) | % bar 44
    g8 r8 r4 r8 ais16( gis16) cis16( b16) d16( cis16) | % bar 45
    d8 r8 r4 r2 | % bar 46
    r4 fis,16( d16 cis16 b16) g'8 g8 g8 g8 | % bar 47
    g8( fis8) fis8 fis8 fis8 eis16( fis16) eis16( fis16) eis16( fis16) | % bar 48
    gis16 a16 b8~ b16 gis16( a16 eis16) fis16( g16) a8~ a16 fis16( g16 dis16) | % bar 49
    e16 fis16 g8~ g16 d16( cis16 d16) e16( fis32 g32 fis16) e16 cis8. b16 | % bar 50
    b4\fermata r4 r2 | % bar 51
}
>>


mvtVob = <<
\mvtVtimeline
\relative c'' {
    R1 | % bar 1
    r4 cis16( ais16 gis16 fis16) d'8 d8 d8 d8 | % bar 2
    d8( cis8) cis8 cis8 c8( b8) b8 b8 | % bar 3
    b8 ais16( b16) ais16( b16) ais16( b16) cis16( d32 e32 d16) cis16 ais8. b16 | % bar 4
    b8 fis8 b8 b8 b8 ais16( b16) ais16( b16) ais16( b16) | % bar 5
    cis16 d16 e8~ e16 d16( e16 ais,16) fis16( cis'16 d8) r4 | % bar 6
    R1 | % bar 7
    r4 g,16( fis16 g16 e16) cis'8 cis8 cis16( ais16 gis16 fis16) | % bar 8
    fis'16( ais,16 b8) r4 r4 cis16( ais16 gis16 fis16) | % bar 9
    d'8 d8 d8 d8 d8 cis16( d16) cis16( d16) cis16( d16) | % bar 10
    e8 e8 e8 e8 e8 dis16( e16) dis16( e16) dis16( e16) | % bar 11
    fis8 b,16( cis16) \once \slurDashed b16( cis16) \once \slurDashed b16( cis16) d16( e32 fis32 e16) d16 cis8. b16 | % bar 12
    b4 r4 r2 | % bar 13
    r8 fis8 b8 b8 b8 a16( b16) a16( b16) a16( b16) | % bar 14
    c16( a16 b8) r4 r2 | % bar 15
    R1 | % bar 16
    r4 a16( fis16 e16 dis16) c'16( a16 b16 dis16) e8 e8 | % bar 17
    e16 d16 e16 cis16 d8 r8 r2 | % bar 18
    R1 | % bar 19
    r4 b16( a16 b16 e,16) c'8 c8 c8 c8 | % bar 20
    c8( b8) b8 b8 b16( fis16) g8 r4 | % bar 21
    R1 | % bar 22
    r4 a16( fis16 e16 d16) b'8 b8 b8 b8 | % bar 23
    b8( a8) a8 a8 a8 gis16( a16) gis16( a16) gis16( a16) | % bar 24
    b16 cis16 d8~ d16 b16( cis16 gis16) a16 b16 c8~ c16 a16( b16 fis16) | % bar 25
    g16 a16 bes8~ bes16 fis16( e16 fis16) g16( a32 b32 a16) g16 e8.\trill d16 | % bar 26
    d4 r4 r2 | % bar 27
    R1 | % bar 28
    r4 b'8 b8 b8 ais16( cis16) e8 e8 | % bar 29
    e8( d8) d8 d8 d8 cis16( eis16) gis8 gis8 | % bar 30
    gis8( fis8) r8 fis8 fis8[( dis8] bis8) gis'8 | % bar 31
    gis8( e8 cis8\noBeam) r8 r2 | % bar 32
    R1 | % bar 33
    r4 b8 b8 b8 ais16( cis16) e8 e8 | % bar 34
    e8( d8) r8 fis8 b,8-. e8-. r8 b8 | % bar 35
    a8-. cis8-. r8 e8 a,8-. d8-. r8 a8 | % bar 36
    g8-. b8-. r8 d8 g,8-. b8-. r8 cis8 | % bar 37
    fis,8-. ais8-. cis16( ais16 \once \set suggestAccidentals = ##t gis16 fis16) d'8 d8 d8 d8 | % bar 38
    b16 a16 b16 cis16 b16 cis16 a16 b16 cis16 b16 cis16 d16 cis16 d16 b16 cis16 | % bar 39
    a16 g16 a16 b16 a16 b16 g16 a16 b16 a16 b16 cis16 b16 cis16 a16 b16 | % bar 40
    cis16 b16 cis16 d16 cis16 d16 b16 cis16 ais16 \once \set suggestAccidentals = ##t gis16 ais16 b16 ais16 b16 gis16 ais16 | % bar 41
    b16 ais16 b16 cis16 b16 cis16 ais16 b16 cis4 r8 fis16 e16 | % bar 42
    fis8 fis,8 r8 g'16 fis16 g8 cis,8 r4 | % bar 43
    r2 r8 \once \slurDashed fis,16( e16) \once \slurDashed b'16( a16) \once \slurDashed b16( c16) | % bar 44
    b8 r8 r4 r8 fis'16( e16) fis16( gis16) b16( ais16) | % bar 45
    b8 r8 r4 r2 | % bar 46
    R1 | % bar 47
    r4 cis,16( ais16 gis16 fis16) d'8 d8 d8 d8 | % bar 48
    d8( cis8) cis8 cis8 c8( b8) b8 b8 | % bar 49
    b8 ais16( b16) ais16( b16) ais16( b16) cis16( d32 e32 d16) cis16 ais8. b16 | % bar 50
    b4\fermata r4 r2 | % bar 51
}
>>


mvtVsoprano = <<
\mvtVtimeline
\relative c'' {
    \autoBeamOff
    R1*5 | % bar 1
    r4 cis16[( ais16]) gis16[( fis16]) d'8 d8 d8 d8 | % bar 6
    d8 cis8 cis8 cis8 c8 b8 b8 b8 | % bar 7
    \autoBeamOn b8 \melisma ais16 b16 ais16 b16 ais16 b16 cis16 d16 e8~ e16 cis16 d16 ais16 | % bar 8
    b16 cis16 d8~ d16 cis16 d16 b16 ais32[( b32 cis16]) \autoBeamOff \melismaEnd fis,8 r4 | % bar 9
    R1*3 | % bar 10
    r4 fis'16[ d16] cis16[ b16] e8 e8 e8 e8 | % bar 13
    e8 d8 d8 d8 d8 cis8 cis16[( dis16]) cis16[( dis16]) | % bar 14
    \autoBeamOn e16 \melisma \once \set suggestAccidentals = ##t dis16 e16 fis16 e16 fis16 e16 fis16 e16 \once \set suggestAccidentals = ##t d!16 e16 cis16 d16 e16 d16 e16 | % bar 15
    d16 cis16 d16 b16 cis16 fis,16 gis16 a16 b16 a16 b16 cis16 b16 cis16 b16 cis16 | % bar 16
    b16[ gis16] \autoBeamOff \melismaEnd a8 fis'16[ dis16] c16[ b16] g'8 g8 g8 g8 | % bar 17
    g8 fis8 fis8 fis8 fis8 e8 e8 e8 | % bar 18
    \autoBeamOn e16 \melisma d16 e16 cis16 d16 e16 d16 e16 d16 cis16 d16 b16 cis16 d16 cis16 d16 | % bar 19
    c16 b16 c16 a16 b16 c16 b16 c16 a16 g16 a16 b16 a16 b16 a16 b16 | % bar 20
    a4~ a16 g16 a16 fis16 g8.\noBeam \autoBeamOff \melismaEnd a16 b16[ cis16] d16[ e16] | % bar 21
    fis8 e8 g8 fis8 e8 d16 b16 cis8. d16 | % bar 22
    d4 r4 r2 | % bar 23
    R1*3 | % bar 24
    r4 a8 a8 a8 gis16[ b16] d8 d8 | % bar 27
    d8[ cis8] c8 c8 c8 b16[( dis16]) fis8 fis8 | % bar 28
    fis16[ e16] e8 r8 e8 e8[ cis8] ais8[ fis'8] | % bar 29
    fis8[ d8] b8 b8 gis8[ b8] d8[( eis,8]) | % bar 30
    eis8 fis8 cis'8 cis8 cis8 bis16[( dis16]) fis8 fis8 | % bar 31
    fis8[( e8]) e8 d16[ cis16] fis8 b,16[ a16] gis16[( a16]) b8 | % bar 32
    b16[ a16] a8 r8 b8 fis8 c'8 b8 dis8 | % bar 33
    dis8[( e8]) e8 cis8 cis8 e8 g8 ais,8 | % bar 34
    ais8 b8 fis'16[ d16] cis16[ b16] g'8 g8 g8 g8 | % bar 35
    \autoBeamOn e16 \melisma d16 e16 fis16 e16 fis16 d16 e16 fis16 e16 fis16 g16 fis16 g16 e16 fis16 | % bar 36
    d16 cis16 d16 e16 d16 e16 cis16 d16 e16 d16 e16 fis16 e16 fis16 d16 e16 | % bar 37
    cis16 b16 cis16 d16 cis16 d16 e16 cis16 d8 \autoBeamOff \melismaEnd b8 r4 | % bar 38
    e8 b8 r8 cis16 d16 e8 a,8 r8 d16 cis16 | % bar 39
    d8 a8 r8 g'16 fis16 g8 g,8 b8 b8 | % bar 40
    e8 e8 e8 e8 \autoBeamOn e4~ \melisma e16 d16 e16 fis16 | % bar 41
    d4~ d16 fis16 e16 d16 cis16 b16 cis16 d16 cis16 d16 b16 cis16 | % bar 42
    d16 cis16 d16 e16 d16 e16 cis16 d16 e4~ e16 d16 e16 cis16 | % bar 43
    \autoBeamOff d16 \melismaEnd cis16 d16 e16 cis8.[ b16] b8 r8 r4 | % bar 44
    r8 e16 d16 cis16[ b16] ais16[ gis16] cis8. b16 \autoBeamOn ais16 \melisma gis16 fis16 e16 | % bar 45
    d16 e16 fis16 gis16 ais16 b16 cis16 d16 \autoBeamOff e16 \melismaEnd g16 fis16 b,16 ais8.[ b16] | % bar 46
    b4 r4 r2 | % bar 47
    R1*3 | % bar 48
    R1\fermata |
    \barNumberCheck # 52
}
>>

mvtVsopranoLyrics = \lyricmode {
    Wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    ist es den -- noch wohl -- ge -- tan, den -- noch wohl -- ge -- tan.

    Wer das Kreuz durch fal -- schen Wahn
    sich vor un -- er -- träg -- lich schät -- zet,
    vor un -- er -- träg -- lich,
    vor un -- er -- träg -- lich,
    wer das Kreuz durch fal -- schen Wahn
    sich vor un -- er -- träg -- lich schät -- zet,
    vor un -- er -- träg -- lich schät -- zet,
    vor un -- er -- träg -- lich schät -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    künf -- tig nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    nicht er -- göt -- zet.
}


mvtValto = <<
\mvtVtimeline
\relative c' {
    \autoBeamOff
    R1*4 | % bar 1
    r4 fis16[ d16] cis16[ b16] g'8 g8 g8 g8 | % bar 5
    g8 fis8 fis8 fis8 fis8 eis8 eis16[ fis16] eis16[ fis16] | % bar 6
    \autoBeamOn gis16 \melisma a16 b8~ b16 gis16 a16 eis16 fis16 g16 a8~ a16 fis16 g16 dis16 | % bar 7
    e2~ e16 fis16 g8~ g16 e16 fis16 cis16 | % bar 8
    d8. b16 e8. fis16 \autoBeamOff \melismaEnd fis4 r4 | % bar 9
    R1*4 | % bar 10
    r4 b16[ g16] fis16[ e16] a8 a8 a8 a8 | % bar 14
    a8 g8 g8 g8 g8 fis8 fis16[( gis16]) fis16[( gis16]) | % bar 15
    a8 e8 cis'16[ a16] gis16[ fis16] d'8 d8 d8 d8 | % bar 16
    d8 cis8 c8 c8 c8 b8 b8 b8 | % bar 17
    \autoBeamOn b8 \melisma ais16 b16 ais16 b16 ais16 b16 cis16 b16 cis16 d16 cis16 d16 cis16 d16 | % bar 18
    cis16 b16 cis16 ais16 b16 cis16 b16 cis16 b16 a16 b16 g16 a16 b16 a16 b16 | % bar 19
    a16 g16 a16 fis16 g16 a16 g16 a16 fis16 e16 fis16 g16 fis16 g16 fis16 g16 | % bar 20
    fis4~ fis16 e fis dis e8.\noBeam \autoBeamOff \melismaEnd fis16 g16[ a16] b16[ cis16] | % bar 21
    d8 cis8 b8 a8 g8 fis16 g16 e8. d16 | % bar 22
    d4 r4 r2 | % bar 23
    R1*4 | % bar 24
    r4 e8 e8 e8 dis16[( fis16]) a8 a8 | % bar 28
    a8[ g8] g8 g8 g8 fis16[ ais16] cis8 cis8 | % bar 29
    cis16[( b16]) b8 r8 b8 b8[ gis8] eis8[ cis'8] | % bar 30
    cis8[( a8]) fis8 fis8 dis8[( fis8]) a8[( bis,8]) | % bar 31
    bis8 cis8 a'8 a8 a8 gis16[ b16] d8 d8 | % bar 32
    d8[ cis8] b8 a16[ gis16] cis8 fis,16[ e16] dis16[ e16] fis8 | % bar 33
    fis16[ e16] e8 r8 e8 e8 cis8 ais8 fis'8 | % bar 34
    fis8 b,8 r4 r4 b'16[ g16] fis16[ e16] | % bar 35
    cis'8 cis8 cis8 cis8 \autoBeamOn a16 \melisma g16 a16 b16 a16 b16 g16 a16 | % bar 36
    b16 a16 b16 cis16 b16 cis16 a16 b16 g16 fis16 g16 a16 gis16 a16 fis16 gis16 | % bar 37
    ais16 gis16 ais16 b16 ais16 b16 cis16 ais16 b8 \autoBeamOff \melismaEnd fis8\noBeam b8 fis8 | % bar 38
    r8 g16 a16 b8 e,8 r8 a16 gis16 a8 e8 | % bar 39
    r8 d'16 cis16 d8 d,8 r4 d8 d8 | % bar 40
    g8 g8 g8 g8 \autoBeamOn fis8 \melisma cis'16 b16 cis8 ais8 | % bar 41
    fis8 b16 ais16 b8 cis16 b16 ais16 \once \set suggestAccidentals = ##t gis16 ais16 b16 ais16 b16 gis16 ais16 | % bar 42
    b16 ais16 b16 cis16 b16 cis16 ais16 b16 cis4~ cis16 b16 cis16 ais16 | % bar 43
    b16 \autoBeamOff \melismaEnd ais16\noBeam b16 cis16 ais8.[ b16] b8 b16 a16 g16[ fis16] e16[ dis16] | % bar 44
    g8. fis16 \autoBeamOn e16 \melisma d16 cis16 b16 fis'2~ | % bar 45
    fis16 e16 d16 e16 cis16 d16 e16 fis16 \autoBeamOff gis16 \melismaEnd ais16 b16 d,16 cis8.[ b16] | % bar 46
    b4 r4 r2 | % bar 47
    R1*3 | % bar 48
    R1\fermata |
    \barNumberCheck # 52
}
>>

mvtValtoLyrics = \lyricmode {
    Wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    wenn des Kreu -- zes Bit -- ter -- kei -- ten
    mit des Flei -- sches Schwach -- heit strei -- ten,
    ist es den -- noch wohl -- ge -- tan, den -- noch wohl -- ge -- tan.

    Wer das Kreuz durch fal -- schen Wahn
    sich vor un -- er -- träg -- lich schät -- zet,
    vor un -- er -- träg -- lich,
    vor un -- er -- träg -- lich,
    wer das Kreuz durch fal -- schen Wahn
    sich vor un -- er -- träg -- lich schät -- zet,
    vor un -- er -- träg -- lich schät -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    künf -- tig nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    nicht er -- göt -- zet,
    wird auch künf -- tig nicht er -- göt -- zet,
    nicht er -- göt -- zet.
}


mvtVbc = <<
\mvtVtimeline
\relative c {
    \clef F
    b8 r8 d8 r8 cis8 r8 b8 r8 | % bar 1
    ais8 r8 fis8 r8 b8 r8 gis8 r8 | % bar 2
    eis8 r8 fis8 r8 dis8 r8 e8 r8 | % bar 3
    cis8 r8 b'8 r8 ais8 b8 fis'8 fis,8 | % bar 4
    b8 r8 d8 r8 cis8 r8 b8 r8 | % bar 5
    ais8 r8 fis8 r8 b8 r8 gis'8 r8 | % bar 6
    eis8 r8 fis8 r8 dis8 r8 e8 r8 | % bar 7
    cis8 r8 b8 r8 ais8 r8 fis r8 | % bar 8
    b8 r8 g8 r8 fis8 r8 ais8 r8 | % bar 9
    b8 r8 b'8 r8 e,8 r8 a8 r8 | % bar 10
    cis8 r8 ais8 r8 b8 r8 fis8 r8 | % bar 11
    dis8 r8 e8 r8 d8 g16 e16 fis8 fis,8 | % bar 12
    b8 r8 d8 r8 cis8 r8 fis8 r8 | % bar 13
    b,8 r8 g8 r8 fis8 r8 b8 r8 | % bar 14
    e,8 r8 cis'8 r8 d8 r8 b8 r8 | % bar 15
    a8 r8 a8 r8 a8 r8 gis8 r8 | % bar 16
    a8 r8 dis8 r8 e8 r8 d8 r8 | % bar 17
    cis8 r8 b8 r8 ais8 r8 fis8 r8 | % bar 18
    b8 r8 d8 r8 e8 r8 a,8 r8 | % bar 19
    d8 r8 g,8 r8 a r8 fis r8 | % bar 20
    dis8 r8 b'8 r8 e8 r8 e,8 r8 | % bar 21
    r16 b'16( cis16 d16) e16( fis16 g16 a16 b16) cis16 d16 g,16 a8 a,8 | % bar 22
    d8 r8 fis8 r8 g8 r8 e8 r8 | % bar 23
    cis8 r8 a8 r8 d8 r8 b8 r8 | % bar 24
    gis8 r8 a8 r8 fis8 r8 g8 r8 | % bar 25
    e'8 r8 d8 r8 cis8 d8 a'8 a,8 | % bar 26
    d8 r8 cis8 r8 b8 r8 e8 r8 | % bar 27
    a,8 r8 fis8 r8 b8 r8 dis,8 r8 | % bar 28
    e8 r8 cis'8 r8 fis8 r8 fis,8 r8 | % bar 29
    b8 r8 gis8 r8 cis8 r8 cis,8 r8 | % bar 30
    fis8 r8 dis'8 r8 gis8 r8 gis,8 r8 | % bar 31
    cis8 r8 fis8 r8 dis8 r8 e8 r8 | % bar 32
    a,8 r8 gis8 r8 ais8 r8 b8 r8 | % bar 33
    e,8 r8 cis'8 r8 fis8 r8 fis,8 r8 | % bar 34
    b8 r8 d8 r8 e8 r8 e,8 r8 | % bar 35
    a8 r8 a'8 r8 d,8 r8 d,8 r8 | % bar 36
    g8 r8 g'8 r8 e8 r8 cis8 r8 | % bar 37
    fis8 r8 fis,8 r8 b8 r8 b'8 r8 | % bar 38
    e,8 r8 e,8 r8 a8 r8 a'8 r8 | % bar 39
    d,8 r8 d,8 r8 g8 r8 g'8 r8 | % bar 40
    e8 r8 cis8 r8 fis8 r8 fis,8 r8 | % bar 41
    fis'8 r8 fis,8 r8 fis'8 r8 fis,8 r8 | % bar 42
    fis'8 r8 fis,8 r8 fis'8 r8 fis,8 r8 | % bar 43
    b8[ e] fis fis, b8 r8 b'8 r8 | % bar 44
    e,8 r8 e,8 r8 e'8 r8 ais,8 r8 | % bar 45
    b8 r8 g'8 r8 cis,8 d16 e16 fis8 fis,8 | % bar 46
    b8 r8 d8 r8 cis8 r8 b8 r8 | % bar 47
    ais8 r8 fis8 r8 b8 r8 gis8 r8 | % bar 48
    eis8 r8 fis8 r8 dis8 r8 e8 r8 | % bar 49
    cis8 r8 b'8 r8 ais8 b8 fis'8 fis, | % bar 50
    b4\fermata r4 r2 | % bar 51
}
>>

mvtVfigs = <<
\mvtVtimeline
\figuremode {
}
>>
