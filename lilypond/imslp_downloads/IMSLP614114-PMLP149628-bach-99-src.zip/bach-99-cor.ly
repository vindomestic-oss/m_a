\version "2.21.0"

\include "bach-99-1.ily"
\include "bach-99-3.ily"
\include "bach-99-5.ily"
\include "bach-99-6.ily"

instrument = "Corno in C"
pInstr = "(Corno)"

\header {
    instrument = "Corno in C"
}

\include "bach-99-title.ily"
% \include "bach-paged-title.ily"


\paper {
    % ragged-last-bottom = ##f
}


% %{

\addQuote mvtIvlnI { \keepWithTag #'( PARTS cIC ) \mvtIvlnI }
\addQuote mvtIob   { \keepWithTag #'( PARTS cIC ) \mvtIob }
\addQuote mvtIfl   { \keepWithTag #'( PARTS cIC ) \mvtIfl }

mvtIcues = <<
\mvtItimeline
{
    \transposition c
    <>^"Violino I" \cueDuring #"mvtIvlnI" #UP { s8 | s1 } |%1
    s1*14 | %15
    s2..
    <>^"Oboe d’Amore" \cueDuring #"mvtIob" #UP { s8 | s1*3 s2 }
        <>^\pInstr
        s2 | %20
    s1*30 | %50
    s2..
    <>^\markup\center-align{Flauto} \cueDuring #"mvtIfl" #UP { s8 | s1*3 s2 }
        <>^\pInstr
        s2 | %55
}
>>

\score {
    \keepWithTag #'( PARTS cIC ) <<
        \new Staff \with {
        } \context Bottom <<
            \mvtIsop
            % { s8 | s1*90 | \pageBreak }
            \mvtIcues
        >>
    >>

    \header {
	piece = \mvtIpiece
    }
}
% %}


\markup\Tacet{\mvtIIpiece \endash \mvtIIIpiece}
\markup\Tacet{\mvtIVpiece \endash \mvtVpiece}


% %{
\score {
    \new Staff = mvtVIsopr <<
	\new Voice = mvtVIinstr \mvtVIsopr
        { s4 | s1*3 | s2. \break }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyrics
        }
        \new Lyrics \with {
            \override LyricText.font-size = #-0.5
        } \lyricsto mvtVIinstr {
            \mvtVIlyricsII
        }
    >>

   \header {
	piece = \mvtVIpiece
	% breakbefore = ##t
    }
}
% %}
