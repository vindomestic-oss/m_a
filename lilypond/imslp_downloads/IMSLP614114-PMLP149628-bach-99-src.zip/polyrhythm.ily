\version "2.21.0"

%
% This file can be included both at top-level and within \score blocks
%

% required to include "common-defs.ily"

\layout {
    \includeOnce "polyrhythm-settings.ily"
}
