\version "2.21.0"

mvtIItimeline = {
    \time 4/4
    \key g \major

    s1*11 |
    s2
	% \once \override Score.RehearsalMark.self-alignment-X = #LEFT
        #(ly:expect-warning "conflict with event: `tempo-change-event'")
        #(ly:expect-warning "discarding event: `tempo-change-event'")
	\tempo \markup{(a tempo)}
	s2 |
    s1*3 |
    \bar "|."
}


mvtIIbasso = <<
\mvtIItimeline
{
    \clef F
    \autoBeamOff

    r8 fis8 b8 ais8 b8 fis8 d8 fis8 | % bar 1
    b,4 r8 b,8 fis8 fis8 fis8 g8 | % bar 2
    a8 a8 r16 a16 a16 fis16 dis8. dis16 dis8 e8 | % bar 3
    fis16 a,16 a,16 b,16 c8 b,8 g4 r8 b8 | % bar 4
    e8 e8 e8 fis8 g8 a8 b8 e8 | % bar 5
    cis'8 cis'8 r8 e8 cis8 e8 g8 fis8 | % bar 6
    d4 r8 d8 a8 a8 c'8 b8 | % bar 7
    b8 b8 r8 b8 e'8 b8 gis16 b16 d'16 cis'16 | % bar 8
    cis'8 r16 cis'16 b8 a16[( gis16]) eis4\trill r8 gis8 | % bar 9
    cis8 fis8 eis8 b16[( a16]) fis8 fis8 r4 | % bar 10
    r8 cis'8 cis'8 a8 fis8 gis8 a8 fis8 | % bar 11
    dis8 dis16 a16 c'8 b8 \autoBeamOn b4~ \melisma b16 ais16 b16 cis'16 | % bar 12
    fis4~ fis16 e16 fis16 g16 b,8 cis16 d16 e16 fis16 gis16 ais16 | % bar 13
    b16 ais16 b16 cis'16 d8 cis16 b,16 \melismaEnd b,4 r4 | % bar 14
    R1 |
}
>>

mvtIIbassLyrics = \new Lyrics \lyricmode {
    Sein Wort der Wahr -- heit ste -- het fest
    und wird mich nicht be -- trü -- gen,
    weil es die Gläu -- bi -- gen nicht fal -- len noch ver -- der -- ben läßt.
    Ja, weil is mich den Weg zum Le -- ben füh -- ret,
    so faßt mein Her -- ze sich
    und läs -- set sich be -- gnü -- gen
    an Got -- tes Va -- ter -- treu und Huld,
    und hat Ge -- duld,
    wenn mich ein Un -- fall rüh -- ret.
    Gott kann mit sei -- nen All -- machts -- hän -- den
    mein Un -- glück wen -- den.
}

mvtIIbc = <<
\mvtIItimeline
{
    \clef F

    b,1~ | % bar 1
    b,1~ | % bar 2
    b,1~ | % bar 3
    b,2 e2~ | % bar 4
    e1~ | % bar 5
    e1 | % bar 6
    fis1 | % bar 7
    g2 gis2 | % bar 8
    a4 d4 gis,2 | % bar 9
    a,4 d4 r4 cis4 | % bar 10
    fis1~ | % bar 11
    fis2 g16 e16 fis16 g16 cis8 b,8 | % bar 12
    ais,16 ais16 b16 cis'16 fis8 e8 d4~ d16 d16 e16 fis16 | % bar 13
    g,8 e,8 fis,8 fis8 b16 g16 a16 b16 e16 cis16 d16 e16 | % bar 14
    ais,8 b,8 fis8 fis,8 b,2 | % bar 15
   
}
>>

mvtIIfigs = <<
\mvtIItimeline
\figuremode {
    s1 |
    s1 |
    <7 _+>1 |
    s1*12 |
}
>>


\addQuote mvtIIbc       { \mvtIIbc }
