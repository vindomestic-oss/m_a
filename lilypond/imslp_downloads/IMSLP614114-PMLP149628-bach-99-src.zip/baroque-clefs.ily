\version "2.21.0"

clefSoprano  = \clef soprano
clefMezzo    = \clef mezzosoprano
clefAlto     = \clef alto
clefTenor    = \clef tenor
clefBaritone = \clef baritone

clefFrench   = \clef french
clefObDAm    = \clef treble
transpObDAm  = c
clefObDaC    = \clef alto
transpObDaC  = c
clefTaille   = \clef alto
transpTaille = c
