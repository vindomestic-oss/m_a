\version "2.21.0"

\include "common.ily"

mvtIVtimeline = {
    \time 4/4
    \key g \major

    s1*11 \bar "||"
    #(ly:expect-warning "conflict with event: `tempo-change-event'")
    #(ly:expect-warning "discarding event: `tempo-change-event'")
    \tempo \markup{(a tempo.)}
    s1*3
    \bar "|."
}


mvtIVbreaksNBA = <<
\mvtIVtimeline
{
    <>^"NBA breaks left in"
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 2 { s1\noBreak | } \break\noPageBreak
    \repeat unfold 4 { s1\noBreak | } \break\noPageBreak
    \barNumberCheck # 15
}
>>


mvtIValto = <<
\mvtIVtimeline
{
    \autoBeamOff
    r8 cis''8 e'8 fis'8 g'8. g'16 g'16 e'16 cis'16 fis'16 | % bar 1
    d'4 r8 b'8 g'8 fis'8 e'8 d'8 | % bar 2
    b4 r4 r8 fis'8 fis'8 d'8 | % bar 3
    a'16 a'16 a'16 fis'16 dis'8\trill b'8 g'8 g'8 r8 b'8 | % bar 4
    g'8 e'8 d''8 r16 g'16 e'8 e'8 fis'8 g'8 | % bar 5
    g'8 d'8 r8 d'8 g'8 g'8 g'8 a'8 | % bar 6
    b'8 b'8 r8 g'8 b'8 c''8 d''8 b'8 | % bar 7
    gis'8 gis'8 r8 b'8 e'8. fis'16 gis'16 gis'16 a'16 b'16 | % bar 8
    c''4 r8 c''8 fis'8 fis'8 a'8 fis'8 | % bar 9
    dis'8 dis'8 r8 fis'8 b'16 b'16 gis'16 e'16 d''8 cis''8 | % bar 10
    cis''4 r8 a'8 d''8 a'8 fis'8 e'16[ d'16] | % bar 11
    b'8 e'8 \autoBeamOn a'4~ \melisma a'16 d''16 cis''16 d''16 g'4~ | % bar 12
    g'16 fis'16 b'16 a'16 fis'8 e'16 d'16 \melismaEnd \autoBeamOn d'4 r4 | % bar 13
    R1\fermata |
    \barNumberCheck # 15
}
>>

mvtIVlyrics = \new Lyrics \lyricmode {
    Nun, der von E -- wig -- keit ge -- schloß -- ne Bund
    bleibt mei -- nes Glau -- bens Grund.
    Er spricht mit Zu -- ver -- sicht
    im Tod und Le -- ben:
    Gott ist mein Licht,
    ihm will ich mich er -- ge -- ben.
    Und ha -- ben al -- le Ta -- ge
    gleich ih -- re eig -- ne Pla -- ge,
    doch auf das ü -- ber -- stand -- ne Leid,
    wenn man ge -- nug ge -- wei -- net,
    kömmt end -- lich die Er -- ret -- tungs -- zeit,
    da Got -- tes treu -- er Sinn er -- schei -- net.
}


mvtIVbc = <<
\mvtIVtimeline
{
    \clef F

    ais,1 | % bar 1
    b,4 d4 e4 g4 | % bar 2
    r4 fis4 b,2 | % bar 3
    fis,2 e,2~ | % bar 4
    e,4 b,4 c2 | % bar 5
    d4 g,4~ g,2~ | % bar 6
    g,1 | % bar 7
    d1 | % bar 8
    dis1 | % bar 9
    a,2 gis,2 | % bar 10
    g,2 fis,2 | % bar 11
    g,4~ g,16 cis16 d16 e16 fis,4~ fis,16 fis16 e16 d16 | % bar 12
    cis8[ d8] a8 a,8 d8 b,8 g,8 a,8 | % bar 13
    \onceCenterNoteColumn #0 d,1\fermata | % bar 14
    \barNumberCheck # 15
}
>>

mvtIVfigs = <<
\mvtIVtimeline
\figuremode {
}
>>

\addQuote mvtIVbc       { \mvtIVbc }
